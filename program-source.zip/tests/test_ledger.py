import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from fission.ledger import append, backfill, read_graph, report


class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.ledger = self.root / 'ledger.jsonl'

    def test_live_execution_and_backfill_deduplicate_but_cache_requests_remain(self):
        self.assertTrue(append({'event_id':'live','type':'generation','prompt_id':'one'}, self.ledger))
        self.assertFalse(append({'event_id':'history:one','type':'generation','prompt_id':'one'}, self.ledger))
        self.assertTrue(append({'event_id':'reuse','type':'generation','prompt_id':'one','cache_hit':True}, self.ledger))
        self.assertFalse(append({'event_id':'reuse','type':'generation','prompt_id':'one','cache_hit':True}, self.ledger))
        self.assertEqual(2, len(self.ledger.read_text().splitlines()))

    def test_report_counts_backend_executions_separately_from_hits_and_export(self):
        common = {'time':'2026-11-02T02:00:00+00:00','task':'product','model':'flux1-fill-dev-Q6_K.gguf','cache_key':'key'}
        append(dict(common,event_id='first',type='generation',stage='food',gpu_seconds=3600),self.ledger)
        append(dict(common,event_id='hit',type='generation',stage='food',cache_hit=True),self.ledger)
        append(dict(common,event_id='export',type='cpu',stage='export',cache_hit=True,cpu_seconds=2),self.ledger)
        data = report('2026-11-01T20:00:00-04:00',self.ledger)
        self.assertEqual(1,data['total']['generations'])
        self.assertEqual(2,data['total']['generation_requests'])
        self.assertEqual(1,data['total']['gpu_hours'])
        self.assertEqual(0.6667,data['total']['cache_hit_rate'])
        self.assertEqual(1,data['tasks']['product / export']['cache_hit_rate'])

    def test_backfill_ignores_reused_measurements_and_is_idempotent(self):
        graph = {'1':{'class_type':'UnetLoaderGGUF','inputs':{'unet_name':'flux-2-klein-4b.gguf'}}}
        for name, reused in [('original',False),('copy',False),('reused',True)]:
            directory = self.root / 'work/logs' / name
            directory.mkdir(parents=True)
            (directory/'measurements.json').write_text(json.dumps({'prompt_id':'one','start_time':1793577600,'wall_seconds':12,'backend_wall_seconds':10,'status':'success','cache_hit':reused}))
            (directory/'submission.json').write_text(json.dumps({'request':{'prompt':graph}}))
        fake_index = {'indexed':[],'indexed_runs':0,'unique_keys':0,'unindexed_runs':1}
        with patch('fission.cache.GenerationCache.index_historical', return_value=fake_index) as index:
            result=backfill(self.root,self.ledger)
            second=backfill(self.root,self.ledger)
        self.assertEqual(2,index.call_count)
        self.assertEqual(1,result['inserted'])
        self.assertEqual(0,second['inserted'])
        self.assertEqual(1,result['cache_measurements_skipped'])
        entries=[json.loads(line) for line in self.ledger.read_text().splitlines()]
        self.assertEqual(10,entries[0]['gpu_seconds'])
        self.assertIsNone(entries[0]['cache_key'])

    def test_empty_receipt_falls_back_to_history_and_unknown_is_not_cpu(self):
        directory=self.root/'work/logs/example'
        directory.mkdir(parents=True)
        (directory/'submission.json').write_text('{}')
        graph={'1':{'class_type':'SaveImage','inputs':{}}}
        (directory/'history.json').write_text(json.dumps({'prompt':[0,'one',graph]}))
        self.assertEqual(graph,read_graph(directory))
        (directory/'history.json').write_text('{}')
        (directory/'measurements.json').write_text(json.dumps({'prompt_id':'one','start_time':1793577600,'wall_seconds':12}))
        fake_index={'indexed':[],'indexed_runs':0,'unique_keys':0,'unindexed_runs':1}
        with patch('fission.cache.GenerationCache.index_historical',return_value=fake_index):
            result=backfill(self.root,self.ledger)
        self.assertEqual(1,result['unknown_graphs'])
        entry=json.loads(self.ledger.read_text())
        self.assertEqual('unknown',entry['type'])
        self.assertEqual(0,entry['cpu_seconds'])


if __name__ == '__main__':
    unittest.main()
