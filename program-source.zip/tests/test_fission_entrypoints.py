"""Guard regressions at the archive/CPU boundary; no backend or delivered images touched."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from fission.__main__ import execute_script, main

ROOT = Path(__file__).resolve().parents[1]


class EntryPointTests(unittest.TestCase):
    def test_help_does_not_execute_historical_eager_script(self):
        with tempfile.TemporaryDirectory() as folder:
            marker = Path(folder) / 'side_effect'
            script = Path(folder) / 'old.py'
            script.write_text('from pathlib import Path\nPath(' + repr(str(marker)) + ').write_text("changed")\n')
            with contextlib.redirect_stdout(io.StringIO()):
                execute_script(script, ['--help'])
            self.assertFalse(marker.exists())

    def test_export_rejects_direct_and_transitive_comfy_adapters(self):
        for name in ('run_hd_replica_export', 'run_multishop_export', 'run_multishop_export_batch'):
            with self.subTest(name=name), patch('sys.argv', ['fission', 'export', '--legacy', name, '--', '--help']), patch('fission.__main__.execute_script') as run, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as error:
                    main()
                self.assertEqual(error.exception.code, 2)
                run.assert_not_called()

    def test_archive_mapping_is_complete_and_sources_remain(self):
        mapping = json.loads((ROOT / 'fission/legacy_map.json').read_text())
        self.assertEqual(mapping['scripts_before'] - mapping['scripts_after'], len(mapping['entries']))
        for entry in mapping['entries']:
            self.assertTrue((ROOT / entry['archive_path']).is_file())
            self.assertFalse((ROOT / 'scripts' / entry['script']).exists())
            if entry['stage'] in ('layout', 'export') and entry['legacy']:
                self.assertFalse(entry['contains_submission'])


if __name__ == '__main__':
    unittest.main()
