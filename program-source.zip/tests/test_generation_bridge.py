import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from fission import bridge
from fission.cache import GenerationCache, GenerationPendingError
from fission.runtime import execution


class FakeClient:
    def __init__(self):
        self.posts = 0
        self.downloads = 0
        self.timeout = False

    def _submit_uncached(self, api, ui, record):
        self.posts += 1
        self.api = api
        Path(record).parent.mkdir(parents=True, exist_ok=True)
        Path(record).write_text(json.dumps({'status': 'queued', 'prompt_id': 'mock-prompt', 'request': {'prompt': api}}))
        return 'mock-prompt'

    def _reconcile_uncached(self, record):
        data = json.loads(Path(record).read_text())
        self.api = data['request']['prompt']
        return data['prompt_id']

    def _wait_uncached(self, prompt_id, logdir, pid, timeout):
        if self.timeout:
            raise TimeoutError('fixture timeout')
        return {'prompt': [0, prompt_id, self.api], 'status': {'status_str': 'success'}, 'outputs': {}}, {'prompt_id': prompt_id, 'status': 'success', 'wall_seconds': 12, 'backend_wall_seconds': 10}

    def _download_uncached(self, result, out):
        self.downloads += 1
        out = Path(out)
        out.mkdir(parents=True, exist_ok=True)
        path = out / 'result.png'
        path.write_bytes(b'generated pixels')
        return {'3': [str(path)]}


class GenerationBridgeTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        (self.root / 'models/unet').mkdir(parents=True)
        (self.root / 'models/unet/a.gguf').write_bytes(b'model')
        (self.root / 'input').mkdir()
        (self.root / 'input/photo.png').write_bytes(b'input')
        self.cache = GenerationCache(self.root / 'cache', [self.root / 'input'], [self.root / 'models'])
        self.api = {'1': {'class_type':'UnetLoaderGGUF', 'inputs': {'unet_name': 'a.gguf'}},
                    '2': {'class_type':'LoadImage', 'inputs': {'image':'photo.png'}},
                    '3': {'class_type':'SaveImage', 'inputs': {'images':['2',0], 'filename_prefix':'prefix'}}}
        self.events = []
        patcher = patch('fission.bridge.GenerationCache', return_value=self.cache)
        patcher.start()
        self.addCleanup(patcher.stop)
        patcher = patch('fission.bridge.append', side_effect=self.events.append)
        patcher.start()
        self.addCleanup(patcher.stop)
        token = execution.set({'task':'fixture', 'stage':'food'})
        self.addCleanup(execution.reset, token)

    def finish(self, client, prompt, location):
        history, metrics = bridge.wait(client, prompt, self.root / location, 0, 0)
        return bridge.download(client, history, self.root / location / 'downloads')

    def test_miss_posts_once_and_next_hit_never_posts_or_downloads(self):
        first = FakeClient()
        prompt = bridge.submit(first, self.api, {}, self.root / 'first/submission.json')
        files = self.finish(first, prompt, 'first')
        second = FakeClient()
        prompt = bridge.submit(second, self.api, {}, self.root / 'second/submission.json')
        reused = self.finish(second, prompt, 'second')
        self.assertEqual((1, 0, 0), (first.posts, second.posts, second.downloads))
        self.assertEqual(Path(files['3'][0]).read_bytes(), Path(reused['3'][0]).read_bytes())
        self.assertTrue(Path(reused['3'][0]).is_relative_to((self.root / 'second').resolve()))
        self.assertTrue(self.events[-1]['cache_hit'])
        self.assertEqual(0, self.events[-1]['gpu_seconds'])
        self.assertIsNone(second._cache_state)

    def test_timeout_preserves_pending_and_reconcile_finishes_without_post(self):
        first = FakeClient()
        receipt = self.root / 'first/submission.json'
        prompt = bridge.submit(first, self.api, {}, receipt)
        first.timeout = True
        with self.assertRaises(TimeoutError):
            self.finish(first, prompt, 'first')
        self.assertIsNone(first._cache_state)
        other = FakeClient()
        with self.assertRaises(GenerationPendingError):
            bridge.submit(other, self.api, {}, self.root / 'second/submission.json')
        self.assertEqual(0, other.posts)
        resumed = FakeClient()
        prompt = bridge.reconcile(resumed, receipt)
        self.finish(resumed, prompt, 'first')
        self.assertEqual(0, resumed.posts)
        self.assertTrue(self.cache.lookup(self.cache.identity(self.api)['key']))
        self.assertEqual('success', self.events[-1]['status'])

    def test_reconciling_completed_receipt_does_not_leave_a_pending_reservation(self):
        client = FakeClient()
        receipt = self.root / 'original/submission.json'
        prompt = bridge.submit(client, self.api, {}, receipt)
        self.finish(client, prompt, 'original')
        resumed = FakeClient()
        prompt = bridge.reconcile(resumed, receipt)
        self.finish(resumed, prompt, 'original')
        key = self.cache.identity(self.api)['key']
        pending = json.loads((self.cache.root / 'pending' / (key + '.json')).read_text())
        self.assertEqual('completed', pending['status'])

    def test_force_requires_reason_and_records_rework(self):
        first = FakeClient()
        prompt = bridge.submit(first, self.api, {}, self.root / 'first/submission.json')
        self.finish(first, prompt, 'first')
        token = execution.set({'task':'fixture','stage':'food','force_regenerate':True})
        try:
            with self.assertRaises(ValueError):
                bridge.submit(FakeClient(), self.api, {}, self.root / 'second/submission.json')
            execution.set({'task':'fixture','stage':'food','force_regenerate':True,'reason':'root requested fixture rerun'})
            second = FakeClient()
            prompt = bridge.submit(second, self.api, {}, self.root / 'second/submission.json')
            self.finish(second, prompt, 'second')
            self.assertEqual(1, second.posts)
            self.assertTrue(self.events[-1]['rework'])
            self.assertEqual('root requested fixture rerun', self.events[-1]['reason'])
        finally:
            execution.reset(token)

    def test_direct_entry_and_export_scope_do_not_submit(self):
        for scope in (None, {'task':'fixture','stage':'export'}):
            token = execution.set(scope)
            try:
                client = FakeClient()
                with self.assertRaises(RuntimeError):
                    bridge.submit(client, self.api, {}, self.root / 'invalid/submission.json')
                self.assertEqual(0, client.posts)
            finally:
                execution.reset(token)


if __name__ == '__main__':
    unittest.main()
