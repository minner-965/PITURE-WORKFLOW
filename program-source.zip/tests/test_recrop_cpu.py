"""CPU crops preserve source evidence and reject tampered exports, without a backend."""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts/fission'))
sys.path.insert(0, str(ROOT / 'scripts'))
import recrop_native_multishop as recrop


class CpuRecropTests(unittest.TestCase):
    def test_export_reuse_and_tamper_detection_without_backend(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder).resolve()
            (root / 'fission/runs').mkdir(parents=True)
            source = root / 'native'
            source.mkdir()
            original = {'id': 'A01', 'shop': 'A', 'sku': 'fixture'}
            (source / 'identity.json').write_text(json.dumps(original))
            for name in ('workflow.api.json', 'workflow.ui.json', 'submission.json', 'history.json'):
                (source / name).write_text('{}')
            Image.new('RGB', (32, 32), (120, 45, 230)).save(source / 'result.png')
            original_result = {'prompt_id': 'original-generation', 'outputs': {'result.png': recrop.fingerprint(source / 'result.png')}}
            identity = {
                'schema_version': 2, 'method': 'pillow_crop_lanczos', 'stage': 'recrop', **original,
                'version': 'cpu01', 'source_directory': str(source),
                'source_identity': recrop.fingerprint(source / 'identity.json'),
                'source_generation': {'prompt_id': 'original-generation', **{key: recrop.fingerprint(source / filename)
                    for key, filename in (('workflow_api', 'workflow.api.json'), ('workflow_ui', 'workflow.ui.json'),
                                          ('submission', 'submission.json'), ('history', 'history.json'))}},
                'files': [recrop.fingerprint(source / 'result.png')], 'reference_loaders': ['1'],
                'crop_xywh': [4, 4, 24, 24], 'output_size': [800, 800], 'image_operations': 'CPU crop',
            }
            out = source / 'crops/cpu01'
            with patch('fission.ledger.LEDGER', root / 'ledger.jsonl'), patch.object(recrop, 'ROOT', root), patch.object(recrop, 'source_data', return_value=(source, original, original_result)):
                result = recrop.run((out, identity, {}, {}), False)
                self.assertEqual(result['status'], 'exported_pending_visual_review')
                self.assertIsNone(recrop.verify_recrop(out)['prompt_id'])
                self.assertFalse((out / 'submission.json').exists())
                self.assertEqual(recrop.run((out, identity, {}, {}), False)['status'], 'verified_existing')
                Image.new('RGB', (800, 800), 'red').save(out / 'result_800.png')
                with self.assertRaisesRegex(ValueError, 'checksum'):
                    recrop.verify_recrop(out)


if __name__ == '__main__':
    unittest.main()
