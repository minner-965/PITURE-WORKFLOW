"""Unchanged Klein graph builder shared by the food and reference adapters."""
from pathlib import Path
from scripts.build_workflows import node

MODEL_SPECS={'unet':('UnetLoaderGGUF','unet_name','flux-2-klein-4b-Q5_K_M.gguf',Path('/Users/luohuiwu/ComfyUI-Shared/models/unet/flux-2-klein-4b-Q5_K_M.gguf'),'58c01c75fee2272eadb127f53e26dd05a5a8e7f812e37c36fa44603301f91e54'),'clip':('CLIPLoaderGGUF','clip_name','Qwen3-4B-Q4_K_M.gguf',Path('/Users/luohuiwu/ComfyUI-Shared/models/text_encoders/Qwen3-4B-Q4_K_M.gguf'),'f6f851777709861056efcdad3af01da38b31223a3ba26e61a4f8bf3a2195813a'),'vae':('VAELoader','vae_name','flux2-vae.safetensors',Path('/Users/luohuiwu/ComfyUI-Shared/models/vae/flux2-vae.safetensors'),'868fe7b343cc8f3a19dbcfcafbc3d5f888802be3f89bd81b65b3621a066ce8f3')}

def graph(c,rev):
 n=node;return {
 '1':n('LoadImage','REFERENCE_1_LAYOUT',image='PENDING_UPLOAD_REF1.png'),'2':n('LoadImage','REFERENCE_2_PRODUCT',image='PENDING_UPLOAD_REF2.png'),
 '3':n('UnetLoaderGGUF','KLEIN_4B_Q5',unet_name=MODEL_SPECS['unet'][2]),'4':n('CLIPLoaderGGUF','QWEN3_4B_Q4',clip_name=MODEL_SPECS['clip'][2],type='flux2'),'5':n('VAELoader','FLUX2_VAE',vae_name=MODEL_SPECS['vae'][2]),
 '6':n('ImageScale','SCALE_REF1',image=['1',0],upscale_method='lanczos',width=c['width'],height=c['height'],crop='disabled'),'7':n('ImageScale','SCALE_REF2',image=['2',0],upscale_method='lanczos',width=c['reference_size'],height=c['reference_size'],crop='disabled'),
 '8':n('CLIPTextEncode','POSITIVE',clip=['4',0],text=c['prompt']),'9':n('ConditioningZeroOut','NEGATIVE',conditioning=['8',0]),'10':n('VAEEncode','ENCODE_REF1',pixels=['6',0],vae=['5',0]),'11':n('VAEEncode','ENCODE_REF2',pixels=['7',0],vae=['5',0]),
 '12':n('ReferenceLatent','POS_REF1',conditioning=['8',0],latent=['10',0]),'13':n('ReferenceLatent','NEG_REF1',conditioning=['9',0],latent=['10',0]),'14':n('ReferenceLatent','POS_REF2',conditioning=['12',0],latent=['11',0]),'15':n('ReferenceLatent','NEG_REF2',conditioning=['13',0],latent=['11',0]),
 '16':n('CFGGuider','GUIDER',model=['3',0],positive=['14',0],negative=['15',0],cfg=1.0),'17':n('EmptyFlux2LatentImage','LATENT',width=c['width'],height=c['height'],batch_size=1),'18':n('Flux2Scheduler','SCHEDULER',steps=4,width=c['width'],height=c['height']),
 '19':n('RandomNoise','SEED',noise_seed=c['seed']),'20':n('KSamplerSelect','SAMPLER',sampler_name='euler'),'21':n('SamplerCustomAdvanced','SAMPLE',noise=['19',0],guider=['16',0],sampler=['20',0],sigmas=['18',0],latent_image=['17',0]),'22':n('VAEDecode','DECODE',samples=['21',0],vae=['5',0]),'23':n('SaveImage','SAVE',images=['22',0],filename_prefix=f'ComfyProductPipeline/taobao_klein/{c["job_id"]}/{rev}')}
