#!/usr/bin/env python3
"""Render one square shop photo with a photo-bound graphic from verified SKU copy."""
import argparse
import hashlib
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps

ART = 1600
FONT = "/System/Library/Fonts/STHeiti Medium.ttc"
TEXT_POSITIONS = ("top", "bottom")
DESIGNS = {
    "A": ("reverse-banner", "shelf-tabs"),
    "B": ("menu-ledger", "counter-card"),
    "C": ("editorial-strip", "window-label"),
}


def resolve_design(style, design_key=None):
    if style not in DESIGNS:
        raise ValueError(f"Unknown style: {style}")
    choices = DESIGNS[style]
    if design_key is None:
        return "default"
    key = design_key.strip()
    if key == "default":
        return "default"
    if not key:
        raise ValueError("Design key must contain a shop ID or a design name")
    if key in choices:
        return key
    if any(key in names for names in DESIGNS.values()):
        raise ValueError(f"{key} does not belong to family {style}")
    # A shop ID chooses the same layout across products and across processes.
    index = int.from_bytes(hashlib.sha256(key.encode("utf-8")).digest()[:4], "big")
    return choices[index % len(choices)]


from fission.ledger import tracked_cpu

@tracked_cpu('layout')
def render(source, style, copy, output, size=800, design_key=None, text_position="bottom"):
    if text_position not in TEXT_POSITIONS:
        raise ValueError("text_position must be top or bottom")
    title = copy["title"].strip()
    benefits = copy["benefits"]
    sub = copy.get("subline", "").strip()
    if not title or not 1 <= len(benefits) <= 3 or not all(isinstance(v, str) and v.strip() for v in benefits):
        raise ValueError("Supply a title and one to three verified short benefits")
    with Image.open(source) as photo:
        photo = ImageOps.exif_transpose(photo)
        if photo.width != photo.height:
            raise ValueError("A reviewed square crop is required")
        stage = photo.convert("RGBA").resize((ART, ART), Image.Resampling.LANCZOS)
    overlay = Image.new("RGBA", stage.size)
    pen = ImageDraw.Draw(overlay)

    def point(box):
        return tuple(round(v * 2) for v in box)

    def roundbox(box, radius, color):
        pen.rounded_rectangle(point(box), radius=radius*2, fill=color)

    def line(box, color, width=1):
        pen.line(point(box), fill=color, width=2*width)

    def label(value, x, y, width, height, color, font_size, bold=False, center=False):
        if not value:
            return
        for pts in range(font_size, 13, -1):
            font = ImageFont.truetype(FONT, 2*pts)
            stroke = 1 if bold else 0
            a,b,c,d = pen.textbbox((0,0), value, font=font, stroke_width=stroke)
            if c-a <= 2*width and d-b <= 2*height:
                left = 2*x + ((2*width-c+a)/2 if center else 0)
                pen.text((left-a, 2*y + (2*height-d+b)/2-b), value, font=font, fill=color,
                         stroke_width=stroke, stroke_fill=color)
                return
        raise ValueError("Copy will not fit at readable size: "+value)

    n = len(benefits)
    design = resolve_design(style, design_key)
    def benefit_cells(left, right):
        width = (right - left) / n
        for i, value in enumerate(benefits):
            yield left + i * width, width, value

    if text_position == "top" and design == "default":
        # Place a compact heading on the reserved upper edge. The title, benefits and
        # optional subline all come from the same verified copy as the lower graphic.
        panel, foreground, tag, tag_ink = {
            "A": ("#33271E", "#FFF8EA", "#F5AE54", "#402615"),
            "B": ("#21503B", "#FFF7DF", "#E5EBCF", "#244A37"),
            "C": ("#E7F4F5", "#17495E", "#B8DCE4", "#164859"),
        }[style]
        roundbox((17, 16, 783, 112), 10, panel)
        label(title, 36, 23 if sub else 37, 332, 50, foreground, 38, True)
        if sub:
            roundbox((35, 78, 373, 104), 5, tag)
            label(sub, 41, 79, 326, 23, tag_ink, 17, False, True)
        for x, width, value in benefit_cells(389, 771):
            line((x, 42, x, 89), tag)
            label(value, x + 6, 39, width - 12, 50, foreground, 22, True, True)
    elif design == "reverse-banner":
        # Services read first on a brick strip. A diagonal joins the headline on the right.
        pen.rectangle(point((0,701,800,800)),fill="#773223")
        pen.polygon([point(p) for p in [(393,701),(800,701),(800,800),(349,800)]],fill="#FFF0D3")
        for x,width,value in benefit_cells(12,348):
            line((x+7,725,x+width-8,725),"#E4AA6B",2)
            label(value,x+4,735,width-8,46,"#FFF9EE",22,True,True)
        label(title,408,710 if sub else 720,374,44,"#4E241B",36,True)
        label(sub,410,758,365,27,"#61382B",17)
    elif design == "shelf-tabs":
        # Separate service tabs project above the bottom shelf.
        for x,width,value in benefit_cells(25,775):
            roundbox((x+4,691,x+width-4,739),7,"#F6CA83")
            label(value,x+10,693,width-20,36,"#412615",22,True,True)
        pen.rectangle(point((0,731,800,800)),fill="#302520")
        line((0,733,800,733),"#F2AD55",3)
        label(title,24,742,309,46,"#FFF4E5",36,True)
        if sub:
            line((340,750,340,780),"#A58261",2)
            label(sub,355,745,425,42,"#F5D6AA",21,False,True)
    elif design == "menu-ledger":
        # A ruled, numbered menu on the right and a dark binder spine.
        roundbox((20,689,780,789),4,"#F8F1DD")
        pen.rectangle(point((20,689,35,789)),fill="#28523F")
        label(title,52,699 if sub else 711,303,49,"#244534",36,True)
        label(sub,52,753,313,25,"#5A5A44",16)
        for i,value in enumerate(benefits):
            y=694+i*(88/n)
            line((391,y,758,y),"#A8AA90")
            label(f"{i+1:02}",391,y+2,42,88/n-4,"#626F52",17,True,True)
            label(value,451,y+2,301,88/n-4,"#233F32",23,True)
    elif design == "counter-card":
        # A centered shop sign and a separate row of dark service panels.
        roundbox((54,691,746,792),10,"#FFF4DA")
        heading_width = 300 if sub else 553
        label(title,124,698,heading_width,43,"#4D3324",32,True,True)
        if sub:
            line((426,707,426,732),"#B48155")
            label(sub,443,704,255,34,"#6F4B33",16,False,True)
        line((76,744,724,744),"#BD9D75")
        for x,width,value in benefit_cells(70,730):
            roundbox((x+5,751,x+width-5,784),4,"#305640")
            label(value,x+9,752,width-18,29,"#FFFAED",21,True,True)
    elif design == "editorial-strip":
        # Announcement at left with a separate feature list on the right.
        pen.rectangle(point((0,704,800,800)),fill="#E6F3F2")
        pen.rectangle(point((0,704,800,712)),fill="#23637B")
        label(title,24,722 if sub else 736,354,41,"#164B5E",34,True)
        label(sub,25,766,349,22,"#315F69",16)
        for x,width,value in benefit_cells(399,788):
            line((x,729,x,781),"#73A9B1",2)
            label(value,x+4,736,width-8,39,"#164D61",23,True,True)
    elif design == "window-label":
        # Two detached shop-window decals expose the scene between them.
        roundbox((18,691,477,786),15,"#173D57")
        line((39,710,78,710),"#A3D7DD",3)
        label(title,37,718 if sub else 721,422,42,"#FFFFFF",36,True)
        label(sub,39,759,416,22,"#D7F0EF",16)
        for i,value in enumerate(benefits):
            top=691+i*(96/n)
            roundbox((501,top,780,top+96/n-4),10,"#E9F7F6")
            label(value,511,top+1,259,96/n-7,"#14516B",22,True,True)
    elif style == "A":
        # Full-bleed merchant ribbon. The curve joins the service rail.
        pen.rectangle(point((0,714,800,800)),fill="#201B17")
        path=[(0,689),(324,689)]
        for i in range(1,33):
            t=i/32; u=1-t
            path.append((u**3*324+3*u*u*t*378+3*u*t*t*387+t**3*411,
                         u**3*689+3*u*u*t*689+3*u*t*t*758+t**3*800))
        pen.polygon([point(p) for p in path+[(0,800)]],fill="#F26B13")
        if sub: label(sub,23,699,319,23,"#2B180F",18,True)
        label(title,22,726 if sub else 711,339,61,"#FFFFFF",43,True)
        for i,value in enumerate(benefits):
            x=412+i*(378/n)
            if i: line((x,735,x,779),"#987B63")
            if 3<len(value)<=6 and n==3:
                split=len(value)-2
                label(value[:split],x+4,724,378/n-8,31,"#FFFFFF",24,True,True)
                label(value[split:],x+4,754,378/n-8,32,"#FFF4E5",24,False,True)
            else: label(value,x+4,736,378/n-8,43,"#FFFFFF",24,True,True)
    elif style == "B":
        # Breakfast shop menu ticket, with a flat green tab tucked behind the paper.
        roundbox((18,688,782,784),7,"#164634")
        roundbox((25,694,775,777),4,"#FBF4DE")
        pen.rectangle(point((25,694,37,777)),fill="#BF7D3E")
        label(title,52,700,290,52,"#214A37",38,True)
        label(sub,53,750,291,23,"#485547",17)
        line((358,707,358,764),"#BDAE86")
        for i,value in enumerate(benefits):
            x=370+i*(390/n)
            label(value,x,720,390/n-6,39,"#234934",23,True,True)
            line((x+390/n*.39,760,x+390/n*.61,760),"#AC7951",2)
    elif style == "C":
        # Staggered headline tab and a narrow translucent services rail.
        roundbox((19,701,431,770),30,"#175676")
        label(title,40,707,370,52,"#FFFFFF",38,True)
        if sub:
            roundbox((430,718,781,762),22,"#E5F4F6")
            label(sub,441,724,329,30,"#18495E",18,False,True)
        left=20
        for i,value in enumerate(benefits):
            width=244 if n==3 else 740/n
            roundbox((left,764,left+width,794),15,"#F2FCFA")
            label(value,left+4,765,width-8,26,"#19556A",19,True,True)
            left+=width+11
    else:
        raise ValueError("Unknown style: "+style)
    if text_position == "top" and design != "default":
        # Preserve the selected design without moving, flipping or cropping the photo.
        left, top, right, bottom = overlay.getchannel("A").getbbox()
        graphic = overlay.crop((left, top, right, bottom))
        overlay = Image.new("RGBA", stage.size)
        overlay.paste(graphic, (left, 32))
    out = Image.alpha_composite(stage,overlay).convert("RGB").resize((size,size),Image.Resampling.LANCZOS)
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    out.save(output,quality=96,subsampling=0)


if __name__ == "__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--image",required=True);cli.add_argument("--style",choices=DESIGNS,required=True)
    cli.add_argument("--copy",type=Path,required=True);cli.add_argument("--out",required=True)
    cli.add_argument("--size",type=int,default=800)
    cli.add_argument("--design-key",help="Shop ID for a stable layout, or a specific family design")
    cli.add_argument("--text-position", choices=TEXT_POSITIONS, default="bottom")
    args=cli.parse_args()
    render(args.image,args.style,json.loads(args.copy.read_text()),args.out,args.size,args.design_key,args.text_position)
