"""Cache boundary used by the shared Comfy client before any prompt POST."""
import json
import shutil
from pathlib import Path
import time
import uuid

from .cache import GenerationCache, GenerationPendingError, CacheIntegrityError, validate_force, sha256
from .ledger import append, graph_fields
from .runtime import generation_options


def save(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2))
    temporary.replace(path)


def _state(client, cache, identity, options, record, api, ui, force, reason):
    if getattr(client, '_cache_state', None):
        raise RuntimeError('Finish or resume the current client operation first')
    lock = cache.lock(identity['key'])
    lock.__enter__()
    state = dict(cache=cache, identity=identity, lock=lock, options=options,
                 record=Path(record), api=api, ui=ui, force=force, reason=reason,
                 event_id=str(uuid.uuid4()), start=time.time())
    client._cache_state = state
    return state


def _close(client):
    state = getattr(client, '_cache_state', None)
    if state:
        state['lock'].__exit__(None, None, None)
        client._cache_state = None


def _pending_path(state):
    return state['cache'].root / 'pending' / (state['identity']['key'] + '.json')


def _receipt(state, status=None):
    path = state['record']
    data = json.loads(path.read_text()) if path.is_file() else {}
    data.update(cache_key=state['identity']['key'], force_regenerate=state['force'], reason=state['reason'],
                event_id=state['event_id'], fission_options=state['options'])
    if status:
        data['status'] = status
    save(path, data)


def _event(state, *, status='success', error=None, files=None, definite=False):
    metrics, options, identity = state.get('metrics', {}), state['options'], state['identity']
    gpu = metrics.get('backend_wall_seconds', metrics.get('wall_seconds', 0)) or 0
    is_generation = status == 'success' or definite
    event_id = state['event_id'] if is_generation else state['event_id'] + ':' + status + ':' + uuid.uuid4().hex
    append(dict(event_id=event_id, type='generation' if is_generation else 'event',
                task=options['task'], stage=options['stage'], **graph_fields(state['api']),
                prompt_id=state.get('prompt_id'), cache_key=identity['key'], input_hashes=identity['input_hashes'],
                cache_hit=bool(state.get('hit')), reused_from=(state.get('hit') or {}).get('source'),
                gpu_seconds=gpu if is_generation else 0,
                wait_seconds=max(0, metrics.get('wall_seconds', 0)-gpu) if is_generation else 0,
                result_paths=[p for paths in (files or {}).values() for p in paths], root_review='pending',
                rework=state['force'] and is_generation, reason=state['reason'], status=status, error=error))


def submit(client, api, ui, record):
    options = generation_options()
    force, reason = options.get('force_regenerate', False), options.get('reason')
    validate_force(force, reason)
    cache = GenerationCache()
    identity = cache.identity(api)
    if not graph_fields(api)['model']:
        raise ValueError('图像合成和导出请使用 fission layout/export 的 CPU 流程')
    state = _state(client, cache, identity, options, record, api, ui, force, reason)
    try:
        try:
            hit = cache.lookup(identity['key'])
        except CacheIntegrityError:
            if not force:
                raise
            hit = None
        if hit and not force:
            state.update(hit=hit, prompt_id=hit['prompt_id'])
            save(record, dict(status='cache_hit', prompt_id=hit['prompt_id'], cache_key=identity['key'],
                              reused_from=hit.get('source') or hit['prompt_id'], event_id=state['event_id'],
                              fission_options=options, force_regenerate=False,
                              request={'prompt':api, 'extra_data':{'extra_pnginfo':{'workflow':ui}}}))
            print('命中缓存 ' + identity['key'] + ' reused_from=' + str(hit.get('source') or hit['prompt_id']), flush=True)
            return hit['prompt_id']
        pending = cache.reserve(identity, source=Path(record).resolve(), force_regenerate=force, reason=reason)
        pending.update(event_id=state['event_id'], options=options)
        save(_pending_path(state), pending)
        prompt_id = client._submit_uncached(api, ui, record)
        state['prompt_id'] = prompt_id
        _receipt(state)
        cache.mark_pending(identity['key'], prompt_id=prompt_id)
        return prompt_id
    except BaseException as error:
        # A network timeout leaves the durable intent unresolved; only a definite
        # backend rejection can release that reservation for explicit retry.
        try:
            if Path(record).is_file():
                data = json.loads(Path(record).read_text())
                if data.get('status') == 'rejected' and _pending_path(state).is_file():
                    cache.mark_pending(identity['key'], status='failed_confirmed')
                _receipt(state)
            _event(state, status='submission_error', error=str(error))
        finally:
            _close(client)
        raise


def reconcile(client, record):
    """Resume the exact receipt after a restart without submitting anything."""
    options = generation_options()
    record = Path(record)
    data = json.loads(record.read_text())
    api = data['request']['prompt']
    ui = data['request'].get('extra_data', {}).get('extra_pnginfo', {}).get('workflow', {})
    cache = GenerationCache()
    identity = cache.identity(api)
    if data.get('cache_key') and data['cache_key'] != identity['key']:
        raise ValueError('Generation inputs changed since the original receipt')
    state = _state(client, cache, identity, data.get('fission_options', options), record, api, ui,
                   data.get('force_regenerate', False), data.get('reason'))
    try:
        pending_path = _pending_path(state)
        pending = json.loads(pending_path.read_text()) if pending_path.exists() else None
        if pending and pending.get('source') != str(record.resolve()) and pending.get('status') != 'completed':
            raise GenerationPendingError('Resume the original receipt: ' + str(pending.get('source')))
        if pending and pending.get('source') == str(record.resolve()):
            state.update(force=pending.get('force_regenerate', False), reason=pending.get('reason'),
                         event_id=pending.get('event_id', data.get('event_id', state['event_id'])),
                         options=pending.get('options', state['options']))
        else:
            state['event_id'] = data.get('event_id', state['event_id'])
        if data.get('status') == 'cache_hit':
            hit = cache.lookup(identity['key'])
            if not hit or hit['prompt_id'] != data.get('prompt_id'):
                raise ValueError('Cached receipt no longer identifies the selected generation')
            state['hit'] = hit
            prompt_id = hit['prompt_id']
        else:
            prompt_id = client._reconcile_uncached(record)
            if pending is None:
                cache.reserve(identity, source=record.resolve(), force_regenerate=state['force'], reason=state['reason'])
            cache.mark_pending(identity['key'], prompt_id=prompt_id)
        state['prompt_id'] = prompt_id
        _receipt(state)
        return prompt_id
    except BaseException as error:
        try:
            _event(state, status='reconcile_error', error=str(error))
        finally:
            _close(client)
        raise


def wait(client, prompt_id, logdir, pid, timeout):
    state = getattr(client, '_cache_state', None)
    if not state:
        raise RuntimeError('Use submit or reconcile before waiting so the generation is recorded')
    try:
        if prompt_id != state.get('prompt_id'):
            raise ValueError('Prompt ID differs from the active cached operation')
        if state.get('hit'):
            hit = state['hit']
            history = hit.get('history')
            if not history:
                raise ValueError('缓存缺少历史回执')
            metrics = dict(prompt_id=prompt_id, status='success', wall_seconds=0,
                           backend_wall_seconds=0, cache_hit=True, reused_from=hit.get('source'))
            save(Path(logdir)/'history.json', history)
            save(Path(logdir)/'measurements.json', metrics)
        else:
            history, metrics = client._wait_uncached(prompt_id, logdir, pid, timeout)
        state.update(history=history, metrics=metrics)
        return history, metrics
    except BaseException as error:
        try:
            measurement = Path(logdir) / 'measurements.json'
            if measurement.is_file():
                metrics = json.loads(measurement.read_text())
                if metrics.get('prompt_id') == prompt_id:
                    state['metrics'] = metrics
            definite = state.get('metrics', {}).get('status') in ('error', 'failed', 'interrupted')
            if definite and not state.get('hit'):
                state['cache'].mark_pending(state['identity']['key'], status='failed_confirmed')
            _event(state, status='failed' if definite else 'wait_interrupted', error=str(error), definite=definite)
        finally:
            _close(client)
        raise


def download(client, result, out):
    state = getattr(client, '_cache_state', None)
    if not state:
        raise RuntimeError('Use submit or reconcile before downloading so the generation is recorded')
    try:
        if 'metrics' not in state:
            raise RuntimeError('Wait for the active generation before downloading')
        if state.get('hit'):
            hit = state['cache'].lookup(state['identity']['key'])
            target_dir = Path(out)
            target_dir.mkdir(parents=True, exist_ok=True)
            files = {}
            for node, paths in hit['files'].items():
                for original in paths:
                    source = Path(original)
                    destination = target_dir / source.name
                    expected = hit['output_hashes'][original]
                    if destination.exists():
                        if sha256(destination) != expected:
                            raise CacheIntegrityError('Existing reused-output destination differs: ' + str(destination))
                    elif source.resolve() != destination.resolve():
                        with source.open('rb') as src, destination.open('xb') as dst:
                            shutil.copyfileobj(src, dst, 1024 * 1024)
                    if sha256(destination) != expected:
                        raise CacheIntegrityError('Copied cached output changed: ' + str(destination))
                    files.setdefault(node, []).append(str(destination.resolve()))
        else:
            files = client._download_uncached(result, out)
            entry = state['cache'].register(state['identity'], files, prompt_id=state['prompt_id'],
                                    history=result, source=str(state['record'].resolve()), measurements=state['metrics'],
                                    force_regenerate=state['force'], reason=state['reason'])
            files = entry['files']
        _event(state, files=files)
        return files
    except BaseException as error:
        _event(state, status='download_error', error=str(error))
        raise
    finally:
        _close(client)


def equivalent_graph(left, right):
    if left == right:
        return True
    cache = GenerationCache()
    return cache.identity(left)['key'] == cache.identity(right)['key']
