"""Read an existing verified generation and export locally. No backend client."""
import json
from pathlib import Path
import shutil

from .cache import GenerationCache, sha256
from .ledger import record_cpu


def export_existing(source_run, output, node=None, config=None):
    cache = GenerationCache()
    entry = cache.import_run(Path(source_run))
    entry = cache.lookup(entry['cache_key'])
    files = entry['files']
    if node is None:
        if len(files) != 1: raise ValueError('多个输出节点，请指定 --node')
        node = next(iter(files))
    if node not in files or len(files[node]) != 1:
        raise ValueError('选择一个仅含一张图片的输出节点')
    source, target = Path(files[node][0]), Path(output).resolve()
    if target.exists(): raise FileExistsError('目标已存在，请使用新的导出路径：' + str(target))
    print('命中缓存 ' + entry['cache_key'] + ' reused_from=' + str(entry.get('source')), flush=True)
    with record_cpu(Path(source_run).name, 'export', cache_key=entry['cache_key'], cache_hit=True,
                    reused_from=entry.get('source'), input_hashes={str(source):sha256(source)}) as record:
        target.parent.mkdir(parents=True, exist_ok=True)
        if config:
            from PIL import Image, ImageOps
            cfg = json.loads(Path(config).read_text())
            project = Path(__file__).resolve().parents[1]
            def resolve(value):
                path = Path(value).expanduser()
                return path if path.is_absolute() else project / path
            reference = resolve(cfg['reference'])
            mask_path = resolve(cfg['generated_mask'])
            if cfg.get('generated') and sha256(resolve(cfg['generated'])) != sha256(source):
                raise ValueError('配置中的已选生成图与缓存源图不同')
            record['input_hashes'].update({str(reference):sha256(reference), str(mask_path):sha256(mask_path)})
            with Image.open(reference) as image:
                result = ImageOps.exif_transpose(image).convert('RGB')
            with Image.open(source) as image:
                generated = image.convert('RGB').resize(result.size, Image.Resampling.LANCZOS)
            with Image.open(mask_path) as image:
                mask = image.convert('RGB').getchannel('R').resize(result.size, Image.Resampling.NEAREST)
            result = Image.composite(generated, result, mask)
            width = int(cfg['output_width'])
            result = result.resize((width, round(result.height*width/result.width)), Image.Resampling.LANCZOS)
            with target.open('xb') as stream: result.save(stream, format='PNG')
        else:
            with source.open('rb') as src, target.open('xb') as dst: shutil.copyfileobj(src, dst)
            if sha256(source) != sha256(target): raise ValueError('导出字节校验异常')
        record.update(result_paths=[str(target)], root_review='pending')
    return dict(status='exported_pending_review', cache_key=entry['cache_key'], reused_from=entry.get('source'),
                output=str(target), sha256=sha256(target))
