"""Process-local execution scope; only the unified CLI opens generation access."""
from contextvars import ContextVar

execution = ContextVar('fission_execution', default=None)


def generation_options():
    value = execution.get()
    if not value or value['stage'] not in {'master', 'scene', 'food', 'multishop'}:
        raise RuntimeError('请从 python3 -m fission 的生成子命令进入；排版和导出只读取已有结果')
    return value
