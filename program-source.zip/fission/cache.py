"""Content-addressed Comfy generation cache. This module never contacts ComfyUI.

Only successful, hash-verified outputs are reusable. An unfinished submission
reservation is durable: process failure must not silently turn into a rerun.
"""
from __future__ import annotations

import copy
import fcntl
import hashlib
import json
import os
import re
import time
import uuid
from contextlib import contextmanager
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODEL_KEYS = {
    'unet_name': ('unet', 'diffusion_models'),
    'ckpt_name': ('checkpoints',),
    'vae_name': ('vae',),
    'clip_name': ('text_encoders', 'clip'),
    'clip_name1': ('text_encoders', 'clip'),
    'clip_name2': ('text_encoders', 'clip'),
    'clip_name3': ('text_encoders', 'clip'),
    'lora_name': ('loras',),
    'control_net_name': ('controlnet',),
    'model_name': ('upscale_models', 'diffusion_models', 'unet', 'checkpoints'),
}
MODEL_SUFFIXES = {'.gguf', '.safetensors', '.ckpt', '.pt', '.pth', '.bin'}
IMAGE_KEYS = {'image', 'mask', 'image_path', 'mask_path'}


class CacheIntegrityError(RuntimeError):
    """Existing evidence changed; require explicit repair instead of a new job."""


class GenerationPendingError(RuntimeError):
    """A prior submission needs reconciliation before any new submission."""


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def _json_bytes(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')


def _write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    with temp.open('xb') as stream:
        stream.write(_json_bytes(value) + b'\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)


def validate_force(force_regenerate=False, reason=None):
    if force_regenerate and (not isinstance(reason, str) or not reason.strip()):
        raise ValueError('--force-regenerate requires a nonblank root-approved reason')
    if reason and not force_regenerate:
        raise ValueError('A regeneration reason requires --force-regenerate')
    return reason.strip() if reason else None


def _default_roots():
    inputs = [Path.home() / 'ComfyUI-Shared/input']
    models = [Path.home() / 'ComfyUI-Shared/models']
    config = ROOT / 'config/environment.json'
    if config.is_file():
        source = Path(json.loads(config.read_text())['source'])
        inputs.append(source / 'input')
        models.append(source / 'models')
    return inputs, models


class GenerationCache:
    def __init__(self, root=None, input_roots=None, model_roots=None):
        self.root = Path(root) if root else ROOT / 'fission/runs/cache'
        default_inputs, default_models = _default_roots()
        self.input_roots = [Path(p) for p in (input_roots if input_roots is not None else default_inputs)]
        self.model_roots = [Path(p) for p in (model_roots if model_roots is not None else default_models)]
        self._model_hashes = {}

    @staticmethod
    def _key(key):
        if not isinstance(key, str) or not re.fullmatch(r'[0-9a-f]{64}', key):
            raise ValueError('Expected a SHA-256 cache key')
        return key

    @contextmanager
    def lock(self, key):
        """Serialize lookup/reserve/register transactions for the same identity."""
        key = self._key(key)
        lock = self.root / 'locks' / (key + '.lock')
        lock.parent.mkdir(parents=True, exist_ok=True)
        with lock.open('a') as stream:
            fcntl.flock(stream, fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(stream, fcntl.LOCK_UN)

    def _resolve_image(self, value, overrides, slot):
        override = overrides.get(slot, overrides.get(value))
        if override is not None:
            return Path(override).expanduser().resolve(strict=True)
        # Comfy accepts an optional directory annotation on loaded image names.
        value = re.sub(r' \[(input|output|temp)\]$', '', value)
        path = Path(value).expanduser()
        candidates = [path] if path.is_absolute() else [root / path for root in self.input_roots]
        for candidate in candidates:
            if candidate.is_file():
                return candidate.resolve()
        raise FileNotFoundError(f'Input for {slot} is missing: {value}; provide input_paths override')

    def _resolve_model(self, value, input_name, overrides, slot):
        override = overrides.get(slot, overrides.get(value))
        if override is not None:
            return Path(override).expanduser().resolve(strict=True)
        path = Path(value).expanduser()
        candidates = [path] if path.is_absolute() else []
        for root in self.model_roots:
            candidates.extend(root / folder / path for folder in MODEL_KEYS.get(input_name, ()))
            candidates.append(root / path)
        for candidate in candidates:
            if candidate.is_file():
                return candidate.resolve()
        # Unknown custom loaders still identify model files by their bytes.
        matches = {p.resolve() for root in self.model_roots if root.is_dir() for p in root.rglob(path.name) if p.is_file()}
        if len(matches) == 1:
            return matches.pop()
        raise FileNotFoundError(f'Model for {slot} is missing or ambiguous: {value}; provide model_paths override')

    def _model_hash(self, path):
        stat = path.stat()
        signature = (str(path), stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)
        if signature in self._model_hashes:
            return self._model_hashes[signature]
        # Persist verified hash+stat so repeated CLI invocations do not reread GBs.
        location_key = hashlib.sha256(str(path).encode()).hexdigest()
        memo = self.root / 'model_hashes' / (location_key + '.json')
        if memo.is_file():
            record = json.loads(memo.read_text())
            if record.get('signature') == list(signature):
                self._model_hashes[signature] = record['sha256']
                return record['sha256']
        digest = sha256(path)
        after = path.stat()
        if (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns) != signature[1:]:
            raise CacheIntegrityError(f'Model changed while hashing: {path}')
        _write_json(memo, {'signature': signature, 'sha256': digest})
        self._model_hashes[signature] = digest
        return digest

    def identity(self, api, input_paths=None, model_paths=None):
        """Hash the exact graph, replacing model/image locations with byte hashes.

        Overrides use either ``node_id.input_name`` or the API filename as key.
        UI titles/positions and SaveImage filename_prefix are non-generative.
        Every other API input (including prompts, seeds, steps, sizes) is kept.
        """
        if not isinstance(api, dict) or not api:
            raise ValueError('A nonempty Comfy API workflow is required')
        canonical = copy.deepcopy(api)
        models, inputs = {}, {}
        parameters = {'prompts': {}, 'seeds': {}, 'steps': {}, 'dimensions': {}}
        for node_id, node in canonical.items():
            node.pop('_meta', None)
            node.pop('is_changed', None)
            cls = node.get('class_type', '')
            for name, value in list(node.get('inputs', {}).items()):
                slot = str(node_id) + '.' + name
                if name == 'filename_prefix':
                    del node['inputs'][name]
                    continue
                if isinstance(value, str) and ((name in MODEL_KEYS and value not in ('', 'none', 'None', 'auto')) or Path(value).suffix.lower() in MODEL_SUFFIXES):
                    path = self._resolve_model(value, name, model_paths or {}, slot)
                    digest = self._model_hash(path)
                    models[slot] = {'path': str(path), 'sha256': digest, 'filename': path.name}
                    node['inputs'][name] = {'file_sha256': digest}
                elif isinstance(value, str) and (name in IMAGE_KEYS or ('LoadImage' in cls and name == 'filename')):
                    path = self._resolve_image(value, input_paths or {}, slot)
                    digest = sha256(path)
                    inputs[slot] = {'path': str(path), 'sha256': digest}
                    node['inputs'][name] = {'file_sha256': digest}
                if name in ('text', 'prompt', 'positive', 'negative') and isinstance(value, str):
                    parameters['prompts'][slot] = value
                elif name in ('seed', 'noise_seed'):
                    parameters['seeds'][slot] = value
                elif name == 'steps':
                    parameters['steps'][slot] = value
                elif name in ('width', 'height'):
                    parameters['dimensions'][slot] = value
        payload = {'schema': 1, 'api': canonical}
        return {'key': hashlib.sha256(_json_bytes(payload)).hexdigest(), 'schema': 1,
                'canonical_api': canonical, 'models': models, 'input_hashes': inputs, 'parameters': parameters}

    def lookup(self, key):
        path = self.root / 'entries' / (self._key(key) + '.json')
        if not path.is_file():
            return None
        entry = json.loads(path.read_text())
        if entry.get('cache_key') != key:
            raise CacheIntegrityError('Cache entry identity mismatch: ' + str(path))
        files = entry.get('files', {})
        if not files or not any(files.values()):
            raise CacheIntegrityError('Cache entry has no output files: ' + str(path))
        for paths in files.values():
            for filename in paths:
                if not Path(filename).is_file() or sha256(filename) != entry['output_hashes'].get(filename):
                    raise CacheIntegrityError('Cached output changed or is missing: ' + filename)
        return entry

    def reserve(self, identity, *, source=None, force_regenerate=False, reason=None):
        """Call under lock, after lookup. Never discard an unresolved submission."""
        reason = validate_force(force_regenerate, reason)
        key = identity['key']
        path = self.root / 'pending' / (self._key(key) + '.json')
        if path.is_file():
            pending = json.loads(path.read_text())
            if pending.get('status') not in ('completed', 'failed_confirmed'):
                raise GenerationPendingError('Existing submission requires reconciliation: ' + str(path))
        record = {'cache_key': key, 'status': 'submitting', 'source': str(source) if source else None,
                  'created_at': time.time(), 'force_regenerate': bool(force_regenerate), 'reason': reason}
        _write_json(path, record)
        return record

    def mark_pending(self, key, *, prompt_id=None, status='queued'):
        path = self.root / 'pending' / (self._key(key) + '.json')
        record = json.loads(path.read_text())
        record.update(status=status)
        if prompt_id is not None:
            record['prompt_id'] = prompt_id
        _write_json(path, record)
        return record

    def register(self, identity, files, *, prompt_id, history=None, source=None, measurements=None,
                 root_review=None, force_regenerate=False, reason=None):
        """Record existing files without copying or changing delivered artifacts.

        The caller holds lock(key) for live completions. Historical imports can
        also call this method under lock; all writes use atomic replacement.
        """
        reason = validate_force(force_regenerate, reason)
        key = self._key(identity['key'])
        normalized = {str(node): [str(Path(p).resolve(strict=True)) for p in paths] for node, paths in files.items()}
        if not normalized or not any(normalized.values()):
            raise ValueError('At least one completed output is required')
        entry = {'schema': 1, 'cache_key': key, 'identity': identity, 'files': normalized,
                 'output_hashes': {p: sha256(p) for paths in normalized.values() for p in paths},
                 'prompt_id': prompt_id, 'history': history, 'measurements': measurements,
                 'source': str(source) if source else None, 'root_review': root_review,
                 'registered_at': time.time(), 'force_regenerate': bool(force_regenerate), 'reason': reason}
        path = self.root / 'entries' / (key + '.json')
        if path.is_file():
            previous = json.loads(path.read_text())
            # Keep the original generation available when registering a duplicate.
            if not force_regenerate:
                self.lookup(key)
                pending = self.root / 'pending' / (key + '.json')
                if pending.is_file() and json.loads(pending.read_text()).get('prompt_id') == prompt_id:
                    self.mark_pending(key, prompt_id=prompt_id, status='completed')
                return previous
            archive = self.root / 'entry_history' / (key + '.' + uuid.uuid4().hex + '.json')
            _write_json(archive, previous)
        _write_json(path, entry)
        pending = self.root / 'pending' / (key + '.json')
        if pending.is_file() and json.loads(pending.read_text()).get('prompt_id') == prompt_id:
            self.mark_pending(key, prompt_id=prompt_id, status='completed')
        return entry

    def import_run(self, directory):
        """Index a completed historical run using its recorded hashes as evidence.

        This deliberately fails closed when historical model/input provenance is
        incomplete; report that run as unindexed instead of claiming cache proof.
        All historical files are read-only. New metadata lives in this cache.
        """
        directory = Path(directory).resolve(strict=True)
        history_path = directory / 'history.json'
        history = json.loads(history_path.read_text())
        if history.get('status', {}).get('status_str') != 'success':
            raise ValueError('Historical run is not a completed success: ' + str(directory))
        api_path = directory / 'actual.api.json'
        api = json.loads(api_path.read_text()) if api_path.is_file() else history['prompt'][2]
        identity_path = directory / 'identity.json'
        evidence = json.loads(identity_path.read_text()) if identity_path.is_file() else {}
        result_path = directory / 'result.json'
        result = json.loads(result_path.read_text()) if result_path.is_file() else {}
        evidence = evidence or result.get('identity', {})
        input_records = [item for item in evidence.get('inputs', {}).values() if isinstance(item, dict) and item.get('path') and item.get('sha256')]
        input_paths = {}
        for node_id, node in api.items():
            for name, value in node.get('inputs', {}).items():
                if isinstance(value, str) and name in IMAGE_KEYS:
                    matches = [item for item in input_records if Path(item['path']).name == Path(value).name]
                    if matches:
                        candidates = {str(Path(item['path']).resolve()) for item in matches if Path(item['path']).is_file() and sha256(item['path']) == item['sha256']}
                        if len(candidates) == 1:
                            input_paths[str(node_id) + '.' + name] = candidates.pop()
        current = self.identity(api, input_paths=input_paths)
        historical_nodes = history['prompt'][2]
        for slot, item in current['input_hashes'].items():
            node_id, name = slot.split('.', 1)
            changed = historical_nodes.get(node_id, {}).get('is_changed', [])
            matches = [record for record in input_records if Path(record['path']).name == Path(item['path']).name]
            recorded_hashes = {record['sha256'] for record in matches}
            if isinstance(changed, list):
                recorded_hashes.update(v for v in changed if isinstance(v, str) and re.fullmatch(r'[0-9a-f]{64}', v))
            if item['sha256'] not in recorded_hashes:
                raise CacheIntegrityError('Historical input hash absent or changed: ' + slot)
        model_records = evidence.get('models', {})
        if isinstance(model_records, dict):
            model_records = list(model_records.values())
        for slot, item in current['models'].items():
            matches = [record for record in model_records if isinstance(record, dict) and (record.get('filename') == item['filename'] or Path(record.get('path', '')).name == item['filename'])]
            hashes = {record.get('expected_sha256', record.get('sha256')) for record in matches}
            if item['sha256'] not in hashes:
                raise CacheIntegrityError('Historical model hash absent or changed: ' + slot)
        files = {}
        output_root = Path.home() / 'ComfyUI-Shared/output'
        recorded_outputs = []
        def collect_outputs(value):
            if isinstance(value, dict):
                filename = value.get('path', value.get('output_path', value.get('filename')))
                digest = value.get('sha256', value.get('output_sha256'))
                if isinstance(filename, str) and isinstance(digest, str):
                    recorded_outputs.append((filename, digest))
                for child in value.values():
                    collect_outputs(child)
            elif isinstance(value, list):
                for child in value:
                    collect_outputs(child)
        collect_outputs(result.get('outputs', {}))
        # Several historical writers store their sole result at the top level.
        for name, digest_name in [('path', 'sha256'), ('output_path', 'output_sha256'), ('filename', 'sha256')]:
            if isinstance(result.get(name), str) and isinstance(result.get(digest_name), str):
                recorded_outputs.append((result[name], result[digest_name]))
        for node_id, outputs in history.get('outputs', {}).items():
            for index, item in enumerate(outputs.get('images', [])):
                raw_name = Path(item['filename']).name
                download_name = f"{node_id}_{index}_{raw_name}"
                expected_hashes = {digest for filename, digest in recorded_outputs if Path(filename).name in (raw_name, download_name)}
                if not expected_hashes:
                    raise CacheIntegrityError('Historical output hash absent: ' + raw_name)
                candidates = [directory / 'downloads' / download_name,
                              directory / 'downloads' / raw_name,
                              output_root / item.get('subfolder', '') / item['filename']]
                candidates.extend(Path(filename) if Path(filename).is_absolute() else directory / filename
                                  for filename, digest in recorded_outputs
                                  if Path(filename).name in (raw_name, download_name))
                existing = next((p for p in candidates if p.is_file()), None)
                if existing is None:
                    raise FileNotFoundError('Historical output missing: ' + raw_name)
                if sha256(existing) not in expected_hashes:
                    raise CacheIntegrityError('Historical output hash changed: ' + str(existing))
                files.setdefault(str(node_id), []).append(existing)
        measurements_path = directory / 'measurements.json'
        measurements = json.loads(measurements_path.read_text()) if measurements_path.is_file() else result.get('measurements')
        review_path = directory / 'root_review.json'
        review = json.loads(review_path.read_text()) if review_path.is_file() else result.get('root_review')
        with self.lock(current['key']):
            return self.register(current, files, prompt_id=history['prompt'][1], history=history,
                                 source=directory, measurements=measurements, root_review=review)

    def index_historical(self, root=ROOT):
        """Index provable completed runs; keep a report of all skipped evidence."""
        root = Path(root)
        candidates = {}
        unreadable = []
        for base in ('work', 'output', 'outputs', 'fission/runs'):
            for path in sorted((root / base).rglob('measurements.json')):
                if 'integration_20261105' in path.parts or 'cache' in path.parts:
                    continue
                try:
                    measurement = json.loads(path.read_text())
                    prompt_id = measurement.get('prompt_id')
                    if prompt_id:
                        candidates.setdefault(prompt_id, []).append(path.parent)
                except (OSError, ValueError) as error:
                    unreadable.append({'path': str(path), 'reason': str(error)})
        indexed, unindexed = [], []
        for prompt_id, directories in candidates.items():
            failures = []
            for directory in directories:
                try:
                    entry = self.import_run(directory)
                    indexed.append({'prompt_id': prompt_id, 'cache_key': entry['cache_key'], 'source': str(directory)})
                    break
                except (OSError, ValueError, RuntimeError, KeyError, TypeError) as error:
                    failures.append({'source': str(directory), 'reason': str(error)})
            else:
                unindexed.append({'prompt_id': prompt_id, 'attempts': failures})
        report = {'measurement_files': sum(map(len, candidates.values())) + len(unreadable),
                  'unique_prompts': len(candidates), 'indexed_runs': len(indexed),
                  'unique_keys': len({item['cache_key'] for item in indexed}),
                  'unindexed_runs': len(unindexed), 'indexed': indexed, 'unindexed': unindexed,
                  'unreadable': unreadable}
        _write_json(self.root / 'historical_index.json', report)
        return report


def index_historical(root=ROOT):
    return GenerationCache().index_historical(root)
