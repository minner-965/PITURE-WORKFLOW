"""Explicit, isolated cache and ledger path for the A01 zero-inference diagnostic."""
import hashlib,json,subprocess,time,uuid
from pathlib import Path
from .cache import GenerationCache,sha256
from .ledger import append
from .runtime import execution

ALLOWED={'LoadImage','FissionPerspective','FissionLocalPerspective','ImageCrop','ImageScale','SaveImage'}
PHOTO_ALLOWED={'LoadImage','FissionPhotoLock','MaskToImage','SaveImage'}
BAND_ALLOWED={'LoadImage','FissionExteriorBandColor','MaskToImage','ImageCrop','ImageScale','SaveImage'}

def identity(api,node_path,source):
 types=[n['class_type'] for n in api.values()]
 if 'FissionExteriorBandColor' in types:
  if set(types)-BAND_ALLOWED or types.count('FissionExteriorBandColor')!=1:raise ValueError('Invalid exterior band graph')
  cache=GenerationCache();ident=cache.identity(api,input_paths={'1.image':source})
  node_sha=sha256(node_path);ident['node_sha256']=node_sha
  ident['key']=hashlib.sha256((ident['key']+':'+node_sha).encode()).hexdigest();return cache,ident
 if 'FissionPhotoLock' in types:
  if set(types)-PHOTO_ALLOWED or types.count('FissionPhotoLock')!=1:raise ValueError('Invalid photo-lock graph')
  cache=GenerationCache();ident=cache.identity(api,input_paths={'1.image':source})
  node_sha=sha256(node_path);ident['node_sha256']=node_sha
  ident['key']=hashlib.sha256((ident['key']+':'+node_sha).encode()).hexdigest();return cache,ident
 if set(types)-ALLOWED or types.count('FissionPerspective')+types.count('FissionLocalPerspective')>1:raise ValueError('Only deterministic perspective nodes are permitted')
 if not any(t in types for t in ('ImageCrop','FissionPerspective','FissionLocalPerspective')):raise ValueError('Missing deterministic operation')
 cache=GenerationCache();ident=cache.identity(api,input_paths={'1.image':source})
 node_sha=sha256(node_path);ident['node_sha256']=node_sha
 ident['key']=hashlib.sha256((ident['key']+':'+node_sha).encode()).hexdigest()
 return cache,ident

def run(client,api,visual,directory,node_path,source):
 scope=execution.get()
 if not scope or scope.get('stage')!='master' or scope.get('mode') not in ('perspective-warp','local-perspective','photo-lock','exterior-band'):raise RuntimeError('Use unified master entry')
 directory=Path(directory);directory.mkdir(parents=True,exist_ok=True);cache,ident=identity(api,node_path,source)
 types={n['class_type'] for n in api.values()}
 if (scope['mode']=='photo-lock') != ('FissionPhotoLock' in types) or (scope['mode']=='exterior-band') != ('FissionExteriorBandColor' in types):raise ValueError('Graph does not match execution mode')
 with cache.lock(ident['key']):
  hit=cache.lookup(ident['key'])
  if hit:
   append(dict(type='cpu',model=None,gpu_seconds=0,task='fastplate',stage='master/'+scope['mode'],cache_key=ident['key'],cache_hit=True,prompt_id=hit['prompt_id'],input_hashes=ident['input_hashes'],result_paths=[p for x in hit['files'].values() for p in x]))
   return hit,True
  receipt=directory/'submission.json'
  pending=cache.root/'pending'/(ident['key']+'.json')
  if pending.exists() and json.loads(pending.read_text()).get('status') not in ('completed','failed_confirmed'):
   reservation=json.loads(pending.read_text())
   original=Path(reservation['source'])/'submission.json'
   if not original.is_file():raise RuntimeError('Pending reservation has no receipt; manual reconciliation required')
   pid=client._reconcile_uncached(original)
  else:
   cache.reserve(ident,source=directory)
   pid=client._submit_uncached(api,visual,receipt)
  cache.mark_pending(ident['key'],prompt_id=pid)
  backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip())
  hist,metrics=client._wait_uncached(pid,directory,backend);files=client._download_uncached(hist,directory/'download')
  entry=cache.register(ident,files,prompt_id=pid,history=hist,source=directory,measurements=metrics)
  append(dict(type='cpu',model=None,gpu_seconds=0,cpu_seconds=metrics.get('backend_wall_seconds',0),task='fastplate',stage='master/'+scope['mode'],cache_key=ident['key'],cache_hit=False,prompt_id=pid,input_hashes=ident['input_hashes'],result_paths=[p for x in files.values() for p in x]))
  return entry,False
