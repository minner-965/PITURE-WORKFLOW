"""Reusable sRGB D65 CIELAB conversion, extracted without changing calculations."""
import numpy as np

def lab(rgb):
    x = rgb / 255.
    x = np.where(x <= .04045, x / 12.92, ((x + .055) / 1.055) ** 2.4)
    xyz = x @ np.array([[.4124564,.2126729,.0193339], [.3575761,.7151522,.119192], [.1804375,.0721750,.9503041]])
    xyz /= np.array([.95047, 1., 1.08883])
    f = np.where(xyz > (6/29)**3, np.cbrt(xyz), xyz / (3*(6/29)**2) + 4/29)
    return np.stack([116*f[...,1]-16, 500*(f[...,0]-f[...,1]), 200*(f[...,1]-f[...,2])], -1)
