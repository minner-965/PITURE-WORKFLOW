"""Append-only, process-safe activity ledger. Old evidence is read-only."""
from collections import defaultdict
from contextlib import contextmanager
from functools import wraps
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import time
import uuid

ROOT = Path(__file__).resolve().parents[1]
LEDGER = ROOT / 'fission/runs/ledger.jsonl'


def append(entry, path=None):
    path = Path(path or LEDGER)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = dict(time=datetime.now(timezone.utc).isoformat(), task='unknown', stage='unknown',
                type='cpu', model=None, size=None, steps=None, seed=None, input_hashes={},
                cache_key=None, cache_hit=False, gpu_seconds=0, wait_seconds=0,
                cpu_seconds=0, result_paths=[], root_review='pending', rework=False,
                event_id=str(uuid.uuid4()), status='success')
    data.update(entry)
    with path.open('a+', encoding='utf-8') as stream:
        fcntl.flock(stream, fcntl.LOCK_EX)
        stream.seek(0)
        # Stable IDs make history backfill and resumed downloads idempotent.
        previous = [json.loads(line) for line in stream if line.strip()]
        if any(item.get('event_id') == data['event_id'] for item in previous):
            return False
        # A live completion and later historical backfill describe one backend
        # execution even when their event IDs differ. Cache requests remain separate.
        if data.get('prompt_id') and not data.get('cache_hit') and data['type'] in ('generation', 'cpu', 'unknown'):
            if any(item.get('prompt_id') == data['prompt_id'] and not item.get('cache_hit')
                   and item.get('type') in ('generation', 'cpu', 'unknown') for item in previous):
                return False
        stream.write(json.dumps(data, ensure_ascii=False) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    return True


@contextmanager
def record_cpu(task, stage, **fields):
    started = time.monotonic()
    record = dict(task=task, stage=stage, type='cpu', **fields)
    try:
        yield record
    except BaseException as error:
        record.update(status='error', error=str(error))
        raise
    finally:
        record['cpu_seconds'] = time.monotonic() - started
        append(record)


def tracked_cpu(stage):
    """Instrument CPU helpers even when they are called by generation adapters."""
    def decorate(function):
        @wraps(function)
        def wrapped(*args, **kwargs):
            from .runtime import execution
            scope = execution.get() or {}
            with record_cpu(scope.get('task', function.__module__), stage):
                return function(*args, **kwargs)
        return wrapped
    return decorate


def graph_fields(graph):
    models, seeds, steps, sizes, inputs = [], [], [], [], {}
    for node_id, node in graph.items():
        values = node.get('inputs', {})
        for key, value in values.items():
            if isinstance(value, str) and (key in ('unet_name', 'ckpt_name', 'model_name', 'lora_name')):
                models.append(value)
            if key in ('seed', 'noise_seed'): seeds.append(value)
            if key == 'steps': steps.append(value)
            if key == 'image' and isinstance(value, str): inputs[node_id] = value
        if 'width' in values and 'height' in values:
            sizes.append([values['width'], values['height']])
    label = ' + '.join(dict.fromkeys(models)) or None
    return dict(model=label, seed=seeds, steps=steps, size=sizes)


def model_group(label):
    label = (label or '').lower()
    if 'klein' in label: return 'Klein'
    if 'fill' in label and 'q6' in label: return 'Fill Q6'
    if 'fill' in label: return 'Fill other'
    return label or 'CPU/image nodes'


def read_graph(directory):
    """Prefer the submitted graph; an incomplete receipt does not hide evidence."""
    directory = Path(directory)
    names = ['submission.json', 'history.json', 'actual.api.json', 'workflow.api.json', 'api.json']
    names.extend(path.name for path in sorted(directory.glob('*.api.json')) if path.name not in names)
    for name in names:
        file = directory / name
        if not file.is_file():
            continue
        try:
            data = json.loads(file.read_text())
            if name == 'submission.json':
                graph = data.get('request', {}).get('prompt', {})
            elif name == 'history.json':
                graph = data.get('prompt', [None, None, {}])[2]
            else:
                graph = data
            if isinstance(graph, dict) and graph and all(isinstance(v, dict) and 'class_type' in v for v in graph.values()):
                return graph
        except (OSError, ValueError, IndexError, TypeError):
            continue
    return {}


def _read_optional(path):
    try:
        return json.loads(Path(path).read_text())
    except (OSError, ValueError):
        return {}


def _recorded_inputs(directory):
    """Use historical recorded hashes, never current bytes as a claim about history."""
    identity = _read_optional(directory / 'identity.json')
    if not identity:
        identity = _read_optional(directory / 'result.json').get('identity', {})
    values = identity.get('inputs', identity.get('files', {}))
    items = values.items() if isinstance(values, dict) else enumerate(values) if isinstance(values, list) else []
    return {str(key): {'path': value.get('path'), 'sha256': value['sha256']}
            for key, value in items if isinstance(value, dict) and isinstance(value.get('sha256'), str)}


def _result_paths(directory):
    result = _read_optional(directory / 'result.json')
    paths = []
    def visit(value):
        if isinstance(value, dict):
            if isinstance(value.get('path'), str):
                paths.append(value['path'])
            for child in value.values():
                visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)
    visit(result.get('outputs', {}))
    for field in ('path', 'output_path', 'filename'):
        if isinstance(result.get(field), str):
            path = Path(result[field])
            paths.append(str(path if path.is_absolute() else directory / path))
    return list(dict.fromkeys(paths))


def backfill(root=ROOT, path=None):
    from .cache import GenerationCache
    root = Path(root).resolve()
    cache = GenerationCache(root / 'fission/runs/cache')
    index = cache.index_historical(root)
    indexed = {item['prompt_id']: item['cache_key'] for item in index['indexed']}
    unique = {}
    unreadable = []
    measurement_files = 0
    cache_measurements_skipped = 0
    for base in ('fission/runs', 'work', 'output', 'outputs'):
        for file in sorted((root / base).rglob('measurements.json')):
            if 'integration_20261105' in file.parts or 'cache' in file.parts:
                continue
            measurement_files += 1
            try:
                data = json.loads(file.read_text())
            except (OSError, ValueError) as error:
                unreadable.append({'path': str(file), 'reason': str(error)})
                continue
            if data.get('cache_hit') or data.get('reused_from'):
                cache_measurements_skipped += 1
                continue
            identifier = data.get('prompt_id')
            if identifier:
                unique.setdefault(identifier, []).append((file, data))
    inserted = 0
    unknown = 0
    for identifier, candidates in unique.items():
        # Prefer a duplicate that has a full submitted graph and backend timing.
        candidates.sort(key=lambda item: (bool(read_graph(item[0].parent)),
                                         item[1].get('backend_wall_seconds') is not None), reverse=True)
        file, data = candidates[0]
        graph = read_graph(file.parent)
        fields = graph_fields(graph)
        gpu = bool(fields['model'])
        kind = 'generation' if gpu else 'cpu' if graph else 'unknown'
        unknown += kind == 'unknown'
        backend = data.get('backend_wall_seconds')
        elapsed = backend if backend is not None else data.get('wall_seconds', 0)
        elapsed = elapsed or 0
        cache_key = indexed.get(identifier)
        entry_from_cache = cache.lookup(cache_key) if cache_key else None
        relative = file.relative_to(root)
        task = relative.parts[2] if relative.parts[0] in ('work', 'fission') and len(relative.parts)>2 else relative.parts[1]
        parts = set(relative.parts)
        stage = ('food' if parts & {'food','texture'} else 'scene' if parts & {'props','background'}
                 else 'multishop' if 'fastplate' in str(relative) or 'multishop' in str(relative)
                 else 'master' if gpu else 'export' if graph else 'unknown')
        review = 'passed' if data.get('visual_pass') is True else 'rejected' if data.get('visual_pass') is False else 'pending'
        entry = dict(event_id='history:'+identifier, prompt_id=identifier,
                     time=datetime.fromtimestamp(data.get('start_time', file.stat().st_mtime), timezone.utc).isoformat(),
                     task=task, stage=stage, type=kind, **fields,
                     gpu_seconds=elapsed if gpu else 0, cpu_seconds=elapsed if kind=='cpu' else 0,
                     wait_seconds=max(0, (data.get('wall_seconds', 0) or 0)-elapsed),
                     timing_source='backend_wall_seconds' if backend is not None else 'wall_seconds_estimate',
                     status=data.get('status', 'unknown'), source_measurements=str(file.resolve()),
                     result_paths=_result_paths(file.parent), root_review=review,
                     cache_key=cache_key,
                     input_hashes=entry_from_cache['identity']['input_hashes'] if entry_from_cache else _recorded_inputs(file.parent),
                     cache_hit=False, rework=False, rework_evidence='unknown_historical')
        inserted += append(entry, path)
    return dict(measurement_files=measurement_files, unique_prompts=len(unique), inserted=inserted,
                cache_measurements_skipped=cache_measurements_skipped, unknown_graphs=unknown,
                unreadable=unreadable,
                cache_index={key:index[key] for key in ('indexed_runs','unique_keys','unindexed_runs')},
                cache_index_report=str(cache.root / 'historical_index.json'))


def _timestamp(value):
    moment = datetime.fromisoformat(value)
    return moment if moment.tzinfo else moment.replace(tzinfo=timezone.utc)


def report(since=None, path=None):
    ledger = Path(path or LEDGER)
    entries = [json.loads(line) for line in ledger.read_text().splitlines() if line.strip()] if ledger.exists() else []
    if since:
        cutoff = _timestamp(since)
        entries = [e for e in entries if _timestamp(e['time']) >= cutoff]
    def summarize(values):
        requests = [e for e in values if e['type'] == 'generation']
        generations = [e for e in requests if not e.get('cache_hit')]
        cache_requests = [e for e in values if e['type']=='generation' or e.get('cache_key')]
        hits = sum(bool(e.get('cache_hit')) for e in cache_requests)
        return dict(count=len(values), generations=len(generations), generation_requests=len(requests),
                    gpu_hours=round(sum(e.get('gpu_seconds',0) or 0 for e in values)/3600,4),
                    cpu_seconds=round(sum(e.get('cpu_seconds',0) or 0 for e in values),3),
                    wait_seconds=round(sum(e.get('wait_seconds',0) or 0 for e in values),3),
                    cache_requests=len(cache_requests), cache_hits=hits,
                    cache_hit_rate=round(hits/len(cache_requests),4) if cache_requests else 0,
                    rework=sum(bool(e.get('rework')) for e in values),
                    historical_rework_unknown=sum(e.get('rework_evidence')=='unknown_historical' for e in values))
    groups, models = defaultdict(list), defaultdict(list)
    for entry in entries:
        groups[entry['task']+' / '+entry['stage']].append(entry)
        label = 'Unknown evidence' if entry['type']=='unknown' else model_group(entry['model'])
        models[label].append(entry)
    return dict(since=since, total=summarize(entries), models={k:summarize(v) for k,v in sorted(models.items())},
                tasks={k:summarize(v) for k,v in sorted(groups.items())})
