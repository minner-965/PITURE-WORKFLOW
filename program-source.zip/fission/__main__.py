"""Unified product-image entry point. Help and reports need only stdlib; plans use the existing image environment."""
import argparse
import json
import os
from pathlib import Path
import runpy
import sys

ROOT = Path(__file__).resolve().parents[1]
PYTHON = Path('/Users/luohuiwu/ComfyUI-Installs/E-commerce image workflow/ComfyUI/.venv/bin/python3')


def dependencies():
    try: import PIL, requests, numpy
    except ImportError:
        if PYTHON.exists() and Path(sys.executable) != PYTHON:
            os.execv(str(PYTHON), [str(PYTHON), '-m', 'fission', *sys.argv[1:]])
        raise RuntimeError('请使用项目现有 ComfyUI Python 环境')


def product_plan(product):
    dependencies()
    sys.path[:0] = [str(ROOT), str(ROOT / 'scripts'), str(ROOT / 'scripts/fission')]
    if product in ('快餐盘', 'fastplate', '火锅盖碗', 'gaiwan'):
        from native_multishop import load_plan, prepare, product_board, prompt_text, read, WORKFLOWS, STEMS
        file = (ROOT / 'fission/runs/gaiwan_20261105/plan.json' if product in ('火锅盖碗', 'gaiwan')
                else ROOT / 'fission/runs/fastplate_20261104/全套重做/任务计划.json')
        data, run_root, rows = load_plan(file, None)
        checks = []
        for row in rows:
            # The background branch prepares locally: no live schema, uploads or files written.
            prepared = prepare(data, row, 'background', 'v01', 'v01', run_root, {})
            product_graph = read((WORKFLOWS / STEMS['product']).with_suffix('.api.json'))
            product_files, loaders, crops, size = product_board(row, product_graph)
            prompt_text(row['product_generation'], 'positive')
            prompt_text(row['product_generation'], 'negative')
            checks.append(dict(id=row['id'], reference_files=len(prepared[1]['reference_sources']),
                               product_files=len(product_files), cfg=prepared[1]['cfg'],
                               steps=prepared[1]['steps'], seed=prepared[1]['seed']))
        return dict(product=('火锅盖碗' if product in ('火锅盖碗', 'gaiwan') else '快餐盘'), source=str(file), route='native_multishop', count=len(rows),
                    check_status='validated_locally_without_submission', checks=checks,
                    rows=[dict(id=r['id'], shop=r['shop'], sku=r['sku']) for r in rows])
    from check import check
    run = ROOT / 'fission/runs/abc_20261104'
    product_file = ROOT / 'fission/products/w1125/product.json'
    checks = check(run, product_file)
    file = run / 'menu.json'
    data = json.loads(file.read_text())
    rows = data if isinstance(data,list) else data.get('rows',data.get('menu',[]))
    return dict(product='w1125',source=str(file), route='native_dual_reference', count=len(rows),
                check_status='validated_locally_without_submission', checks=checks,
                rows=[dict(shop=r['shop'], dish_id=r['dish_id'], color=r.get('bowl_color'), name=r['name']) for r in rows])


def execute_script(path, args):
    if '--help' in args or '-h' in args:
        import ast
        tree = ast.parse(path.read_text())
        if not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'ArgumentParser' for n in ast.walk(tree)):
            print(f'{path.name}: historical task-specific adapter; no command-line arguments. Defaults and inputs remain in {path}.')
            return
    sys.path[:0] = [str(ROOT), str(ROOT/'scripts'), str(ROOT/'scripts/fission'), str(ROOT/'scripts/archive')]
    previous = sys.argv
    try:
        sys.argv = [str(path), *args]
        runpy.run_path(str(path), run_name='__main__')
    finally: sys.argv = previous


def main():
    parser = argparse.ArgumentParser(description='统一商品主图入口；--plan 只检查，layout/export 仅复用现有图片')
    sub = parser.add_subparsers(dest='command',required=True)
    for name in ('master','scene','food','multishop'):
        p=sub.add_parser(name)
        p.add_argument('--mode',choices=('local-edit','perspective-warp','local-perspective','photo-lock','photo-fill','photo-klein','photo-klein-v02','gaiwan-food','gaiwan-photo','gaiwan-assemble','gaiwan-guide','gaiwan-differential','gaiwan-remove','gaiwan-color-edit','gaiwan-regional','exterior-band'))
        p.add_argument('--plan', action='store_true')
        p.add_argument('--product', choices=('快餐盘','fastplate','w1125','火锅盖碗','gaiwan'), default='w1125')
        p.add_argument('--legacy',help='归档适配器名称（省略 .py）')
        p.add_argument('--force-regenerate',action='store_true')
        p.add_argument('--reason',help='root 明确要求重跑的原因')
        p.add_argument('args',nargs=argparse.REMAINDER)
    p=sub.add_parser('layout');p.add_argument('--legacy');p.add_argument('--mode',choices=('closeup','typography','shop-hero'),default='typography');p.add_argument('args',nargs=argparse.REMAINDER)
    p=sub.add_parser('export');p.add_argument('--legacy');p.add_argument('--source-run',type=Path);p.add_argument('--output',type=Path);p.add_argument('--node');p.add_argument('--config',type=Path)
    p.add_argument('--mode',choices=('publish','closeup','typography','recrop'));p.add_argument('args',nargs=argparse.REMAINDER)
    p=sub.add_parser('report');p.add_argument('--since');p.add_argument('--backfill',action='store_true');p.add_argument('--json',action='store_true')
    args=parser.parse_args()
    if args.command=='report':
        from .ledger import backfill,report
        if args.backfill: print(json.dumps(backfill(),ensure_ascii=False))
        data=report(args.since)
        if args.json: print(json.dumps(data,ensure_ascii=False,indent=2))
        else:
            print('范围',args.since or '全部','总记录',data['total']['count'])
            print('模型 | 次数 | GPU小时 | CPU秒 | 缓存命中 | 返工')
            for key,row in data['models'].items(): print(f"{key} | {row['count']} | {row['gpu_hours']:.3f} | {row['cpu_seconds']:.2f} | {row['cache_hits']} | {row['rework']}")
            print('任务 / 阶段 | 次数 | GPU小时 | CPU秒 | 命中率 | 返工')
            for key,row in data['tasks'].items(): print(f"{key} | {row['count']} | {row['gpu_hours']:.3f} | {row['cpu_seconds']:.2f} | {row['cache_hit_rate']:.1%} | {row['rework']}")
            print('历史返工未推测：',data['total']['historical_rework_unknown'],'条；GPU时间采用后端执行时间，缺失时使用总耗时估计。')
        return
    if getattr(args,'plan',False):
        print(json.dumps(product_plan(args.product),ensure_ascii=False,indent=2));return
    dependencies()
    from .runtime import execution
    from .cache import validate_force
    force=getattr(args,'force_regenerate',False);reason=getattr(args,'reason',None)
    validate_force(force,reason)
    execution.set(dict(stage=args.command,task=getattr(args,'product',args.command),mode=getattr(args,'mode',None),force_regenerate=force,reason=reason))
    trailing=args.args[1:] if args.args[:1]==['--'] else args.args
    if args.command in ('layout', 'export') and args.legacy:
        if Path(args.legacy).name != args.legacy: parser.error('legacy 需要脚本名称')
        name = args.legacy.removesuffix('.py')
        entries = json.loads((ROOT/'fission/legacy_map.json').read_text())['entries']
        entry = next((e for e in entries if e['script'] == name+'.py'), None)
        if not entry or not entry['legacy'] or entry['stage'] != args.command or entry['contains_submission']:
            parser.error('请按 scripts/archive/README.md 的 CPU 入口调用')
        os.environ['FISSION_ENTRYPOINT'] = '1'
        path = ROOT / entry['archive_path']
        if '--help' in trailing or '-h' in trailing:
            execute_script(path, trailing)
        else:
            from .ledger import record_cpu
            with record_cpu(name, args.command, adapter=entry['archive_path']) as record:
                execute_script(path, trailing)
        return
    if args.command=='export' and not args.mode:
        if not args.source_run or not args.output: parser.error('export 需要 --source-run 和 --output')
        from .export import export_existing
        print(json.dumps(export_existing(args.source_run,args.output,args.node,args.config),ensure_ascii=False,indent=2));return
    modes={'publish':'publish_native_multishop','closeup':'closeup_export','typography':'typography_export','recrop':'recrop_native_multishop','shop-hero':'layout_shop_hero'}
    if args.command in ('layout','export'):
        name=modes[args.mode]
        # Pure CPU modules reject generation options through their own parsers.
        execute_script((ROOT/'fission' if name=='layout_shop_hero' else ROOT/'scripts/fission')/f'{name}.py',trailing);return
    if args.command == 'master' and args.mode in ('local-edit','perspective-warp','local-perspective','photo-lock','photo-fill','photo-klein','photo-klein-v02','gaiwan-food','gaiwan-photo','gaiwan-assemble','gaiwan-guide','gaiwan-differential','gaiwan-remove','gaiwan-color-edit','gaiwan-regional','exterior-band'):
        script = {'local-edit':'native_local_edit.py','perspective-warp':'native_perspective_warp.py','local-perspective':'native_local_perspective.py','photo-lock':'native_photo_lock.py','photo-fill':'native_photo_fill.py','photo-klein':'native_photo_klein.py','photo-klein-v02':'native_photo_klein_v02.py','gaiwan-food':'native_gaiwan_food.py','gaiwan-photo':'native_gaiwan_photo.py','gaiwan-assemble':'native_gaiwan_assemble.py','gaiwan-guide':'native_gaiwan_guide.py','gaiwan-differential':'native_gaiwan_differential.py','gaiwan-remove':'native_gaiwan_remove.py','gaiwan-color-edit':'native_gaiwan_color_edit.py','gaiwan-regional':'native_gaiwan_regional.py','exterior-band':'native_exterior_band.py'}[args.mode]
        execute_script(ROOT/'scripts/fission'/script,trailing);return
    if args.legacy:
        if Path(args.legacy).name!=args.legacy: parser.error('legacy 需要脚本名称')
        name=args.legacy.removesuffix('.py')
        special={'run_layers':ROOT/'scripts/fission/run_layers.py', 'run_fusion':ROOT/'work/diagnostics/multishop_hero_refresh_v1/run_fusion.py'}
        path=special.get(name,ROOT/'scripts/archive'/f'{name}.py')
        if not path.is_file(): parser.error('旧入口未登记：'+name)
        mapping=json.loads((ROOT/'fission/legacy_map.json').read_text())['entries']
        registered=next((e for e in mapping if e['script']==name+'.py'),None)
        if name not in special and (not registered or not registered['legacy'] or registered['stage']!=args.command):
            parser.error('请按 scripts/archive/README.md 的对应子命令调用')
        # Old layout/export entry points never receive a generation execution scope.
        if any(word in name for word in ('export','composite','layout','finalize','render','audit','report')):
            parser.error('旧排版和导出请使用 fission layout/export 读取源图')
    else:
        name={'master':'build_master','scene':'native_multishop','food':'native_dual_reference','multishop':'native_multishop'}[args.command]
        path=ROOT/'scripts/fission'/f'{name}.py'
    if args.legacy: os.environ['FISSION_ENTRYPOINT']='1'
    execute_script(path,trailing)


if __name__=='__main__':main()
