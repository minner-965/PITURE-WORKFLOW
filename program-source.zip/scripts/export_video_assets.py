#!/usr/bin/env python3
"""Build an immutable, verified A-to-B asset batch from explicit selections."""
import argparse, datetime, hashlib, io, json, os, re, shutil, tempfile
from pathlib import Path, PurePosixPath
from PIL import Image, ImageCms, ImageOps
import qa_state

ROOT=Path(__file__).resolve().parents[1]
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for part in iter(lambda:f.read(1024*1024),b''): h.update(part)
 return h.hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def safe_relative(value):
 if not isinstance(value,str) or not value or '\\' in value: raise ValueError('invalid relative path')
 p=PurePosixPath(value)
 if p.is_absolute() or any(x in ('.','..') for x in value.split('/')) or not value.startswith('files/'): raise ValueError('invalid relative path: '+value)
 return p

def validate_batch(directory, require_ready=True, receiver_strict=False):
 directory=Path(directory); mp=directory/'manifest.json'; data=json.loads(mp.read_text(encoding='utf-8')); entries=data['assets']; ids=set(); paths=set(); total=0
 if data.get('schema_version')!=1 or data.get('producer')!='A' or not isinstance(data.get('batch_id'),str) or not re.fullmatch(r'batch_[0-9]{3,}',data['batch_id']) or not isinstance(data.get('product_id'),str) or not re.fullmatch(r'[A-Za-z0-9_-]+',data['product_id']): raise ValueError('invalid manifest identity')
 if not isinstance(data.get('source_revision'),str) or not re.fullmatch(r'[a-f0-9]{12}',data['source_revision']): raise ValueError('invalid source revision')
 facts=data.get('product_facts')
 if not isinstance(facts,dict) or 'moq' not in facts or 'units_per_sale' not in facts or facts['moq'] is not None or facts['units_per_sale'] is not None: raise ValueError('invalid product facts')
 if not isinstance(entries,list): raise ValueError('invalid asset list')
 public_values(data)
 for a in entries:
  if not isinstance(a.get('asset_id'),str) or not re.fullmatch(r'[A-Za-z0-9_-]+',a['asset_id']): raise ValueError('invalid asset_id')
  if a.get('asset_type') not in ('raw_photo','empty_rgba','detail_photo','scene_image','white_bg') or a.get('review_status') not in ('APPROVED','TECHNICAL_ONLY','UNREVIEWED','REJECTED') or a.get('usage_scope') not in ('pipeline_test','listing','social'): raise ValueError('invalid asset metadata')
  if a['usage_scope'] in ('listing','social') and a['review_status']!='APPROVED': raise ValueError('published usage requires APPROVED')
  if a['asset_id'] in ids: raise ValueError('duplicate asset_id')
  ids.add(a['asset_id']); rel=safe_relative(a['relative_path']); p=directory.joinpath(*rel.parts)
  if rel.as_posix() in paths: raise ValueError('duplicate relative_path')
  paths.add(rel.as_posix())
  if p.is_symlink() or not p.is_file() or not p.resolve().is_relative_to(directory.resolve()): raise ValueError('invalid asset file')
  if p.stat().st_size!=a['byte_size'] or sha(p)!=a['sha256']: raise ValueError('asset checksum mismatch: '+str(rel))
  with Image.open(p) as im:
   im.verify()
  with Image.open(p) as im:
   im.load()
   if [im.width,im.height]!=[a['width'],a['height']]: raise ValueError('dimensions mismatch')
  total+=p.stat().st_size
 if not entries: raise ValueError('empty batch')
 for a in entries:
  if not isinstance(a.get('derived_from'),list) or any(x not in ids for x in a['derived_from']):raise ValueError('unresolved derived_from')
 actual={p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file() or p.is_symlink()}
 expected=paths|{'manifest.json'}|({'READY.json'} if require_ready else set())
 if require_ready and not receiver_strict and (directory/'receive_report_from_B.json').is_file() and not (directory/'receive_report_from_B.json').is_symlink(): expected.add('receive_report_from_B.json')
 if actual!=expected: raise ValueError('extra or missing files: '+str(actual^expected))
 if require_ready:
  ready=json.loads((directory/'READY.json').read_text(encoding='utf-8'))
  if ready['batch_id']!=data['batch_id'] or ready['manifest_sha256']!=sha(mp) or ready['file_count']!=len(paths) or ready['total_bytes']!=total: raise ValueError('READY mismatch')
 return data, {'batch_id':data['batch_id'],'manifest_sha256':sha(mp),'file_count':len(paths),'total_bytes':total,'completed_at':now()}

def public_values(value):
 if isinstance(value,dict):
  for v in value.values(): public_values(v)
 elif isinstance(value,list):
  for v in value: public_values(v)
 elif isinstance(value,str) and (value.startswith('/') or re.search(r'(^|\s)/Users/',value)): raise ValueError('absolute path in public metadata')

def approved(a, source):
 review=a.get('review') or {}; typ=a['asset_type']; status=a['review_status']
 if status not in ('APPROVED','TECHNICAL_ONLY','UNREVIEWED','REJECTED'): raise ValueError('invalid review status')
 if a['usage_scope'] not in ('pipeline_test','listing','social'): raise ValueError('invalid usage scope')
 if a['usage_scope'] in ('listing','social') and status!='APPROVED': raise ValueError('published usage requires APPROVED')
 if status!='APPROVED': return None
 if typ in ('raw_photo','detail_photo','empty_rgba'):
  if review.get('reviewer')!='root' or not isinstance(review.get('note'),str) or not review['note'].strip() or review.get('sha256')!=sha(source): raise ValueError('root written review and source SHA-256 required')
  return None
 ident=a.get('qa_id'); rows=qa_state.rows()
 if not ident or ident not in rows or qa_state.issues(ident): raise ValueError('QA not approved: '+str(ident))
 final=Path(rows[ident]['planned_path'])
 if source.resolve() not in (final.with_suffix('.jpg').resolve(),final.with_suffix('.png').resolve()): raise ValueError('QA item does not review this file')
 entry=qa_state.get(ident);ext=source.suffix.lower().lstrip('.')
 if entry.get(ext+'_sha256')!=sha(source): raise ValueError('QA source hash mismatch')
 return 'config/qa_approvals.json#'+ident

def srgb_copy(src,dst):
 with Image.open(src) as opened:
  icc=opened.info.get('icc_profile'); im=ImageOps.exif_transpose(opened); alpha=im.getchannel('A') if 'A' in im.getbands() else None
  if icc:
   profile=ImageCms.ImageCmsProfile(io.BytesIO(icc)); target=ImageCms.createProfile('sRGB')
   mode='RGB' if im.mode in ('RGBA','P','LA') else im.mode
   im=ImageCms.profileToProfile(im.convert(mode),profile,target,outputMode='RGB'); method='embedded ICC converted to sRGB'
  else:
   if im.mode not in ('RGB','RGBA','L','LA','P'): raise ValueError('unprofiled non-RGB image requires an ICC profile')
   im=im.convert('RGB'); method='no ICC; assumed sRGB'
  if alpha is not None:
   bg=Image.new('RGB',im.size,'white');bg.paste(im,mask=alpha);im=bg
  dst.parent.mkdir(parents=True,exist_ok=True);im.save(dst,'JPEG',quality=95,subsampling=0,icc_profile=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes())
 return method

def export(config, output_root):
 config=json.loads(Path(config).read_text(encoding='utf-8')); batch=config['batch_id']; product=config['product_id']
 if not re.fullmatch(r'batch_[0-9]{3,}',batch) or not re.fullmatch(r'[A-Za-z0-9_-]+',product): raise ValueError('invalid batch or product id')
 facts=config['product_facts'];
 if 'moq' not in facts or 'units_per_sale' not in facts or facts['moq'] is not None or facts['units_per_sale'] is not None: raise ValueError('moq and units_per_sale must be null')
 public_values(facts); revision=sha(Path(config['source_xlsx']))[:12]
 out=Path(output_root)/product;out.mkdir(parents=True,exist_ok=True);dest=out/batch
 if dest.exists(): raise FileExistsError(dest)
 lock=out/('.'+batch+'.lock')
 lock.mkdir()
 stage=None
 try:
  if dest.exists(): raise FileExistsError(dest)
  stage=Path(tempfile.mkdtemp(prefix='.'+batch+'_',dir=out))
  manifest={'schema_version':1,'product_id':product,'batch_id':batch,'source_revision':revision,'created_at':now(),'producer':'A','product_facts':facts,'assets':[]}; ids=set()
  for a in config['assets']:
   ident=a['asset_id'];typ=a['asset_type']
   if not re.fullmatch(r'[A-Za-z0-9_-]+',ident) or ident in ids: raise ValueError('invalid or duplicate asset_id')
   if typ not in ('raw_photo','detail_photo','empty_rgba','scene_image','white_bg'): raise ValueError('invalid asset_type')
   ids.add(ident); source=Path(a['source'])
   if not source.is_file(): raise ValueError('source missing')
   ref=approved(a,source); ext=source.suffix.lower()
   if ext not in ('.jpg','.jpeg','.png','.tif','.tiff','.webp'): raise ValueError('unsupported format')
   rel=f'files/{typ}/{ident}{ext}'; safe_relative(rel); target=stage/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
   if sha(source)!=sha(target): raise ValueError('copy mismatch')
   approved(a,source)  # Recheck the exact copied source against its review.
   def record(id,path,derived,extra=None):
    with Image.open(path) as im: im.load();w,h=im.size
    rec={k:a.get(k) for k in ('asset_revision','asset_type','color_id','sku_ids','view_angle','review_status','usage_scope','provenance')};rec['asset_revision']=rec['asset_revision'] or 1
    rec.update(asset_id=id,relative_path=path.relative_to(stage).as_posix(),sha256=sha(path),byte_size=path.stat().st_size,width=w,height=h,derived_from=derived,qa_ref=ref)
    if extra: rec.update(extra)
    public_values(rec);manifest['assets'].append(rec)
   record(ident,target,a.get('derived_from',[]))
   if typ in ('raw_photo','detail_photo'):
    sid=ident+'_srgb'
    if sid in ids: raise ValueError('duplicate generated asset_id')
    ids.add(sid);p=stage/f'files/{typ}/{sid}.jpg';method=srgb_copy(source,p);record(sid,p,[ident],{'color_conversion':method})
  allids={a['asset_id'] for a in manifest['assets']}
  for a in manifest['assets']:
   if not isinstance(a['derived_from'],list) or any(x not in allids for x in a['derived_from']): raise ValueError('unresolved derived_from')
  (stage/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  _,ready=validate_batch(stage,False)
  if dest.exists(): raise FileExistsError(dest)
  os.rename(stage,dest)
  (dest/'READY.json').write_text(json.dumps(ready,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  validate_batch(dest); return dest
 finally:
  if stage is not None and stage.exists(): shutil.rmtree(stage)
  lock.rmdir()
if __name__=='__main__':
 p=argparse.ArgumentParser();group=p.add_mutually_exclusive_group(required=True);group.add_argument('--config',type=Path);group.add_argument('--validate-batch',type=Path);p.add_argument('--receiver-strict',action='store_true');p.add_argument('--output-root',type=Path,default=ROOT/'exchange');a=p.parse_args()
 if a.receiver_strict and not a.validate_batch:p.error('--receiver-strict requires --validate-batch')
 if a.validate_batch:
  _,result=validate_batch(a.validate_batch,receiver_strict=a.receiver_strict);print(json.dumps(result,ensure_ascii=False,indent=2))
 else:print(export(a.config,a.output_root))
