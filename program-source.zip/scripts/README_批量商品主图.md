# 批量商品主图入口

## w1125 单碗换菜的原生双参考入口

本批 A01 保留黄碗生滚牛肉粥。用户已选 A02 红碗紫菜蛋花汤的原生 01 版，02 版留作对照。其他主题使用同一条原生路线，每次提交一个「店铺／菜品 ID／版本」，本机 GPU 串行工作。旧俯拍纹理投影已停用。

在批次的 `<店铺>/<菜品 ID>/原生双参考/<两到三位版本号>/` 准备 `prompt.txt` 和 `settings.json`。提示词须明确写出这道菜、该色商品和本张的餐厅画面。设置使用本店的背景参考、整数种子和 `[1280,1024]`。商品参考由菜单指定的同款实拍母版读取。可参照[已跑通的 A02/01 输入和回执](../fission/runs/abc_20261104/A/seaweed_egg/原生双参考/01/)。

从项目根目录用 ComfyUI 的 Python 运行下列命令，可核对 A02 第一版的现有结果。

```sh
python scripts/batch_shop_hero.py fission/runs/abc_20261104/batch.json --native-sample A/seaweed_egg/01 --plan
```

换成菜单中目标店铺、菜品 ID 和准备好的版本号，使用 `--run` 提交或接回这一张原有任务。也可直接执行 `scripts/fission/native_dual_reference.py --run fission/runs/abc_20261104 --shop 店铺 --dish 菜品ID --version 版本号` 进行单张离线检查，增加 `--submit` 才进入实际执行。无提示词、原片或参考哈希不符时会停止。已选主题的现有版本可读取，若本次版本从未提交则停止。新出图只登记待复核，通过后再登记选择和导出。


**独立菜名链接的上架顺序**　每个商品、每家店分别排。第一张使用该批选定的真实商品颜色和菜品；第二张起与上一张比较，颜色、菜品均须不同。更换颜色使用该款对应实拍，更换菜品使用不同菜品身份。颜色可隔张再用。

入口 `scripts/batch_shop_hero.py` 接收 UTF-8 JSON 清单，例子见 `work/diagnostics/multishop_hero_refresh_v1/examples/w1125_C.json`。示例 C 使用已完成背景 `C_bg_v1` 和示例融合提示词，正式执行前由 root 审核背景、商品参考及提示词。

```sh
python scripts/batch_shop_hero.py 路径/清单.json --plan
python scripts/batch_shop_hero.py 路径/清单.json
```

清单的 `skus` 数组每项包含安全英文 `id`、可选整数 `order`、默认 `product`、显式核实的 `copy`（`title`、1–3 条 `benefits`、可选 `subline`）和 `shops`。各店键为任意英文数字店铺 ID，字段 `style` 为 A/B/C 排版家族；可用店铺级 `product` 覆盖商品摆位参考，另需 `background`、`background_prompt`、`fusion_prompt`、两个 seed，以及 `composition` 的 `layout_id`、`subject_count`、`stacking`、`arrangement`、`camera`。路径可相对于清单。只填写已核实文案，不从其他 SKU 继承。

预检按序号、自然数字顺序 SKU，再按店铺自然数字顺序列计划；对同 SKU 的重复或高度相似商品摆位参考、重复构图属性报错。感知哈希只是一道粗筛，不能保证识别所有相似图，也不代表平台判重结果。构图信息随任务身份保存，供人工复核。照片、构图、提示词或程序变化会生成不同任务标识。

执行时逐店串行提交背景、融合及排版，前一步完成并验哈希后才进入下一步。可用 `existing_background_job` 指定已完成背景；其原图、提示词、种子、基础工作流与输出文件必须与清单和现存记录一致。中断后重跑同一清单，已完成的生成和排版会核对身份与文件哈希后复用；已有提交记录交给后端恢复。输出标记待 root 视觉审核，不上传。每一步只比较自身用到的输入，单改文案可以直接用既有无字照片重新排版。现有运行器/排版程序及其依赖应保持可用；执行前确认 Comfy 服务正常且空闲。

商品文件夹按款建目录。目录内放 `sku.json`（结构与单清单中的单个 SKU 对象相同），相对路径以各自商品目录为基准：

```sh
python scripts/batch_shop_hero.py --sku-root 商品目录 --plan
python scripts/batch_shop_hero.py --sku-root 商品目录 --shops shop2,shop10 --run
```

`composition.bounds` 在手动摆位时必填。每个主体一个 `[左,上,右,下]`，相对画面宽高归一到 0–1，与 `subject_count` 对应。同一 SKU 各店位置框接近时，即使改变店名、背景、颜色或种子，也会报错；选择部分店铺运行时仍检查该 SKU 的所有店铺。位置框由配置提供，需要人工对照参考图核实，检测不能保证识别所有重复构图。`--run` 明确执行，`--plan` 仅检查。w1125 C 运行：

```sh
python scripts/batch_shop_hero.py work/diagnostics/multishop_hero_refresh_v1/examples/w1125_C.json --run
```

自动摆位示例：`work/diagnostics/multishop_hero_refresh_v1/examples/sku_root/01_w1125/sku.json`。每款的 `auto_assets` 可填透明单件 PNG 路径，或 `{ "path": "...", "role": "empty", "view": "oblique", "description": "真实绿碗实拍" }`；可用 role 为 `single`、`empty`、`food`、`held`、`action`、`stack`，view 为 `oblique`、`front`、`side`、`overhead`，标注必须符合实拍。每家融合提示文件需包含 `{AUTO_LAYOUT}`，入口据真实素材和摆位模板补充对应对象数量与位置。每店也可提供显式 `product` 和 `composition`，优先保留手工摆位。预检先保留手工项，自动选择尚未占用且未被历史使用的布局；实际可用布局由真实素材决定，素材不足时预检报错并说明需要补充的拍摄视角或动作。

店铺可提供自己的 `copy` 覆盖 SKU 文案，并可设置 `design_key`。背景、融合和排版各自按输入身份分别缓存，改文案或版式不会改变背景与融合任务编号。可配置 `existing_background_job` 和 `existing_fusion_job`，入口核对输入、种子、提示词、工作流、结果、回执及文件哈希后复用。可选 `reviewed_photo` 包含 `path`、`sha256`、`fusion_sha256`，用已审无字图排版并核对来源融合输出。

每个店铺的配置可填写 `"text_position": "top"`，将标题、卖点和副标放在照片内上方。填写 `"bottom"` 或省略时沿用下方版式。选择上方前先确认上方约 16% 有留白，检查原寸图和手机缩略图中的碗口、耳、持握的手或印字是否完整可见。切换位置只重新排版，可复用同一背景与融合母图。独立排版入口支持 `--text-position top` 或 `--text-position bottom`。

新构图在 root 实看通过后登记（替换占位值）：

```sh
python scripts/shop_hero_history.py --sku SKU_ID --shop SHOP_ID --label 构图名称 \
  --reference 商品参考图.png --photo 已审无字照片.png --batch-dir 批次输出目录 --root-reviewed
```
