#!/usr/bin/env python3
"""Propose front-mask extensions from a real, normalized photo; root review required."""
import argparse, hashlib, json
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--original',type=Path,required=True);ap.add_argument('--mask',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--x-min',type=int,required=True);ap.add_argument('--x-max',type=int,required=True);ap.add_argument('--search-px',type=int,default=6);ap.add_argument('--crease-guard',type=int,default=1);a=ap.parse_args()
 if a.search_px<1 or a.search_px>6 or a.crease_guard<1:ap.error('search-px must be 1–6 and crease-guard at least 1')
 original=a.original.resolve(strict=True);mask_path=a.mask.resolve(strict=True)
 with Image.open(original) as img:
  if img.mode!='RGB':raise ValueError('original must be normalized real RGB photograph')
  if any(k in img.info for k in ('prompt','workflow','listing_export_metadata')):raise ValueError('original carries generated-image metadata')
  rgb=np.array(img)
 with Image.open(mask_path) as image:old=np.array(image.convert('L'))
 height,width=old.shape
 if rgb.shape[:2]!=(height,width) or not (0<=a.x_min<=a.x_max<width):raise ValueError('image/mask dimensions or x range invalid')
 luma=rgb.astype(float)@np.array([.299,.587,.114]);values=[]
 for x in range(a.x_min,a.x_max+1):
  pixels=np.flatnonzero(old[:,x]);front=int(pixels[-1]) if pixels.size else None; candidates=[]
  if front is not None:
   for y in range(front+1,min(front+a.search_px,height-3)+1):
    if y<2:continue
    score=float(luma[y,x]-(luma[y-2:y,x].mean()+luma[y+1:y+3,x].mean())/2)
    if luma[y,x]<=luma[y-1,x] and luma[y,x]<=luma[y+1,x] and score<=-5:candidates.append((score,y))
  score,y=min(candidates) if candidates else (None,None)
  values.append({'x':x,'old_front':front,'crease_candidate':y,'contrast_score':score,'status':'candidate_pending_root' if y is not None else 'pending_review'})
 new=old.copy();covered=0
 for i,rec in enumerate(values):
  front=rec['old_front'];candidate=rec['crease_candidate'];rec['new_front']=front
  if candidate is None or front is None:continue
  adjacent=[r['crease_candidate'] for r in values[max(0,i-3):min(len(values),i+4)] if r['crease_candidate'] is not None]
  smoothed=int(round(float(np.median(adjacent))));taper=min(1.,(rec['x']-a.x_min)/8,(a.x_max-rec['x'])/8)
  upper=min(front+4,candidate-a.crease_guard,smoothed-a.crease_guard);shift=max(0,int(np.floor(max(0,upper-front)*taper+.5)));end=front+shift
  if shift:
   new[front:end+1,rec['x']]=255;new[end,rec['x']]=128
  rec.update(smoothed_candidate=smoothed,new_front=end,added_pixels=shift)
  if new[candidate,rec['x']]>0:covered+=1
 outside=np.ones_like(old,dtype=bool);outside[:,a.x_min:a.x_max+1]=False
 if not np.array_equal(new[outside],old[outside]):raise ValueError('mask changed outside x range')
 for rec in values:
  if rec['old_front'] is not None:
   front=rec['old_front'];x=rec['x'];end=rec['new_front']
   if not np.array_equal(new[:front,x],old[:front,x]):raise ValueError('rear or existing mask above front changed')
   if end==front and new[front,x]!=old[front,x]:raise ValueError('unchanged front was altered')
   if end>front and (new[front,x]!=255 or np.any(new[front:end,x]!=255) or new[end,x]!=128):raise ValueError('front alpha transition invalid')
 if covered:raise ValueError('candidate line covered by new mask')
 out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
 if any((out/name).exists() for name in ('old_mask.png','paint_mask.png','inverse_mask.png','source_candidates_4x.png','evidence.json')):raise FileExistsError('output exists; choose a new directory')
 Image.fromarray(old).save(out/'old_mask.png');Image.fromarray(new).save(out/'paint_mask.png');Image.fromarray(255-new).save(out/'inverse_mask.png')
 populated=[v for v in values if v['old_front'] is not None]
 if not populated:raise ValueError('mask contains no pixels in x range')
 y0=max(0,min(v['old_front'] for v in populated)-18);y1=min(height,max((v['crease_candidate'] or v['old_front']) for v in populated)+19);x0=max(0,a.x_min-12);x1=min(width,a.x_max+13)
 tile=Image.fromarray(rgb[y0:y1,x0:x1]).resize(((x1-x0)*4,(y1-y0)*4),Image.Resampling.NEAREST);canvas=Image.new('RGB',(tile.width+65,tile.height+34),'white');canvas.paste(tile,(65,34));d=ImageDraw.Draw(canvas);font=ImageFont.load_default()
 for x in range(((x0+9)//10)*10,x1,10):
  X=65+(x-x0)*4;d.line((X,34,X,canvas.height),fill='#bbbbbb',width=1);d.text((X,8),str(x),fill='black',font=font)
 for y in range(((y0+9)//10)*10,y1,10):
  Y=34+(y-y0)*4;d.line((65,Y,canvas.width,Y),fill='#bbbbbb',width=1);d.text((5,Y),str(y),fill='black',font=font)
 for v in values:
  x=65+(v['x']-x0)*4
  if v['old_front'] is not None:d.rectangle((x,34+(v['old_front']-y0)*4,x+3,37+(v['old_front']-y0)*4),fill='#0066ff')
  if v['new_front'] is not None:d.rectangle((x,34+(v['new_front']-y0)*4,x+3,37+(v['new_front']-y0)*4),fill='#00d000')
  if v['crease_candidate'] is not None:d.rectangle((x,34+(v['crease_candidate']-y0)*4,x+3,37+(v['crease_candidate']-y0)*4),fill='#ff2424')
 canvas.save(out/'source_candidates_4x.png')
 report={'status':'mechanical_candidates_pending_root','visual_review':'required','original':str(original),'original_sha256':sha(original),'mask':str(mask_path),'mask_sha256':sha(mask_path),'new_mask_sha256':sha(out/'paint_mask.png'),'inverse_mask_sha256':sha(out/'inverse_mask.png'),'x_range_inclusive':[a.x_min,a.x_max],'search_px':a.search_px,'crease_guard':a.crease_guard,'contrast_threshold':-5,'luma':'BT.601 encoded RGB','contrast':'center minus mean of two rows above and two below; center is local minimum','median_window':7,'taper_columns':8,'max_extension_px':4,'last_added_alpha':128,'added_pixels':int(np.count_nonzero((old==0)&(new>0))),'promoted_soft_pixels':int(np.count_nonzero((old>0)&(old<255)&(new==255))),'unchanged_outside_x':bool(np.array_equal(new[outside],old[outside])),'existing_mask_change_scope':'only old front on columns with extension may be promoted to 255','detected_candidate_covered_pixels':covered,'candidate_is_not_proven_real_crease':True,'candidate_count':sum(v['crease_candidate'] is not None for v in values),'pending_columns':sum(v['crease_candidate'] is None for v in values),'plot':'blue old front; green new front; red mechanical valley candidate; 4x source pixels with original-coordinate 10px grid','records':values}
 (out/'evidence.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='records'},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
