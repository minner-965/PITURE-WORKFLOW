#!/usr/bin/env python3
"""Experimental matting of A using the real aligned photograph as edge RGB."""
from pathlib import Path
import json, hashlib
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import distance_transform_edt
from pymatting import estimate_alpha_cf, estimate_foreground_ml
P=Path(__file__).resolve().parents[1]; O=P/'work/diagnostics/matting_20261103'; O.mkdir(parents=True,exist_ok=True)
I=P/'work/diagnostics/scene_v7/inputs'; B=P/'work/diagnostics/scene_v7/branch_A_inputs'
bowl=np.asarray(Image.open(I/'A_food_rgba.png').convert('RGBA')); core=np.asarray(Image.open(I/'A_food_core.png').convert('L'))>0
orig=Image.open(P/'work/base/LISTING_orange/Base_Image.png').convert('RGB')
s=1.35; tx=-179; ty=-130
base=np.asarray(orig.transform((1024,1024),Image.Transform.AFFINE,(1/s,0,-tx/s,0,1/s,-ty/s),resample=Image.Resampling.BICUBIC,fillcolor=(0,0,0))).copy()
# Actual original photograph provides both foreground and background around the bowl;
# generated food RGB is substituted only deep in the protected interior.
base[core]=bowl[:,:,:3][core]
alpha0=bowl[:,:,3]; silhouette=alpha0>=128
inside=distance_transform_edt(silhouette); outside=distance_transform_edt(~silhouette)
unknown=(inside<=3)&(outside<=3); trimap=np.where(silhouette,1.,0.);trimap[unknown]=.5;trimap[core]=1.
# Bounding the solve to the specimen reduces resource use while retaining real background.
box=(180,420,850,885); x0,y0,x1,y1=box
im=base[y0:y1,x0:x1].astype(np.float64)/255; tri=trimap[y0:y1,x0:x1]
a=estimate_alpha_cf(im,tri); f=estimate_foreground_ml(im,a)
fulla=np.zeros((1024,1024),dtype=np.float64);fulla[y0:y1,x0:x1]=np.clip(a,0,1)
fullf=base.astype(np.float64)/255;fullf[y0:y1,x0:x1]=np.clip(f,0,1)
fulla[core]=1;fullf[core]=bowl[:,:,:3][core]/255
rgba=np.dstack((np.rint(fullf*255).astype('uint8'),np.rint(fulla*255).astype('uint8')))
Image.fromarray(base).save(O/'aligned_source_rgb.png');Image.fromarray(np.uint8(trimap*255)).save(O/'trimap.png');Image.fromarray(rgba).save(O/'foreground_rgba.png')
bg=Image.open(B/'BGsource.png').convert('RGBA');old=Image.alpha_composite(bg,Image.fromarray(bowl)).convert('RGB');new=Image.alpha_composite(bg,Image.fromarray(rgba)).convert('RGB');old.save(O/'original_composite.png');new.save(O/'decontaminated_composite.png')
# Restore protected core exactly, then verify.
n=np.array(new);n[core]=bowl[:,:,:3][core];new=Image.fromarray(n);new.save(O/'decontaminated_composite.png')
Image.fromarray(np.uint8(silhouette)*255).save(O/'silhouette_mask.png')
for name,region in {'left_wall':(195,540,300,740),'right_wall':(735,520,830,730),'foot':(330,780,750,865)}.items():
 sheet=Image.new('RGB',((region[2]-region[0])*8,(region[3]-region[1])*4+24),'white'); d=ImageDraw.Draw(sheet);d.text((2,3),'original',fill='black');d.text(((region[2]-region[0])*4+2,3),'matting',fill='black')
 for i,img in enumerate((old,new)): sheet.paste(img.crop(region).resize(((region[2]-region[0])*4,(region[3]-region[1])*4),Image.Resampling.NEAREST),(i*(region[2]-region[0])*4,24))
 sheet.save(O/f'{name}_4x_comparison.png')
report={'source':'work/base/LISTING_orange/Base_Image.png, bicubic affine scale 1.35 translation [-179,-130]; protected core taken from A_food_rgba.png','baseline_is_photograph':True,'solve_box':box,'unknown_band':'three pixels inside/outside silhouette; original core forced foreground','unknown_pixels':int(unknown.sum()),'core_pixels':int(core.sum()),'core_differing_pixels':int(np.count_nonzero(np.any(n[core]!=bowl[:,:,:3][core],axis=1))),'silhouette_bounds':[212,453,819,853],'warning':'Matting an orange-white bowl against a light original background may erode genuine white edges; result requires visual inspection. Original baseline and generated interior have different provenance; matting is constrained to the outer edge.'}
(O/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');print(json.dumps(report,indent=2,ensure_ascii=False))
