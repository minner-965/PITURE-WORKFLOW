import argparse,json
from pathlib import Path
import numpy as np
from PIL import Image,ImageFilter
from prepare_inputs import sha

def masks(base,bowl,inner,out,radius=1,core_extra=None):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    im=Image.open(base).convert('RGB');b=Image.open(bowl).convert('L');i=Image.open(inner).convert('L')
    if not im.size==b.size==i.size:raise ValueError('Base and masks must have identical size')
    B=np.array(b)>=128;I=np.array(i)>=128
    if not B.any() or not I.any() or np.any(I&~B):raise ValueError('Empty bowl/inner or inner outside bowl')
    P=B&~I;hard=Image.fromarray(P.astype('uint8')*255)
    core=np.array(hard.filter(ImageFilter.MinFilter(3)))>=128
    if core_extra:
        e=Image.open(core_extra).convert('L')
        if e.size!=im.size:raise ValueError('Core size mismatch')
        core|=np.array(e)>=128
    if np.any(core&~P) or not core.any():raise ValueError('Core must be nonempty and within protected bowl')
    paste=np.array(hard.filter(ImageFilter.GaussianBlur(radius)));paste[~P]=0;paste[core]=255
    for name,arr in [('bowl_mask',B*255),('inner_mask',I*255),('protect_hard',P*255),('paint_mask',(~P)*255),('paste_mask',paste),('core_mask',core*255)]:Image.fromarray(arr.astype('uint8')).save(out/(name+'.png'))
    rgb=np.array(im).copy();rgb[core]=(rgb[core]*.5+np.array([0,255,0])*.5).astype('uint8');band=P&~core;rgb[band]=[255,0,255];Image.fromarray(rgb).save(out/'core_overlay.png')
    rgba=im.convert('RGBA');rgba.putalpha(Image.fromarray(B.astype('uint8')*255));rgba.save(out/'empty_bowl_cutout.png')
    record=dict(base_sha256=sha(base),bowl_sha256=sha(bowl),inner_sha256=sha(inner),radius=radius,core_pixels=int(core.sum()),protected_pixels=int(P.sum()),core_fraction=float(core.sum()/P.sum()),transition_pixels=int(band.sum()),review='人工检查碗沿、主体与绿色核心覆盖；此字段不表示已通过视觉验收')
    (out/'masks.json').write_text(json.dumps(record,ensure_ascii=False,indent=2));return record
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('base');p.add_argument('bowl');p.add_argument('inner');p.add_argument('out');p.add_argument('--radius',type=float,default=1);p.add_argument('--core-extra');a=p.parse_args();print(masks(a.base,a.bowl,a.inner,a.out,a.radius,a.core_extra))
