#!/usr/bin/env python3
"""Export white photos and source-table specification drafts, without invented pack counts."""
import csv
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
R=Path(__file__).resolve().parents[1]; root=R/'output/LISTING_V3/w1125'
assets={r['color_id']:r for r in csv.DictReader(open(R/'config/product_assets.csv',encoding='utf-8-sig'))}
font='/System/Library/Fonts/STHeiti Medium.ttc'
def f(n): return ImageFont.truetype(font,n)
def save(im,dir,name):
 dir.mkdir(parents=True,exist_ok=True);im.save(dir/(name+'.png'));im.convert('RGB').save(dir/(name+'.jpg'),quality=95,subsampling=0)
def product(path,width):
 im=Image.open(path).convert('RGBA');im=im.crop(im.getchannel('A').getbbox());scale=min(width/im.width,440/im.height);im=im.resize((round(im.width*scale),round(im.height*scale)),Image.Resampling.LANCZOS);return im
for row in csv.DictReader(open(R/'config/skus.csv',encoding='utf-8-sig')):
 a=assets[row['color_id']]; im=product(a['rgba_empty'],650)
 white=Image.new('RGB',(800,800),'white'); white.paste(im,((800-im.width)//2,(800-im.height)//2),im);save(white,root/'04_white_by_color',row['color_id'])
 card=Image.new('RGB',(800,800),'white');d=ImageDraw.Draw(card);d.text((70,65),'w1125  '+row['color_name'],font=f(38),fill='#252b2c');d.text((70,125),'批量采购',font=f(24),fill='#777e80')
 card.paste(im,((800-im.width)//2,205),im);d.line((70,665,730,665),fill='#e2e4e3',width=2)
 for title,value,x in [('容量','550 ml',70),('长','16.5 cm',270),('宽','12.8 cm',440),('高','8 cm',610)]:
  d.text((x,685),title,font=f(24),fill='#343b3b');d.text((x,717),value,font=f(25),fill='#343b3b')
 d.text((70,765),'尺寸与容量为单只参数',font=f(18),fill='#777e80');save(card,root/'03_sku',row['sku_id'])
print('Exported five white images and five bulk color-option specification images; order quantity unspecified.')
