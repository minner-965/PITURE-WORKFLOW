#!/usr/bin/env python3
"""Manifest-led mechanical validation. Human visual approval remains independent."""
import qa_state
import argparse,csv,hashlib,json
from collections import Counter
from pathlib import Path
import numpy as np
from PIL import Image
from compose_scene import OUT,ROOT
from original_region_restore import validate_restore
COLORS={'red','orange','green','yellow','blue'}
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read_csv(path):
 with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def checked_file(value):
 p=Path(value)
 if not p.is_absolute():raise ValueError(f'expected absolute project path: {value}')
 p=p.resolve()
 if not p.is_relative_to(ROOT.resolve()) or not p.is_file():raise ValueError(f'missing or external project file: {value}')
 return p
def image_info(p):
 with Image.open(p) as im:im.verify()
 with Image.open(p) as im:return {'size':list(im.size),'sha256':sha(p)}
def recorded_file(path,digest,description):
 p=checked_file(path)
 if not digest or sha(p)!=digest:raise ValueError(f'{description}: hash missing or mismatch: {p}')
 return p
def validate_stage(data,path):
 identity=data['identity'];outputs=data['outputs'];checks=data['pixel_checks'];base=recorded_file(identity['base_path'],identity['base_sha256'],'stage base');paint=recorded_file(identity['paint_path'],identity['paint_sha256'],'stage mask');exact=recorded_file(outputs['exact']['path'],outputs['exact']['sha256'],'stage exact')
 if checks['exact']['different_pixels']!=0 or checks['exact']['max_abs_difference']!=0:raise ValueError(f'{path}: recorded exact comparison nonzero')
 b=np.asarray(Image.open(base).convert('RGB'));e=np.asarray(Image.open(exact).convert('RGB'));m=np.asarray(Image.open(paint).convert('L'))
 if b.shape!=e.shape or b.shape[:2]!=m.shape or b.shape[:2]!=(1024,1024):raise ValueError(f'{path}: stage image/mask dimensions mismatch')
 region=m==0
 if not region.any():raise ValueError(f'{path}: no protected pixels')
 diff=np.abs(e.astype('int16')-b.astype('int16')).max(axis=2)[region];count=int(np.count_nonzero(diff));maximum=int(diff.max())
 if count or maximum:raise ValueError(f'{path}: recomputed protected difference {count}, max {maximum}')
 restore_audit=None
 if data.get('stage_kind')=='deterministic_original_restore' or identity.get('stage_kind')=='deterministic_original_restore':
  if data.get('stage_kind')!=identity.get('stage_kind'):raise ValueError(f'{path}: deterministic restore stage kind mismatch')
  original=data['original_restore'];source=recorded_file(original['source_path'],original['source_sha256'],'restore original');oldmask=recorded_file(original['original_mask_path'],original['original_mask_sha256'],'restore original mask');binary=recorded_file(original['binary_mask_path'],original['binary_mask_sha256'],'restore binary mask')
  if sha(source)!=identity['source_sha256'] or sha(binary)!=sha(paint):raise ValueError(f'{path}: restore source/mask identity mismatch')
  sm=np.asarray(Image.open(oldmask).convert('L'));bm=np.asarray(Image.open(binary).convert('L'));orig=np.asarray(Image.open(source).convert('RGB'))
  if sm.shape!=(1024,1024) or bm.shape!=sm.shape or orig.shape!=b.shape or not np.array_equal(bm,(sm>0).astype('uint8')*255):raise ValueError(f'{path}: restore mask is not binary original nonzero support')
  inside=bm>0
  if not inside.any() or not (~inside).any():raise ValueError(f'{path}: restore region invalid')
  delta=np.abs(e.astype('int16')-orig.astype('int16')).max(axis=2)[inside];di=int(np.count_nonzero(delta));mi=int(delta.max())
  if di or mi:raise ValueError(f'{path}: restored original differs in {di} pixels')
  for section,expected_pixels in [('inside',int(inside.sum())),('outside',int((~inside).sum()))]:
   rec=original[section]
   if rec.get('pixels')!=expected_pixels or rec.get('different_pixels')!=0 or rec.get('max_abs_difference')!=0:raise ValueError(f'{path}: recorded {section} restore checks invalid')
  ref=recorded_file(identity['reference_reset_path'],identity['reference_reset_sha256'],'restore reference');refarr=np.asarray(Image.open(ref).convert('RGB'))
  if refarr.shape!=e.shape or not np.array_equal(refarr,e):raise ValueError(f'{path}: exact differs from expected original reset')
  raw_audit=None
  if 'postprocess' in data or 'comfy_raw' in outputs:
   post=data['postprocess'];rawpath=recorded_file(outputs['comfy_raw']['path'],outputs['comfy_raw']['sha256'],'restore Comfy raw');raw=np.asarray(Image.open(rawpath).convert('RGB'))
   if raw.shape!=e.shape or post.get('method')!='integer_original_pixel_restore' or post.get('comfy_raw_sha256')!=sha(rawpath) or post.get('original_sha256')!=sha(source) or post.get('mask_sha256')!=sha(binary):raise ValueError(f'{path}: restore postprocess identity mismatch')
   rin=np.abs(raw.astype('int16')-orig.astype('int16')).max(axis=2)[inside];rout=np.abs(raw.astype('int16')-b.astype('int16')).max(axis=2)[~inside];raw_audit={'inside_different_pixels':int(np.count_nonzero(rin)),'inside_max_diff':int(rin.max()),'outside_different_pixels':int(np.count_nonzero(rout)),'outside_max_diff':int(rout.max())}
   if raw_audit['inside_max_diff']>1 or raw_audit['outside_different_pixels'] or post.get('float_rounding_different_pixels')!=raw_audit['inside_different_pixels'] or post.get('float_rounding_max_diff')!=raw_audit['inside_max_diff'] or post.get('changed_region_pixels')!=int(inside.sum()):raise ValueError(f'{path}: restore raw rounding/outside verification failed')
  restore_audit={'inside_pixels':int(inside.sum()),'inside_diff_count':di,'inside_max_diff':mi,'outside_pixels':int((~inside).sum()),'outside_diff_count':count,'outside_max_diff':maximum,'binary_matches_original_mask':True,'reference_matches_exact':True,'stage_kind':'deterministic_original_restore','comfy_raw':raw_audit}
 parent=identity.get('parent_prompt_id') or data.get('parent_prompt_id');prep_path=identity.get('base_preparation_path');prep_hash=identity.get('base_preparation_sha256');prep=None
 if 'base_preparation_path' in identity or 'base_preparation_sha256' in identity:
  if not prep_path or not prep_hash or not parent:raise ValueError(f'{path}: preparation path, hash and parent prompt are all required')
  prep=validate_restore(prep_path,prep_hash)
  if prep['reset_output_sha256']!=sha(base) or prep['parent_prompt_id']!=parent or prep['paint_sha256']!=sha(paint):raise ValueError(f'{path}: preparation does not match stage base, mask or parent')
 return {'result':str(path),'prompt_id':data.get('prompt_id'),'parent_prompt_id':parent,'base_sha256':sha(base),'exact_sha256':sha(exact),'protected_pixels':int(region.sum()),'different_pixels':count,'max_diff':maximum,'base_preparation':prep,'original_restore':restore_audit}
def validate_whole(data,png,jpg,deliverable):
 source=recorded_file(data['source_path'],data['source_sha256'],'native source');si=image_info(source)
 if si['size']!=[1024,1024] or data.get('native_generation_size')!=[1024,1024]:raise ValueError('native source must be 1024x1024')
 pi=image_info(png);ji=image_info(jpg)
 if sha(png)!=data.get('png_sha256') or sha(jpg)!=data.get('jpg_sha256'):raise ValueError('export PNG/JPG hash missing or mismatch')
 if pi['size']!=data.get('export_size') or ji['size']!=data.get('jpg_export_size'):raise ValueError('export dimensions differ from sidecar')
 transform=data['export_transform']['png'];size=transform['source_resize'];placement=transform.get('placement',[0,0]);canvas=transform['canvas']
 if pi['size']!=canvas or len(size)!=2 or len(placement)!=2 or size[0]!=size[1] or 'Lanczos' not in transform.get('resampling',''):raise ValueError('unsupported or non-uniform PNG export transform')
 left,top=placement;right,bottom=left+size[0],top+size[1]
 if left<0 or top<0 or right>canvas[0] or bottom>canvas[1]:raise ValueError('photo placement outside canvas')
 expected=np.asarray(Image.open(source).convert('RGB').resize(tuple(size),Image.Resampling.LANCZOS));actual=np.asarray(Image.open(png).convert('RGB'))[top:bottom,left:right];allowed=np.ones((size[1],size[0]),bool)
 boxes=data['text_boxes']['png']
 if not isinstance(boxes,list):raise ValueError('invalid PNG text_boxes')
 for obj in boxes:
  x0,y0,x1,y1=obj['bbox']
  if not (0<=x0<=x1<=canvas[0] and 0<=y0<=y1<=canvas[1]):raise ValueError('text bbox outside canvas')
  a,b,c,d=max(0,x0-left),max(0,y0-top),min(size[0],x1-left),min(size[1],y1-top)
  if a<c and b<d:allowed[b:d,a:c]=False
 if not allowed.any():raise ValueError('no comparable non-text photo pixels')
 diff=np.abs(actual.astype('int16')-expected.astype('int16')).max(axis=2)[allowed];count=int(np.count_nonzero(diff));maximum=int(diff.max())
 if count or maximum:raise ValueError(f'PNG source resize comparison differs at {count} pixels (max {maximum})')
 if data.get('export_pixel_check',{}).get('changed_pixel_count')!=0 or data.get('export_pixel_check',{}).get('max_diff')!=0:raise ValueError('recorded PNG export pixel check missing or nonzero')
 refs=data.get('provenance_files')
 if not isinstance(refs,list) or not refs:raise ValueError('whole photo provenance_files missing')
 stages=[]
 for raw in refs:
  p=checked_file(raw)
  if p.name!='result.json':continue
  stage=json.loads(p.read_text())
  if all(k in stage for k in ('identity','outputs','pixel_checks')):stages.append(validate_stage(stage,p))
 if not stages:raise ValueError('whole photo provenance has no stage result with identity/outputs/pixel_checks')
 byid={s['prompt_id']:s for s in stages if s['prompt_id']}
 if len(byid)!=len(stages):raise ValueError('stage prompt IDs missing or duplicated')
 for stage in stages:
  parent=stage['parent_prompt_id']
  expected_parent=stage['base_preparation']['parent_exact_sha256'] if stage['base_preparation'] else stage['base_sha256']
  if parent and (parent not in byid or byid[parent]['exact_sha256']!=expected_parent):raise ValueError(f"stage parent missing or hash mismatch: {stage['result']}")
 if data['source_sha256'] not in {s['exact_sha256'] for s in stages}:raise ValueError('native source is not an exact output in the provided stage lineage')
 if deliverable=='MAIN_02':
  bowls=data.get('filled_bowls')
  if not isinstance(bowls,list) or any(not isinstance(b,dict) or not all(b.get(k) for k in ('color_id','dish','region_id')) for b in bowls):raise ValueError('MAIN_02 requires explicit filled_bowls metadata')
  if {b['color_id'] for b in bowls}!=COLORS:raise ValueError('MAIN_02 filled_bowls lacks verified five-color coverage')
 return {'native_source':si,'png':pi,'jpg':ji,'png_recomputed':{'compared_pixels':int(allowed.sum()),'different_pixels':count,'max_diff':maximum},'recorded_export_pixel_check':data['export_pixel_check'],'stages':stages,'filled_bowls':data.get('filled_bowls')}
def validate_pure_copy(data,png,jpg,deliverable):
 if deliverable!='MAIN_05' or data.get('deliverable_id')!='MAIN_05' or data.get('pure_copy') is not True:raise ValueError('pure_copy is only supported for MAIN_05')
 reused=data['reused_from'];hashes=data['source_hashes'];refs=data['provenance_files']
 if not isinstance(reused,dict) or not isinstance(hashes,dict) or not isinstance(refs,list):raise ValueError('MAIN_05 invalid pure_copy schema')
 records={}
 for ext,target in [('png',png),('jpg',jpg)]:
  source=recorded_file(reused[ext],hashes[ext+'_sha256'],'MAIN_05 source '+ext);target=checked_file(str(target.resolve()))
  if sha(target)!=data.get(ext+'_sha256') or sha(target)!=sha(source):raise ValueError(f'MAIN_05 {ext}: final and source hash mismatch')
  if image_info(source)['size']!=[800,800] or image_info(target)['size']!=[800,800]:raise ValueError(f'MAIN_05 {ext}: expected 800x800')
  records[ext]=source
 original=recorded_file(data['original_photo'],data['original_photo_sha256'],'MAIN_05 photographer original')
 expected=(ROOT/'input/supplied_20261102/测试品/sku实拍/IMG_1105.jpg').resolve()
 if original!=expected:raise ValueError('MAIN_05 photographer original must be IMG_1105.jpg')
 provenance={checked_file(x) for x in refs}
 if not {records['png'],records['jpg'],original}.issubset(provenance):raise ValueError('MAIN_05 provenance missing source PNG/JPG or original photo')
 return {'source_png':str(records['png']),'source_jpg':str(records['jpg']),'original_photo':str(original),'hashes_verified':True}
def validate_cards(data):
 sources=data.get('sources')
 if not isinstance(sources,list) or len(sources)!=3:raise ValueError('D02 requires exactly three explicit source records')
 ids={x.get('asset_id') for x in sources}
 if ids!={'orange_plain_congee','red_fish_congee','blue_century_pork_congee'}:raise ValueError('D02 source IDs differ from approved three cards')
 for item in sources:recorded_file(item['path'],item['sha256'],'D02 source')
 return {'source_ids':sorted(ids),'source_hashes_verified':True}
def validate_legacy(data):
 assets=data.get('assets')
 if not isinstance(assets,list) or not assets:raise ValueError('unsupported legacy asset metadata: missing assets')
 result=[]
 for a in assets:
  for key in ('asset_core','visible_layout_core'):
   c=a.get(key)
   if not isinstance(c,dict) or not c.get('core_count') or c.get('diffcount')!=0:raise ValueError(f"legacy {a.get('asset_id')} has missing/nonzero {key}")
  visibility=a.get('outer_wall_visibility')
  if not isinstance(visibility,dict) or visibility.get('fraction') is None:raise ValueError(f"legacy {a.get('asset_id')} missing outer wall visibility")
  result.append({'asset_id':a.get('asset_id'),'asset_core':a['asset_core'],'visible_layout_core':a['visible_layout_core']})
 return result
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--full',action='store_true',help='print full JSON rather than summary');parser.add_argument('--summary',action='store_true',help='print summary (the default)');args=parser.parse_args()
 report={'visual_qa':'pending','groups':{},'errors':[],'pending_review':[],'items':{},'extra_white_background':None};errors=report['errors'];manifest=OUT/'manifest.csv'
 try:rows=read_csv(manifest)
 except (OSError,csv.Error) as e:raise SystemExit(f'manifest unreadable: {e}')
 expected={'main':5,'detail':8,'sku':5,'white_by_color':5,'extra':1};counts=Counter(r['role'] for r in rows)
 if len(rows)!=24 or counts!=expected or len({r['deliverable_id'] for r in rows})!=24:errors.append(f'manifest count/roles invalid: {len(rows)} {dict(counts)}')
 # Check inventory mappings independently of file counts.
 try:
  skus=read_csv(ROOT/'config/skus.csv');products=read_csv(ROOT/'config/product_assets.csv')
  skurows=[r for r in rows if r['role']=='sku'];whiterows=[r for r in rows if r['role']=='white_by_color']
  sku_ids=[r['sku_id'] for r in skus];manifest_ids=[r['deliverable_id'] for r in skurows]
  if len(sku_ids)!=len(set(sku_ids)) or len(manifest_ids)!=len(set(manifest_ids)) or set(sku_ids)!=set(manifest_ids):errors.append('SKU manifest IDs do not exactly match unique config/skus.csv IDs')
  sku_map={r['sku_id']:r['color_id'] for r in skus};manifest_sku_map={r['deliverable_id']:r.get('color_ids','') for r in skurows}
  if set(sku_map.values())!=COLORS or len(sku_map)!=5 or any(manifest_sku_map.get(k)!=v for k,v in sku_map.items()):errors.append('SKU colors must map one-to-one to the five configured colors')
  asset_colors=[r['color_id'] for r in products];white_colors=[r.get('color_ids','') for r in whiterows]
  if len(asset_colors)!=5 or len(set(asset_colors))!=5 or set(asset_colors)!=COLORS:errors.append('product_assets must contain exactly the five unique selected colors')
  if len(white_colors)!=5 or len(set(white_colors))!=5 or set(white_colors)!=set(asset_colors):errors.append('white image manifest colors must match selected product colors without duplicates')
  report['inventory_mapping']={'sku_ids':sku_ids,'sku_colors':sku_map,'white_colors':white_colors,'product_colors':asset_colors}
 except (OSError,KeyError,csv.Error) as e:errors.append(f'inventory mapping: {e}')
 for role,n in expected.items():
  group=[r for r in rows if r['role']==role];present=sum(Path(r['planned_path']).is_file() for r in group);report['groups'][role]={'actual':present,'expected':n}
  if present!=n:errors.append(f'{role}: expected {n}, found {present}')
 for row in rows:
  ident=row['deliverable_id'];role=row['role'];p=Path(row['planned_path']);item={'qa_result':row.get('qa_result'),'role':role};report['items'][ident]=item
  gate=qa_state.issues(ident);item['qa_effective']='passed' if not gate else 'blocked';item['qa_issues']=gate
  if gate:report['pending_review'].append({'deliverable_id':ident,'qa_result':row.get('qa_result'),'qa_issues':gate})
  try:
   if not p.is_absolute() or not p.resolve().is_relative_to(OUT.resolve()):raise ValueError('planned_path outside output')
   jpg=p.with_suffix('.jpg');png=p.with_suffix('.png');j=image_info(jpg);n=image_info(png);item.update(jpg=j,png=n)
   if role in ('main','sku','white_by_color','extra') and j['size']!=[800,800]:raise ValueError('expected 800x800 JPG')
   if role in ('sku','white_by_color','extra') and n['size']!=[800,800]:raise ValueError('expected 800x800 PNG')
   if role=='main' and (n['size'][0]!=n['size'][1] or n['size'][0]<800):raise ValueError('main PNG must be square >=800')
   if role=='detail' and (j['size'][0]!=750 or n['size']!=j['size'] or not 900<=j['size'][1]<=1400):raise ValueError('detail PNG/JPG dimensions invalid')
   meta=p.with_suffix('.json')
   if meta.is_file():
    data=json.loads(meta.read_text())
    if 'export_transform' in data and 'native_generation_size' in data:item['whole_photo']=validate_whole(data,png,jpg,ident)
    elif 'export_transform' in data or 'native_generation_size' in data:raise ValueError('unsupported whole-photo metadata: export_transform and native_generation_size are both required')
    elif data.get('pure_copy') is True:item['pure_copy']=validate_pure_copy(data,png,jpg,ident)
    elif ident=='D02':item['cards']=validate_cards(data)
    elif role in ('main','detail') and data.get('assets'):item['legacy']=validate_legacy(data)
    elif role in ('main','detail') and any(k in data for k in ('pixel_checks','provenance_files','export_pixel_check')):raise ValueError('unsupported scene metadata schema')
   elif ident in ('MAIN_01','MAIN_02','MAIN_03','MAIN_04','D01','D02','D08'):raise ValueError('scene sidecar missing')
  except (OSError,ValueError,KeyError,TypeError,IndexError,json.JSONDecodeError) as e:item['error']=str(e);errors.append(f'{ident}: {e}')
 try:
  extra=next(r for r in rows if r['role']=='extra');p=Path(extra['planned_path']).with_suffix('.png');mask=ROOT/'work/diagnostics/white_group_coverage.png';a=np.asarray(Image.open(p).convert('RGB'));m=np.asarray(Image.open(mask).convert('L'))
  if a.shape[:2]!=m.shape:raise ValueError('extra coverage dimensions mismatch')
  outside=m==0;bad=int(np.any(a[outside]!=255,axis=1).sum());report['extra_white_background']={'outside_pixels':int(outside.sum()),'nonwhite_pixels':bad}
  if bad:raise ValueError(f'extra white background has {bad} nonwhite outside pixels')
 except (StopIteration,OSError,ValueError) as e:errors.append(f'extra white check: {e}')
 try:
  details=sorted([r for r in rows if r['role']=='detail'],key=lambda r:r['deliverable_id']);mp=OUT/'02_detail/slice_map.json';mapping=json.loads(mp.read_text());full=OUT/'02_detail/full_preview.jpg'
  if len(details)!=8 or len(mapping)!=8:raise ValueError('expected eight detail modules and slice mappings')
  total=0
  for i,(row,item) in enumerate(zip(details,mapping),1):
   if item.get('module')!=i or not item.get('slice'):raise ValueError('detail slice mapping mismatch')
   module=Path(row['planned_path']);sl=OUT/'02_detail/slices'/item['slice'];a=image_info(module);b=image_info(sl)
   if a['size']!=b['size']:raise ValueError(f'{sl}: slice size mismatch')
   total+=a['size'][1]
  if image_info(full)['size']!=[750,total]:raise ValueError('full preview size mismatch')
  report['detail_complete']=True
 except (OSError,ValueError,KeyError,TypeError,json.JSONDecodeError) as e:report['detail_complete']=False;errors.append(f'detail full/slices: {e}')
 report['mechanical_ok']=not errors;report['delivery_complete']=not errors and not report['pending_review'];report['visual_qa']='passed' if not report['pending_review'] else 'pending'
 OUT.mkdir(parents=True,exist_ok=True);output=OUT/'validation.json';output.write_text(json.dumps(report,ensure_ascii=False,indent=2));summary={'mechanical_ok':report['mechanical_ok'],'delivery_complete':report['delivery_complete'],'groups':report['groups'],'error_count':len(errors),'errors':errors,'pending_review':report['pending_review'],'report_path':str(output)};print(json.dumps(report if args.full else summary,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
