import argparse,json
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser();p.add_argument('picks');a=p.parse_args();picks=json.loads(Path(a.picks).read_text())
    if not picks:raise SystemExit('No picks; no finished products exported')
    for r in picks:
        path=(ROOT/r['master']).resolve();sku=r['sku']
        if not path.is_relative_to(ROOT/'work/masters') or not r.get('visual_pass') or '/' in sku or '..' in sku:raise ValueError('Invalid/unreviewed pick')
        check=json.loads(path.with_suffix('.check.json').read_text())
        if check['core_diff_max'] or check['core_diff_count']:raise ValueError('Core pixel check failed')
        target=ROOT/'output'/sku;target.mkdir(exist_ok=True);im=Image.open(path).convert('RGB');im.resize((800,800),Image.Resampling.LANCZOS).save(target/('scene_'+path.stem+'.png'));im.resize((800,800),Image.Resampling.LANCZOS).save(target/('scene_'+path.stem+'.jpg'),quality=95,subsampling=0)
        (target/'selection.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(target)
if __name__=='__main__':main()
