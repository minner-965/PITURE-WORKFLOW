#!/usr/bin/env python3
"""Export a whole generated photo and text; drafts never imply visual approval."""
import argparse,hashlib,json,re,sys
import qa_state
import numpy as np
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,PngImagePlugin
ROOT=Path(__file__).resolve().parents[1];DIAG=ROOT/'work/diagnostics';FONT='/System/Library/Fonts/STHeiti Medium.ttc'
FINAL_NAMES={'MAIN_01':'main_01_restaurant_multi','MAIN_02':'main_02_all_colors_filled','MAIN_03':'main_03_food_uses','MAIN_04':'main_04_texture_scene','D01':'D01','D08':'D08'}
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def inside(path,parent):return path==parent or parent in path.parents
def project_file(path):
    p=Path(path).resolve()
    if not inside(p,ROOT) or not p.is_file():raise ValueError(f'Provenance must be an existing project file: {p}')
    return p
def label(d,xy,text,size,color,max_right):
    if not text:return None
    while size>=12:
        font=ImageFont.truetype(FONT,size);box=d.textbbox(xy,text,font=font)
        if box[2]<=max_right:break
        size-=1
    if size<12:raise ValueError('Text does not fit')
    if box[0]<0 or box[1]<0 or box[3]>d._image.height:raise ValueError(f'Text extends beyond canvas: {box}')
    d.text(xy,text,font=font,fill=color)
    return {'text':text,'bbox':list(box),'font_size':size}
def main():
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--deliverable-id',required=True,choices=['MAIN_01','MAIN_02','MAIN_03','MAIN_04','D01','D08']);p.add_argument('--output-dir',type=Path,required=True);p.add_argument('--headline',default=None);p.add_argument('--subtitle',default=None);p.add_argument('--feature',action='append');p.add_argument('--ui',required=True);p.add_argument('--api',required=True);p.add_argument('--lineage',required=True);p.add_argument('--provenance',action='append',default=[]);p.add_argument('--publish',action='store_true');p.add_argument('--review-record');p.add_argument('--filled-bowls-json',type=Path);p.add_argument('--text-layout-json',type=Path);p.add_argument('--source-kind',choices=['generated','photographic_base'],default='generated');a=p.parse_args()
    source=project_file(a.source);target=a.output_dir.resolve();source_hash=sha(source); ui=project_file(a.ui);api=project_file(a.api);lineage=project_file(a.lineage);provenance=[]
    for path in [a.lineage,a.ui,a.api,*a.provenance]:
        q=str(project_file(path))
        if q not in provenance:provenance.append(q)
    filled_bowls=None
    if a.filled_bowls_json:
        filled_path=project_file(a.filled_bowls_json); supplied=json.loads(filled_path.read_text()); filled_bowls=supplied.get('filled_bowls') if isinstance(supplied,dict) else supplied
        if not isinstance(filled_bowls,list) or any(not isinstance(b,dict) or not all(b.get(k) for k in ('color_id','dish','region_id')) for b in filled_bowls):raise ValueError('filled-bowls JSON must be a list of objects with color_id, dish, region_id')
        if str(filled_path) not in provenance:provenance.append(str(filled_path))
    layout=None
    if a.text_layout_json:
        layout_path=project_file(a.text_layout_json);layout=json.loads(layout_path.read_text());required={'headline_xy','headline_size','subtitle_xy','subtitle_size','color','max_right'}
        if not isinstance(layout,dict) or set(layout)!=required:raise ValueError('Invalid text layout fields')
        for key in ('headline_xy','subtitle_xy'):
            xy=layout[key]
            if not isinstance(xy,list) or len(xy)!=2 or any(type(n) is not int or n<0 or n>=1600 for n in xy):raise ValueError(f'Invalid {key}')
        for key in ('headline_size','subtitle_size'):
            if type(layout[key]) is not int or not 12<=layout[key]<=200:raise ValueError(f'Invalid {key}')
        if not isinstance(layout['color'],str) or not re.fullmatch(r'#[0-9A-Fa-f]{6}',layout['color']):raise ValueError('Invalid text color')
        if type(layout['max_right']) is not int or not 0<layout['max_right']<=1600 or any(layout[k][0]>=layout['max_right'] for k in ('headline_xy','subtitle_xy')):raise ValueError('Invalid max_right')
        if str(layout_path) not in provenance:provenance.append(str(layout_path))
    if a.publish and a.source_kind!='generated':raise ValueError('Photographic bases are diagnostic only')
    review=None
    if a.publish:
        if not a.review_record:raise ValueError('Publishing requires explicit root review record')
        review_path=project_file(a.review_record);review=json.loads(review_path.read_text())
        if review.get('status')!='passed' or review.get('reviewer')!='root' or review.get('source_sha256')!=source_hash or review.get('deliverable_id')!=a.deliverable_id:raise ValueError('Review must pass this deliverable and exact source hash')
        provenance.append(str(review_path))
        # Root review of a hash does not authorize a trial or its descendants.
        known=qa_state._known_preview_hashes()
        for source_record in [source,*map(Path,provenance)]:
            reasons=qa_state.preview_reasons(source_record,known)
            if reasons:raise ValueError('Trial source cannot be published: '+'; '.join(reasons))
    elif not inside(target,DIAG.resolve()):raise ValueError('Draft output must remain in work/diagnostics')
    with Image.open(source) as original:
        original.load();source_size=list(original.size);text_metadata={k:str(v) for k,v in original.info.items() if isinstance(v,str)};image=original.convert('RGB')
    if source_size!=[1024,1024]:raise ValueError(f'Expected actual 1024x1024 native source; got {source_size}')
    detail=a.deliverable_id in ('D01','D08');headline=a.headline if a.headline is not None else ('多色双耳粥碗' if detail else '五色双耳粥碗');subtitle=a.subtitle if a.subtitle is not None else ('w1125 · 餐饮批量采购' if detail else '粥 · 汤 · 糖水  |  550 ml')
    if detail:
        canvas=Image.new('RGB',(750,1200),'#f8f7f2');d=ImageDraw.Draw(canvas);png_text=[label(d,(48,42),headline,40,'#302c24',702),label(d,(48,104),subtitle,22,'#665f55',702)]
        photo=image.resize((750,750),Image.Resampling.LANCZOS);canvas.paste(photo,(0,170));d=ImageDraw.Draw(canvas);features=a.feature or ['五色可选','双耳器型','粥汤糖水']
        if len(features)!=3:raise ValueError('Detail features must contain exactly three items')
        font=ImageFont.truetype(FONT,25)
        for i,text in enumerate(features):
            box=d.textbbox((0,0),text,font=font);width=box[2]-box[0]
            if width>220:raise ValueError('Detail feature exceeds column')
            xy=(round((i+.5)*250-width/2),1015);bounds=d.textbbox(xy,text,font=font);d.text(xy,text,font=font,fill='#302c24');png_text.append({'text':text,'bbox':list(bounds),'font_size':25})
        photo_rect=(0,170,750,920)
        if any(t and t['bbox'][0]<photo_rect[2] and t['bbox'][2]>photo_rect[0] and t['bbox'][1]<photo_rect[3] and t['bbox'][3]>photo_rect[1] for t in png_text):raise ValueError('Detail text intersects photo rectangle')
        diff=np.abs(np.asarray(canvas.crop(photo_rect),dtype=np.int16)-np.asarray(photo,dtype=np.int16));audit={'comparison':'PNG detail photo rectangle vs uniform source resize','pixel_count':750*750,'changed_pixel_count':int(np.count_nonzero(diff.max(axis=2))),'max_diff':int(diff.max()),'photo_rectangle_xyxy':list(photo_rect)}
        jpg_text=png_text;transform={'png':{'source_resize':[750,750],'placement':[0,170],'canvas':[750,1200],'resampling':'Lanczos; uniform'},'jpg':{'source_resize':[750,750],'placement':[0,170],'canvas':[750,1200],'resampling':'Lanczos; uniform; same layout'}}
    else:
        expected=image.resize((1600,1600),Image.Resampling.LANCZOS);canvas=expected.copy();d=ImageDraw.Draw(canvas)
        hxy=tuple(layout['headline_xy']) if layout else (80,64);sxy=tuple(layout['subtitle_xy']) if layout else (84,165);hs=layout['headline_size'] if layout else 76;ss=layout['subtitle_size'] if layout else 38;color=layout['color'] if layout else '#302c24';hr=layout['max_right'] if layout else 1520;sr=layout['max_right'] if layout else 1516
        png_text=[label(d,hxy,headline,hs,color,hr),label(d,sxy,subtitle,ss,color,sr)]
        jpg_canvas=image.resize((800,800),Image.Resampling.LANCZOS);jd=ImageDraw.Draw(jpg_canvas)
        half=lambda x:(x+1)//2
        jpg_hxy=tuple(half(v) for v in hxy) if layout else (40,32);jpg_sxy=tuple(half(v) for v in sxy) if layout else (42,82)
        jpg_text=[label(jd,jpg_hxy,headline,half(hs),color,half(hr)),label(jd,jpg_sxy,subtitle,half(ss),color,half(sr))]
        allowed=np.zeros((1600,1600),dtype=bool)
        for t in png_text:
            if t:
                x0,y0,x1,y1=t['bbox'];allowed[max(0,y0):min(1600,y1),max(0,x0):min(1600,x1)]=True
        diff=np.abs(np.asarray(canvas,dtype=np.int16)-np.asarray(expected,dtype=np.int16)).max(axis=2);outside=diff[~allowed];audit={'comparison':'PNG master vs uniform source resize outside text boxes','pixel_count':int((~allowed).sum()),'changed_pixel_count':int(np.count_nonzero(outside)),'max_diff':int(outside.max()) if outside.size else None}
        transform={'png':{'source_resize':[1600,1600],'canvas':[1600,1600],'resampling':'Lanczos; uniform'},'jpg':{'source_resize':[800,800],'canvas':[800,800],'resampling':'Lanczos; uniform; text redrawn at half scale'}}
    if audit['changed_pixel_count'] or audit['max_diff']!=0:raise ValueError('PNG export pixel check failed')
    target.mkdir(parents=True,exist_ok=True);stem=FINAL_NAMES[a.deliverable_id] if a.publish else a.deliverable_id.lower()+'_whole_photo_layout_draft';png=target/(stem+'.png');jpg=target/(stem+'.jpg');side=target/(stem+'.json')
    metadata={'command_argv':[sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]],'deliverable_id':a.deliverable_id,'source_path':str(source),'source_sha256':source_hash,'native_generation_size':[1024,1024] if a.source_kind=='generated' else None,'native_source_size':[1024,1024],'source_kind':a.source_kind,'workflow_status':'prepared_only_no_inference' if a.source_kind=='photographic_base' else 'actual_run','export_size':list(canvas.size),'jpg_export_size':[750,1200] if detail else [800,800],'draft_only':not a.publish,'source_qa':'passed' if a.publish else ('not_generated_photographic_base' if a.source_kind=='photographic_base' else 'pending_or_rework'),'visual_qa':'pending_root_export_review' if a.publish else 'pending','ui_path':str(ui),'api_path':str(api),'prompt_lineage_path':str(lineage),'provenance_files':provenance,'export_transform':transform,'text_boxes':{'png':[t for t in png_text if t],'jpg':[t for t in jpg_text if t]},'export_pixel_check':audit,'text_layout':layout,'filled_bowls':filled_bowls,'headline':headline,'subtitle':subtitle,'features':features if detail else None}
    info=PngImagePlugin.PngInfo()
    for k,v in text_metadata.items():info.add_itxt(k,v)
    if a.source_kind=='generated':info.add_text('native_generation','1024')
    info.add_itxt('listing_export_metadata',json.dumps(metadata,ensure_ascii=False));canvas.save(png,pnginfo=info)
    # Re-open the written PNG; the report is about the actual lossless file.
    with Image.open(png) as saved:
        saved.load();disk=np.asarray(saved.convert('RGB'),dtype=np.int16)
    if detail: diskdiff=np.abs(disk[170:920,:,:]-np.asarray(photo,dtype=np.int16)).max(axis=2).ravel()
    else: diskdiff=np.abs(disk-np.asarray(expected,dtype=np.int16)).max(axis=2)[~allowed]
    audit['changed_pixel_count']=int(np.count_nonzero(diskdiff));audit['max_diff']=int(diskdiff.max()) if diskdiff.size else None;audit['file_reopened']=True
    if audit['changed_pixel_count'] or audit['max_diff']!=0:raise ValueError('Saved PNG pixel check failed')
    (canvas if detail else jpg_canvas).save(jpg,quality=95,subsampling=0);metadata.update(png_sha256=sha(png),jpg_sha256=sha(jpg));side.write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'png':str(png),'jpg':str(jpg),'sidecar':str(side),'draft_only':not a.publish},ensure_ascii=False))
if __name__=='__main__':main()
