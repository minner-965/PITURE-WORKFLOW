#!/usr/bin/env python3
"""Independent IMG_5887 scene candidate: preview masks before food mapping."""
import argparse,csv,hashlib,io,json,math
from pathlib import Path
import numpy as np
from PIL import Image,ImageCms,ImageDraw,ImageFilter,ImageFont,ImageOps
from scipy.ndimage import map_coordinates
ROOT=Path(__file__).resolve().parents[1]; CONFIG=ROOT/'config/photographed_scene_v4.json'; DIAG=ROOT/'work/diagnostics/scene_rebuild_v4'; FONT='/System/Library/Fonts/STHeiti Medium.ttc'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def source(cfg):
    path=ROOT/cfg['source_photo']
    with Image.open(path) as raw:
        profile=raw.info.get('icc_profile'); image=ImageOps.exif_transpose(raw).convert('RGB')
        if profile:image=ImageCms.profileToProfile(image,ImageCms.ImageCmsProfile(io.BytesIO(profile)),ImageCms.createProfile('sRGB'),outputMode='RGB')
        image=image.crop(tuple(cfg['source_crop_xyxy_exif_normalized']));return image.resize((cfg['master_size'],)*2,Image.Resampling.LANCZOS)
def masks(cfg):
    n=cfg['master_size']; ratio=n/cfg['reference_size']; yy,xx=np.mgrid[:n,:n]; result=[]
    for b in cfg['bowls']:
        angle=math.radians(b['angle_deg']);cx,cy=[v*ratio for v in b['center']];rx,ry=[(v-cfg['target_inset_reference_px'])*ratio for v in b['radii']]
        dx=xx-cx;dy=yy-cy;u=(dx*math.cos(angle)+dy*math.sin(angle))/rx;v=(-dx*math.sin(angle)+dy*math.cos(angle))/ry
        hard=u*u+v*v<=1; result.append((b,u,v,hard))
    return result
def overlay(cfg,base):
    DIAG.mkdir(parents=True,exist_ok=True);prefix=cfg.get('diagnostic_prefix','IMG_5887');md=DIAG/('masks' if prefix=='IMG_5887' else prefix+'_masks');md.mkdir(exist_ok=True);arr=base.copy().convert('RGBA');font=ImageFont.truetype(FONT,24);reports=[]
    for idx,(b,u,v,hard) in enumerate(masks(cfg),1):
        mask=Image.fromarray((hard*255).astype('uint8'),'L');mask.save(md/f"{b['id']}.png")
        layer=Image.new('RGBA',base.size,(255,74,42,0));layer.putalpha(mask.point(lambda a:round(a*.36)));arr=Image.alpha_composite(arr,layer)
        border=Image.fromarray((hard*255).astype('uint8')).filter(ImageFilter.FIND_EDGES);red=Image.new('RGBA',base.size,(255,55,25,255));arr.paste(red,(0,0),border)
        x,y=[round(v*cfg['master_size']/cfg['reference_size']) for v in b['center']];d=ImageDraw.Draw(arr);d.text((x-12,y-13),str(idx),font=font,fill='white',stroke_width=2,stroke_fill='black');reports.append({'number':idx,'id':b['id'],'food_asset_id':b['food_asset_id'],'mask':str(md/f"{b['id']}.png"),'pixel_count':int(hard.sum())})
    dest=DIAG/(prefix+'_target_masks_overlay.png');arr.convert('RGB').save(dest);(DIAG/('target_masks.json' if prefix=='IMG_5887' else prefix+'_target_masks.json')).write_text(json.dumps({'status':'pending_root_mask_review','source_sha256':sha(ROOT/cfg['source_photo']),'items':reports},ensure_ascii=False,indent=2));print(dest)
def render(cfg,base,partial=False):
    if cfg.get('visual_qa')!='masks_approved':raise ValueError('Target mask review must be recorded before rendering a candidate')
    with open(ROOT/'config/food_assets.csv',encoding='utf-8-sig',newline='') as f: rows={r['asset_id']:r for r in csv.DictReader(f)}
    selected=[];missing=[]
    for b,u,v,hard in masks(cfg):
        item=rows.get(b['food_asset_id']); e=b.get('source_ellipse')
        problem=None
        if not item or item.get('status')!='passed':problem='food asset awaiting visual pass'
        elif b.get('food_source_color') and item.get('color_id')!=b['food_source_color']:problem='food source color mismatch'
        elif not e or e.get('approved') is not True:problem='source ellipse awaiting explicit calibration approval'
        elif not Path(item['rgba_filled']).is_file():problem='food asset file missing'
        if problem:
            missing.append({'id':b['id'],'asset_id':b['food_asset_id'],'reason':problem})
            continue
        selected.append((b,u,v,hard,item))
    if missing and not partial:raise ValueError('Complete candidate requires every food and approved source ellipse: '+json.dumps(missing,ensure_ascii=False))
    if not selected:raise ValueError('No passed food with approved source ellipse for draft')
    original=np.asarray(base); canvas=original.copy();all_masks=np.zeros(original.shape[:2],bool);audit=[]
    for b,u,v,hard,item in selected:
        if np.any(all_masks & hard):raise ValueError('Target masks overlap: '+b['id'])
        all_masks|=hard;src=np.asarray(Image.open(item['rgba_filled']).convert('RGB'));e=b['source_ellipse'];rad=np.maximum(np.sqrt(u*u+v*v),1e-8);factor=np.minimum(1,float(e.get('radial_clamp',.95))/rad);sx=e['center'][0]+u*e['radii'][0]*factor;sy=e['center'][1]+v*e['radii'][1]*factor
        sampled=np.stack([map_coordinates(src[:,:,k].astype('float32'),[sy,sx],order=1,mode='nearest') for k in range(3)],axis=2);soft=Image.fromarray((hard*255).astype('uint8')).filter(ImageFilter.GaussianBlur(cfg['feather_reference_px']*cfg['master_size']/cfg['reference_size']));weight=np.asarray(soft).astype('float32')/255;weight[~hard]=0
        canvas=np.rint(canvas*(1-weight[:,:,None])+sampled*weight[:,:,None]).clip(0,255).astype('uint8');audit.append({'id':b['id'],'source_asset_id':b['food_asset_id'],'target_color':b.get('target_color',b.get('color_id')),'food_source_color':item.get('color_id'),'source_sha256':sha(item['rgba_filled']),'source_ellipse':e,'target_center':b['center'],'target_radii':b['radii'],'target_angle_deg':b['angle_deg']})
    diff=np.abs(canvas.astype('int16')-original.astype('int16')).max(axis=2); outside=diff[~all_masks];report={'status':'partial_draft_incomplete' if partial else 'candidate_pending_root_review','missing_bowls':missing,'source_sha256':sha(ROOT/cfg['source_photo']),'crop_xyxy':cfg['source_crop_xyxy_exif_normalized'],'outside_mask_count':int((~all_masks).sum()),'outside_changed_count':int(np.count_nonzero(outside)),'outside_maxdiff':int(outside.max()),'items':audit}
    if report['outside_changed_count']:raise ValueError('Pixels outside food masks changed')
    prefix=cfg.get('diagnostic_prefix','IMG_5887');name=DIAG/(prefix+('_food_partial_draft' if partial else '_food_candidate'));Image.fromarray(canvas).save(name.with_suffix('.png'));Image.fromarray(canvas).resize((800,800),Image.Resampling.LANCZOS).save(name.with_suffix('.jpg'),quality=95,subsampling=0);name.with_suffix('.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(name)
def main():
    a=argparse.ArgumentParser();a.add_argument('--config',type=Path,default=CONFIG);mode=a.add_mutually_exclusive_group();mode.add_argument('--render',action='store_true');mode.add_argument('--draft-partial',action='store_true');args=a.parse_args();cfg=json.loads(args.config.read_text());base=source(cfg)
    if args.render or args.draft_partial:render(cfg,base,partial=args.draft_partial)
    else:overlay(cfg,base)
if __name__=='__main__':main()
