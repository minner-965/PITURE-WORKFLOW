import json,csv
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parents[1]
rows=[]
for p in (ROOT/'work/logs').glob('*/identity.json'):
 identity=json.loads(p.read_text());folder=p.parent;measure=folder/'measurements.json';result=folder/'result.json'
 if not measure.exists():continue
 m=json.loads(measure.read_text());r=json.loads(result.read_text()) if result.exists() else {};ini=m['initial'];end=m['final']
 rows.append(dict(run_id=folder.name,sku=identity['sku'],seed=identity['seed'],status=m['status'],wall_seconds=round(m['wall_seconds'],3),backend_seconds=m.get('backend_wall_seconds'),rss_peak_sampled_bytes=m['rss_peak_sampled_bytes'],swap_start_bytes=ini.get('swap_used_bytes'),swap_end_bytes=end.get('swap_used_bytes'),swap_delta_bytes=m.get('swap_delta_bytes'),core_diff_max=r.get('check',{}).get('core_diff_max'),core_diff_count=r.get('check',{}).get('core_diff_count'),visual_pass=r.get('visual_pass'),master=r.get('master'),error=m.get('error')))
if not rows:raise SystemExit('No completed/failed measurements yet')
with (ROOT/'work/logs/run_summary.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
lines=['# 首轮真实实测记录','',datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'', '实物：w1125 橙白双耳粥碗，IMG_1076.jpg。真实输入1024×1024，20步，Q6_K，guidance30/cfg1/euler/normal。','', '最初绿豆沙冷加载尝试因菜品方向调整主动停止，已记录为中断；随后米粥任务复用已加载模型，因此属于已有模型缓存的运行，不冒充完整冷启动。','', '|任务|状态|墙钟秒|后端秒|RSS采样峰值字节|swap起/止/增量字节|核心最大差/不同像素|','|---|---|---:|---:|---:|---|---|']
for row in rows:lines.append(f"|{row['run_id']}|{row['status']}|{row['wall_seconds']}|{row['backend_seconds']}|{row['rss_peak_sampled_bytes']}|{row['swap_start_bytes']} / {row['swap_end_bytes']} / {row['swap_delta_bytes']}|{row['core_diff_max']} / {row['core_diff_count']}|")
pressure=ROOT/'work/logs/kernel-pressure.jsonl'
if pressure.exists():
 samples=[json.loads(x) for x in pressure.read_text().splitlines() if x.strip()];levels=sorted(set(x['pressure_level'] for x in samples));lines+=['',f'补充系统压力采样 kern.memorystatus_vm_pressure_level 实际值：{levels}；1为正常，2为警告，4为临界。此采样从米粥任务开始后补充启动，未覆盖之前绿豆沙冷加载全程。']
lines+=['','RSS为每5秒采样峰值，不代表统一内存总占用；MPS allocator/driver峰值未测，未将RSS和MPS数值相加。原始数据见各任务memory_samples.jsonl、history.json、measurements.json。','', '完整冷运行、三次独立seed热运行、多色小批与真实详情扩图按后续稳定性验证分别记录；当前表只包含实际已测任务。']
(ROOT/'docs/首轮真实实测.md').write_text('\n'.join(lines));print('Saved run_summary.csv and docs/首轮真实实测.md; measured tasks:',len(rows))
