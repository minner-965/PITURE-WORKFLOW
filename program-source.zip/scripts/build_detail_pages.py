#!/usr/bin/env python3
"""Deterministic 750px detail modules from registered photos and reviewed food assets."""
import qa_state
import argparse,json,shutil
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageOps
from compose_scene import ROOT,OUT,asset_path,read_csv,render,export
FONT='/System/Library/Fonts/STHeiti Medium.ttc'; PHOTOS=ROOT/'input/supplied_20261102/测试品/sku实拍'
def font(n): return ImageFont.truetype(FONT,n)
def title(d,head,sub=''):
    d.text((55,48),head,font=font(45),fill='#27332d')
    if sub: d.text((57,112),sub,font=font(24),fill='#758178')
def save(im,n): export(im,OUT/f'02_detail/modules/D{n:02d}')
def colors():
    out={}
    for r in read_csv(ROOT/'config/product_assets.csv'):
        if r.get('color_id') and r.get('rgba_empty') and asset_path(r['rgba_empty']).is_file(): out.setdefault(r['color_id'],r)
    if len(out)!=5: raise ValueError(f'need five empty bowls; got {len(out)}')
    return out

def paste_bowl(im,r,box):
    src=Image.open(asset_path(r['rgba_empty'])).convert('RGBA'); src=src.crop(src.getchannel('A').getbbox()); src.thumbnail((box[2],box[3]),Image.Resampling.LANCZOS); im.paste(src,(box[0]+(box[2]-src.width)//2,box[1]+(box[3]-src.height)//2),src)

def crop(name,box,size):
    im=Image.open(PHOTOS/name).convert('RGB'); return ImageOps.fit(im.crop(box),size,method=Image.Resampling.LANCZOS)

def arrow(d,a,b,label,tx,ty):
    d.line((a,b),fill='#343d37',width=3); dx=b[0]-a[0]; dy=b[1]-a[1]
    if abs(dx)>abs(dy):
        d.polygon([(a[0],a[1]),(a[0]+12,a[1]-6),(a[0]+12,a[1]+6)],fill='#343d37'); d.polygon([(b[0],b[1]),(b[0]-12,b[1]-6),(b[0]-12,b[1]+6)],fill='#343d37')
    else:
        d.polygon([(a[0],a[1]),(a[0]-6,a[1]+12),(a[0]+6,a[1]+12)],fill='#343d37'); d.polygon([(b[0],b[1]),(b[0]-6,b[1]-12),(b[0]+6,b[1]-12)],fill='#343d37')
    d.text((tx,ty),label,font=font(23),fill='#26332b',stroke_width=2,stroke_fill='#faf9f5')

def main():
    (OUT/'02_detail/modules').mkdir(parents=True,exist_ok=True); cs=colors()
    im=Image.new('RGB',(750,1100),'#faf9f5'); d=ImageDraw.Draw(im); title(d,'五色可选','同款双耳粥碗 · 真实颜色展示')
    for idx,(key,r) in enumerate(cs.items()):
        x=35+(idx%2)*350; y=185+(idx//2)*292; paste_bowl(im,r,(x,y,330,230)); d.text((x+95,y+238),r.get('color_name') or key,font=font(27),fill='#39423e')
    save(im,3)
    # The measured width runs across the bowl without its two ears.
    im=Image.new('RGB',(750,1400),'#faf9f5'); d=ImageDraw.Draw(im); title(d,'尺寸与规格','型号 w1125  ·  6.5 英寸')
    top=crop('IMG_1075.jpg',(1700,700,4700,3600),(440,425)); im.paste(top,(135,175)); d=ImageDraw.Draw(im)
    d.line((164,455,164,625),fill='#68756e',width=2); d.line((550,455,550,625),fill='#68756e',width=2); arrow(d,(164,625),(550,625),'长 16.5 cm',255,640); d.line((534,235,610,235),fill='#68756e',width=2); d.line((534,556,610,556),fill='#68756e',width=2); arrow(d,(610,235),(610,556),'宽 12.8 cm',470,580)
    side=crop('IMG_1078.jpg',(1000,900,5200,4050),(515,362)); im.paste(side,(95,700)); d=ImageDraw.Draw(im)
    d.line((535,850,650,850),fill='#68756e',width=2); d.line((535,1030,650,1030),fill='#68756e',width=2); arrow(d,(650,850),(650,1030),'高 8 cm',535,1070)
    d.line((55,1150,695,1150),fill='#dcded7',width=2); d.text((65,1185),'容量 550 ml',font=font(30),fill='#27332d'); d.text((400,1185),'重量 207 g',font=font(30),fill='#27332d'); d.text((65,1290),'尺寸、容量与重量均为单只参数',font=font(25),fill='#758178'); save(im,4)
    im=Image.new('RGB',(750,1250),'#faf9f5'); d=ImageDraw.Draw(im); title(d,'碗沿与表面','真实实拍细节'); d.text((65,182),'碗沿与双耳',font=font(28),fill='#27332d')
    im.paste(crop('IMG_1076.jpg',(1450,1750,4800,3560),(620,335)),(65,230)); d=ImageDraw.Draw(im); d.text((65,630),'内外配色',font=font(28),fill='#27332d'); im.paste(crop('IMG_1076.jpg',(1750,2200,4550,3710),(620,335)),(65,680)); save(im,5)
    im=Image.new('RGB',(750,1250),'#faf9f5'); d=ImageDraw.Draw(im); title(d,'碗底与侧面','真实实拍细节'); d.text((65,182),'倒扣碗底',font=font(28),fill='#27332d')
    im.paste(crop('IMG_1082.jpg',(1700,1400,4550,3000),(620,335)),(65,230)); d=ImageDraw.Draw(im); d.text((65,630),'侧面实拍',font=font(28),fill='#27332d'); im.paste(crop('IMG_1078.jpg',(1400,1400,4850,3265),(620,335)),(65,680)); save(im,6)
    im=Image.new('RGB',(750,1250),'#faf9f5'); d=ImageDraw.Draw(im); title(d,'颜色与规格','批量采购  ·  五色可选'); d.text((290,190),'颜色',font=font(26),fill='#758178'); d.text((495,190),'规格',font=font(26),fill='#758178'); d.line((55,235,695,235),fill='#dadfd9',width=2)
    for i,(key,r) in enumerate(cs.items()):
        y=245+i*165; paste_bowl(im,r,(55,y,200,145)); d.text((290,y+55),r.get('color_name') or key,font=font(30),fill='#27332d'); d.text((495,y+55),'6.5 英寸',font=font(27),fill='#27332d'); d.line((55,y+157,695,y+157),fill='#e1e4df',width=1)
    d.text((57,1125),'尺寸与容量为单只参数',font=font(25),fill='#758178'); save(im,7)
    # The same reviewed-background gate and layout-selected assets apply to every scene.
    from listing_q6 import compose
    for n in (1,2,8):
        try: compose(f'detail_{n:02}')
        except (FileNotFoundError,ValueError) as e: print(f'D{n:02} pending: {e}')
    stitch_existing_modules()

def stitch_existing_modules():
    """Use only eight reviewed, existing masters and copy their JPEG slices exactly."""
    module_dir=OUT/'02_detail/modules'; ids=[f'D{i:02}' for i in range(1,9)]
    approvals_path=ROOT/'config/qa_approvals.json'
    approvals=json.loads(approvals_path.read_text()) if approvals_path.is_file() else {}
    missing=[]
    for ident in ids:
        for suffix in ('.png','.jpg'):
            if not (module_dir/(ident+suffix)).is_file():missing.append(ident+suffix)
        entry=approvals.get(ident,{})
        if qa_state.issues(ident):missing.append(ident+':review_pending')
    if missing:
        print('detail stitch pending: '+', '.join(missing));return False
    masters=[]
    for ident in ids:
        with Image.open(module_dir/(ident+'.png')) as im:
            im.load();master=im.convert('RGB')
        with Image.open(module_dir/(ident+'.jpg')) as jpeg:
            jpeg.load()
            if jpeg.size!=master.size:raise ValueError(f'{ident}: PNG/JPG dimensions differ')
        if master.width!=750:raise ValueError(f'{ident}: expected 750px width, got {master.width}')
        masters.append(master)
    full=Image.new('RGB',(750,sum(im.height for im in masters)),'white');y=0
    for im in masters:full.paste(im,(0,y));y+=im.height
    detail=OUT/'02_detail';slices=detail/'slices';slices.mkdir(parents=True,exist_ok=True)
    full.save(detail/'full_preview.jpg',quality=92,subsampling=0)
    for i,ident in enumerate(ids,1):shutil.copyfile(module_dir/(ident+'.jpg'),slices/f'slice_{i:02}.jpg')
    mapping=[{'module':i,'slice':f'slice_{i:02}.jpg'} for i in range(1,9)]
    (detail/'slice_map.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2))
    print('detail stitched: 8 reviewed modules');return True

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--stitch-only',action='store_true');args=parser.parse_args()
    if args.stitch_only:stitch_existing_modules()
    else:main()
