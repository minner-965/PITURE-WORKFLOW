#!/usr/bin/env python3
"""One-off repair of reviewed SKU dimensions; takes prior export backup as source.

Used: update_sku_dimensions.py --backup-dir work/diagnostics/rejected_exports/sku_dimension_layout_20261102T145958731254Z
"""
import argparse,csv,hashlib,json
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parents[1];OUT=R/'output/LISTING_V3/w1125';FONT='/System/Library/Fonts/STHeiti Medium.ttc'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--backup-dir',type=Path,required=True);a=p.parse_args();backup=a.backup_dir.resolve()
 rows=list(csv.DictReader((R/'config/skus.csv').open(encoding='utf-8-sig',newline='')));reviews=json.loads((R/'config/qa_approvals.json').read_text());dest=OUT/'03_sku';cols=[('容量','550 ml',70),('长','16.5 cm',270),('宽','12.8 cm',440),('高','8 cm',610)]
 for row in rows:
  ident=row['sku_id'];original=backup/(ident+'.png');previous_jpg=backup/(ident+'.jpg')
  if not original.is_file() or not previous_jpg.is_file():raise FileNotFoundError('backed-up SKU files missing: '+ident)
  with Image.open(original) as src:card=src.convert('RGB')
  if card.size!=(800,800):raise ValueError('wrong SKU image size: '+ident)
  d=ImageDraw.Draw(card);d.rectangle((0,665,799,799),fill='white');d.line((70,665,730,665),fill='#e2e4e3',width=2)
  for title,value,x in cols:
   d.text((x,685),title,font=ImageFont.truetype(FONT,24),fill='#343b3b');d.text((x,717),value,font=ImageFont.truetype(FONT,25),fill='#343b3b')
  d.text((70,765),'尺寸与容量为单只参数',font=ImageFont.truetype(FONT,18),fill='#777e80')
  png=dest/(ident+'.png');jpg=dest/(ident+'.jpg');side=dest/(ident+'.json');card.save(png);card.save(jpg,quality=95,subsampling=0)
  with Image.open(original) as before,Image.open(png) as after:
   delta=np.abs(np.asarray(before.convert('RGB'),dtype=np.int16)[:665]-np.asarray(after.convert('RGB'),dtype=np.int16)[:665]).max(axis=2);count=int(np.count_nonzero(delta));maximum=int(delta.max())
  if count:raise ValueError(f'upper image differs: {ident}, {count}')
  previous=reviews.get(ident);prior_side=backup/(ident+'.json');history={'prior_approval':previous,'prior_sidecar':json.loads(prior_side.read_text()) if prior_side.is_file() else None,'backup_png':str(original),'backup_jpg':str(previous_jpg),'backup_png_sha256':sha(original),'backup_jpg_sha256':sha(previous_jpg)}
  record={'sku_id':ident,'color_id':row['color_id'],'visual_qa':'pending_root_export_review','dimensions_columns':[{'label':t,'value':v,'x':x} for t,v,x in cols],'upper_pixel_check':{'region':'y<665','changed_count':count,'maxdiff':maximum},'png_sha256':sha(png),'jpg_sha256':sha(jpg),'previous_export':history};side.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(ident,'y<665',count,maximum)
if __name__=='__main__':main()
