
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission multishop --legacy prepare_multishop_hero_v2 -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
from PIL import Image,ImageOps
import json,hashlib
R=Path(__file__).resolve().parents[2];W=R/'work/diagnostics/multishop_20261103/scene_inputs';source=W/'hero_layout_guide.png';ref=W/'hero_square_guide.png'
ImageOps.pad(Image.open(source),(832,832),method=Image.Resampling.LANCZOS,color=(215,208,190)).save(ref)
ref2=R/'work/diagnostics/multishop_20261103/product_refs/五色器型_1024.png'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
prompts={
'B':'Three matching deep double-tab melamine bowls as shown in image 2, all with white interiors and white upper collars. Fresh morning light, pale stone counter, muted sage wall. An adult in an olive apron holds one RED bowl forward at upper center, with both hands gently gripping its two flat side tabs. This bowl contains glossy ivory rice congee with three pale fish slices. Two separate bowls sit fully visible on the counter: one BLUE bowl of glossy golden pumpkin porridge at front left, one GREEN empty bowl at front right showing its white interior. Each bowl has the same rounded body, low foot and flat tabs as image 2. Grey linen and a blue spoon lie at the right side. Three bowls total, realistic fingers, continuous photographic background, soft grounded shadows.',
'C':'Three matching deep double-tab melamine bowls as shown in image 2, all with white interiors and white upper collars. Powder-blue wall, matte white counter, soft cool daylight. An adult in a pale blue apron stands at the right. Their right hand grips the right flat tab of one GREEN bowl at middle right, gently setting it on the counter; their left hand holds a white dessert spoon beside it. The green bowl contains white coconut milk and three red dragon-fruit cubes. Two separate bowls sit at left: one YELLOW empty bowl at back left showing its white interior, one ORANGE bowl with glossy flowing golden mango puree at front left. Each bowl has the rounded deep body, low foot and two solid flat tabs from image 2. Three bowls total, all fully framed. A blue linen napkin lies at lower right. Natural relaxed hands and delicate contact shadows.'}
for s,p in prompts.items():
 c={'job_id':s+'_hero_v2','mode':'edit','start_step':0,'reference1':str(ref),'reference2':str(ref2),'reference1_source':str(R/'output/TAOBAO_REPLICA_HD_20261103/01_参考底稿/详情/detail_modules/A02_参考模块.png'),'reference2_source':str(R/'output/LISTING_V3/w1125/assets/empty_bowls/red.png'),'width':832,'height':832,'reference_size':768,'seed':20261104700+ord(s),'prompt':p,'root_input_review':{'status':'approved','reviewer':'root','prompt_sha256':hashlib.sha256(p.encode()).hexdigest(),'reference1_sha256':sha(ref),'reference2_sha256':sha(ref2),'note':'Reduced hero composition to three bowls and supplied genuine five-color identity reference. All actual product shape checks remain required.'}}
 (W/(c['job_id']+'.json')).write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
