
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission multishop --legacy multishop_blue_green_candidates_v1 -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import numpy as np,json,hashlib
from scipy import ndimage as ndi
B=Path('/Users/luohuiwu/codex/ComfyProductPipeline'); D=B/'work/diagnostics/multishop_20261103';O=D/'blue_green_candidates_v1';O.mkdir(exist_ok=True,parents=True)
reg=json.load(open(B/'config/multishop_scene_assets.json')); report=json.load(open(D/'color_audit_v1/report.json')); rows=report['rows']
# Conservative interior polygons in 256x256 coordinates, staying away from rims, food, hands and props.
regions={
'A_hero':{'blue':[[(127,88),(205,87),(200,98),(187,106),(154,106),(138,100)]]},
'A_food':{'blue':[[(187,151),(232,151),(230,164),(219,175),(198,175),(188,166)]],'green':[[(19,143),(72,143),(69,157),(60,167),(34,167),(24,158)]]},
'A_empty':{'blue':[[(54,121),(135,121),(132,137),(122,146),(76,146),(61,138)]], 'green':[[(56,110),(133,109),(125,115),(70,116)]]},
'A_underside':{'blue':[[(87,84),(130,101),(128,112),(117,126),(103,128),(81,115),(79,104)]], 'green':[[(185,169),(235,169),(231,181),(221,188),(200,188),(190,180)]]},
'B_hero':{'blue':[[(33,193),(100,193),(96,211),(84,224),(52,224),(40,214)]],'green':[[(150,202),(217,202),(213,216),(201,230),(166,230),(156,218)]]},
'B_food':{'blue':[[(110,127),(156,127),(153,140),(141,149),(124,149),(113,141)]],'green':[[(171,109),(219,109),(216,121),(206,131),(185,131),(174,122)]]},
'B_empty':{'blue':[[(50,119),(107,119),(103,138),(90,151),(68,151),(54,140)]],'green':[[(105,187),(158,187),(155,200),(145,212),(119,212),(109,203)]]},
'C_hero':{'green':[[(119,154),(193,154),(190,169),(177,185),(145,185),(126,171)]]},
'C_food':{'blue':[[(15,140),(72,140),(69,154),(57,167),(31,167),(20,156)],[(50,185),(103,185),(100,200),(89,215),(63,215),(53,201)]],'green':[[(176,173),(224,173),(220,188),(210,202),(189,202),(179,191)]]},
'C_empty':{'green':[[(147,177),(223,177),(219,191),(205,208),(170,208),(153,195)]]}}
def lab(x):
 x=x/255.; x=np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4);z=x@np.array([[.4124564,.2126729,.0193339],[.3575761,.7151522,.119192],[.1804375,.0721750,.9503041]]);z/=np.array([.95047,1,1.08883]);f=np.where(z>(6/29)**3,np.cbrt(z),z/(3*(6/29)**2)+4/29);return np.stack([116*f[...,1]-16,500*(f[...,0]-f[...,1]),200*(f[...,1]-f[...,2])],-1)
def rgb(l):
 fy=(l[:,:,0]+16)/116;fx=fy+l[:,:,1]/500;fz=fy-l[:,:,2]/200;f=np.stack([fx,fy,fz],-1); z=np.where(f>6/29,f**3,3*(6/29)**2*(f-4/29))*np.array([.95047,1,1.08883]);x=z@np.linalg.inv(np.array([[.4124564,.2126729,.0193339],[.3575761,.7151522,.119192],[.1804375,.0721750,.9503041]]));x=np.clip(x,0,1);x=np.where(x<=.0031308,12.92*x,1.055*x**(1/2.4)-.055);return np.rint(x*255).clip(0,255).astype('uint8')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();entries=[];thumbs=[]
for name,colors in regions.items():
 shop,scene=name.split('_',1);src=Path(reg[shop][scene]['path']);arr=np.array(Image.open(src).convert('RGB'));h,w=arr.shape[:2];orig=lab(arr.astype(float));result=arr.copy();allmask=np.zeros((h,w),np.uint8);details=[]
 for color,polys in colors.items():
  m=Image.new('L',(w,h));draw=ImageDraw.Draw(m)
  for poly in polys:draw.polygon([(round(x*w/256),round(y*h/256)) for x,y in poly],fill=255)
  region=np.array(m)>0;r,g,b=[arr[:,:,i].astype(float) for i in range(3)];L,a,bb=orig[:,:,0],orig[:,:,1],orig[:,:,2]
  # Chroma criteria prevent edits to white porcelain, hands, neutral table and textiles.
  keep=region & (L>18) & (L<90) & ((bb<-7)&(b>r*1.05) if color=='blue' else (bb>12)&(g>b*1.12)&(g>r*.85))
  dist=ndi.distance_transform_edt(keep);alpha=np.clip(dist/2.5,0,1);mask=np.rint(alpha*255).astype('uint8');allmask=np.maximum(allmask,mask)
  ref=report['references'][f'side_{color}']['lab_median'];matches=[x for x in rows if x['scene']==name and x['color']==color and 'sample' in x]
  if matches:samp=matches[0]['sample']['lab_median']; da=np.clip(ref[1]-samp[1],-18,18)*.65;db=np.clip(ref[2]-samp[2],-18,18)*.65
  else:da,db=(-7,5) if color=='blue' else (-8,9)
  altered=orig.copy();altered[:,:,1]+=da*alpha;altered[:,:,2]+=db*alpha;candidate=rgb(altered);result[keep]=candidate[keep]
  Image.fromarray(mask).save(O/f'{name}_{color}_mask.png');details.append({'color':color,'polygon_256':polys,'da':round(float(da),3),'db':round(float(db),3),'sample_pixels':int(keep.sum())})
 out=O/f'{name}_candidate.png';Image.fromarray(result).save(out);Image.fromarray(allmask).save(O/f'{name}_mask.png')
 overlay=Image.composite(Image.blend(Image.fromarray(arr),Image.new('RGB',(w,h),(255,0,255)),.5),Image.fromarray(arr),Image.fromarray(allmask));overlay.save(O/f'{name}_mask_overlay.png')
 changed=np.any(arr!=result,2);entries.append({'scene':name,'source':str(src),'source_sha256':sha(src),'output':str(out),'output_sha256':sha(out),'mask_sha256':sha(O/f'{name}_mask.png'),'changed_pixels':int(changed.sum()),'changed_outside_mask':int((changed&(allmask==0)).sum()),'details':details,'status':'pending_root_visual_review'})
 pair=Image.new('RGB',(512,256),'white');pair.paste(Image.fromarray(arr).resize((256,256)),(0,0));pair.paste(Image.fromarray(result).resize((256,256)),(256,0));thumbs.append((name,pair))
contact=Image.new('RGB',(1024,((len(thumbs)+1)//2)*280),'white');draw=ImageDraw.Draw(contact)
for i,(name,im) in enumerate(thumbs):x=i%2*512;y=i//2*280;contact.paste(im,(x,y+20));draw.text((x,y),f'{name}: before | candidate',fill='black')
contact.save(O/'before_after_montage.png');(O/'provenance.json').write_text(json.dumps({'method':'Conservative hand polygons and chroma filter; Lab a/b offset 65% of sample gap clipped +/-18, L held in Lab before sRGB gamut clipping. Interior feather 2.5 px. Manually inspect mask and missed edges.','entries':entries},ensure_ascii=False,indent=2));print(len(entries),'scenes; changed outside masks',sum(x['changed_outside_mask'] for x in entries))
