#!/usr/bin/env python3
"""Read-only technical audit of a three-shop delivery; never marks visual approval."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission export --legacy audit_multishop_delivery -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

import argparse,hashlib,json,re,datetime,collections
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageOps,ImageChops

ROOT=Path(__file__).resolve().parents[2]
PLAN=ROOT/'config/multishop_variants_20261103_plan.json'
DELIVERY=ROOT/'output/MULTISHOP_20261103'
REPORT=ROOT/'work/diagnostics/multishop_20261103/audit'
EXPORTS=ROOT/'work/diagnostics/multishop_20261103/exports'
GENERATIONS=ROOT/'work/diagnostics/multishop_20261103/generation'
ID_RE=re.compile(r'^(M\d{2}|D\d{2})(?:[_\-\s.]|$)',re.I)
CJK=re.compile(r'[\u3400-\u9fff]')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def load(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def ui_links(api,visual):
 """Compare actual link endpoints/types, including destination input names."""
 nodes={str(n['id']):n for n in visual.get('nodes',[]) if str(n.get('id')) in api}
 if set(nodes)!=set(api):return False,'UI node set differs from API'
 for nid,n in api.items():
  if nodes[nid].get('type')!=n.get('class_type'):return False,'UI node type differs: '+nid
 expected=set()
 for target,n in api.items():
  for key,value in n.get('inputs',{}).items():
   if isinstance(value,list) and len(value)==2 and str(value[0]) in api and isinstance(value[1],int):expected.add((str(value[0]),value[1],str(target),key))
 actual=set()
 for link in visual.get('links',[]):
  if not isinstance(link,list) or len(link)<5:continue
  _,source,slot,target,input_index=link[:5];target=str(target)
  if target not in nodes or str(source) not in nodes:continue
  inputs=nodes[target].get('inputs',[])
  if not isinstance(input_index,int) or not 0<=input_index<len(inputs):return False,'UI input index invalid'
  actual.add((str(source),slot,target,inputs[input_index].get('name')))
 if actual!=expected:return False,'UI/API links differ'
 return True,None

def inspect_evidence(folder,expected_output=None,expected_hash=None):
 folder=Path(folder);required=['actual.api.json','actual.ui.json','history.json','submission.json','result.json'];missing=[n for n in required if not (folder/n).is_file()]
 result={'directory':str(folder),'status':'incomplete','missing_files':missing,'issues':[],'visual_review':'not_checked'}
 if missing:return result
 try:
  api,visual,history,sub,rec=[load(folder/n) for n in required];pid=rec.get('prompt_id');result['prompt_id']=pid
  if not pid or sub.get('prompt_id')!=pid:result['issues'].append('submission/result prompt_id mismatch')
  if history.get('status',{}).get('status_str')!='success':result['issues'].append('history status is not success')
  hp=history.get('prompt')
  if not isinstance(hp,list) or len(hp)<3 or hp[1]!=pid:result['issues'].append('history prompt_id mismatch')
  elif hp[2]!=api:result['issues'].append('history graph differs from actual API')
  if sub.get('request',{}).get('prompt')!=api:result['issues'].append('submission graph differs from actual API')
  input_checks=[]
  for role,item in rec.get('identity',{}).get('inputs',{}).items():
   if not isinstance(item,dict) or not item.get('path') or not item.get('sha256'):
    result['issues'].append('input provenance incomplete: '+role);continue
   src=Path(item['path']);exists=src.is_file();matched=exists and sha(src)==item['sha256'];input_checks.append({'role':role,'path':str(src),'exists':exists,'sha256_matches':matched})
   if not matched:result['issues'].append('input missing or hash mismatch: '+role)
  result['input_checks']=input_checks
  saved_ids=[nid for nid,node in api.items() if node.get('class_type')=='SaveImage']
  if not saved_ids or not any(history.get('outputs',{}).get(nid,{}).get('images') for nid in saved_ids):result['issues'].append('history does not contain a saved image output')
  ok,reason=ui_links(api,visual)
  if not ok:result['issues'].append(reason)
  if expected_output is not None:
   if str(Path(rec.get('output_path','')).resolve())!=str(Path(expected_output).resolve()):result['issues'].append('result output path mismatch')
   if rec.get('output_sha256')!=expected_hash:result['issues'].append('result output hash mismatch')
  result['files_sha256']={n:sha(folder/n) for n in required};result['status']='flag' if result['issues'] else 'pass'
 except Exception as exc:result['status']='incomplete';result['issues'].append(type(exc).__name__+': '+str(exc))
 return result

def inspect_scene_provenance(scene):
 """Check the reviewed scene, color gate, and every direct composition input."""
 result={'status':'flag','issues':[],'checks':[],'evidence_files':[],'composition_chain':[],'generation_evidence':[]};issues=result['issues']
 def check(entry,label,package=False):
  if not isinstance(entry,dict) or not entry.get('path') or not entry.get('sha256'):
   issues.append('missing provenance: '+label);return False
  p=Path(entry['path']);ok=p.is_file() and sha(p)==entry['sha256']
  result['checks'].append({'role':label,'path':str(p),'sha256_matches':ok})
  if not ok:issues.append('missing or changed provenance: '+label)
  elif package:result['evidence_files'].append({'role':label,'path':str(p.resolve()),'sha256':entry['sha256']})
  return ok
 def key(entry):
  if not isinstance(entry,dict) or not entry.get('path') or not entry.get('sha256'):return None
  return str(Path(entry['path']).resolve()),entry['sha256']
 def evidence_json(pointer,label):
  # Existing registries use a path; new pointers may additionally freeze its hash.
  entry=pointer if isinstance(pointer,dict) else {'path':pointer}
  if not entry.get('path') or not Path(entry['path']).is_file():
   issues.append('missing evidence: '+label);return None,None
  entry=dict(entry);entry.setdefault('sha256',sha(entry['path']))
  if not check(entry,label,True):return None,None
  return load(entry['path']),entry
 try:
  if not isinstance(scene,dict):raise ValueError('invalid scene provenance')
  check(scene,'scene')
  rr,_=evidence_json(scene.get('root_review'),'scene.root_review')
  if rr is not None and (rr.get('status')!='approved' or rr.get('reviewer')!='root' or rr.get('sha256')!=scene.get('sha256')):issues.append('scene review is not approved for this hash')
  cr,cr_entry=evidence_json(scene.get('color_review'),'scene.color_review')
  if cr is not None:
   if cr.get('status')!='approved' or cr.get('reviewer')!='root' or cr.get('sha256')!=scene.get('sha256'):issues.append('scene color review is not approved for this hash')
   notes=cr.get('notes')
   if not ((isinstance(notes,str) and notes.strip()) or (isinstance(notes,list) and notes and all(isinstance(n,str) and n.strip() for n in notes))):issues.append('scene color review requires root notes explaining threshold handling')
   report=cr.get('automated_report')
   if check(report,'scene.color_review.automated_report',True):
    color_data=load(report['path'])
    if not isinstance(color_data,dict):issues.append('automated color report must be a JSON object')
    elif key(color_data.get('image'))!=key(scene):issues.append('automated color report is not for the current scene image')
    else:
     color_rows=color_data.get('rows',[])
     if not color_rows:issues.append('automated color report has no measured colors')
     for i,row in enumerate(color_rows):
      for role in ('reference','sample_mask'):
       check(row.get(role),f'scene.color_samples[{i}].{role}',True)
   result['color_review']={'path':cr_entry['path'],'sha256':cr_entry['sha256'],'review':cr}
  generation=scene.get('generation_result');additional=scene.get('additional_generation_results',[])
  if not generation:issues.append('scene generation result missing')
  if not isinstance(additional,list):issues.append('additional_generation_results must be a list');additional=[]
  generation_paths=([generation] if generation else [])+additional
  expected_generations={str(Path(p).resolve()) for p in generation_paths};generated=[]
  if len(expected_generations)!=len(generation_paths):issues.append('duplicate scene generation results')
  for path in generation_paths:
   if not Path(path).is_file():issues.append('generation result missing: '+str(path));continue
   evidence=inspect_evidence(Path(path).parent);result['generation_evidence'].append(evidence)
   if evidence['status']!='pass':issues.append('generation evidence invalid: '+str(path))
   record=load(path);output_entry=record.get('outputs',{}).get('generated');check(output_entry,'generation_output');generated.append(output_entry)
  produced={key(x) for x in generated if key(x) is not None}
  visited=set()
  def composition(pointer,expected_output,depth=0):
   if depth>=64:issues.append('composition ancestry exceeds 64 layers');return
   c,entry=evidence_json(pointer,'composition.provenance')
   if c is None:return
   path=str(Path(entry['path']).resolve())
   if path in visited:issues.append('composition ancestry cycle: '+path);return
   visited.add(path);result['composition_chain'].append({'path':path,'sha256':entry['sha256'],'depth':depth})
   for name in ('source_original','mask','output'):check(c.get(name),'composition.'+name,True)
   if key(c.get('output'))!=key(expected_output):issues.append('composition output does not match direct downstream input: '+path)
   if 'source_liquid_repair' in c:
    check(c['source_liquid_repair'],'composition.source_liquid_repair',True)
    if key(c['source_liquid_repair']) not in produced:issues.append('composition source has no matching generation result: source_liquid_repair')
   extras=c.get('additional_sources',[])
   if not isinstance(extras,list):issues.append('composition.additional_sources must be a list')
   else:
    for i,source in enumerate(extras):check(source,'composition.additional_sources['+str(i)+']',True)
   recorded=c.get('generation_results')
   if not isinstance(recorded,list) or {str(Path(p).resolve()) for p in recorded}!=expected_generations:issues.append('composition generation result list mismatch: '+path)
   upstream=c.get('upstream_composition_provenance')
   if upstream:composition(upstream,c.get('source_original'),depth+1)
   elif key(c.get('source_original')) not in produced:issues.append('composition source_original has no matching generation result or upstream composition: '+path)
  if scene.get('composition_provenance'):
   composition(scene['composition_provenance'],scene)
   result['composition_provenance']=scene['composition_provenance']
  elif key(scene) not in produced:issues.append('scene does not match generation output')
  result['status']='flag' if issues else 'pass'
 except Exception as exc:issues.append(type(exc).__name__+': '+str(exc))
 return result

def inspect_provenance(folder, rec, output):
 """Verify the frozen source chain in the submitted input configuration."""
 result={'status':'flag','issues':[],'checks':[]}; issues=result['issues']
 try:
  config=load(Path(folder)/'input_config.json'); prov=config['provenance']; identity=rec['identity']
  for role in ('reference','generated','generated_mask'):
   value=config.get(role); recorded=identity.get('inputs',{}).get(role)
   if value and (not recorded or str(Path(value).resolve())!=str(Path(recorded.get('path','')).resolve())):issues.append('configuration/identity input mismatch: '+role)
  def check(entry, label):
   if not isinstance(entry,dict) or not entry.get('path') or not entry.get('sha256'):
    issues.append('missing provenance: '+label);return False
   p=Path(entry['path']);ok=p.is_file() and sha(p)==entry['sha256']
   result['checks'].append({'role':label,'path':str(p),'sha256_matches':ok})
   if not ok:issues.append('missing or changed provenance: '+label)
   return ok
  for role in ('source_template','layout_preview','layout_manifest'):check(prov.get(role),role)
  extras=prov.get('additional_sources')
  if not isinstance(extras,list):issues.append('additional_sources must be a list')
  else:
   for i,entry in enumerate(extras):check(entry,'additional_sources['+str(i)+']')
  preview=prov.get('layout_preview',{}).get('path')
  if preview and Path(preview).is_file():
   with Image.open(output) as actual,Image.open(preview) as expected:
    actual=actual.convert('RGB');expected=expected.convert('RGB')
    if actual.size!=expected.size:issues.append('preview/output dimensions differ')
    else:
     diff=ImageChops.difference(actual,expected);maximum=max(x[1] for x in diff.getextrema());result['preview_max_channel_difference']=maximum
     if maximum>1:issues.append('output differs from CPU preview by more than one level')
  scene=prov.get('scene')
  if scene is None:result['upstream_kind']='static_layout'
  elif not isinstance(scene,dict):issues.append('invalid scene provenance')
  else:
   result['upstream_kind']='generated_scene';scene_result=inspect_scene_provenance(scene)
   issues.extend(scene_result['issues']);result['checks'].extend(scene_result['checks'])
   for name in ('generation_evidence','composition_provenance','composition_chain','color_review','evidence_files'):
    if name in scene_result:result[name]=scene_result[name]
  result['status']='flag' if issues else 'pass'
 except Exception as exc:issues.append(type(exc).__name__+': '+str(exc))
 return result

def font(size):
 for name in ['/System/Library/Fonts/STHeiti Medium.ttc','/System/Library/Fonts/Supplemental/Arial Unicode.ttf']:
  try:return ImageFont.truetype(name,size)
  except OSError:pass
 return ImageFont.load_default()
def tile(row,width=220,height=240):
 im=Image.new('RGB',(width,height),'white');d=ImageDraw.Draw(im);title=f"{row['shop']} {row['module_id']} {row['title']}";d.text((6,5),title,font=font(15),fill='#18252c')
 if row['path']:
  try:
   with Image.open(row['path']) as src:
    src=ImageOps.exif_transpose(src).convert('RGB');src.thumbnail((width-12,height-48),Image.Resampling.LANCZOS);im.paste(src,((width-src.width)//2,27+(height-48-src.height)//2))
  except Exception:d.text((8,70),'文件读取失败',font=font(16),fill='#9c2828')
 else:d.text((8,70),'待生成',font=font(17),fill='#777777')
 visual='已复核' if row.get('visual_status')=='approved_via_reviewed_preview' else '待审核'
 d.text((6,height-20),'技术: '+row['technical_status']+'  视觉: '+visual,font=font(12),fill='#35404a');return im

def sheet(rows,path,cols):
 cw,ch=220,240;nr=max(1,(len(rows)+cols-1)//cols);canvas=Image.new('RGB',(cw*cols,ch*nr),'#e4e8e9')
 for idx,r in enumerate(rows):canvas.paste(tile(r),(idx%cols*cw,idx//cols*ch))
 canvas.save(path,quality=90,subsampling=0)

def main():
 p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,default=PLAN);p.add_argument('--delivery-root',type=Path,default=DELIVERY);p.add_argument('--report-dir',type=Path,default=REPORT);p.add_argument('--exports-root',type=Path,default=EXPORTS);p.add_argument('--generations-root',type=Path,default=GENERATIONS);a=p.parse_args();plan=load(a.plan);mods=plan.get('modules',[]);ids=[m.get('module_id') for m in mods]
 if len(mods)!=22 or len(set(ids))!=22 or set(ids)!={*(f'M{i:02}' for i in range(1,6)),*(f'D{i:02}' for i in range(1,16)),'D20','D21'}:raise ValueError('Plan must contain exactly expected 22 distinct modules')
 reportdir=a.report_dir.resolve();reportdir.mkdir(parents=True,exist_ok=True);root=a.delivery_root.resolve();export_index=collections.defaultdict(list);generation_index=collections.defaultdict(list)
 for pth in a.exports_root.rglob('result.json') if a.exports_root.is_dir() else []:
  try:
   r=load(pth);path=r.get('output_path') or r.get('identity',{}).get('output_path')
   if path:export_index[str(Path(path).resolve())].append(pth.parent)
  except (OSError,ValueError,TypeError):pass
 for pth in a.generations_root.rglob('result.json') if a.generations_root.is_dir() else []:
  try:
   r=load(pth);generated=r.get('outputs',{}).get('generated',{});path=generated.get('path')
   if path:generation_index[(str(Path(path).resolve()),generated.get('sha256'))].append(pth.parent)
  except (OSError,ValueError,TypeError):pass
 rows=[];unknown=[]
 for shop in ('A','B','C'):
  store=root/shop;found=collections.defaultdict(list)
  if store.is_dir():
   for path in store.rglob('*'):
    if not path.is_file() or path.suffix.lower() not in ('.png','.jpg','.jpeg','.webp','.tif','.tiff'):continue
    rel=path.relative_to(store)
    if any(part in ('04_工作流','03_对照审核','inputs','generation','export') for part in rel.parts):continue
    match=ID_RE.match(path.stem)
    if match and match.group(1).upper() in ids:found[match.group(1).upper()].append(path)
    else:unknown.append({'shop':shop,'path':str(path),'issue':'unmatched image filename'})
  for m in mods:
   mid=m['module_id'];title=m['title'];r={'shop':shop,'module_id':mid,'title':title,'path':None,'technical_status':'incomplete','visual_status':'pending_root_review','issues':[],'warnings':[]};candidates=found.get(mid,[])
   if not candidates:r['issues'].append('missing deliverable');rows.append(r);continue
   if len(candidates)!=1:r['issues'].append('multiple matching deliverables');r['candidates']=[str(p) for p in candidates];rows.append(r);continue
   path=candidates[0];r['path']=str(path);r['relative_path']=str(path.relative_to(store));r['sha256']=sha(path)
   expected_folder='主图' if mid.startswith('M') else ('尺寸标注' if mid in ('D20','D21') else '详情图')
   if not any(expected_folder in part for part in path.relative_to(store).parts[:-1]):r['warnings'].append('expected Chinese category directory: '+expected_folder)
   if not CJK.search(path.stem):r['warnings'].append('filename lacks Chinese module label')
   if title not in path.stem:r['warnings'].append('filename does not contain plan title; verify label: '+title)
   try:
    with Image.open(path) as im:
     im.load();r.update(format=im.format,mode=im.mode,size=list(im.size)); rgb=ImageOps.exif_transpose(im).convert('RGBA');rh=hashlib.sha256();rh.update(f'{rgb.width}x{rgb.height}:RGBA:'.encode());rh.update(rgb.tobytes());r['decoded_pixel_sha256']=rh.hexdigest()
    if r['format']!='PNG' or path.suffix.lower()!='.png':r['issues'].append('expected PNG format and extension')
    if r['mode'] not in ('RGB','RGBA'):r['issues'].append('expected RGB or RGBA mode')
    expected=m['source_size_px'];r['expected_size']=expected
    if r['size']!=expected:r['issues'].append('dimensions differ from plan source_size_px')
   except Exception as exc:r['issues'].append('image decode failed: '+str(exc));rows.append(r);continue
   evidences=export_index.get(str(path.resolve()),[])
   if len(evidences)!=1:r['export_evidence']={'status':'incomplete','matching_runs':len(evidences),'issue':'expected exactly one result matching output path'};r['issues'].append('Comfy export evidence missing or ambiguous')
   else:
    r['export_evidence']=inspect_evidence(evidences[0],path,r['sha256'])
    if r['export_evidence']['status']!='pass':r['issues'].append('Comfy export evidence incomplete or inconsistent')
    try:
     rec=load(evidences[0]/'result.json');r['export_method']=rec.get('method')
     r['upstream_generation_evidence']=inspect_provenance(evidences[0],rec,path)
     cfg=load(evidences[0]/'input_config.json');review=cfg.get('root_review',{});preview=cfg.get('provenance',{}).get('layout_preview',{});chain=r['upstream_generation_evidence']
     if review.get('status')=='approved' and review.get('reviewer')=='root' and review.get('preview_sha256') and review['preview_sha256']==preview.get('sha256') and any(c.get('role')=='layout_preview' and c.get('sha256_matches') for c in chain.get('checks',[])) and chain.get('preview_max_channel_difference',2)<=1:
      r['visual_status']='approved_via_reviewed_preview'
     if r['upstream_generation_evidence']['status']!='pass':r['issues'].append('source provenance or CPU preview comparison failed')
    except Exception as exc:r['issues'].append('could not inspect provenance: '+str(exc))
   r['technical_status']='flag' if r['issues'] else ('warning' if r['warnings'] else 'pass');rows.append(r)
 # A duplicate is reported only when identical content appears in different shops.
 duplicates=[]
 for kind in ('sha256','decoded_pixel_sha256'):
  groups=collections.defaultdict(list)
  for row in rows:
   if row.get(kind):groups[row[kind]].append(row)
  for digest,group in groups.items():
   if len({r['shop'] for r in group})>1:
    item={'type':'byte_identical' if kind=='sha256' else 'decoded_pixel_identical','sha256':digest,'members':[{'shop':r['shop'],'module_id':r['module_id'],'path':r['path']} for r in group]};duplicates.append(item)
    for r in group:r['warnings'].append('identical content also occurs in another shop');r['technical_status']='warning' if r['technical_status']=='pass' else r['technical_status']
 categories={'主图':[m['module_id'] for m in mods if m['module_id'].startswith('M')],'详情图':[m['module_id'] for m in mods if m['module_id'].startswith('D') and m['module_id'] not in ('D20','D21')],'尺寸参数':['D20','D21']};sheets={}
 for shop in ('A','B','C'):
  for category,mids in categories.items():
   subset=[r for r in rows if r['shop']==shop and r['module_id'] in mids];path=reportdir/f'{shop}_{category}_接触表.jpg';sheet(subset,path,cols=3);sheets[f'{shop}_{category}']=str(path)
 for category,mids in categories.items():
  subset=[next(r for r in rows if r['shop']==shop and r['module_id']==mid) for mid in mids for shop in ('A','B','C')];path=reportdir/f'三店横向_{category}.jpg';sheet(subset,path,cols=3);sheets['三店横向_'+category]=str(path)
 counts={shop:{'expected':22,'files_found':sum(bool(x['path']) for x in rows if x['shop']==shop),'pass':sum(x['technical_status']=='pass' for x in rows if x['shop']==shop),'warnings':sum(x['technical_status']=='warning' for x in rows if x['shop']==shop),'flagged':sum(x['technical_status']=='flag' for x in rows if x['shop']==shop),'incomplete':sum(x['technical_status']=='incomplete' for x in rows if x['shop']==shop)} for shop in ('A','B','C')}
 snapshot={'generated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'plan':str(a.plan.resolve()),'plan_sha256':sha(a.plan),'delivery_root':str(root),'plan_proposed_delivery_root':plan.get('proposed_delivery_root'),'root_mismatch':str(root)!=str(Path(plan.get('proposed_delivery_root','')).resolve()),'counts':counts,'items':rows,'cross_shop_duplicates':duplicates,'unmatched_images':unknown,'contact_sheets':sheets,'scope_limitations':['A technical pass is not visual approval; every image remains pending root visual review.','PNG filename/category/title checks are conventions; warnings require human review.','Identical-file checks do not detect visually similar or semantically equivalent images.','Static and generated inputs are classified from the submitted provenance; technical verification does not establish visual correctness.','Measurements and report claims are not verified by this script.'],'status':'incomplete' if any(x['technical_status'] in ('flag','incomplete') for x in rows) else ('warning' if duplicates or any(x['warnings'] for x in rows) else 'technical_pass_visual_pending')}
 snapshot['scope_limitations'][0]='Technical checks verify recorded root preview approvals and pixel correspondence; they do not create visual approval.'
 if snapshot['status']=='technical_pass_visual_pending' and all(x['visual_status']=='approved_via_reviewed_preview' for x in rows):
  snapshot['status']='technical_and_root_visual_pass'
 if snapshot['root_mismatch']:snapshot['status']='incomplete'
 out=reportdir/'audit.json';out.write_text(json.dumps(snapshot,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':snapshot['status'],'counts':counts,'report':str(out),'contact_sheets':len(sheets),'root_mismatch':snapshot['root_mismatch']},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
