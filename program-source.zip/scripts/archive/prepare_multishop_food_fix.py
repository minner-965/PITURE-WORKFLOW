
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission multishop --legacy prepare_multishop_food_fix -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[2];W=R/'work/diagnostics/multishop_20261103/scene_inputs';ref=R/'work/diagnostics/multishop_20261103/generation/A_food_v1/af4db2e327313c058b9a4ee6/downloads/23_0_af4db2e327313c058b9a4ee6_00001_.png';c=json.loads((W/'A_food_v1.json').read_text());c.update(job_id='A_food_liquid_fix_v1',reference1=str(ref),reference1_source=str(ref),seed=20261105001)
p='Edit image 1. The front red bowl contains thin translucent reddish-brown liquid red bean broth, a level smooth flowing surface with a few small beans submerged just beneath it. The right blue bowl contains thin very dark charcoal-black sesame soup, a flat continuous glossy liquid surface with one soft broad window reflection. Both liquid surfaces are level and visibly wet. The other three foods and the five physical bowls remain in the same positions. The physical bowls retain their exact deep rounded shape, white collars and flat side tabs. Preserve the same wood table, background, lighting and camera view.'
c['prompt']=p;c['root_input_review']={'status':'approved','reviewer':'root','prompt_sha256':hashlib.sha256(p.encode()).hexdigest(),'reference1_sha256':hashlib.sha256(ref.read_bytes()).hexdigest(),'reference2_sha256':hashlib.sha256(Path(c['reference2']).read_bytes()).hexdigest(),'note':'Fix only selected red and blue food interiors; root will review and composite accepted liquid surfaces within their existing boundaries. Original five-bowl scene geometry remains authoritative.'};(W/'A_food_liquid_fix_v1.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
