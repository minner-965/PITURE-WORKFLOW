"""Prepare the five root-reviewed HD listing references; no GPU submission."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission master --legacy prepare_hd_main_jobs -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
import hashlib,json
from PIL import Image

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'work/diagnostics/taobao_replica_hd_20261103/main_inputs'
OUT.mkdir(parents=True,exist_ok=True)
BASE=ROOT/'output/TAOBAO_REPLICA_HD_20261103/01_参考底稿/主图'
template=json.loads((ROOT/'work/diagnostics/taobao_replica_hd_20261103/D07_hd_input/job.json').read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
intro='Recreate the complete square product advertisement in image 1 with the same layout, object positions, object scale, camera angle, background, and lighting. Image 2 is the physical product shape reference: deep rounded melamine bowl, white interior and white upper collar, thin opening edge, low circular foot, two solid flat horizontal tab handles. Match image 1 closely. '
prompts=[
 'A cropped adult in a dark grey knitted apron holds the two side tabs of a yellow bowl with both hands, lifting it just above a green bowl stacked on a red bowl on a round ridged bamboo mat. In the front left is one blue bowl containing a blue spoon; front right is one orange bowl containing orange peach pieces and a red jujube in clear syrup. There are exactly five bowls. A small square potted succulent sits behind the blue bowl, an orange spoon lies on the wood table at the bottom. Warm restaurant background. Retain the orange and white circular label at upper left and the orange and black information band along the bottom.',
 'There are exactly seven bowls against a sage green wall on a pale stone table. The two back stacks stand on a rectangular wooden tray: two red bowls at left, the top containing whole red beans in red bean soup; two blue bowls at right, the top containing white milk soup and pale pieces. Front row: one yellow bowl with beige sweet soup and a small dry golden topping on the left; one green bowl with smooth thick green soup in the middle; one orange bowl with distinct mango cubes in bright mango soup on the right. One yellow spoon lies at lower left, and two small translucent yellow and purple decorative cubes sit near the bottom. Continuous natural lighting across the entire green wall and tabletop. Large black Chinese title at upper left.',
 'A white studio product advertisement with a beige top heading. On the left stands the original wooden clipboard containing the inspection report from image 1. On the right is one stack of exactly five empty bowls, from top to bottom yellow, orange, blue, green, red. White interiors face upward, both solid flat tab handles visible. Match the reference report board and the soft grounded shadows.',
 'A white three-row product feature collage with the exact photograph blocks and typography positions of image 1. Upper left photograph: one upright orange bowl, three-quarter view. Middle right photograph: a close crop of a stack of bowls with yellow above orange above blue; the product extends through the right crop edge. Bottom left photograph: one blue bowl turned upside down, its circular raised foot and two solid flat side tabs visible. Keep the exact placement of all three photo rectangles and surrounding Chinese typography.',
 'A beige product customization poster with the same exact layout as image 1. Two separate rounded photo panels near the top show the same upright orange bowl and white interior, left with grey Chinese lettering inside the bowl and right with red Chinese lettering. Keep the two bowls identical in size, shape, and angle. Below them are small orange caption pills, a customization notice, three text lines, an orange heading band, and the original framed inspection-report collage with a magnifying glass at the bottom. Retain all object and graphic positions.'
]
manifest=[]
for i,desc in enumerate(prompts,1):
 ident=f'M{i:02d}'
 source=BASE/f'HD_{i:02d}_商品画布_参考.png'
 ref=OUT/'M02_overlay_recovered.png' if i==2 else source
 c=dict(template)
 c.update(job_id=f'{ident}_HD_dualref_800',reference1=str(ref),reference1_source=str(source),prompt=intro+desc,seed=20261103200+i,width=800,height=800,test_only=False)
 c['evidence_files']=[str(ROOT/'output/TAOBO_REPLICA_HD_20261103/01_参考底稿/manifest.json')] if False else [str(ROOT/'output/TAOBAO_REPLICA_HD_20261103/01_参考底稿/manifest.json')]
 c['root_input_review']={'status':'approved','reviewer':'root','prompt_sha256':hashlib.sha256(c['prompt'].encode()).hexdigest(),'reference1_sha256':sha(ref),'reference2_sha256':sha(c['reference2']),'note':'Root inspected all five 615px square HD crops. M02 white UI veil inverted with alpha=0.4 at [93,0,379,286], visually checked. Chinese/report layers will be restored deterministically after generation.'}
 path=OUT/f'{ident}.json';path.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
 manifest.append({'id':ident,'job':str(path),'reference':str(ref),'reference_sha256':sha(ref)})
(OUT/'batch.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(OUT/'M02_recovery.json').write_text(json.dumps({'source':str(BASE/'HD_02_商品画布_参考.png'),'source_sha256':sha(BASE/'HD_02_商品画布_参考.png'),'output':str(OUT/'M02_overlay_recovered.png'),'output_sha256':sha(OUT/'M02_overlay_recovered.png'),'region_xyxy':[93,0,379,286],'assumed_ui_white_alpha':0.4,'formula':'clip(round((observed-102)/0.6),0,255)','evidence':'right vertical edge RGB contrast factor approximately .6; root visual inspection continuous scene and black text','limitation':'8bit veil inversion introduces quantization; used as generative input'} ,ensure_ascii=False,indent=2)+'\n')
print(OUT/'batch.json')
