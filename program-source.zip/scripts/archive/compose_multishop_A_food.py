
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission layout --legacy compose_multishop_A_food -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import json,hashlib
R=Path(__file__).resolve().parents[2];G=R/'work/diagnostics/multishop_20261103/generation';W=R/'work/diagnostics/multishop_20261103/accepted_scenes';W.mkdir(parents=True,exist_ok=True)
a=G/'A_food_v1/af4db2e327313c058b9a4ee6/downloads/23_0_af4db2e327313c058b9a4ee6_00001_.png';b=G/'A_food_liquid_fix_v1/5475accd879b6a2798729b94/downloads/23_0_5475accd879b6a2798729b94_00001_.png'
old=Image.open(a).convert('RGB');new=Image.open(b).convert('RGB');m=Image.new('L',old.size);d=ImageDraw.Draw(m);d.rectangle((444,187,730,400),fill=255);d.polygon([(0,340),(303,340),(303,463),(230,463),(230,571),(0,571)],fill=255);m=m.filter(ImageFilter.GaussianBlur(4));out=Image.composite(old,new,m);p=W/'A_food_composed.png';out.save(p);mask=W/'A_food_restore_green_yellow_mask.png';m.save(mask)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
prep={'method':'composite_original_green_yellow_objects_over_liquid_repair','source_original':{'path':str(a),'sha256':sha(a)},'source_liquid_repair':{'path':str(b),'sha256':sha(b)},'mask':{'path':str(mask),'sha256':sha(mask)},'feather_px':4,'output':{'path':str(p),'sha256':sha(p)},'generation_results':[str(a.parents[1]/'result.json'),str(b.parents[1]/'result.json')],'status':'pending_root_review'};(W/'A_food_composition.json').write_text(json.dumps(prep,ensure_ascii=False,indent=2)+'\n')
