#!/usr/bin/env python3
"""Generate internal static layout previews; no Comfy submission or final export.

Static modules are internal previews; scene modules require available inputs.
Reuses reviewed source-image and dimension components; no GPU submission.
"""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission layout --legacy render_multishop_layouts -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
import argparse, hashlib, json
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageFilter

ROOT=Path(__file__).resolve().parents[2]
PLAN=ROOT/'config/multishop_variants_20261103_plan.json'
OUT=ROOT/'work/diagnostics/multishop_20261103/layouts'
FONTPATH='/System/Library/Fonts/STHeiti Medium.ttc'
_original_text = ImageDraw.ImageDraw.text
def _checked_text(self, xy, text, fill=None, font=None, anchor=None, *args, **kwargs):
 bbox=self.textbbox(xy,text,font=font,anchor=anchor,stroke_width=kwargs.get('stroke_width',0))
 w,h=self._image.size
 if bbox[0]<0 or bbox[1]<0 or bbox[2]>w or bbox[3]>h:
  raise ValueError(f'Text outside image: {text!r} {bbox} in {(w,h)}')
 return _original_text(self,xy,text,fill=fill,font=font,anchor=anchor,*args,**kwargs)
ImageDraw.ImageDraw.text=_checked_text
THEMES={'A':{'bg':'#F5EEE2','accent':'#A2572D','sub':'#765646','card':'#FFFCF7'},
        'B':{'bg':'#F0F3ED','accent':'#496556','sub':'#53655A','card':'#FFFFFF'},
        'C':{'bg':'#EFF6FA','accent':'#387D9C','sub':'#526D7A','card':'#FFFFFF'}}

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()

def font(size):return ImageFont.truetype(FONTPATH,size)

def text_center(d,xy,text,f,fill,anchor='mm'):
 d.text(xy,text,font=f,fill=fill,anchor=anchor)

def title(d,shop,theme,title,subtitle,w):
 a=theme['accent']; sub=theme['sub']
 if shop=='A':
  d.rounded_rectangle((34,24,w-34,103),radius=28,fill=a);text_center(d,(w/2,62),title,font(37),'white');text_center(d,(w/2,123),subtitle,font(19),sub)
 elif shop=='B':
  d.text((44,30),title,font=font(38),fill=a);d.line((44,91,w-44,91),fill=a,width=2);d.text((46,104),subtitle,font=font(19),fill=sub)
 else:
  d.rounded_rectangle((30,26,w-92,105),radius=10,fill=theme['card']);d.rounded_rectangle((w-107,44,w-35,89),radius=8,fill=a);d.text((52,40),title,font=font(37),fill=a);d.text((52,112),subtitle,font=font(19),fill=sub)

def paste_fit(layer,source,box):
 x0,y0,x1,y1=box;im=ImageOps.contain(source.convert('RGB'),(x1-x0,y1-y0),Image.Resampling.LANCZOS);layer.alpha_composite(im.convert('RGBA'),(x0+(x1-x0-im.width)//2,y0+(y1-y0-im.height)//2));return [x0+(x1-x0-im.width)//2,y0+(y1-y0-im.height)//2,x0+(x1-x0+im.width)//2,y0+(y1-y0+im.height)//2]

def draw_M04(layer,shop,t,src):
 w,h=layer.size;d=ImageDraw.Draw(layer);title(d,shop,t,'贴心细节 彰显品质','出色细节满足挑剔的你',w)
 images=[src.crop((54,140,432,340)),src.crop((367,367,746,565)),src.crop((54,585,432,782))]
 words=[('面',['环保材质 · 安全健康','质感细腻光滑明亮','不易磨损 · 不掉色']),('边',['加厚边缘 · 釉面亮滑','边角平滑圆润','手工二次打磨']),('底',['底部加高防滑设计','平稳放置桌面','美观又实用'])]
 boxes=[]
 for i,(im,(label,body)) in enumerate(zip(images,words)):
  y=151+i*208;offset=16 if shop=='C' and i%2 else 0
  d.rounded_rectangle((30+offset,y,w-30,y+191),radius=20 if shop=='A' else 8,fill=t['card'],outline=t['accent'] if shop=='B' else None,width=1)
  image_left=(i%2==0) if shop!='C' else (i!=1)
  if shop=='B':image_left=(i%2==1)
  ib=(43+offset,y+12,405+offset,y+180) if image_left else (395,y+12,757,y+180)
  boxes.append(paste_fit(layer,im,ib));d=ImageDraw.Draw(layer)
  tx=430 if image_left else 58+offset
  d.text((tx,y+22),label,font=font(39),fill=t['accent'])
  for j,line in enumerate(body):d.text((tx,y+82+29*j),line,font=font(20),fill='#26302D')
 return boxes

def draw_D14(layer,shop,t):
 w,h=layer.size;d=ImageDraw.Draw(layer);title(d,shop,t,'五大保障','贴心服务 放心选购',w)
 rows=[('安全保障','大厂生产，值得信赖'),('运输保障','运输中破损包赔'),('使用保障','签收日起，使用15天内破损包赔'),('品质保障','加厚加固，抗摔耐用'),('服务保障','专业客服，在线解决问题')]
 for i,(name,body) in enumerate(rows):
  y=151+i*112;left=30+(18 if shop=='C' and i%2 else 0);right=w-30-(18 if shop=='C' and not i%2 else 0)
  d.rounded_rectangle((left,y,right,y+96),radius=24 if shop=='A' else 7,fill=t['card'],outline=t['accent'] if shop=='B' else None,width=1)
  if shop=='A':d.ellipse((left+17,y+19,left+75,y+77),fill=t['accent']);text_center(d,(left+46,y+48),str(i+1),font(25),'white');x=left+95
  elif shop=='B':d.line((left+17,y+15,left+17,y+81),fill=t['accent'],width=4);x=left+36
  else:d.rounded_rectangle((left+14,y+18,left+70,y+76),radius=8,fill=t['accent']);text_center(d,(left+42,y+47),str(i+1),font(25),'white');x=left+88
  d.text((x,y+10),name,font=font(29),fill=t['accent']);d.text((x,y+52),body,font=font(20),fill='#26302D')
 return []

def draw_D20(layer,shop,t,src):
 w,h=layer.size;d=ImageDraw.Draw(layer);title(d,shop,t,'产品参数','w1125 双耳碗 · 单只参数',w)
 top=src.crop((64,169,710,771));side=src.crop((64,818,710,1145))
 d.rounded_rectangle((28,148,w-28,1110),radius=22 if shop=='A' else 8,fill=t['card'])
 if shop=='B':boxes=[(48,150,702,490),(48,500,702,1110)];objects=[side,top]
 else:boxes=[(44 if shop=='A' else 59,153,706 if shop=='A' else 718,775),(44 if shop=='A' else 34,778,706 if shop=='A' else 690,1105)];objects=[top,side]
 placed=[paste_fit(layer,im,box) for im,box in zip(objects,boxes)]
 d=ImageDraw.Draw(layer);d.line((45,1140,w-45,1140),fill=t['accent'],width=2);text_center(d,(w/2,1190),'容量 550 ml  ·  重量 207 g  ·  6.5 英寸',font(23),'#26302D');text_center(d,(w/2,1250),'尺寸、容量与重量均为单只参数',font(21),t['sub']);return placed


def draw_D21(layer,shop,t):
 w,h=layer.size;d=ImageDraw.Draw(layer);title(d,shop,t,'商品参数','w1125 双耳碗 · 单只参数',w)
 rows=[('型号','w1125'),('颜色','红 / 橙 / 绿 / 黄 / 蓝（内白）'),('长 × 宽 × 高','16.5 × 12.8 × 8 cm'),('容量','550 ml'),('重量','207 g'),('尺寸','6.5 英寸')]
 if shop=='A':
  for i,(k,v) in enumerate(rows):
   y=150+i*75;d.rounded_rectangle((35,y,715,y+66),radius=16,fill=t['card']);d.text((58,y+16),k,font=font(25),fill=t['accent']);d.text((258,y+16),v,font=font(25),fill='#26302D')
 elif shop=='B':
  for i,(k,v) in enumerate(rows):
   y=148+i*74;d.line((45,y+64,705,y+64),fill=t['accent'],width=1);d.text((55,y+15),k,font=font(24),fill=t['accent']);d.text((260,y+15),v,font=font(24),fill='#26302D')
 else:
  for i,(k,v) in enumerate(rows):
   y=150+i*75;x=38+(16 if i%2 else 0);d.rounded_rectangle((x,y,712,y+66),radius=8,fill=t['card']);d.text((x+18,y+16),k,font=font(24),fill=t['accent']);d.text((x+220,y+16),v,font=font(24),fill='#26302D')
 d.text((42,620),'五色实拍展示',font=font(27),fill=t['accent'])
 sources=[]
 for i,color in enumerate(['red','orange','green','yellow','blue']):
  path=ROOT/'output/LISTING_V3/w1125/assets/empty_bowls'/f'{color}.png';im=Image.open(path).convert('RGBA');box=im.getchannel('A').getbbox();im=im.crop(box);im.thumbnail((125,115),Image.Resampling.LANCZOS);x=35+i*140+(125-im.width)//2;layer.alpha_composite(im,(x,695));d=ImageDraw.Draw(layer);text_center(d,(35+i*140+62,835),['红色','橙色','绿色','黄色','蓝色'][i],font(20),'#26302D');sources.append({'path':str(path),'sha256':sha(path),'alpha_bbox':list(box)})
 text_center(d,(w/2,945),'尺寸、容量与重量均为单只参数',font(21),t['sub']);return [],sources


def draw_logo(layer,shop,t,src,id):
 w,h=layer.size;d=ImageDraw.Draw(layer)
 if id=='M05':
  groups=[src.crop((75,0,725,113)),src.crop((97,115,403,410)),src.crop((405,115,710,410)),src.crop((100,418,705,563)),src.crop((80,565,725,800))]
  boxes=[(35,12,765,105),(38,108,390,395),(410,108,762,395),(45,398,755,548),(48,553,752,792)]
 else:
  groups=[src.crop((25,0,725,226)),src.crop((25,238,372,563)),src.crop((380,238,727,563)),src.crop((24,587,728,850))]
  boxes=[(32,12,718,218),(28,225,370,552),(380,225,722,552),(27,565,723,875)]
 if shop=='B':groups[1],groups[2]=groups[2],groups[1]
 if shop=='C':
  if id=='M05': boxes[1]=(38,115,388,395); boxes[2]=(412,108,762,388)
  else: boxes[1]=(28,230,365,552); boxes[2]=(385,225,722,547)
 placed=[]
 for im,box in zip(groups,boxes):placed.append(paste_fit(layer,im,box))
 return placed


def draw_preserved_source(layer,shop,t,src):
 # Preserve all source pixels within the image content; change the surrounding
 # information hierarchy and placement across stores without fabricating details.
 w,h=layer.size;d=ImageDraw.Draw(layer)
 if shop=='A':
  d.rounded_rectangle((12,12,w-12,h-12),radius=24,fill=t['card'])
  d.rounded_rectangle((30,24,w-30,68),radius=16,fill=t['accent'])
  text_center(d,(w/2,46),'w1125 双耳碗',font(23),'white')
  inner=(25,78,w-25,h-24)
 elif shop=='B':
  d.rectangle((12,12,w-12,h-12),fill=t['card'],outline=t['accent'],width=1)
  d.rectangle((20,20,68,h-20),fill=t['accent'])
  for i,c in enumerate('双耳粥碗'):
   text_center(d,(44,54+i*33),c,font(22),'white')
  inner=(78,22,w-24,h-22)
 else:
  d.rounded_rectangle((8,8,w-8,h-8),radius=8,fill=t['card'])
  d.rounded_rectangle((38,h-61,w-22,h-18),radius=8,fill=t['accent'])
  text_center(d,((w+16)/2,h-40),'w1125 双耳碗',font(23),'white')
  inner=(18,18,w-35,h-71)
 return [paste_fit(layer,src,inner)]


def draw_D01(layer,shop,t):
 w,h=layer.size;d=ImageDraw.Draw(layer);title(d,shop,t,'三大免费','厂家直销',w)
 text_center(d,(w/2,177),'货好又便宜 用的放心',font(27),'#26302D')
 text_center(d,(w/2,221),'店内餐具 均有套装',font(26),t['accent'])
 labels=['免费设计LOGO','免费印制店标','免费包邮']
 if shop=='B':
  for i,label in enumerate(labels):
   y=275+i*106;d.rounded_rectangle((55,y,695,y+85),radius=6,fill=t['card'],outline=t['accent'],width=2);d.text((100,y+24),label,font=font(29),fill=t['accent'])
 else:
  for i,label in enumerate(labels):
   x=30+i*240+(8 if shop=='C' and i==1 else 0);y=290+(25 if shop=='C' and i%2 else 0)
   d.rounded_rectangle((x,y,x+215,y+175),radius=20 if shop=='A' else 6,fill=t['card'],outline=t['accent'],width=2)
   parts=[label[:4],label[4:]] if len(label)>4 else [label]
   for j,line in enumerate(parts):text_center(d,(x+107,y+62+j*40),line,font(25),t['accent'])
 return []

def draw_real_blocks(layer,shop,t,src,id):
 w,h=layer.size
 if id=='M03':
  parts=[src.crop((60,0,745,162)),src.crop((58,256,465,785)),src.crop((465,405,776,785))]
  boxes=[(20,7,780,157),(20,160,444,790),(448,230,780,777)]
  if shop=='B':boxes[1],boxes[2]=(355,160,780,790),(18,230,350,777)
  if shop=='C':boxes[1],boxes[2]=(25,180,450,790),(460,250,780,795)
 elif id=='D03':
  parts=[src.crop((8,0,742,309)),src.crop((8,310,742,423)),src.crop((8,423,742,731))]
  boxes=[(15,10,735,300),(15,310,735,414),(15,425,735,748)]
  if shop=='B':parts[0],parts[2]=parts[2],parts[0]
  if shop=='C':boxes=[(26,15,724,291),(35,300,715,405),(15,414,735,745)]
 else:
  parts=[src.crop((0,0,750,256)),src.crop((0,256,374,482)),src.crop((375,256,750,482))]
  boxes=[(8,4,742,245),(12,257,367,500),(383,257,738,500)]
  if shop=='B':parts[1],parts[2]=parts[2],parts[1]
  if shop=='C':boxes=[(18,8,732,243),(25,258,370,500),(380,250,725,492)]
 return [paste_fit(layer,im,box) for im,box in zip(parts,boxes)]

def scene_image(shop,key):
 config=ROOT/'config/multishop_scene_assets.json'
 if not config.is_file():return None,'scene_config_missing'
 data=json.loads(config.read_text());entry=data.get(shop,{}).get(key)
 if not entry:return None,'scene_asset_missing'
 val=entry.get('path') if isinstance(entry,dict) else entry
 if not isinstance(val,str) or not val:return None,'scene_path_missing'
 path=Path(val);path=path if path.is_absolute() else ROOT/path
 if not path.is_file():return None,'scene_file_missing'
 if isinstance(entry,dict) and entry.get('sha256') and sha(path)!=entry['sha256']:raise ValueError('Scene hash mismatch: '+str(path))
 return path.resolve(),None


def draw_details(layer,shop,t,src,id):
 w,h=layer.size;d=ImageDraw.Draw(layer)
 content={'D10':('好清洗',['一抹一冲，好洗这件事','也是很重要的']),'D11':('不易脏',['高端保护层，釉面细腻','触感舒适柔和']),'D12':('光滑质感',['碗面光滑，边角平滑圆润','清洗很轻松'])}
 heading,lines=content[id];title(d,shop,t,heading,'贴心细节 彰显品质',w)
 if shop=='A': box=(40,235,w-70,h-55);tx=65
 elif shop=='B':box=(75,240,w-35,h-48);tx=45
 else:box=(45,240,w-45,h-50);tx=80
 d.text((tx,160),lines[0],font=font(24),fill='#26302D');d.text((tx,195),lines[1],font=font(24),fill='#26302D')
 if id=='D12':
  # Reviewed source image contains the complete photographed stack.
  path=ROOT/'input/supplied_20261102/测试品/详情页实拍/IMG_5889.jpg';original=ImageOps.exif_transpose(Image.open(path)).convert('RGB');ow,oh=original.size;crop=(round(ow*.685),round(oh*.43),round(ow*.97),round(oh*.64));stack=original.crop(crop);placed=[paste_fit(layer,stack,box)];return placed,[{'path':str(path),'sha256':sha(path),'crop_xyxy':list(crop)}]
 color={'A':'orange','B':'green','C':'blue'}[shop];path=ROOT/'output/LISTING_V3/w1125/assets/empty_bowls'/f'{color}.png';product=Image.open(path).convert('RGBA');alpha_box=product.getchannel('A').getbbox();product=product.crop(alpha_box)
 product.thumbnail((box[2]-box[0]-40,box[3]-box[1]-70),Image.Resampling.LANCZOS)
 x=(box[0]+box[2]-product.width)//2;y=(box[1]+box[3]-product.height)//2
 shadow=Image.new('RGBA',layer.size,(0,0,0,0));sd=ImageDraw.Draw(shadow);sd.ellipse((x+product.width*.12,y+product.height*.84,x+product.width*.90,y+product.height*.98),fill=(30,25,20,50));layer.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(10)));layer.alpha_composite(product,(x,y))
 return [[x,y,x+product.width,y+product.height]],[{'path':str(path),'sha256':sha(path),'alpha_bbox':list(alpha_box)}]


def draw_scene(layer,shop,t,src,id,path):
 # The new photo fills its own independent box. Never reuse old-layout masks.
 w,h=layer.size;d=ImageDraw.Draw(layer)
 texts={'M01':('连锁餐具直供',['A8耐高温 · 不掉色 · 多种颜色可选','logo定制   无毒无味   破损包赔']),
 'D02':('连锁餐具直供',['A8耐高温 · 不掉色 · 多种颜色可选','logo定制   无毒无味   破损包赔']),
 'M02':('密胺糖水碗',['发现食与器的美好关系']),
 'D05':('无毒无味',['健康光面易清洁','开启品味享受 · 小助手']),
 'D06':('产品展示',['PRODUCT DISPLAY','用心做好每一个餐具']),
 'D07':('',[]),'D08':('密胺食品级餐具',['MELAMINE','开启品味享受 · 小助手','QUALITY OF LIFE']),'D09':('',[])}
 heading,lines=texts[id];top=30
 if heading:
  title(d,shop,t,heading,lines[0] if lines else '',w);top=148
 footer=64 if len(lines)>1 else 24
 if len(lines)>1:
  for j,line in enumerate(lines[1:]):
   text_center(d,(w/2,h-footer+10+j*23),line,font(18),t['accent'])
 box=(24,top,w-24,h-footer-10)
 if shop=='B':box=(45,top,w-22,h-footer-10)
 elif shop=='C':box=(17,top,w-40,h-footer-10)
 scene=Image.open(path).convert('RGB');placed=paste_fit(layer,scene,box)
 return [placed],None


def main():
 ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['preview','all'],default='all');args=ap.parse_args();plan=json.loads(PLAN.read_text());assets={m['module_id']:m for m in plan['modules']};summary=[]
 scene_map={'M01':'hero','D02':'hero','M02':'food','D05':'food','D06':'empty','D09':'empty','D07':'flatlay','D08':'underside'}
 ids=['M04','D14','D20'] if args.stage=='preview' else list(assets)
 for shop in ['A','B','C']:
  folder=OUT/shop;folder.mkdir(parents=True,exist_ok=True);records=[];t=THEMES[shop]
  for id in ids:
   asset=assets[id];source=Path(asset['source_template']);
   if sha(source)!=asset['source_sha256']:raise ValueError('Template hash mismatch '+str(source))
   size=tuple(asset['source_size_px']);base=Image.new('RGBA',size,t['bg']);layer=Image.new('RGBA',size,(0,0,0,0));scene_path=None;scene_mask=None;extras=[]
   if id in scene_map:
    scene_path,reason=scene_image(shop,scene_map[id])
    if reason:
     record={'module_id':id,'status':'pending_scene_asset','scene_key':scene_map[id],'reason':reason,'dimensions':list(size),'output':None};records.append(record);summary.append({'shop':shop,**record});continue
   with Image.open(source) as im:
    im.load();im=im.convert('RGB')
    if id=='M04':boxes=draw_M04(layer,shop,t,im)
    elif id=='D14':boxes=draw_D14(layer,shop,t)
    elif id=='D20':boxes=draw_D20(layer,shop,t,im)
    elif id=='D21':boxes,extras=draw_D21(layer,shop,t)
    elif id=='D01':boxes=draw_D01(layer,shop,t)
    elif id in ('M03','D03','D04'):boxes=draw_real_blocks(layer,shop,t,im,id)
    elif id in ('D10','D11','D12'):boxes,extras=draw_details(layer,shop,t,im,id)
    elif id in ('M05','D13'):boxes=draw_logo(layer,shop,t,im,id)
    elif scene_path:boxes,scene_mask=draw_scene(layer,shop,t,im,id,scene_path)
    else:boxes=draw_preserved_source(layer,shop,t,im)
   for box in boxes:
    if len(box)!=4 or not (0<=box[0]<=box[2]<=size[0] and 0<=box[1]<=box[3]<=size[1]):raise ValueError(f'Image placement outside {shop}/{id}: {box}')
   composed=Image.alpha_composite(base,layer).convert('RGB');stem=folder/id;base.convert('RGB').save(str(stem)+'_background.png');layer.save(str(stem)+'_layer.png');layer.getchannel('A').save(str(stem)+'_mask.png');composed.save(str(stem)+'_preview.png')
   record={'module_id':id,'status':'internal_preview_pending_root','source':str(source),'source_sha256':asset['source_sha256'],'dimensions':list(size),'background':str(stem)+'_background.png','layer':str(stem)+'_layer.png','layer_mask':str(stem)+'_mask.png','preview':str(stem)+'_preview.png','placed_image_boxes':boxes,'additional_sources':extras,'generated_scene_used':bool(scene_path),'scene_path':str(scene_path) if scene_path else None,'scene_sha256':sha(scene_path) if scene_path else None,'scene_mask_path':scene_mask,'scene_mask_sha256':sha(scene_mask) if scene_mask else None,'visual_approval':None};records.append(record);summary.append({'shop':shop,**record})
  (folder/'manifest.json').write_text(json.dumps({'shop':shop,'theme':t,'scope':'内部布局预览；缺少场景时不产出该项','items':records},ensure_ascii=False,indent=2)+'\n')
 (OUT/'preview_manifest.json').write_text(json.dumps({'status':'pending_root_review','rendered_count':sum(x['status']=='internal_preview_pending_root' for x in summary),'pending_count':sum(x['status']=='pending_scene_asset' for x in summary),'scene_assets_config':'config/multishop_scene_assets.json','items':summary},ensure_ascii=False,indent=2)+'\n')
 print('internal previews:',sum(x['status']=='internal_preview_pending_root' for x in summary),'pending:',sum(x['status']=='pending_scene_asset' for x in summary))
if __name__=='__main__':main()
