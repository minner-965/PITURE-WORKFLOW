
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission layout --legacy multishop_B_hero_color_v4 -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
from PIL import Image
import numpy as np, json, hashlib
D=Path('/Users/luohuiwu/codex/ComfyProductPipeline/work/diagnostics/multishop_20261103');old=D/'blue_green_candidates_v3/B_hero';new=D/'blue_green_candidates_v4/B_hero';new.mkdir(parents=True,exist_ok=True)
c=json.loads((old/'composition.json').read_text());src=Path(c['source_original']['path']);a=np.array(Image.open(src).convert('RGB'));prior=np.array(Image.open(old/'candidate.png').convert('RGB'));mask=np.array(Image.open(old/'mask.png').convert('L'));green=np.array(Image.open(old/'green_mask.png').convert('L'));h,w=mask.shape; yy,xx=np.indices((h,w));zone=(yy>=719)&(yy<=734)&(xx>=520)&(xx<=543);bound=529+.8*(yy-720);weight=np.clip((xx-bound)/2,0,1);newgreen=green.copy();newgreen[zone]=np.minimum(green[zone],np.rint(255*weight[zone]).astype('uint8'));blue=np.array(Image.open(old/'blue_mask.png').convert('L'));newmask=np.maximum(blue,newgreen);ratio=np.ones((h,w),float);valid=zone&(mask>0);ratio[valid]=newmask[valid]/mask[valid];result=prior.copy();result[valid]=np.rint(a[valid].astype(float)+(prior[valid].astype(float)-a[valid].astype(float))*ratio[valid,None]).clip(0,255).astype('uint8')
Image.fromarray(result).save(new/'candidate.png');Image.fromarray(newmask).save(new/'mask.png');Image.fromarray(newgreen).save(new/'green_mask.png');Image.fromarray(blue).save(new/'blue_mask.png');overlay=Image.composite(Image.blend(Image.fromarray(a),Image.new('RGB',(w,h),(255,0,255)),.5),Image.fromarray(a),Image.fromarray(newmask));overlay.save(new/'overlay.png');out=Image.new('RGB',(w*2,h));out.paste(Image.fromarray(a),(0,0));out.paste(Image.fromarray(result),(w,0));out.save(new/'before_after.png')
box=(500,700,560,750);z=Image.new('RGB',(540,150));
for i,im in enumerate([Image.fromarray(a),Image.fromarray(prior),Image.fromarray(result)]):z.paste(im.crop(box).resize((180,150)),(i*180,0))
z.save(new/'local_original_v3_v4_3x.png')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();c['mask']={'path':str(new/'mask.png'),'sha256':sha(new/'mask.png')};c['output']={'path':str(new/'candidate.png'),'sha256':sha(new/'candidate.png')};c['status']='pending_root_visual_review';c['color_parameters']['v4_local_adjustment']={'reference_v3_candidate':{'path':str(old/'candidate.png'),'sha256':sha(old/'candidate.png')},'reference_v3_mask':{'path':str(old/'mask.png'),'sha256':sha(old/'mask.png')},'zone_xy':[520,719,543,734],'boundary':'x=529+0.8*(y-720); 2px inward feather','operation':'locally restore source as mask shrinks; other pixels retain exact v3 candidate'};c['outside_mask_exact']=not np.any(np.any(result!=a,axis=2)&(newmask==0));c['outside_changed_pixels']=int(np.sum(np.any(result!=a,axis=2)&(newmask==0)));c['pixels_differing_from_v3_outside_local_zone']=int(np.sum(np.any(result!=prior,axis=2)&(~zone)));(new/'composition.json').write_text(json.dumps(c,ensure_ascii=False,indent=2));print('outside_mask_changed',c['outside_changed_pixels'],'outside_local_changed',c['pixels_differing_from_v3_outside_local_zone'])
