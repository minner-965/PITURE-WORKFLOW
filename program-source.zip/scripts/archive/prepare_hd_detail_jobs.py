"""Prepare reference-anchored detail jobs from root-reviewed complete modules."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission master --legacy prepare_hd_detail_jobs -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
from PIL import Image
import hashlib,json,math
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'work/diagnostics/taobao_replica_hd_20261103/detail_inputs'
OUT.mkdir(exist_ok=True,parents=True)
MOD=ROOT/'output/TAOBAO_REPLICA_HD_20261103/01_参考底稿/详情/detail_modules'
manifest=json.loads((MOD/'manifest.json').read_text())
modules={m['module_id']:m for m in manifest['modules']}
template=json.loads((ROOT/'work/diagnostics/taobao_replica_hd_20261103/main_inputs/M01_refine_step2.json').read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
intro='Faithfully reconstruct image 1. Keep its exact camera angle, cropping, object contours, relative object sizes, positions, background colors, and graphic layout. Image 2 identifies the physical w1125 bowl: rounded deep colored melamine body, white interior, white upper collar, thin opening edge, low circular foot, and two solid flat horizontal tab handles. The composition and product orientation remain exactly as in image 1. '
descriptions={
 'A02':'An adult in a dark grey knit garment holds both side tabs of a yellow bowl above the green and red stacked bowls on a round ridged bamboo mat. The two hands and pose match image 1. Front left is a blue bowl containing a blue spoon. Front right is an orange bowl containing glossy orange peach chunks and one red jujube in syrup. Exactly five bowls, small succulent behind blue bowl, orange spoon on wooden table. Preserve the warm cafe scene, top-left orange badge and bottom orange-and-black information band.',
 'A05':'A sage green background with white headline at upper right and pale tabletop. Exactly eleven bowls: a back-center stack of five, red above green above yellow above orange above blue; a stack of two green bowls at middle left, with a green spoon inside the upper bowl; a separate red bowl and a separate orange bowl at middle right, each containing a white spoon with colored edge; two separate bowls in front, blue at left and green at right. All bowls empty except for the three spoons. Match the rounded frame and the original soft daylight.',
 'A06':'A two-photo product collage on white. The large left photo shows a cropped five-color bowl stack at the back, a succulent plant to its left, and one empty red bowl in front. The narrower upper-right photo shows one empty orange bowl viewed from above, a cropped colored stack at upper left, and an orange spoon at upper right. Keep the original photo edges, the right-hand PRODUCT DISPLAY title, the Chinese product display heading, and all white gaps.',
 'A07':'A top-down photograph on pale stone showing exactly six bowls. Five are upside down: partially cropped orange at top, yellow upper left, red upper right, blue middle left, green middle right. Their small circular raised foot rings face the camera. One white-interior bowl faces upward at bottom center. A small potted succulent is bottom left and a red soup spoon is bottom right. Preserve the original boundaries and the amount of bowl cropping at the top and sides.',
 'A08':'A white heading panel reading MELAMINE above a rounded sage-green scene. In the scene a stack of five empty bowls at left has red, green, yellow, orange, blue from top to bottom. At right a hand holds an upside-down orange bowl by its right tab above a stack with blue over green. One empty red bowl is at the front, a small succulent is left, and a red soup spoon is front right. Exactly nine bowls including the hand-held orange bowl. Preserve the orange underside facing the camera, the hand pose, the green backdrop and pale table.',
 'B02':'A white feature card with the existing heading and Chinese text positions. One orange bowl stands upright at a three-quarter top view, inside a pale grey teardrop-shaped photo cutout. Its white interior and white collar have the exact thin edge and flat tab handles seen in image 1. The red square number 1 stays at the bottom-right of the photograph. Preserve the original drop outline, shadows, and whitespace.',
 'C01':'A white feature card with the original Chinese heading and caption at upper left. One red bowl stands upright in a near-level side view, inside the pale grey teardrop photo. The shallow visible elliptical opening, thin white collar and two horizontal side tabs match image 1. Retain the deep rounded red body and its low foot. The red square number 2 stays at lower left.',
 'C02':'A white feature card with Chinese heading and caption at upper right. Inside a pale grey teardrop photo is a tight close-up of a five-bowl stack, from top to bottom yellow, orange, blue, green, red. The top white interior opening faces upward. The red bowl is cropped by the bottom photo boundary. Keep exact side-tab shape, white collar widths, crop, and red square number 3 at lower right.',
 'C03':'A white customization card with its original Chinese heading, red subtitle pill, two rounded tan photo panels, and tan notice box. Both panels show the same upright orange bowl, identical in size and camera angle, white interior and collar, deep orange body, solid flat tabs. The left bowl has grey Chinese lettering on the inner back wall and the right bowl has red Chinese lettering in exactly the same place. Preserve exact panels, text, margins, shadows, and all graphic positions.'
}
batch=[]
for i,(key,desc) in enumerate(descriptions.items()):
 m=modules[key];source=Path(m['output']);im=Image.open(source).convert('RGB')
 width=800;scaled_h=round(im.height*width/im.width);height=math.ceil(scaled_h/16)*16
 scaled=im.resize((width,scaled_h),Image.Resampling.LANCZOS)
 canvas=Image.new('RGB',(width,height),'white');canvas.paste(scaled,(0,0))
 folder=OUT/key;folder.mkdir(exist_ok=True);ref=folder/'reference_canvas.png';canvas.save(ref)
 prep={'module':key,'source':str(source),'source_sha256':sha(source),'source_size':list(im.size),'source_crop_in_strip':m['source_bbox_xyxy'],'scaled_size':[width,scaled_h],'canvas_size':[width,height],'paste_xy':[0,0],'operation':'uniform Lanczos scale, white padding only at bottom','content_crop_xyxy':[0,0,width,scaled_h]}
 pp=folder/'preparation.json';pp.write_text(json.dumps(prep,ensure_ascii=False,indent=2)+'\n')
 c=dict(template);c.update(job_id=f'D_{key}_HD_refine_step2',reference1=str(ref),reference1_source=str(source),prompt=intro+desc,seed=20261103300+i,width=width,height=height,start_step=2,evidence_files=[str(pp)],test_only=False)
 c['root_input_review']={'status':'approved','reviewer':'root','prompt_sha256':hashlib.sha256(c['prompt'].encode()).hexdigest(),'reference1_sha256':sha(ref),'reference2_sha256':sha(c['reference2']),'note':'Root inspected complete 15-module overview and approved whitespace cutline corrections. Preserve layout with reference-initialized refinement; typography restored from the source in a deterministic Comfy composite. Run after M01 init test review.'}
 jp=folder/'job.json';jp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');batch.append({'module':key,'job':str(jp),'preparation':str(pp)})
(OUT/'batch.json').write_text(json.dumps(batch,ensure_ascii=False,indent=2)+'\n')
print(OUT/'batch.json')
