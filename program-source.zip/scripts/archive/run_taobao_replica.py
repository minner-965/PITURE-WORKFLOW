#!/usr/bin/env python3
"""Reference-image FLUX Fill reconstruction with durable submission and provenance."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission multishop --legacy run_taobao_replica -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

import argparse, hashlib, json, re, shutil, subprocess, time
from pathlib import Path
import numpy as np
from PIL import Image
from build_workflows import ROOT,make_a,node,check_graph,ui
from comfy_client import ComfyClient,sync_ui

WF=ROOT/'workflows/taobao_replica'
LOGS=ROOT/'work/diagnostics/taobao_replica_20261103/runs'
BACKEND_LOG=ROOT/'work/diagnostics/headless_backend_20261103/comfyui.log'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(path,obj):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def options(info,node_name,key):
 spec=info[node_name]['input']['required'][key]
 return spec[1].get('options',[]) if spec[0]=='COMBO' else spec[0]
def graph_for(cfg,revision):
 g=make_a()
 for k in ('3','14','16','17','18'):g.pop(k)
 g['1']['inputs']['image']='ComfyProductPipeline/replica_reference.png';g['2']['inputs'].update(image='ComfyProductPipeline/replica_mask.png',channel='red')
 g['20']=node('ImageScale','SCALE_REFERENCE',image=['1',0],upscale_method='lanczos',width=cfg['width'],height=cfg['height'],crop='disabled')
 g['21']=node('MaskToImage','MASK_TO_IMAGE',mask=['2',0]);g['22']=node('ImageScale','SCALE_FULL_MASK',image=['21',0],upscale_method='nearest-exact',width=cfg['width'],height=cfg['height'],crop='disabled');g['23']=node('ImageToMask','MASK_TO_CHANNEL',image=['22',0],channel='red')
 g['11']['inputs'].update(pixels=['20',0],mask=['23',0],noise_mask=True)
 g['7']['inputs']['text']=cfg['prompt'];g['12']['inputs'].update(seed=cfg['seed'],steps=cfg['steps'],cfg=1.0,sampler_name='euler',scheduler='normal',denoise=cfg['denoise']);g['8']['inputs']['guidance']=30.0
 g['15']['inputs']['filename_prefix']=f'ComfyProductPipeline/taobao_replica/{cfg["job_id"]}/{revision}'
 return g
def validate(cfg):
 for k in ('job_id','image_path','mask_path','prompt','seed'):
  if k not in cfg:raise ValueError('Missing required field: '+k)
 if not isinstance(cfg['job_id'],str) or not re.fullmatch(r'[A-Za-z0-9_-]+',cfg['job_id']):raise ValueError('Invalid job_id')
 for k in ('image_path','mask_path'):
  p=Path(cfg[k]);
  if not p.is_absolute() or not p.is_file():raise ValueError(f'{k} must be an existing absolute file')
 if cfg.get('reference_source_path') is not None:
  source=Path(cfg['reference_source_path'])
  if not source.is_absolute() or not source.is_file():raise ValueError('reference_source_path must be an existing absolute file')
 if not isinstance(cfg['prompt'],str) or not cfg['prompt'].strip():raise ValueError('prompt must be nonempty')
 if isinstance(cfg['seed'],bool) or not isinstance(cfg['seed'],int) or cfg['seed']<0:raise ValueError('seed must be a nonnegative integer')
 cfg=dict(cfg);cfg.setdefault('width',1024);cfg.setdefault('height',1024);cfg.setdefault('steps',20);cfg.setdefault('denoise',1.0)
 for k in ('width','height'):
  if isinstance(cfg[k],bool) or not isinstance(cfg[k],int) or cfg[k]<64 or cfg[k]>4096 or cfg[k]%16:raise ValueError(k+' must be a multiple of 16 in 64..4096')
 if isinstance(cfg['steps'],bool) or not isinstance(cfg['steps'],int) or not 1<=cfg['steps']<=100:raise ValueError('steps must be 1..100')
 d=cfg['denoise']
 if isinstance(d,bool) or not isinstance(d,(float,int)) or not 0<d<=1:raise ValueError('denoise must be >0 and <=1')
 cfg['denoise']=float(d)
 with Image.open(cfg['image_path']) as img: size=img.size;img.verify()
 with Image.open(cfg['mask_path']) as mask:
  if mask.size!=size:raise ValueError('reference and mask must share dimensions')
  if np.any(np.asarray(mask.convert('L'))!=255):raise ValueError('mask must be full white (255)')
 if size[0]*cfg['height']!=size[1]*cfg['width']:raise ValueError('reference and output aspect ratios must match; crop/pad explicitly before running')
 return cfg,size

def schema_audit(info):
 cfg={'job_id':'schema_audit','prompt':'Reference reconstruction schema check.','seed':1,'width':1024,'height':1024,'steps':20,'denoise':.7}
 g=graph_for(cfg,'schema_only');checks=check_graph(g,info)
 for n,k,v in [('UnetLoaderGGUF','unet_name',g['4']['inputs']['unet_name']),('DualCLIPLoaderGGUF','clip_name1',g['6']['inputs']['clip_name1']),('DualCLIPLoaderGGUF','clip_name2',g['6']['inputs']['clip_name2']),('VAELoader','vae_name',g['10']['inputs']['vae_name'])]:
  if v not in options(info,n,k):raise ValueError(f'{n}.{k} unavailable: {v}')
 visual=sync_ui(g,ui(g,info,'Taobao reconstruction schema audit','Schema-only graph. Reference pixels seed the initial latent; full mask. Not a submitted task.'),info)
 save(WF/'schema_audit.api.json',g);save(WF/'schema_audit.ui.json',visual);save(WF/'schema_audit.checks.json',checks)
 print('schema checked',WF/'schema_audit.checks.json')

def main():
 ap=argparse.ArgumentParser(description='Taobao screenshot reconstruction; --run submits once, --resume reconciles existing submission.')
 ap.add_argument('--job-config');m=ap.add_mutually_exclusive_group(required=True);m.add_argument('--schema-only',action='store_true');m.add_argument('--prepare',action='store_true');m.add_argument('--run',action='store_true');m.add_argument('--resume',action='store_true');a=ap.parse_args();client=ComfyClient();info=client.get('/object_info')
 if a.schema_only:schema_audit(info);return
 if not a.job_config:raise ValueError('--job-config required')
 p=Path(a.job_config)
 if not p.is_absolute() or not p.is_file():raise ValueError('job-config must be an existing absolute file')
 cfg,size=validate(json.loads(p.read_text()));inventory=json.loads((ROOT/'work/diagnostics/model_inventory.json').read_text())['models'];models={r['path']:r['sha256'] for r in inventory};identity={'job_id':cfg['job_id'],'source_image_path':cfg['image_path'],'source_image_sha256':sha(cfg['image_path']),'source_mask_path':cfg['mask_path'],'source_mask_sha256':sha(cfg['mask_path']),'source_dimensions':list(size),'prompt':cfg['prompt'],'prompt_sha256':hashlib.sha256(cfg['prompt'].encode()).hexdigest(),'seed':cfg['seed'],'settings':{k:cfg[k] for k in ('width','height','steps','denoise')},'model_hashes':models,'runner_sha256':sha(__file__),'status':'not_approved','source_limitation':'Reference capture is low resolution; reconstruction is synthetic and does not recover original source detail.'}
 if cfg.get('reference_source_path'):
  identity['reference_source_path']=cfg['reference_source_path'];identity['reference_source_sha256']=sha(cfg['reference_source_path'])
 revision=hashlib.sha256(json.dumps(identity,sort_keys=True,ensure_ascii=False).encode()).hexdigest()[:24];log=LOGS/cfg['job_id']/revision;workflow=WF/cfg['job_id']/revision;log.mkdir(parents=True,exist_ok=True);workflow.mkdir(parents=True,exist_ok=True);g=graph_for(cfg,revision);checks=check_graph(g,info)
 for n,k,v in [('UnetLoaderGGUF','unet_name',g['4']['inputs']['unet_name']),('DualCLIPLoaderGGUF','clip_name1',g['6']['inputs']['clip_name1']),('DualCLIPLoaderGGUF','clip_name2',g['6']['inputs']['clip_name2']),('VAELoader','vae_name',g['10']['inputs']['vae_name'])]:
  if v not in options(info,n,k):raise ValueError(f'{n}.{k} unavailable: {v}')
 visual=sync_ui(g,ui(g,info,'Taobao reference reconstruction','Input reference seeds initial latent; full mask regenerates scene. Pending visual review.'),info);save(log/'identity.json',identity);save(log/'job_config.json',cfg);save(log/'schema_checks.json',checks);save(workflow/'prepared.api.json',g);save(workflow/'prepared.ui.json',visual)
 print('prepared',log,flush=True)
 if a.prepare:return
 sub=log/'submission.json';result=log/'result.json'
 if result.exists():
  record=json.loads(result.read_text())
  if record['identity']!=identity or any(not Path(v['path']).is_file() or sha(v['path'])!=v['sha256'] for v in record['outputs'].values()):raise ValueError('Existing result identity/output mismatch')
  print('already complete',result,flush=True);return
 if a.resume:
  if not sub.exists():raise ValueError('No submission to resume')
  record=json.loads(sub.read_text());g=record['request']['prompt'];visual=record['request']['extra_data']['extra_pnginfo']['workflow'];pid=client.reconcile(sub)
 else:
  if sub.exists():raise RuntimeError('Submission exists; use --resume; no automatic resubmission')
  q=client.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('Queue occupied; no submission')
  g['1']['inputs']['image']=client.upload(Path(cfg['image_path']));g['2']['inputs']['image']=client.upload(Path(cfg['mask_path']));check_graph(g,info);visual=sync_ui(g,visual,info);save(log/'actual.api.json',g);save(log/'actual.ui.json',visual);save(workflow/'actual.api.json',g);save(workflow/'actual.ui.json',visual);pid=client.submit(g,visual,sub)
 print('submitted_or_resumed',pid,flush=True)
 try:
  backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());history,measure=client.wait(pid,log,backend,7200);files=client.download(history,log/'downloads')
  if len(files.get('15',[]))!=1:raise ValueError('Expected one output image')
  path=Path(files['15'][0]);
  with Image.open(path) as im:
   if im.size!=(cfg['width'],cfg['height']):raise ValueError('Unexpected output size')
  measure.update(seconds_per_iteration=measure['wall_seconds']/cfg['steps']);save(log/'measurements.json',measure)
  report={'status':'awaiting_root_visual_review','visual_pass':None,'prompt_id':pid,'identity':identity,'outputs':{'generated':{'path':str(path),'sha256':sha(path)}},'measurements':measure,'actual_api':str(log/'actual.api.json'),'actual_ui':str(log/'actual.ui.json')};save(result,report);print('completed',result,flush=True)
 except Exception as e:save(log/'failure.json',{'prompt_id':pid,'error':str(e),'time':time.time()});raise
 finally:
  if BACKEND_LOG.is_file():shutil.copyfile(BACKEND_LOG,log/'comfyui_full.log')
if __name__=='__main__':main()
