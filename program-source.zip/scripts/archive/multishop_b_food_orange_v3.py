"""Orange-only B_food correction over frozen v2, retaining its composition chain."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission multishop --legacy multishop_b_food_orange_v3 -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
import hashlib,json
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
from scipy import ndimage as ndi
from pymatting import estimate_alpha_cf
from multishop_blue_green_bc_v2 import lab,rgb
B=Path(__file__).resolve().parents[2];D=B/'work/diagnostics/multishop_20261103';UP=D/'blue_green_candidates_v2/B_food';O=D/'blue_green_candidates_v3/B_food'
def item(p):return {'path':str(p.resolve()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def poly_mask(points,w,h):
 im=Image.new('L',(w*4,h*4));ImageDraw.Draw(im).polygon([(x*4,y*4) for x,y in points],fill=255);return np.array(im.resize((w,h),Image.Resampling.LANCZOS)).astype(float)/255.
def main():
 O.mkdir(parents=True,exist_ok=True);source=UP/'output.png';assert item(source)['sha256']=='5e9a3f72fdeb344e7f5a41812a76bab9fc935efd6daf0d336a46e5069d040899'
 src=Image.open(source).convert('RGB');arr=np.array(src);h,w=arr.shape[:2];base=lab(arr.astype(float));L,a,b=base.transpose(2,0,1)
 body=[(110,302),(128,312),(149,319),(173,324),(199,327),(224,325),(248,319),(271,310),(299,296),(297,315),(291,333),(281,348),(268,360),(255,368),(250,375),(237,381),(219,384),(199,385),(179,381),(166,375),(162,368),(147,361),(133,348),(123,335),(116,319)]
 trim_left=[(78,280),(84,282),(102,289),(118,302),(132,310),(130,316),(113,306),(102,297),(88,292),(79,288)]
 trim_right=[(285,303),(302,290),(318,287),(326,276),(330,277),(328,287),(320,294),(306,298),(294,307)]
 polygon=poly_mask(body,w,h);binary=polygon>.5;inner=ndi.binary_erosion(binary,iterations=5);outer=ndi.binary_dilation(binary,iterations=8);yy,xx=np.where(outer);x0,x1=xx.min()-2,xx.max()+3;y0,y1=yy.min()-2,yy.max()+3
 trimap=np.zeros((h,w),float);trimap[outer]=.5;trimap[inner]=1
 matte=estimate_alpha_cf(arr[y0:y1,x0:x1].astype(float)/255.,trimap[y0:y1,x0:x1],cg_kwargs={'maxiter':2000});alpha=np.zeros((h,w),float);alpha[y0:y1,x0:x1]=matte;alpha[inner]=1;alpha[~outer]=0
 # Color separation is restricted to the uncertain contour band; all wall interiors stay opaque.
 edge=np.clip((b-17)/13,0,1)*np.clip((a-10)/13,0,1);alpha[~inner]*=edge[~inner]
 trim=np.maximum(poly_mask(trim_left,w,h),poly_mask(trim_right,w,h));trim[trim<.03]=0;alpha=np.maximum(alpha,trim*edge);alpha[alpha<.015]=0;alpha[alpha>.985]=1
 sample_path=D/'color_audit_v1/B_food_orange_sample_mask.png';sample=(np.array(Image.open(sample_path).convert('L'))>127)&(alpha>.98);old=np.median(base[sample],axis=0);target=np.array([old[0]+4.0,35.23,53.7]);ratio=complex(*target[1:])/complex(*old[1:]);z=(a+1j*b)*ratio
 adjusted=base.copy();adjusted[:,:,1]=z.real;adjusted[:,:,2]=z.imag;adjusted[:,:,0]+=4.0*np.clip((96-L)/(96-old[0]),0,1)
 out=np.rint(arr*(1-alpha[:,:,None])+rgb(adjusted)*alpha[:,:,None]).astype('uint8');mask=np.rint(alpha*255).astype('uint8');mask[(alpha>0)&(mask==0)]=1
 output=O/'output.png';maskpath=O/'mask.png';Image.fromarray(out).save(output);Image.fromarray(mask).save(maskpath)
 overlay=Image.composite(Image.blend(src,Image.new('RGB',(w,h),(255,0,255)),.5),src,Image.fromarray(mask));overlay.save(O/'mask_overlay.png')
 pair=Image.new('RGB',(w*2,h+26),'white');pair.paste(src,(0,26));pair.paste(Image.fromarray(out),(w,26));ImageDraw.Draw(pair).text((8,5),'B_food orange: frozen v2 | orange correction',fill='black');pair.save(O/'before_after.png')
 box=(72,275,333,389);edgepair=Image.new('RGB',((box[2]-box[0])*6,(box[3]-box[1])*3),'white')
 for i,im in enumerate([src,Image.fromarray(out)]):im=im.crop(box).resize(((box[2]-box[0])*3,(box[3]-box[1])*3));edgepair.paste(im,(i*im.width,0))
 edgepair.save(O/'edge_compare.png')
 changed=np.any(arr!=out,2);outside=int((changed&(mask==0)).sum());assert outside==0;assert not changed[390:,:].any()
 refs=json.loads((D/'color_audit_v1/report.json').read_text())['references'];ref=Path(refs['side_orange']['path']);up=json.loads((UP/'composition.json').read_text());new=np.median(lab(out.astype(float))[sample],axis=0)
 # Red diagnostic uses the whole approved red core rectangle, retaining deep shadows rejected by L>=30 sampling.
 rm=Image.new('L',(w,h));rd=ImageDraw.Draw(rm);rd.polygon([(600,600),(625,611),(652,617),(683,615),(719,603),(746,591),(747,612),(735,632),(716,646),(693,652),(664,650),(639,640),(618,626)],fill=255)
 redmask=np.array(rm)>0;rm.save(O/'red_diagnostic_sample_mask.png');redlab=base[redmask];redmed=np.median(redlab,axis=0);redref=np.array(refs['side_red']['lab_median']);redhue=float(np.degrees(np.arctan2(redmed[2],redmed[1])));refhue=float(np.degrees(np.arctan2(redref[2],redref[1])))
 red={'image':item(output),'reference':item(Path(refs['side_red']['path'])),'sample_mask':item(O/'red_diagnostic_sample_mask.png'),'sample_pixels':int(redmask.sum()),'sample_lab_median':redmed.tolist(),'reference_lab_median':redref.tolist(),'sample_lightness_range':[float(redlab[:,0].min()),float(redlab[:,0].max())],'sample_hue_degrees':redhue,'reference_hue_degrees':refhue,'hue_difference_degrees':redhue-refhue,'changed_red_sample_pixels':int(changed[redmask].sum()),'note':'Red bowl retained exactly, including original low-key lighting. No L>=30 filter applied to this diagnostic. Brightness and chroma differ from studio reference; root visual review must judge whether the unchanged dark-red hue is acceptable.'};(O/'red_check.json').write_text(json.dumps(red,ensure_ascii=False,indent=2)+'\n')
 comp={'method':'Orange-only continuous Lab hue/chroma rotation to actual orange reference; L lift bounded to 4.0. Full opaque wall and narrow boundary matting; no red/green/blue edits.','status':'pending_root_visual_review','source_original':item(source),'upstream_composition_provenance':item(UP/'composition.json'),'mask':item(maskpath),'output':item(output),'additional_sources':[item(ref),item(sample_path)],'generation_results':up['generation_results'],'color_parameters':{'body_polygon_px':body,'ear_trim_polygons_px':[trim_left,trim_right],'old_sample_lab':old.tolist(),'target_sample_lab':target.tolist(),'new_sample_lab':new.tolist(),'lab_chroma_complex_ratio':[float(ratio.real),float(ratio.imag)],'max_L_lift':4.0,'masking':'PyMatting 1.1.16 boundary band with erode5/dilate8; full interior opaque; continuous contour color separation only'},'pixels_changed_outside_mask':outside,'outside_mask_exact':True,'non_orange_bowls_unchanged':True,'red_diagnostic':item(O/'red_check.json')}
 (O/'composition.json').write_text(json.dumps(comp,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'output':item(output),'old_lab':old.tolist(),'new_lab':new.tolist(),'outside_mask_changed':outside,'red_hue_difference':redhue-refhue,'red_pixels':int(redmask.sum())},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
