#!/usr/bin/env python3
"""Run a root-approved deterministic replica composition without replacing drafts."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission export --source-run RUN --node NODE --output NEW.png [--config CONFIG]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

import argparse,hashlib,json,subprocess
from pathlib import Path
import numpy as np
from PIL import Image
from build_workflows import check_graph
from comfy_client import ComfyClient,sync_ui
R=Path(__file__).resolve().parents[2];WF=R/'workflows/taobao_replica_20261103';OUT=R/'output/TAOBAO_REPLICA_20261103/drafts';ROOT=R/'work/diagnostics/taobao_replica_20261103'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def idle(client):
 q=client.get('/queue')
 if q.get('queue_running') or q.get('queue_pending'):raise ValueError('Queue occupied; no submission made')
def main():
 p=argparse.ArgumentParser();p.add_argument('--task',required=True,choices=('D05','D21'));p.add_argument('--run',action='store_true');args=p.parse_args()
 if not args.run:p.error('--run required after root approval and queue clearance')
 ident=args.task;work=ROOT/(ident+'_replica');meta=json.loads((work/'preparation.json').read_text());approval=json.loads((work/'root_review.json').read_text());draft=OUT/(ident+'_replica_draft.png');target=OUT/(ident+'_replica_comfy.png')
 if approval.get('reviewer')!='root' or approval.get('approved_for_composite') is not True or approval.get('draft_sha256')!=sha(draft):raise ValueError('Exact draft requires root approval for composition')
 if target.exists():raise FileExistsError(target)
 for f in meta['local_inputs']:
  if not Path(f['path']).is_file() or sha(f['path'])!=f['sha256']:raise ValueError('Prepared input changed: '+f['path'])
 graph=json.loads(Path(meta['workflow_api']).read_text());frontend=json.loads(Path(meta['workflow_ui']).read_text())
 if [graph[str(i)]['class_type'] for i in range(1,6)]!=['LoadImage','LoadImage','LoadImageMask','ImageCompositeMasked','SaveImage'] or graph['3']['inputs']['channel']!='red' or graph['4']['inputs']!={'destination':['1',0],'source':['2',0],'mask':['3',0],'x':0,'y':0,'resize_source':False}:raise ValueError('Unexpected graph')
 client=ComfyClient();log=work/'comfy_composite_run';log.mkdir(exist_ok=True);record=log/'submission.json'
 if record.exists():
  if not (log/'actual.api.json').is_file() or not (log/'actual.ui.json').is_file():raise ValueError('Existing submission missing workflow evidence')
  pid=client.reconcile(record)
 else:
  idle(client)
  for nodeid,filename in [('1','base.png'),('2','overlay_rgb.png'),('3','overlay_mask.png')]:graph[nodeid]['inputs']['image']=client.upload(work/filename)
  info=client.get('/object_info');check_graph(graph,info);bound=sync_ui(graph,frontend,info)
  for nodeid in ('1','2','3'):
   if next(n for n in bound['nodes'] if str(n['id'])==nodeid)['widgets_values'][0]!=graph[nodeid]['inputs']['image']:raise ValueError('UI/API binding mismatch')
  save(log/'actual.api.json',graph);save(log/'actual.ui.json',bound);idle(client);pid=client.submit(graph,bound,record)
 backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());history,measurement=client.wait(pid,log,backend,timeout=600);images=client.download(history,log/'downloads').get('5',[])
 if len(images)!=1:raise ValueError('Expected one output')
 image=Path(images[0]);a=np.array(Image.open(draft).convert('RGB'));b=np.array(Image.open(image).convert('RGB'))
 if a.shape!=b.shape:raise ValueError('Output dimension mismatch')
 delta=np.abs(a.astype('int16')-b.astype('int16'));changed=int(np.any(delta,axis=2).sum());target.write_bytes(image.read_bytes());report={'task_id':ident,'status':'pending_root_review','prompt_id':pid,'draft_sha256':sha(draft),'comfy_path':str(target),'comfy_sha256':sha(target),'different_rgb_pixels':changed,'max_channel_difference':int(delta.max()),'exact_equal':changed==0,'measurements':measurement};save(log/'comparison.json',report);print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
