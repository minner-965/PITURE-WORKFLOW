"""Deterministic complete-body color candidates; root review remains separate."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission multishop --legacy multishop_blue_green_bc_v2 -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
import hashlib,json
import numpy as np
from scipy import ndimage as ndi
from pymatting import estimate_alpha_cf
from PIL import Image,ImageDraw,ImageFilter
B=Path(__file__).resolve().parents[2];D=B/'work/diagnostics/multishop_20261103';O=D/'blue_green_candidates_v2'
reg=json.loads((B/'config/multishop_scene_assets.json').read_text());audit=json.loads((D/'color_audit_v1/report.json').read_text())
# Refined geometric bodies: no interior HSV/chroma holes. White rims, foreground
# occlusions and table/contact shadows lie outside these traced boundaries.
body_regions={
'B_food':{'blue':[[(354,414),(373,424),(399,432),(426,436),(450,435),(474,431),(497,424),(520,414),(517,432),(510,449),(497,467),(481,481),(467,488),(450,481),(434,475),(415,469),(397,465),(378,462),(368,451),(360,434)]],
'green':[[(549,338),(569,347),(596,356),(625,361),(657,363),(688,360),(716,353),(736,345),(730,361),(719,380),(703,397),(688,409),(682,418),(670,424),(651,427),(634,426),(615,423),(601,416),(597,409),(581,399),(567,382),(558,363)]]},
'B_empty':{'blue':[[(142,397),(163,403),(187,409),(214,413),(242,415),(271,412),(298,406),(324,396),(350,382),(348,407),(340,428),(330,446),(314,461),(300,470),(296,479),(283,485),(263,490),(241,490),(220,486),(210,480),(208,471),(190,462),(176,450),(162,433),(153,417),(147,402)]],
'green':[[(302,606),(321,617),(348,627),(378,633),(411,635),(442,632),(470,623),(494,610),(516,596),(508,618),(497,638),(483,654),(463,667),(458,673),(446,680),(427,685),(405,686),(385,682),(370,675),(363,667),(346,660),(332,649),(320,634),(310,618)]]},
'C_hero':{'green':[[(394,496),(415,507),(444,516),(475,520),(508,522),(540,519),(570,513),(596,503),(618,493),(612,518),(602,540),(590,557),(575,572),(559,583),(553,591),(540,598),(521,602),(500,602),(479,599),(463,593),(452,584),(435,573),(421,557),(410,539),(401,518)]]},
'C_food':{'blue':[[(39,475),(59,485),(83,491),(111,495),(140,496),(169,492),(197,485),(220,476),(236,470),(230,491),(219,510),(203,527),(187,536),(172,542),(156,550),(145,558),(125,558),(108,554),(98,548),(95,542),(78,535),(64,524),(53,510),(45,493)],[(142,627),(162,637),(188,646),(217,651),(248,652),(277,648),(304,640),(328,626),(341,618),(337,638),(329,657),(316,676),(300,690),(286,702),(269,709),(248,713),(226,712),(209,707),(200,702),(198,697),(182,689),(168,676),(157,660),(148,644)]],
'green':[[(555,565),(577,579),(608,589),(643,596),(677,598),(713,593),(742,584),(771,572),(765,595),(756,617),(742,635),(724,648),(711,656),(702,662),(685,667),(664,667),(642,663),(626,656),(618,649),(602,639),(586,622),(574,604),(563,583)]]},
'C_empty':{'blue':[[(445,257),(466,267),(494,275),(525,280),(558,284),(594,284),(627,281),(657,274),(680,267),(676,279),(666,288),(644,296),(614,300),(581,302),(549,302),(520,299),(491,293),(469,285),(455,277)]],
'green':[[(438,704),(457,715),(483,727),(512,735),(543,740),(575,742),(609,740),(639,734),(667,724),(693,712),(690,731),(682,753),(669,776),(652,794),(633,807),(625,818),(610,826),(588,832),(565,833),(543,829),(522,822),(511,813),(505,805),(487,795),(470,779),(457,760),(447,740)]]}}
# Only thin colored edge/ear portions use a continuous chroma matte; the full
# bowl wall uses the geometric mask at full weight throughout, including reflections.
trim_regions={
'B_food':{'blue':[[(326,375),(342,373),(359,405),(370,420),(354,416),(342,396),(326,390)],[(510,414),(537,408),(557,402),(554,414),(530,421),(520,422)]], 'green':[[(519,305),(535,302),(554,335),(551,341),(540,326),(519,315)],[(728,347),(748,337),(771,331),(767,343),(737,351)]]},
'B_empty':{'blue':[[(103,372),(117,370),(144,391),(164,400),(141,400),(118,398),(105,388)],[(331,393),(352,376),(378,359),(389,359),(387,367),(366,372),(350,390)]], 'green':[[(257,577),(273,576),(303,599),(315,613),(301,607),(284,594),(261,593)],[(497,610),(523,584),(548,574),(552,576),(550,584),(526,591),(514,602)]]},
'C_hero':{'green':[[(355,468),(370,466),(399,492),(411,504),(394,499),(380,488),(356,480)],[(603,502),(625,485),(651,481),(656,485),(651,493),(630,496),(617,503)]]},
'C_food':{'blue':[[(10,432),(22,431),(42,464),(51,479),(38,476),(27,457),(11,446)],[(223,477),(238,464),(259,457),(266,449),(266,458),(259,467),(237,475)],[(125,595),(138,595),(150,624),(162,639),(143,630),(134,618),(126,609)],[(326,628),(349,609),(365,597),(373,598),(370,607),(363,615),(342,621)]], 'green':[[(526,514),(537,514),(559,550),(571,573),(555,568),(548,548),(535,535),(527,524)],[(752,583),(778,568),(802,559),(811,558),(812,569),(804,578),(776,582)]]},
'C_empty':{'blue':[[(409,235),(423,235),(448,255),(457,267),(444,261),(435,254),(410,246)],[(661,274),(684,262),(715,258),(718,260),(716,268),(681,272)]], 'green':[[(395,665),(407,651),(424,648),(438,649),(427,670),(427,687),(443,706),(439,710),(421,694),(398,681)],[(680,721),(696,703),(702,675),(716,678),(734,684),(741,689),(739,704),(732,712),(710,716),(694,718)]]}}
XYZ=np.array([[.4124564,.2126729,.0193339],[.3575761,.7151522,.119192],[.1804375,.0721750,.9503041]])
def lab(x):
 x=x/255.;x=np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4);z=x@XYZ/np.array([.95047,1,1.08883]);f=np.where(z>(6/29)**3,np.cbrt(z),z/(3*(6/29)**2)+4/29);return np.stack([116*f[...,1]-16,500*(f[...,0]-f[...,1]),200*(f[...,1]-f[...,2])],-1)
def rgb(l):
 fy=(l[:,:,0]+16)/116;fx=fy+l[:,:,1]/500;fz=fy-l[:,:,2]/200;f=np.stack([fx,fy,fz],-1);z=np.where(f>6/29,f**3,3*(6/29)**2*(f-4/29))*np.array([.95047,1,1.08883]);x=np.clip(z@np.linalg.inv(XYZ),0,1);x=np.where(x<=.0031308,12.92*x,1.055*x**(1/2.4)-.055);return np.rint(x*255).clip(0,255).astype('uint8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def item(p):return {'path':str(p.resolve()),'sha256':sha(p)}

def main(names=None):
 summaries=[]
 for name,colors in body_regions.items():
  if names and name not in names:continue
  shop,scene=name.split('_');asset=reg[shop][scene];source=Path(asset['path'])
  if source.resolve()==(O/name/'output.png').resolve():raise ValueError('Registry already references this frozen candidate; use a new version directory before further edits: '+name)
  im=Image.open(source).convert('RGB');arr=np.array(im);h,w=arr.shape[:2];base=lab(arr.astype(float));out=arr.copy();mask_all=np.zeros((h,w),np.uint8);dest=O/name;dest.mkdir(parents=True,exist_ok=True);details=[]
  for color,polys in colors.items():
   polyim=Image.new('L',(w*4,h*4));draw=ImageDraw.Draw(polyim)
   for poly in polys:draw.polygon([(x*4,y*4) for x,y in poly],fill=255)
   polygon=np.array(polyim.resize((w,h),Image.Resampling.LANCZOS).filter(ImageFilter.GaussianBlur(.45))).astype(float)/255.;polygon[polygon<.02]=0
   trimim=Image.new('L',(w*4,h*4));td=ImageDraw.Draw(trimim)
   for poly in trim_regions.get(name,{}).get(color,[]):td.polygon([(x*4,y*4) for x,y in poly],fill=255)
   trim=np.array(trimim.resize((w,h),Image.Resampling.LANCZOS)).astype(float)/255.;trim[trim<.03]=0
   if name=='C_empty' and color=='green':polygon=np.maximum(polygon,trim);trim[:]=0
   L,a,b=base.transpose(2,0,1);r,g,bl=arr.astype(float).transpose(2,0,1)
   chroma=np.clip((-b-10)/7,0,1)*np.clip((bl-r-12)/12,0,1) if color=='blue' else np.clip((b-5)/10,0,1)*np.clip((-a-4)/6,0,1)
   # Snap only the narrow geometric boundary band to the actual photograph.
   binary=polygon>.5;inner=ndi.binary_erosion(binary,iterations=7);outer=ndi.binary_dilation(binary,iterations=11)
   yy,xx=np.where(outer);x0,x1=max(0,xx.min()-2),min(w,xx.max()+3);y0,y1=max(0,yy.min()-2),min(h,yy.max()+3)
   trimap=np.zeros((h,w),float);trimap[outer]=.5;trimap[inner]=1
   matte=estimate_alpha_cf(arr[y0:y1,x0:x1].astype(float)/255.,trimap[y0:y1,x0:x1],cg_kwargs={'maxiter':2000})
   body_alpha=np.zeros((h,w),float);body_alpha[y0:y1,x0:x1]=matte;body_alpha[inner]=1;body_alpha[~outer]=0
   edge_gate=np.clip((-b-10)/7,0,1) if color=='blue' else np.clip((-a-6)/7,0,1)
   body_alpha[~inner]*=edge_gate[~inner]
   alpha=np.maximum(body_alpha,trim*chroma);alpha[alpha<.015]=0;alpha[alpha>.985]=1
   # Use existing diagnostic swatch when available, otherwise the complete masked body.
   sample=D/'color_audit_v1'/f'{name}_{color}_sample_mask.png'
   sel=(np.array(Image.open(sample).convert('L'))>127)&(alpha>.95) if sample.exists() else alpha>.95
   old=np.median(base[sel],axis=0);ref=np.array(audit['references']['side_'+color]['lab_median']);targetL=min(float(ref[0])-6,float(old[0])+20);target_ab=ref[1:]*np.sqrt(targetL/ref[0]);ratio=complex(*target_ab)/complex(*old[1:]);lift=targetL-old[0]
   altered=base.copy();lift_weight=.45+.55*np.clip(L/max(old[0],1),0,1)
   if name=='C_empty':lift_weight*=np.where(L>old[0],np.clip((96-L)/(96-old[0]),0,1),1)
   altered[:,:,0]+=lift*lift_weight;altered[:,:,1]=target_ab[0]+.65*(a-old[1]);altered[:,:,2]=target_ab[1]+.65*(b-old[2])
   if name=='C_empty':
    high=np.clip((L-old[0])/(96-old[0]),0,1)
    altered[:,:,1]=a+(altered[:,:,1]-a)*(1-.65*high)
    altered[:,:,2]=b+(altered[:,:,2]-b)*(1-.65*high)
   converted=rgb(altered);mixed=np.rint(arr*(1-alpha[:,:,None])+converted*alpha[:,:,None]).astype('uint8');active=alpha>0;out[active]=mixed[active];mask=np.rint(alpha*255).astype('uint8');mask[active&(mask==0)]=1;mask_all=np.maximum(mask_all,mask);mp=dest/(color+'_mask.png');Image.fromarray(mask).save(mp)
   new=np.median(lab(out.astype(float))[sel],axis=0);details.append({'color':color,'polygons_px':polys,'trim_polygons_px':trim_regions.get(name,{}).get(color,[]),'sample_mask':item(sample) if sample.exists() else None,'old_lab':old.tolist(),'reference_lab':ref.tolist(),'target_median_lab':[targetL,*target_ab.tolist()],'actual_new_lab':new.tolist(),'lightness_lift':float(lift),'highlight_taper':name=='C_empty','chroma_mapping':'reference target + 0.65 * original deviation from body median','boundary_refinement':'PyMatting 1.1.16 closed-form alpha in edge band only, sure foreground erode7 and sure background outside dilate11; full interior opaque; continuous edge color separation excludes neutral table and white rim','mask':item(mp),'affected_pixels':int(active.sum())})
  output=dest/'output.png';maskp=dest/'mask.png';Image.fromarray(out).save(output);Image.fromarray(mask_all).save(maskp)
  overlay=Image.composite(Image.blend(im,Image.new('RGB',(w,h),(255,0,255)),.5),im,Image.fromarray(mask_all));overlay.save(dest/'mask_overlay.png')
  pair=Image.new('RGB',(w*2,h+26),'white');pair.paste(im,(0,26));pair.paste(Image.fromarray(out),(w,26));ImageDraw.Draw(pair).text((8,5),name+' | original -> corrected',fill='black');pair.save(dest/'before_after.png')
  changed=np.any(arr!=out,axis=2);outside=int((changed&(mask_all==0)).sum());assert outside==0
  refs=[item(Path(audit['references']['side_'+c]['path'])) for c in colors]
  comp={'method':'Complete opaque bowl wall with closed-form matting only in a narrow outer contour band; continuous chroma matte on thin ear trims; Lab hue/chroma transfer from actual side references, bounded lightness lift preserving shading. Original pixels retained outside mask.','status':'pending_root_visual_review','source_original':item(source),'mask':item(maskp),'output':item(output),'additional_sources':refs,'generation_results':[asset['generation_result']]+asset.get('additional_generation_results',[]),'color_parameters':details,'pixels_changed_outside_mask':outside,'outside_mask_exact':True,'source_size_px':[w,h]}
  if asset.get('composition_provenance'):comp['upstream_composition_provenance']=item(Path(asset['composition_provenance']))
  (dest/'composition.json').write_text(json.dumps(comp,ensure_ascii=False,indent=2)+'\n');summaries.append({'scene':name,'output':item(output),'composition':item(dest/'composition.json'),'changed_pixels':int(changed.sum()),'pixels_changed_outside_mask':outside,'details':details})
 (O/'bc_v2_summary.json').write_text(json.dumps(summaries,ensure_ascii=False,indent=2)+'\n');print(json.dumps([{'scene':s['scene'],'changed_pixels':s['changed_pixels'],'outside':s['pixels_changed_outside_mask']} for s in summaries]))
if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--scene',action='append',choices=list(body_regions));args=ap.parse_args();main(args.scene)
