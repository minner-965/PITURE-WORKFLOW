
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission layout --legacy compose_multishop_B_food -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import hashlib,json
R=Path(__file__).resolve().parents[2];G=R/'work/diagnostics/multishop_20261103/generation';W=R/'work/diagnostics/multishop_20261103/accepted_scenes';p=G/'B_food_v1/d448a658f16e77ab16fde287/downloads/23_0_d448a658f16e77ab16fde287_00001_.png';im=Image.open(p).convert('RGB');patch=im.crop((80,420,205,451)).resize((178,64),Image.Resampling.LANCZOS);mask=Image.new('L',im.size);ImageDraw.Draw(mask).ellipse((551,270,729,334),fill=255);mask=mask.filter(ImageFilter.GaussianBlur(1.5));layer=im.copy();layer.paste(patch,(551,270));out=Image.composite(layer,im,mask);op=W/'B_food_composed.png';out.save(op);mp=W/'B_food_congee_mask.png';mask.save(mp)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
x={'method':'same_scene_food_surface_transfer','source_original':{'path':str(p),'sha256':sha(p)},'source_liquid_repair':{'path':str(p),'sha256':sha(p)},'donor_crop':[80,420,205,451],'target_rect':[551,270,729,334],'mask':{'path':str(mp),'sha256':sha(mp)},'output':{'path':str(op),'sha256':sha(op)},'generation_results':[str(p.parents[1]/'result.json')],'status':'pending_root_review'};(W/'B_food_composition.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
