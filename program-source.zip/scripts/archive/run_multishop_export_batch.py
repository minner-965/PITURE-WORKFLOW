#!/usr/bin/env python3
"""Execute a fully reviewed multishop export batch, one item at a time.

No export runs without --execute --lease-granted. Existing submissions are
reconciled, never submitted again. A failed check or command stops the batch.
"""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission export --source-run RUN --node NODE --output NEW.png [--config CONFIG]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

from run_multishop_export import ROOT, LOG_ROOT, MULTISHOP_ROOT, read_config, sha

DEFAULT_BATCH = ROOT / 'work/diagnostics/multishop_20261103/export_configs/batch.json'
BATCH_LOG = ROOT / 'work/diagnostics/multishop_20261103/batch_export_logs'
RUNNER = ROOT / 'scripts/archive/run_multishop_export.py'


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def preflight(batch_path):
    batch = read_json(batch_path)
    jobs = batch.get('jobs')
    if not isinstance(jobs, list) or batch.get('expected_count') != 66 or len(jobs) != 66 or batch.get('pending'):
        raise ValueError('Batch must contain all 66 jobs and no pending items')
    checked, seen = [], set()
    for job in jobs:
        key = (job.get('shop'), job.get('module_id'))
        if key in seen or key[0] not in ('A', 'B', 'C'):
            raise ValueError(f'duplicate or invalid shop/module: {key}')
        seen.add(key)
        config_path = Path(job['config']).resolve(strict=True)
        cfg, identity = read_config(config_path)
        if identity['asset_id'] != job.get('asset_id') or Path(identity['output_root']) != MULTISHOP_ROOT / key[0]:
            raise ValueError(f'{key}: job identity or shop mismatch')
        review = cfg.get('root_review') or {}
        if review.get('status') != 'approved' or review.get('reviewer') != 'root':
            raise ValueError(f'{key}: root approval missing')
        preview = (cfg.get('provenance') or {}).get('layout_preview') or {}
        preview_path = Path(preview.get('path', '')).resolve(strict=True)
        digest = sha(preview_path)
        if digest != review.get('preview_sha256') or digest != preview.get('sha256'):
            raise ValueError(f'{key}: approved preview hash mismatch')
        log = LOG_ROOT / key[0] / identity['asset_id']
        checked.append((job, config_path, identity, log, sha(config_path), digest))
    for shop in ('A', 'B', 'C'):
        if sum(k[0] == shop for k in seen) != 22:
            raise ValueError(f'{shop}: expected 22 unique modules')
    return checked


def verify_result(identity, log):
    result = read_json(log / 'result.json')
    target = Path(identity['output_path'])
    if result.get('identity') != identity or not target.is_file() or sha(target) != result.get('output_sha256'):
        raise ValueError(f'{identity["asset_id"]}: result or output mismatch')
    if not all((log / name).is_file() for name in ('submission.json', 'actual.api.json', 'actual.ui.json', 'history.json')):
        raise ValueError(f'{identity["asset_id"]}: missing submission/workflow/history evidence')


def run_command(config_path, mode, item_log):
    command = [sys.executable, str(RUNNER), '--config', str(config_path), mode]
    if mode == '--run':
        command.append('--lease-granted')
    with item_log.open('a', encoding='utf-8') as out:
        out.write('\n' + json.dumps(command, ensure_ascii=False) + '\n')
        out.flush()
        result = subprocess.run(command, stdout=out, stderr=subprocess.STDOUT, check=False)
    if result.returncode:
        raise RuntimeError(f'{config_path}: {mode} failed ({result.returncode}); see {item_log}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--batch', type=Path, default=DEFAULT_BATCH)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--lease-granted', action='store_true')
    args = parser.parse_args()
    if args.execute != args.lease_granted:
        parser.error('--execute and --lease-granted must be supplied together')
    checked = preflight(args.batch)
    print(f'preflight approved {len(checked)} items', flush=True)
    if not args.execute:
        return
    BATCH_LOG.mkdir(parents=True, exist_ok=True)
    for index, (job, config, identity, log, config_sha, preview_sha) in enumerate(checked, 1):
        if sha(config) != config_sha:
            raise ValueError(f'{config}: config changed after batch preflight')
        cfg_now = read_json(config)
        if sha(cfg_now['provenance']['layout_preview']['path']) != preview_sha:
            raise ValueError(f'{config}: preview changed after batch preflight')
        item_log = BATCH_LOG / (identity['asset_id'] + '.log')
        if (log / 'result.json').is_file():
            verify_result(identity, log)
            state = 'verified_existing'
        elif (log / 'submission.json').exists():
            run_command(config, '--resume', item_log)
            verify_result(identity, log)
            state = 'resumed'
        else:
            run_command(config, '--prepare', item_log)
            if sha(config) != config_sha or sha(cfg_now['provenance']['layout_preview']['path']) != preview_sha:
                raise ValueError(f'{config}: input review changed after prepare')
            run_command(config, '--run', item_log)
            verify_result(identity, log)
            state = 'completed'
        print(f'{index}/{len(checked)} {identity["asset_id"]} {state} {log / "result.json"}', flush=True)


if __name__ == '__main__':
    main()
