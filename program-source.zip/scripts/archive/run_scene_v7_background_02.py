#!/usr/bin/env python3
"""One full-canvas background test, with a durable submission and raw output."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission scene --legacy run_scene_v7_background_02 -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

import argparse, hashlib, json, shutil, subprocess, time
from pathlib import Path
from build_workflows import ROOT, make_a, node, check_graph, ui
from comfy_client import ComfyClient, sync_ui

LOG = ROOT / 'work/diagnostics/scene_v7/background_02'
WF = ROOT / 'workflows/scene_v7'
BACKEND_LOG = ROOT/'work/diagnostics/headless_backend_20261103/comfyui.log'
def save(p, x): p.write_text(json.dumps(x, ensure_ascii=False, indent=2))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--tier',choices=('preview','final'),default='final'); ap.add_argument('--prepare-only',action='store_true'); a=ap.parse_args()
    config_path=LOG/'config.json'; cfg=json.loads(config_path.read_text())
    size,steps=(768,12) if a.tier=='preview' else (1024,20)
    log=ROOT/'work/diagnostics/preview_tiers'/LOG.name/a.tier; log.mkdir(parents=True,exist_ok=True)
    wf=ROOT/'workflows/preview'/LOG.name/a.tier; wf.mkdir(parents=True,exist_ok=True)
    c = ComfyClient(); info = json.loads((ROOT/'work/diagnostics/object_info.json').read_text()) if a.prepare_only else c.get('/object_info'); graph = make_a()
    for k in ('2','3','14','16','17','18'): graph.pop(k)
    graph['1'] = node('EmptyImage','EMPTY_BACKGROUND',width=size,height=size,batch_size=1,color=8421504)
    graph['19'] = node('SolidMask','FULL_CANVAS_MASK',value=1.0,width=size,height=size)
    graph['11']['inputs']['mask'] = ['19',0]
    graph['7']['inputs']['text'] = cfg['prompt']
    graph['12']['inputs'].update(seed=cfg['seed'],steps=steps,cfg=1.0,sampler_name='euler',scheduler='normal',denoise=1.0)
    graph['8']['inputs']['guidance'] = 30.0
    graph['15']['inputs']['filename_prefix'] = f'ComfyProductPipeline/scene_v7/{a.tier}/background_02/raw'
    checks = check_graph(graph,info)
    visual = sync_ui(graph,ui(graph,info,'Scene v7 background test','Full-canvas Q6 Fill; raw output pending root visual review.'),info)
    for dest,obj in [(wf/'background_02.api.json',graph),(wf/'background_02.ui.json',visual),(log/'schema_checks.json',checks)]: save(dest,obj)
    opts = {n:{k:v[0] for k,v in info[n]['input']['required'].items()} for n in ('UnetLoaderGGUF','DualCLIPLoaderGGUF','VAELoader')}
    save(log/'loader_options.json',opts)
    identity = {'config_sha256':sha(config_path),'script_sha256':sha(Path(__file__)),'prompt_sha256':hashlib.sha256(cfg['prompt'].encode()).hexdigest(),'tier':a.tier,'width':size,'height':size,'steps':steps,'input':f'EmptyImage {size} square RGB #808080','mask':'SolidMask 1.0 full canvas','seed':cfg['seed']}
    save(log/'identity.json',identity)
    if a.prepare_only: print('prepared',wf); return
    submission = log/'submission.json'; result = log/'result.json'
    if result.exists(): print('result exists',result,flush=True); return
    if submission.exists():
        previous = json.loads(submission.read_text()); graph=previous['request']['prompt']; visual=previous['request']['extra_data']['extra_pnginfo']['workflow']; pid=c.reconcile(submission)
    else:
        q = c.get('/queue')
        if q['queue_running'] or q['queue_pending']: raise RuntimeError('Queue occupied; no submission')
        save(log/'actual.api.json',graph); save(log/'actual.ui.json',visual)
        pid=c.submit(graph,visual,submission)
    print('submitted',pid,flush=True)
    try:
        backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip())
        started=time.monotonic(); history,measure=c.wait(pid,log,backend,7200); wall=time.monotonic()-started; measure.update(wait_seconds=wall,seconds_per_iteration=measure['wall_seconds']/steps,tier=a.tier,steps=steps); save(log/'measurements.json',measure); files=c.download(history,log/'raw_output')
        if len(files.get('15',[])) != 1: raise ValueError('Expected exactly one raw image')
        raw=Path(files['15'][0]); record={'status':'generated_pending_root_review','prompt_id':pid,'source_sha256':sha(raw),'raw_output':str(raw),'identity':identity,'measurements':measure,'visual_pass':None}
        save(result,record); print('completed',json.dumps(record,ensure_ascii=False),flush=True)
    except Exception as e:
        save(log/'failure.json',{'prompt_id':pid,'error':str(e),'time':time.time()}); raise
    finally:
        if BACKEND_LOG.is_file(): shutil.copyfile(BACKEND_LOG,log/'comfyui_full.log')
if __name__ == '__main__': main()
