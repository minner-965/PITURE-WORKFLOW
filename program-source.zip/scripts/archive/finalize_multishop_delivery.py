#!/usr/bin/env python3
"""Package three-shop evidence after all technical and preview approvals pass.

No model execution or task-state changes. Use --audit/--qa to select frozen reports.
"""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission export --legacy finalize_multishop_delivery -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

import argparse, hashlib, json, shutil, tempfile
from pathlib import Path
from PIL import Image
from audit_multishop_delivery import inspect_evidence, inspect_provenance

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'output/MULTISHOP_20261103'
DIAG = ROOT / 'work/diagnostics/multishop_20261103'
DOC = ROOT / 'docs/三店铺差异化商品图方案_20261103.md'
REGISTRY = ROOT / 'config/multishop_scene_assets.json'
REQUIRED = ('actual.api.json', 'actual.ui.json', 'submission.json', 'history.json', 'input_config.json', 'result.json')

def load(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''): h.update(b)
    return h.hexdigest()

def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def copy(source, destination):
    source = Path(source)
    if not source.is_file(): raise ValueError('Missing evidence: ' + str(source))
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    if sha(source) != sha(destination): raise ValueError('Copy hash mismatch: ' + str(source))

def copy_scene_evidence(evidence_files, workflows):
    """Copy the freshly audited recursive/color evidence and preserve its binding."""
    packaged=[]
    for evidence in evidence_files:
        src=Path(evidence['path'])
        if not src.is_file() or sha(src)!=evidence['sha256']:
            raise ValueError('Scene evidence changed since validation: '+str(src))
        relative=Path('生成来源/关联记录')/(evidence['sha256'][:16]+'_'+src.name)
        destination=workflows/relative
        if destination.exists():
            if sha(destination)!=evidence['sha256']: raise ValueError('Packaged evidence hash conflict: '+str(destination))
        else: copy(src,destination)
        packaged.append(dict(evidence,packaged_path=str(Path('04_工作流')/relative)))
    return packaged

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--audit', type=Path, default=DIAG/'audit/audit.json')
    ap.add_argument('--qa', type=Path, default=DIAG/'independent_visual_qa_20261103.json')
    args = ap.parse_args()
    audit = load(args.audit); rows = audit.get('items', [])
    expected = {(s, m) for s in 'ABC' for m in [*(f'M{i:02}' for i in range(1,6)), *(f'D{i:02}' for i in range(1,16)), 'D20','D21']}
    actual = [(x.get('shop'), x.get('module_id')) for x in rows]
    if len(rows)!=66 or len(set(actual))!=66 or set(actual)!=expected or audit.get('cross_shop_duplicates'):
        raise ValueError('Audit requires 66 unique modules and zero cross-shop duplicates')
    if audit.get('status')!='technical_and_root_visual_pass' or any(x.get('technical_status')!='pass' or x.get('visual_status')!='approved_via_reviewed_preview' for x in rows):
        raise ValueError('Audit is not a full technical and root visual pass')
    if Path(audit.get('delivery_root','')).resolve()!=OUT.resolve(): raise ValueError('Audit delivery root mismatch')
    if audit.get('unmatched_images'): raise ValueError('Audit lists unmatched images')
    if sha(audit['plan'])!=audit.get('plan_sha256'): raise ValueError('Plan changed since audit')
    load(args.qa); load(REGISTRY)
    entries=[]
    for row in rows:
        image=Path(row['path']).resolve(); shop=row['shop']; mid=row['module_id']
        if not image.is_relative_to((OUT/shop).resolve()) or sha(image)!=row.get('sha256'): raise ValueError('Output changed since audit: '+str(image))
        with Image.open(image) as im:
            im.load(); size=list(im.size)
        if size!=row.get('expected_size') or size!=row.get('size'): raise ValueError('Output size mismatch: '+str(image))
        folder=Path(row['export_evidence']['directory']); cfg=load(folder/'input_config.json'); rec=load(folder/'result.json'); prov=cfg.get('provenance',{}); review=cfg.get('root_review',{})
        preview_hash=prov.get('layout_preview',{}).get('sha256')
        if review.get('status')!='approved' or review.get('reviewer')!='root' or review.get('preview_sha256')!=preview_hash or not preview_hash:
            raise ValueError('Preview approval absent or hash mismatch: '+shop+'/'+mid)
        evidence=inspect_evidence(folder,image,row['sha256']); chain=inspect_provenance(folder,rec,image)
        if evidence['status']!='pass' or chain['status']!='pass' or chain.get('preview_max_channel_difference',2)>1:
            raise ValueError('Current evidence or pixel check failed: '+shop+'/'+mid+' '+str(chain.get('issues')))
        entries.append({'shop':shop,'module_id':mid,'title':row['title'],'path':str(image),'sha256':row['sha256'],'size':size,'category':'AI场景与确定性合成' if prov.get('scene') else '实拍或资料确定性合成','provenance':prov,'export_directory':str(folder),'preview_review':review,'preview_max_channel_difference':chain['preview_max_channel_difference'],'color_review':chain.get('color_review'),'composition_chain':chain.get('composition_chain',[]),'scene_evidence_files':chain.get('evidence_files',[])})
    # All gates precede creating the staging directory. Publication happens only after staging succeeds.
    with tempfile.TemporaryDirectory(prefix='.multishop-finalize-', dir=OUT) as tmp:
        stage=Path(tmp); listing=stage/'05_交付清单'; compare=stage/'03_对照审核'; workflows=stage/'04_工作流'
        for source in (DOC,args.audit,args.qa,REGISTRY): copy(source,listing/Path(source).name)
        for name,path in audit.get('contact_sheets',{}).items():
            source=Path(path);copy(source,compare/source.name)
        copied=set(); referenced=[]; related={}
        for entry in entries:
            folder=Path(entry['export_directory']);dest=workflows/entry['shop']/entry['module_id']
            for name in REQUIRED: copy(folder/name,dest/name)
            dump(dest/'root_review.json',entry['preview_review'])
            scene=entry['provenance'].get('scene') or {}
            paths=([scene['generation_result']] if scene.get('generation_result') else []) + scene.get('additional_generation_results',[])
            for result in paths:
                job=Path(result).resolve().parent; key=sha(Path(result))[:16]
                if str(job) in copied: continue
                copied.add(str(job));target=workflows/'生成来源'/key
                for name in ('actual.api.json','actual.ui.json','submission.json','history.json','result.json'):
                    copy(job/name,target/name)
                rec=load(job/'result.json')
                referenced.append({'copied_directory':str(Path('04_工作流/生成来源')/key),'source_directory':str(job),'result_sha256':sha(job/'result.json'),'inputs':rec.get('identity',{}).get('inputs',{}),'outputs':rec.get('outputs',{})})
            entry['packaged_scene_evidence']=copy_scene_evidence(entry['scene_evidence_files'],workflows)
            for item in entry['packaged_scene_evidence']:
                related[(item['role'],item['path'],item['sha256'])]=item
        dump(workflows/'生成来源'/'来源索引.json',{'generation_jobs':referenced,'related_evidence':list(related.values()),'note':'递归合成记录、各层蒙版和图像输入输出、root 颜色审核及自动颜色报告已复制；原始路径和 SHA-256 同时保留，模型不复制。'})
        dump(listing/'成品清单.json',{'items':entries,'audit_sha256':sha(args.audit),'independent_qa_sha256':sha(args.qa),'scene_registry_sha256':sha(REGISTRY),'visual_review_basis':'root 审核布局预览，正式图与该预览每通道最大差不超过 1；每个 AI 场景另须通过绑定当前图像哈希和自动检测报告的 root 颜色审核。'})
        lines=['# 三店铺商品图成品索引','','三套各 22 张：5 张主图、15 张详情图、2 张尺寸与参数图；每张尺寸沿用原模板。成品包含 AI 场景，以及实拍和真实资料的确定性合成。','', '逐张视觉复核关联 root 已审核的布局预览，正式图与预览的每通道最大差不超过 1。平台算法判重结果以平台实际判断为准。','']
        for shop in 'ABC':
            lines += [f'## 店铺 {shop}','']
            for e in entries:
                if e['shop']==shop:
                    rel=Path(e['path']).relative_to(OUT);lines.append(f"- [{e['module_id']} {e['title']}]({rel.as_posix()}) · {e['size'][0]}×{e['size'][1]} · {e['category']} · SHA-256 `{e['sha256']}`")
            lines.append('')
        (stage/'01_成品索引.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
        # Never silently replace a prior packaged directory.
        for name in ('01_成品索引.md','03_对照审核','04_工作流','05_交付清单'):
            if (OUT/name).exists(): raise FileExistsError('Existing package path: '+str(OUT/name))
        for name in ('01_成品索引.md','03_对照审核','04_工作流','05_交付清单'):
            (stage/name).rename(OUT/name)
    print('Packaged 66 verified items into', OUT)

if __name__=='__main__': main()
