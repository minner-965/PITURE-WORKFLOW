#!/usr/bin/env python3
"""Build review-pending export configurations from the current layout manifests."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission export --legacy prepare_multishop_exports -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

import hashlib, json, re
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
DIAG = ROOT / 'work/diagnostics/multishop_20261103'
LAYOUT = DIAG / 'layouts'
DEST = DIAG / 'export_configs'

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def ref(path):
    path = Path(path).resolve(strict=True)
    return {'path': str(path), 'sha256': digest(path)}

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def main():
    plan = json.loads((ROOT / 'config/multishop_variants_20261103_plan.json').read_text())
    modules = {m['module_id']: m for m in plan['modules']}
    scenes = json.loads((ROOT / 'config/multishop_scene_assets.json').read_text())
    manifest = json.loads((LAYOUT / 'preview_manifest.json').read_text())
    jobs, pending = [], []
    for item in manifest['items']:
        shop, mid = item['shop'], item['module_id']
        if item['status'] != 'internal_preview_pending_root':
            pending.append({'shop': shop, 'module_id': mid, 'reason': item.get('reason')})
            continue
        template = ref(item['source'])
        if template['sha256'] != item['source_sha256']:
            raise ValueError(f'template changed: {shop}/{mid}')
        width, height = item['dimensions']
        for key in ('background', 'layer', 'layer_mask', 'preview'):
            with Image.open(item[key]) as image:
                image.load()
                if image.size != (width, height):
                    raise ValueError(f'bad {key} size: {shop}/{mid}')
        extra = item.get('additional_sources', [])
        for source in extra:
            if digest(source['path']) != source['sha256']:
                raise ValueError(f'additional source changed: {shop}/{mid}')
        scene = None
        if item.get('scene_path'):
            scene_entry = next((v for v in scenes.get(shop, {}).values() if (v if isinstance(v, str) else v.get('path')) == item['scene_path']), None)
            if scene_entry is None:
                raise ValueError(f'scene registry changed: {shop}/{mid}; rerender')
            scene = dict(scene_entry) if isinstance(scene_entry, dict) else {}
            scene.update(ref(item['scene_path']))
            if scene['sha256'] != item['scene_sha256']:
                raise ValueError(f'scene changed: {shop}/{mid}; rerender')
            if isinstance(scene_entry, dict):
                for k in ('generation_result', 'root_review', 'additional_generation_results', 'composition_provenance', 'actual_action'):
                    if k in scene_entry: scene[k] = scene_entry[k]
            scene.setdefault('generation_result', None)
            scene.setdefault('root_review', None)
        name = re.sub(r'[\\/\x00-\x1f]', '_', modules[mid]['title'])
        category = '主图' if mid.startswith('M') else ('尺寸标注' if mid in ('D20', 'D21') else '详情图')
        output_root = ROOT / 'output/MULTISHOP_20261103' / shop
        cfg = {'asset_id': f'{shop}_{mid}_v1', 'reference': item['background'], 'generated': item['layer'], 'generated_mask': item['layer_mask'], 'output_width': width, 'output_height': height, 'output_root': str(output_root), 'output_path': str(output_root / category / f'{mid}_{name}.png'), 'root_review': {'status': 'pending_root_review', 'reviewer': None}, 'provenance': {'source_template': template, 'additional_sources': extra, 'scene': scene, 'layout_preview': ref(item['preview']), 'layout_manifest': ref(LAYOUT / shop / 'manifest.json')}}
        path = DEST / shop / f'{mid}.json'
        if path.exists():
            old = json.loads(path.read_text())
            if old.get('root_review', {}).get('status') != 'pending_root_review' and old != cfg:
                old_payload = {k: v for k, v in old.items() if k != 'root_review'}
                new_payload = {k: v for k, v in cfg.items() if k != 'root_review'}
                if old_payload != new_payload:
                    raise ValueError(f'approved config requires manual review: {path}')
                cfg['root_review'] = old['root_review']
        save(path, cfg)
        jobs.append({'shop': shop, 'module_id': mid, 'asset_id': cfg['asset_id'], 'config': str(path), 'status': cfg['root_review']['status']})
    save(DEST / 'batch.json', {'status': 'pending_root_review', 'expected_count': len(modules) * 3, 'rendered_count': len(jobs), 'pending_count': len(pending), 'jobs': jobs, 'pending': pending})
    print(f'configs: {len(jobs)}; pending scenes: {len(pending)}')

if __name__ == '__main__': main()
