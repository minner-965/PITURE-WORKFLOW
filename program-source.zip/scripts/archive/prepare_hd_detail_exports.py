"""Collect completed reference-initialized jobs and prepare source-text composites."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission export --legacy prepare_hd_detail_exports -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
from PIL import Image,ImageDraw
import hashlib,json
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'output/TAOBAO_REPLICA_HD_20261103'
DIAG=ROOT/'work/diagnostics/taobao_replica_hd_20261103'
OUT=DIAG/'detail_exports';OUT.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
mask_manifest=json.loads((DIAG/'detail_photo_masks/manifest.json').read_text())
masks={x['module']:x for x in mask_manifest['modules']}
mapping={'A02':('D02','手持展示'),'A05':('D05','五色场景'),'A06':('D06','产品展示'),'A07':('D07','碗底俯拍'),'A08':('D08','密胺餐具展示'),'B02':('D10','好清洗'),'C01':('D11','不易脏'),'C02':('D12','光滑质感'),'C03':('D13','LOGO定制')}
batch=[];previews=[]
for module,(ident,name) in mapping.items():
 results=list((ROOT/f'work/diagnostics/taobao_replica_20261103/klein_refine_runs/D_{module}_HD_refine_step2').glob('*/result.json'))
 if len(results)!=1:print('pending',module);continue
 result_path=results[0];result=json.loads(result_path.read_text());gen=Path(result['outputs']['generated']['path'])
 prep_path=DIAG/f'detail_inputs/{module}/preparation.json';prep=json.loads(prep_path.read_text());m=masks[module]
 assert sha(m['reference'])==m['reference_sha256'] and sha(m['mask'])==m['mask_sha256']
 im=Image.open(gen).convert('RGB');assert list(im.size)==prep['canvas_size']
 im=im.crop(tuple(prep['content_crop_xyxy']));cropped=OUT/f'{ident}_generated_unpadded.png';im.save(cropped)
 ref=Image.open(m['reference']).convert('RGB');mask=Image.open(m['mask']).convert('L');assert ref.size==mask.size
 composite=Image.composite(im.resize(ref.size,Image.Resampling.LANCZOS),ref,mask)
 cpu=composite.resize((750,round(ref.height*750/ref.width)),Image.Resampling.LANCZOS);cpu_path=OUT/f'{ident}_cpu_preview.png';cpu.save(cpu_path);previews.append((ident,cpu_path))
 c={'asset_id':ident,'reference':m['reference'],'generated':str(cropped),'generated_mask':m['mask'],'output_width':750,'output_path':str(BASE/f'02_ComfyUI复刻/详情图/{ident}_{name}_复刻.png'),'root_review':{'status':'prepared_pending_visual_review','reviewer':'root','generation_result':str(result_path),'reference_preparation':str(prep_path),'unpadded_crop_xyxy':prep['content_crop_xyxy'],'cpu_preview':str(cpu_path),'mask_sha256':sha(m['mask']),'note':'Chinese, numeric badges and original inscriptions preserved from company artwork; AI photograph regions from reference-initialized Klein reconstruction.'}}
 cp=OUT/f'{ident}.json'
 if cp.exists():
  old=json.loads(cp.read_text())
  if old.get('root_review',{}).get('status')=='approved_for_export':c['root_review']=old['root_review']
 cp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');batch.append(str(cp))
 provenance={'generated_source':str(gen),'generated_source_sha256':sha(gen),'generation_result':str(result_path),'operation':'Remove recorded bottom-only canvas padding without scaling','crop_xyxy':prep['content_crop_xyxy'],'derived_path':str(cropped),'derived_sha256':sha(cropped),'reference_size':list(ref.size),'mask_manifest':str(DIAG/'detail_photo_masks/manifest.json')}
 (OUT/f'{ident}_preparation.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2)+'\n')
if (OUT/'D09.json').exists():batch.append(str(OUT/'D09.json'))
(OUT/'batch.json').write_text(json.dumps(sorted(batch),ensure_ascii=False,indent=2)+'\n')
if previews:
 contact=Image.new('RGB',(1000,520*((len(previews)+2)//3)),'#eeeeee');d=ImageDraw.Draw(contact)
 for i,(key,pp) in enumerate(previews):
  im=Image.open(pp);im.thumbnail((320,490));x=(i%3)*333;y=(i//3)*520;contact.paste(im,(x,y+22));d.text((x+3,y+3),key+' COMPOSITE PREVIEW',fill='black')
 contact.save(OUT/'details_composite_preview.jpg')
print('prepared',len(batch),'detail exports')
