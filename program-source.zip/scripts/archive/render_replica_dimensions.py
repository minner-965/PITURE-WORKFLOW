#!/usr/bin/env python3
"""Render a deterministic transparent dimension overlay; no product claims inferred."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission layout --legacy render_replica_dimensions -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

import argparse, hashlib, json, math
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont

FONT='/System/Library/Fonts/STHeiti Medium.ttc'
LABELS={'length':'长','width':'宽','height':'高'}

def positive(value):return not isinstance(value,bool) and isinstance(value,(int,float)) and math.isfinite(value) and value>0

def render(cfg, out, final=False, base=None):
 canvas=cfg.get('canvas');bbox=cfg.get('product_bbox');lines=cfg.get('lines')
 if not isinstance(canvas,list) or len(canvas)!=2 or any(type(x)!=int or x<=0 for x in canvas):raise ValueError('canvas must be [width,height] positive integers')
 w,h=canvas
 def point(p):
  if not isinstance(p,list) or len(p)!=2 or any(not isinstance(v,(int,float)) or isinstance(v,bool) or not math.isfinite(v) for v in p) or not (0<=p[0]<w and 0<=p[1]<h):raise ValueError('point outside canvas or invalid: '+repr(p))
  return tuple(p)
 if not isinstance(bbox,list) or len(bbox)!=4 or not (0<=bbox[0]<bbox[2]<=w and 0<=bbox[1]<bbox[3]<=h):raise ValueError('invalid product_bbox')
 if not isinstance(lines,list) or len(lines)!=3 or {x.get('key') for x in lines if isinstance(x,dict)}!=set(LABELS):raise ValueError('lines must contain length, width and height exactly once')
 im=Image.new('RGBA',(w,h),(0,0,0,0));d=ImageDraw.Draw(im);font=ImageFont.truetype(FONT,int(cfg.get('font_size',26)));color=cfg.get('color','#303030');line_width=cfg.get('line_width',3);arrow_size=cfg.get('arrow_size',12)
 if type(line_width)!=int or not 1<=line_width<=12 or not positive(arrow_size) or arrow_size>40:raise ValueError('invalid line or arrow size')
 records=[]
 def arrow(tip,tail):
  dx=tail[0]-tip[0];dy=tail[1]-tip[1];n=math.hypot(dx,dy)
  if n<arrow_size*2:raise ValueError('measurement line too short')
  ux=dx/n;uy=dy/n;perp=(-uy,ux);heel=(tip[0]+arrow_size*ux,tip[1]+arrow_size*uy);p1=(heel[0]+arrow_size*.38*perp[0],heel[1]+arrow_size*.38*perp[1]);p2=(heel[0]-arrow_size*.38*perp[0],heel[1]-arrow_size*.38*perp[1])
  if any(not (0<=p[0]<w and 0<=p[1]<h) for p in (p1,p2)):raise ValueError('arrowhead outside canvas')
  d.polygon((tip,p1,p2),fill=color)
 for item in lines:
  key=item['key'];start=point(item.get('start'));end=point(item.get('end'));label_pos=point(item.get('label_position'));extensions=item.get('extensions',[]);value=item.get('value');unit=item.get('unit');confirmed=item.get('confirmed') is True;source=item.get('source')
  if value is not None and not positive(value):raise ValueError(key+': value must be null or positive finite number')
  if value is not None and (not isinstance(unit,str) or not unit.strip()):raise ValueError(key+': unit required')
  if final and (value is None or not confirmed or not isinstance(source,str) or not source.strip()):raise ValueError(key+': final requires confirmed value and source')
  if value is None or not confirmed:label=LABELS[key]+'待核'
  else:label=LABELS[key]+' '+format(value,'g')+' '+unit.strip()
  if not isinstance(extensions,list):raise ValueError(key+': extensions must be list')
  for ext in extensions:
   if not isinstance(ext,list) or len(ext)!=2:raise ValueError(key+': each extension requires two endpoints')
   d.line((point(ext[0]),point(ext[1])),fill=color,width=line_width)
  d.line((start,end),fill=color,width=line_width);arrow(start,end);arrow(end,start)
  box=d.textbbox(label_pos,label,font=font,anchor='mm',stroke_width=0)
  if box[0]<0 or box[1]<0 or box[2]>=w or box[3]>=h:raise ValueError(key+': label exceeds canvas')
  d.text(label_pos,label,font=font,fill=color,anchor='mm');records.append({'key':key,'label':label,'label_bbox':box,'confirmed':confirmed,'source':source})
 out=Path(out);out.mkdir(parents=True,exist_ok=True);overlay=out/'dimensions_overlay.png';im.save(overlay)
 if base:
  with Image.open(base) as src:
   src.load()
   if src.size!=(w,h):raise ValueError('base must match canvas size')
   Image.alpha_composite(src.convert('RGBA'),im).convert('RGB').save(out/'dimensions_preview.png')
 info={'status':'final_confirmed' if final else 'draft_pending_confirmation','canvas':canvas,'product_bbox':bbox,'overlay':str(overlay.resolve()),'overlay_sha256':hashlib.sha256(overlay.read_bytes()).hexdigest(),'font':FONT,'lines':records,'note':'尺寸和线位由输入提供；草稿待核，非商品事实。' if not final else '来源由输入提供；只生成标注层。'}
 (out/'dimensions_report.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n');return info
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--config',required=True,type=Path);p.add_argument('--out',required=True,type=Path);p.add_argument('--base',type=Path);p.add_argument('--final',action='store_true');a=p.parse_args();print(json.dumps(render(json.loads(a.config.read_text(encoding='utf-8')),a.out,a.final,a.base),ensure_ascii=False,indent=2))
