#!/usr/bin/env python3
"""Prepare an intermediate A-branch composite after root background approval."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission scene --legacy prepare_scene_v7_A -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
import argparse, hashlib, json
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import distance_transform_edt

P = Path(__file__).resolve().parents[2]
I = P / 'work/diagnostics/scene_v7/inputs'
O = P / 'work/diagnostics/scene_v7/branch_A_inputs'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--background', required=True, type=Path)
    parser.add_argument('--review-record', required=True, type=Path, help='JSON with root_approved_for_fusion_test=true and background_sha256')
    args = parser.parse_args()
    bg_path = args.background.resolve(strict=True)
    review_path = args.review_record.resolve(strict=True)
    review = json.loads(review_path.read_text())
    bg_hash = sha(bg_path)
    if review.get('root_approved_for_fusion_test') is not True or review.get('background_sha256') != bg_hash:
        raise ValueError('Review must have root_approved_for_fusion_test=true and the exact background_sha256')
    bg = Image.open(bg_path).convert('RGB')
    bowl = Image.open(I / 'A_food_rgba.png').convert('RGBA')
    core = Image.open(I / 'A_food_core.png').convert('L')
    if bg.size != (1024,1024) or bowl.size != bg.size or core.size != bg.size:
        raise ValueError('All inputs must be 1024x1024')
    alpha = np.asarray(bowl.getchannel('A'))
    if bowl.getchannel('A').getbbox() != (212,453,819,853):
        raise ValueError('Unexpected product alpha bounds')
    # Standard Pillow straight-alpha composite in encoded sRGB, without scaling.
    composite = Image.alpha_composite(bg.convert('RGBA'), bowl).convert('RGB')
    rgb = np.asarray(bowl.convert('RGB')); result = np.asarray(composite)
    opaque_differences = int(np.count_nonzero(np.any(rgb[alpha == 255] != result[alpha == 255], axis=1)))
    if opaque_differences:
        raise ValueError('Opaque product pixels differ after compositing')
    distance = distance_transform_edt(alpha == 0)
    # Ring reaches full strength through 62 px and fades across the outer 8 px.
    ring = np.clip((70.0-distance)/8.0, 0, 1)
    yy,xx = np.mgrid[:1024,:1024]
    # Soft ellipse, centered in requested foot-shadow area. Falloff is smooth in the outer 8 px.
    cx,cy,rx,ry = 590.0,850.0,290.0,80.0
    radial = np.sqrt(((xx-cx)/rx)**2 + ((yy-cy)/ry)**2)
    ellipse = np.clip((1.0-radial)*min(rx,ry)/8.0, 0, 1)
    paint = np.rint(np.maximum(ring,ellipse)*255).astype(np.uint8)
    paint[alpha >= 1] = 0
    paste = 255-paint
    if np.any(paint[alpha>=1]) or np.any(paint.astype(np.uint16)+paste.astype(np.uint16)!=255):
        raise ValueError('Mask invariant failed')
    O.mkdir(parents=True,exist_ok=True)
    composite.save(O/'A_precomposite.png')
    Image.fromarray(paint).save(O/'A_paint.png')
    Image.fromarray(paste).save(O/'A_paste.png')
    core.save(O/'A_core.png')
    # Normalize the selected background to PNG while retaining the original byte hash in the record.
    bg.save(O/'BGsource.png')
    tint=Image.new('RGBA',bg.size,(255,0,0,0));tint.putalpha(Image.fromarray((paint.astype(np.float32)*0.5).astype(np.uint8)))
    ov=composite.convert('RGBA');ov.alpha_composite(tint);ov.convert('RGB').save(O/'A_paint_overlay.png')
    thumb=340; sheet=Image.new('RGB',(thumb*3,thumb+25),'white');draw=ImageDraw.Draw(sheet)
    for n,(label,im) in enumerate([('Background',bg),('Intermediate composite',composite),('Paint overlay',ov.convert('RGB'))]):
        draw.text((n*thumb+5,5),label,fill='black');sheet.paste(im.resize((thumb,thumb),Image.Resampling.LANCZOS),(n*thumb,25))
    sheet.save(O/'preview.png')
    report={'background_path':str(bg_path),'background_sha256':bg_hash,'review_record_path':str(review_path),'review_record_sha256':sha(review_path),'food_rgba_sha256':sha(I/'A_food_rgba.png'),'food_core_sha256':sha(I/'A_food_core.png'),'bounds_xyxy_exclusive':list(bowl.getchannel('A').getbbox()),'scale':1,'translation':[0,0],'composite':'Pillow alpha_composite, straight alpha in encoded sRGB, equivalent to standard source-over RGBA compositing','opaque_product_differing_pixels':opaque_differences,'paint_pixels_on_alpha_nonzero':int(np.count_nonzero(paint[alpha>=1])),'inverse_mask_sum_always_255':bool(np.all(paint.astype(np.uint16)+paste.astype(np.uint16)==255)),'ring_outer_distance_px':70,'outer_fade_px':8,'shadow_ellipse_bbox_xyxy':[300,770,880,930]}
    (O/'checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (O/'README.md').write_text('''# A branch intermediate input\n\nThis is an intermediate composite prepared from a background approved by root for a fusion test and the existing food-bowl asset. It is not an approved final product image. No image generation is performed by this script. The intended final contact shadow is to be generated by ComfyUI Q6; visual review remains required.\n\nA_paint is white in repaint regions and zero wherever product alpha is nonzero. A_paste is its inverse. A_core is the existing product core. The image uses ordinary source-over compositing in encoded sRGB. BGsource.png is a losslessly saved decoded copy; checks.json records the original background path and file SHA-256.\n''')
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
