"""Make text-preserving masks for the five approved-layout main replicas."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission export --legacy prepare_hd_main_exports -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import hashlib,json
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'output/TAOBAO_REPLICA_HD_20261103'
WORK=ROOT/'work/diagnostics/taobao_replica_hd_20261103/main_exports'
WORK.mkdir(exist_ok=True,parents=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
names=['手持展示','五色糖水碗','材质与检测报告','贴心细节','LOGO定制']
batch=[];previews=[]
for i in range(1,6):
 key=f'M{i:02d}'
 ref=BASE/f'01_参考底稿/主图/HD_{i:02d}_商品画布_参考.png'
 if i==2:ref=ROOT/'work/diagnostics/taobao_replica_hd_20261103/main_inputs/M02_overlay_recovered_v2.png'
 mask=Image.new('L',(615,615),255 if i in(1,2) else 0);d=ImageDraw.Draw(mask)
 if i==1:
  d.rectangle((33,32,194,145),fill=0);d.rectangle((0,534,614,614),fill=0);mask=mask.filter(ImageFilter.GaussianBlur(2))
 elif i==2:
  d.rectangle((0,0,614,149),fill=0)
  for y in range(150,168):d.line((0,y,614,y),fill=round(255*(y-150)/17))
 elif i==3:
  d.rectangle((357,307,614,614),fill=255);mask=mask.filter(ImageFilter.GaussianBlur(3))
 elif i==4:
  for box in [(42,107,331,260),(283,281,573,434),(43,450,333,601)]:d.rectangle(box,fill=255)
  mask=mask.filter(ImageFilter.GaussianBlur(.6))
 elif i==5:
  for box in [(78,90,310,289),(314,90,541,289)]:d.rounded_rectangle(box,radius=10,fill=255)
  for box in [(145,117,237,150),(380,117,470,150)]:d.rectangle(box,fill=0)
  mask=mask.filter(ImageFilter.GaussianBlur(2))
 mp=WORK/f'{key}_generated_mask.png';mask.convert('RGB').save(mp)
 src=Image.open(ref).convert('RGB');red=Image.new('RGB',src.size,(255,40,40));overlay=Image.composite(Image.blend(src,red,.35),src,mask);overlay.save(WORK/f'{key}_mask_preview.png')
 prep={'id':key,'reference':str(ref),'reference_sha256':sha(ref),'mask':str(mp),'mask_sha256':sha(mp),'mask_semantics':'white selects AI reconstruction; black preserves original Chinese lettering and inspection reports','source_geometry':[615,615]}
 (WORK/f'{key}_mask_preparation.json').write_text(json.dumps(prep,ensure_ascii=False,indent=2)+'\n')
 results=list((ROOT/f'work/diagnostics/taobao_replica_20261103/klein_refine_runs/{key}_HD_refine_step2').glob('*/result.json'))
 if len(results)!=1:
  print('pending',key);continue
 result=json.loads(results[0].read_text());gen=result['outputs']['generated']['path']
 c={'asset_id':key,'reference':str(ref),'generated':gen,'generated_mask':str(mp),'output_width':800,'output_path':str(BASE/f'02_ComfyUI复刻/主图/{key}_{names[i-1]}_复刻.png'),'root_review':{'status':'input_layout_and_mask_prepared_for_review','reviewer':'root','generation_result':str(results[0]),'note':'Source typography and certificate pixels restored; AI photograph reconstruction only in white mask regions.'}}
 cp=WORK/f'{key}.json';cp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');batch.append(str(cp))
contact=Image.new('RGB',(615*3,650*2),'#eeeeee');dd=ImageDraw.Draw(contact)
for i in range(1,6):
 x=((i-1)%3)*615;y=((i-1)//3)*650;contact.paste(Image.open(WORK/f'M{i:02d}_mask_preview.png'),(x,y+25));dd.text((x+5,y+3),f'M{i:02d} RED = AI PHOTO REGION',fill='black')
contact.resize((1230,867)).save(WORK/'main_masks_overview.jpg')
(WORK/'batch.json').write_text(json.dumps(batch,ensure_ascii=False,indent=2)+'\n')
print('prepared',len(batch),'main exports')
