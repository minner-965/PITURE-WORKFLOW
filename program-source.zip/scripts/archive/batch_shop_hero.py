#!/usr/bin/env python3
"""Sequential SKU/store hero pipeline. --plan performs only local validation."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission multishop --legacy batch_shop_hero -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]


import argparse, hashlib, json, re, subprocess, sys
from PIL import Image, ImageOps
import io
from auto_shop_reference import build as build_auto_reference
from shop_hero_history import check_layout_history, same_footprint
from fission.layout_shop_hero import TEXT_POSITIONS, resolve_design
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BACK = ROOT / "work/diagnostics/multishop_hero_refresh_v1"
RUNNER = BACK / "run_fusion.py"
RENDER = ROOT / "fission/layout_shop_hero.py"


def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def hashed(x):
    return hashlib.sha256(
        json.dumps(
            x, sort_keys=True, ensure_ascii=False, separators=(",", ":")
        ).encode()
    ).hexdigest()


def natural(s):
    return [
        (1, int(x)) if x.isdigit() else (0, x.lower())
        for x in re.split(r"(\d+)", str(s))
    ]


def phash(p):
    with Image.open(p) as im:
        pixels = ImageOps.exif_transpose(im).convert("L").resize((9, 8)).tobytes()
    return sum(
        (pixels[y * 9 + x] > pixels[y * 9 + x + 1]) << (y * 8 + x)
        for y in range(8)
        for x in range(8)
    )


def safe(s):
    if not re.fullmatch(r"[A-Za-z0-9_-]+", s):
        raise ValueError(
            "SKU/job id must contain only ASCII letters, digits, _ or -: " + s
        )
    return s


def path(p, base):
    q = Path(p).expanduser()
    return (q if q.is_absolute() else base / q).resolve(strict=True)


def verify(job, inputs, prompt, seed):
    d = BACK / "runs" / job
    ident = json.loads((d / "identity.json").read_text())
    result = json.loads((d / "result.json").read_text())
    submission = json.loads((d / "submission.json").read_text())
    history = json.loads((d / "history.json").read_text())
    if ident.get("job") != job or result.get("inputs") != ident.get("inputs"):
        raise ValueError("Existing result identity mismatch: " + job)
    if (
        not result.get("prompt_id")
        or result["prompt_id"] != submission.get("prompt_id")
        or result["prompt_id"] != history["prompt"][1]
    ):
        raise ValueError("Existing receipt/history mismatch: " + job)
    if (
        ident["seed"] != seed
        or ident["prompt"] != Path(prompt).read_text().strip()
        or set(ident["inputs"]) != set(inputs)
    ):
        raise ValueError("Existing job identity differs: " + job)
    for role, p in inputs.items():
        v = ident["inputs"][role]
        if v["path"] != str(p) or v["sha256"] != digest(p):
            raise ValueError("Existing job input differs: " + job + " " + role)
    for k in ("baseline_api", "baseline_ui"):
        q = ident[k]
        if digest(q["path"]) != q["sha256"]:
            raise ValueError("Baseline changed: " + job)
    out = Path(result["output"]["path"]).resolve()
    if not out.is_relative_to((d / "downloads").resolve()):
        raise ValueError("Output outside job downloads: " + job)
    images = history.get("outputs", {}).get("23", {}).get("images", [])
    if len(images) != 1 or out.name != "23_0_" + images[0]["filename"]:
        raise ValueError("Output does not match job history: " + job)
    if digest(out) != result["output"]["sha256"]:
        raise ValueError("Existing output changed: " + job)
    return out


def run_child(command, **kwargs):
    from fission.runtime import execution
    scope = execution.get() or {}
    command = list(command)
    if scope.get("force_regenerate"):
        boundary = command.index("--")
        command[boundary:boundary] = ["--force-regenerate", "--reason", scope["reason"]]
    return subprocess.run(command, **kwargs)


def runjob(job, inputs, prompt, seed, plan):
    d = BACK / "runs" / job
    if (d / "result.json").exists():
        return verify(job, inputs, prompt, seed)
    if plan:
        return None
    cmd = [sys.executable, "-m", "fission", "scene", "--legacy", "run_fusion", "--", "--job", job]
    if (d / "submission.json").exists():
        cmd += ["--resume"]
    else:
        cmd += [
            "--background",
            str(inputs["background"]),
            "--prompt-file",
            str(prompt),
            "--seed",
            str(seed),
        ]
        cmd += (
            ["--product", str(inputs["product"])]
            if "product" in inputs
            else ["--background-only"]
        )
    run_child(cmd, check=True, cwd=ROOT)
    return verify(job, inputs, prompt, seed)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("manifest", type=Path, nargs="?")
    p.add_argument("--sku-root", type=Path)
    p.add_argument("--native-sample", metavar="SHOP/DISH/VERSION", help="只处理该店的一份原生双参考样图")
    p.add_argument("--shops", help="Comma-separated store IDs")
    p.add_argument("--plan", action="store_true")
    p.add_argument("--run", action="store_true")
    p.add_argument(
        "--output", type=Path, default=ROOT / "work/diagnostics/multishop_hero_batches"
    )
    a = p.parse_args()
    if bool(a.manifest) == bool(a.sku_root):
        raise ValueError("Supply exactly one manifest or --sku-root")
    if a.plan and a.run:
        raise ValueError("Choose either --plan or --run")
    if a.native_sample and a.sku_root:
        raise ValueError("--native-sample 需要原生批次清单")
    if a.sku_root:
        root = a.sku_root.resolve(strict=True)
        skus = []
        for f in sorted(root.glob("*/sku.json")):
            item = json.loads(f.read_text())
            item["_config_base"] = str(f.parent.resolve())
            skus.append(item)
        if not skus:
            raise ValueError("No */sku.json files found")
        base = root
    else:
        manifest = a.manifest.resolve(strict=True)
        base = manifest.parent
        data = json.loads(manifest.read_text())
        if data.get("mode") == "fission":
            from fission.check import check
            run_dir = path(data["run_dir"], base)
            product = path(data["product"], base)
            shops = a.shops.split(",") if a.shops else None
            if data.get("route") == "native_dual_reference":
                if not a.native_sample:
                    if a.run:
                        raise ValueError("实际运行须指定 --native-sample SHOP/DISH/VERSION，一次只生成一张")
                    for line in check(run_dir, product, shops):
                        print(line)
                    return
                sample = a.native_sample.split("/")
                if len(sample) != 3 or (shops and sample[0] not in shops):
                    raise ValueError("单张目标应为当前店铺的 SHOP/DISH/VERSION")
                shop, dish, version = sample
                cmd = [sys.executable, "-m", "fission", "food", "--",
                       "--run", str(run_dir), "--shop", shop, "--dish", dish, "--version", version]
                if a.run:
                    cmd.append("--submit")
                run_child(cmd, check=True, cwd=ROOT)
                return
            if a.native_sample:
                raise ValueError("请使用 route=native_dual_reference 的批次清单")
            for line in check(run_dir, product, shops):
                print(line, flush=True)
            if a.run:
                for shop in shops or [None]:
                    cmd = [sys.executable, "-m", "fission", "food", "--legacy", "run_layers", "--",
                           "--run", str(run_dir), "--product", str(product), "--stage", data.get("stage", "preview")]
                    if shop:
                        cmd += ["--shop", shop]
                    run_child(cmd, check=True, cwd=ROOT)
            return
        if a.native_sample:
            raise ValueError("--native-sample 只用于原生裂变批次")
        skus = data["skus"]
    selected = set(a.shops.split(",")) if a.shops else None
    ids = [safe(x["id"]) for x in skus]
    if len(set(ids)) != len(ids):
        raise ValueError("Duplicate SKU id")
    if not RUNNER.is_file():
        raise ValueError("Missing fusion runner")
    # Renderer is checked during execution: it may be developed while planning.
    if not a.plan and not RENDER.is_file():
        raise ValueError("Missing renderer: " + str(RENDER))
    jobs = []
    for sku in sorted(
        skus, key=lambda x: (int(x.get("order", 999999)), natural(x["id"]))
    ):
        sku_base = Path(sku.get("_config_base", base))
        seen = []
        seen_backgrounds = []
        for shop in sorted(
            sku["shops"],
            key=lambda name: (
                0
                if sku["shops"][name].get("product") or not sku.get("auto_assets")
                else 1,
                natural(name),
            ),
        ):
            safe(shop)
            cfg = sku["shops"][shop]
            style = cfg["style"]
            text_position = cfg.get("text_position", "bottom")
            if text_position not in TEXT_POSITIONS:
                raise ValueError(f"{shop}: text_position must be top or bottom")
            copy = cfg.get("copy", sku.get("copy", {}))
            if (
                not isinstance(copy.get("title"), str)
                or not copy["title"].strip()
                or not 1 <= len(copy.get("benefits", [])) <= 3
                or not all(isinstance(v, str) and v.strip() for v in copy["benefits"])
            ):
                raise ValueError(
                    "Each shop requires explicit title and 1–3 verified benefits"
                )
            design_key = cfg.get(
                "design_key", None if shop in "ABC" and len(shop) == 1 else shop
            )
            design = resolve_design(style, design_key)
            if style not in "ABC" or len(style) != 1:
                raise ValueError("style must be A, B or C")
            auto = None
            if not cfg.get("product") and sku.get("auto_assets"):
                metadata = sku["auto_assets"]
                sources = [
                    path(v["path"] if isinstance(v, dict) else v, sku_base)
                    for v in metadata
                ]
                # Reserve explicit layouts first, then choose the first unoccupied automatic plan.
                index = 0
                while True:
                    auto = build_auto_reference(sources, index, metadata=metadata)
                    trial_boxes = auto["bounds"]
                    trial_sig = phash(io.BytesIO(auto["bytes"]))
                    try:
                        check_layout_history(
                            sku["id"], shop, auto["sha256"], trial_sig, trial_boxes
                        )
                        if any(
                            (trial_sig ^ psig).bit_count() <= 3
                            or same_footprint(trial_boxes, pbounds)
                            for _, psig, _, pbounds in seen
                        ):
                            raise ValueError("layout already used in this batch")
                    except ValueError:
                        index += 1
                        continue
                    break
                product = a.output.resolve() / "_references" / (auto["sha256"] + ".png")
                cfg = dict(cfg)
                cfg["composition"] = {
                    "layout_id": auto["name"],
                    "subject_count": auto["count"],
                    "stacking": auto["stacking"],
                    "arrangement": auto["name"],
                    "camera": auto["view"],
                    "bounds": auto["bounds"],
                }
            else:
                product = path(cfg.get("product", sku.get("product", "")), sku_base)
            layout = cfg["composition"]
            required = [
                "layout_id",
                "subject_count",
                "stacking",
                "arrangement",
                "camera",
            ]
            if any(k not in layout or str(layout[k]).strip() == "" for k in required):
                raise ValueError("Missing composition fields: " + shop)
            bounds = layout.get("bounds")
            if (
                not isinstance(bounds, list)
                or len(bounds) != int(layout["subject_count"])
                or any(
                    not isinstance(b, list)
                    or len(b) != 4
                    or any(
                        not isinstance(v, (int, float)) or not 0 <= v <= 1 for v in b
                    )
                    or b[0] >= b[2]
                    or b[1] >= b[3]
                    for b in bounds
                )
            ):
                raise ValueError(
                    "composition.bounds must contain one normalized [left,top,right,bottom] box per subject: "
                    + shop
                )
            bounds = sorted(tuple(float(v) for v in b) for b in bounds)
            sig = phash(io.BytesIO(auto["bytes"])) if auto else phash(product)
            structural = tuple(str(layout[k]).strip().casefold() for k in required[1:])
            for prevshop, prevsig, prevstruct, prevbounds in seen:
                if (sig ^ prevsig).bit_count() <= 3:
                    raise ValueError(
                        "Duplicate or nearly identical product placement references: "
                        + prevshop
                        + " / "
                        + shop
                    )
                if structural == prevstruct:
                    raise ValueError(
                        "Duplicate composition attributes: " + prevshop + " / " + shop
                    )
                if same_footprint(bounds, prevbounds):
                    raise ValueError(
                        "Duplicate subject positions: " + prevshop + " / " + shop
                    )
            check_layout_history(
                sku["id"],
                shop,
                auto["sha256"] if auto else digest(product),
                sig,
                bounds,
            )
            seen.append((shop, sig, structural, bounds))
            bg = path(cfg["background"], sku_base)
            bp = path(cfg["background_prompt"], sku_base)
            fp = path(cfg["fusion_prompt"], sku_base)
            bs = int(cfg["background_seed"])
            fs = int(cfg["fusion_seed"])
            for prompt in [bp, fp]:
                if not prompt.read_text().strip():
                    raise ValueError("Empty prompt: " + str(prompt))
            generated_prompt = None
            if auto:
                template = fp.read_text(encoding="utf-8")
                if "{AUTO_LAYOUT}" not in template:
                    raise ValueError(
                        "Automatic placement requires {AUTO_LAYOUT} in fusion_prompt: "
                        + shop
                    )
                directive = (
                    f"Recreate the {auto['count']} photographed group(s) in reference image 2. "
                    f"{auto['placement_text']} "
                    "Match the pictured number of vessels within every group, their relative "
                    "sizes and depth order, and any food or hands shown with the product."
                )
                generated_prompt = template.replace("{AUTO_LAYOUT}", directive)
                prompt_sha = hashlib.sha256(generated_prompt.encode()).hexdigest()
                fp = a.output.resolve() / "_prompts" / (prompt_sha + ".txt")
            # Background, fusion and layout identities have separate dependencies.
            baselines = [
                digest(BACK / "baseline_D4_v02/双参考.api.json"),
                digest(BACK / "baseline_D4_v02/双参考.ui.json"),
            ]
            runtime = {"runner": digest(RUNNER), "baselines": baselines}
            background_key = hashed(
                {"input": digest(bg), "prompt": digest(bp), "seed": bs, **runtime}
            )[:16]
            bgjob = safe(
                cfg.get(
                    "existing_background_job", f"{sku['id']}_{shop}_{background_key}_bg"
                )
            )
            for oldshop, oldjob, oldkey in seen_backgrounds:
                if (
                    cfg.get("existing_background_job") and bgjob == oldjob
                ) or background_key == oldkey:
                    raise ValueError(
                        "Duplicate background job or inputs: " + oldshop + " / " + shop
                    )
            seen_backgrounds.append((shop, bgjob, background_key))
            if selected and shop not in selected:
                continue
            product_sha = auto["sha256"] if auto else digest(product)
            fusion_key = hashed(
                {
                    "background_job": bgjob,
                    "background_identity": background_key,
                    "product": product_sha,
                    "prompt": hashlib.sha256(generated_prompt.encode()).hexdigest()
                    if generated_prompt
                    else digest(fp),
                    "seed": fs,
                    **runtime,
                }
            )[:16]
            fjob = safe(
                cfg.get(
                    "existing_fusion_job", f"{sku['id']}_{shop}_{fusion_key}_fusion"
                )
            )
            reviewed = cfg.get("reviewed_photo")
            if reviewed:
                reviewed = dict(reviewed)
                reviewed_path = path(reviewed["path"], sku_base)
                if digest(reviewed_path) != reviewed["sha256"]:
                    raise ValueError("Reviewed photo hash mismatch: " + shop)
                reviewed["path"] = str(reviewed_path)
            layout_key = hashed(
                {
                    "fusion_job": fjob,
                    "copy": copy,
                    "style": style,
                    "text_position": text_position,
                    "design_key": design_key,
                    "design": design,
                    "reviewed_photo": reviewed,
                    "renderer": digest(RENDER) if RENDER.exists() else None,
                }
            )[:16]
            dest = a.output.resolve() / sku["id"] / shop / layout_key
            identity = {
                "sku_id": sku["id"],
                "shop": shop,
                "composition": layout,
                "product_sha256": product_sha,
                "background_sha256": digest(bg),
                "background_prompt_sha256": digest(bp),
                "fusion_prompt_sha256": hashlib.sha256(
                    generated_prompt.encode()
                ).hexdigest()
                if generated_prompt
                else digest(fp),
                "runner_sha256": digest(RUNNER),
                "baselines": baselines,
                "background_key": background_key,
                "fusion_key": fusion_key,
                "layout_key": layout_key,
                "text_position": text_position,
                "auto_sources": [
                    {"path": str(v), "sha256": digest(v), "metadata": metadata[i]}
                    for i, v in enumerate(sources)
                ]
                if auto
                else None,
            }
            jobs.append(
                {
                    "sku": sku["id"],
                    "shop": shop,
                    "style": style,
                    "text_position": text_position,
                    "design_key": design_key,
                    "design": design,
                    "reviewed": reviewed,
                    "auto": auto,
                    "generated_prompt": generated_prompt,
                    "existing_background": bool(cfg.get("existing_background_job")),
                    "existing_fusion": bool(cfg.get("existing_fusion_job")),
                    "background_job": bgjob,
                    "fusion_job": fjob,
                    "destination": str(dest),
                    "identity": identity,
                    "product": product,
                    "background": bg,
                    "bp": bp,
                    "fp": fp,
                    "bs": bs,
                    "fs": fs,
                    "copy": copy,
                }
            )
    if not jobs:
        raise ValueError("No matching shops selected")
    sku_order = {
        sku["id"]: i
        for i, sku in enumerate(
            sorted(skus, key=lambda x: (int(x.get("order", 999999)), natural(x["id"])))
        )
    }
    jobs.sort(key=lambda j: (sku_order[j["sku"]], natural(j["shop"])))
    # Validate all requested existing jobs before any generation.
    for j in jobs:
        if (BACK / "runs" / j["background_job"] / "result.json").exists():
            finished_bg = verify(
                j["background_job"], {"background": j["background"]}, j["bp"], j["bs"]
            )
            if j["existing_fusion"]:
                if j["auto"]:
                    raise ValueError(
                        "Existing fusion with generated reference requires an explicit materialized product reference"
                    )
                verified_fusion = verify(
                    j["fusion_job"],
                    {"background": finished_bg, "product": j["product"]},
                    j["fp"],
                    j["fs"],
                )
                if (
                    j["reviewed"]
                    and digest(verified_fusion) != j["reviewed"]["fusion_sha256"]
                ):
                    raise ValueError("Reviewed photo fusion binding mismatch")
        elif j["existing_fusion"]:
            raise ValueError("Existing fusion requires finished background")
        elif j["existing_background"]:
            raise ValueError(
                "Requested background job has no finished result: "
                + j["background_job"]
            )
        print(
            json.dumps(
                {
                    k: j[k]
                    for k in [
                        "sku",
                        "shop",
                        "background_job",
                        "fusion_job",
                        "destination",
                    ]
                },
                ensure_ascii=False,
            ),
            flush=True,
        )
    if a.plan:
        return
    for j in jobs:
        if j["generated_prompt"] is not None:
            j["fp"].parent.mkdir(parents=True, exist_ok=True)
            if j["fp"].exists() and j["fp"].read_text() != j["generated_prompt"]:
                raise ValueError("Automatic prompt changed")
            if not j["fp"].exists():
                j["fp"].write_text(j["generated_prompt"])
        if j["auto"]:
            product = j["product"]
            product.parent.mkdir(parents=True, exist_ok=True)
            if product.exists() and digest(product) != j["auto"]["sha256"]:
                raise ValueError("Automatic reference changed: " + str(product))
            if not product.exists():
                product.write_bytes(j["auto"]["bytes"])
        dest = Path(j["destination"])
        dest.mkdir(parents=True, exist_ok=True)
        (dest / "identity.json").write_text(
            json.dumps(j["identity"], ensure_ascii=False, indent=2)
        )
        cp = dest / "copy.json"
        cp.write_text(json.dumps(j["copy"], ensure_ascii=False, indent=2))
        bg = runjob(
            j["background_job"],
            {"background": j["background"]},
            j["bp"],
            j["bs"],
            False,
        )
        fused = runjob(
            j["fusion_job"],
            {"background": bg, "product": j["product"]},
            j["fp"],
            j["fs"],
            False,
        )
        photo = fused
        if j["reviewed"]:
            if digest(fused) != j["reviewed"]["fusion_sha256"]:
                raise ValueError("Reviewed photo fusion binding mismatch")
            photo = Path(j["reviewed"]["path"])
            if digest(photo) != j["reviewed"]["sha256"]:
                raise ValueError("Reviewed photo changed")
        out = dest / "candidate.png"
        receipt = dest / "layout_result.json"
        fingerprint = hashed(
            {
                "fusion": digest(fused),
                "photo": digest(photo),
                "copy": digest(cp),
                "renderer": digest(RENDER),
                "style": j["style"],
                "text_position": j["text_position"],
                "design_key": j["design_key"],
                "design": j["design"],
            }
        )
        if receipt.exists():
            old = json.loads(receipt.read_text())
            if (
                old["fingerprint"] != fingerprint
                or not out.is_file()
                or digest(out) != old["sha256"]
            ):
                raise ValueError("Layout receipt mismatch: " + str(dest))
        else:
            subprocess.run(
                [
                    sys.executable,
                    "-m", "fission", "layout", "--mode", "shop-hero", "--",
                    "--image",
                    str(photo),
                    "--style",
                    j["style"],
                    "--copy",
                    str(cp),
                    "--out",
                    str(out),
                    "--size",
                    "800",
                    "--text-position",
                    j["text_position"],
                ]
                + (
                    ["--design-key", j["design_key"]]
                    if j["design_key"] is not None
                    else []
                ),
                check=True,
                cwd=ROOT,
            )
            receipt.write_text(
                json.dumps(
                    {
                        "status": "pending_root_visual_review",
                        "fingerprint": fingerprint,
                        "source": str(photo),
                        "source_sha256": digest(photo),
                        "fusion_path": str(fused),
                        "fusion_sha256": digest(fused),
                        "output": str(out),
                        "sha256": digest(out),
                        "background_job": j["background_job"],
                        "fusion_job": j["fusion_job"],
                        "text_position": j["text_position"],
                        "design_key": j["design_key"],
                        "design": j["design"],
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, OSError, subprocess.CalledProcessError) as e:
        print("Error:", e, file=sys.stderr)
        sys.exit(1)
