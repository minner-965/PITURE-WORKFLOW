
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission food --legacy run_food_assets -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

import argparse,csv,fcntl,hashlib,json,os,tempfile
from pathlib import Path
from PIL import Image,PngImagePlugin
import numpy as np,yaml
from comfy_client import ComfyClient,sync_ui
from build_workflows import make_a,check_graph,ui
from restore_and_check import restore
from prompt_rules import resolve_food_prompt, lint_prompt
ROOT=Path(__file__).resolve().parents[2]; OUT=ROOT/'output/LISTING_V3/w1125/assets/filled_bowls'; LOG=ROOT/'work/logs/listing_v3'; CSV=ROOT/'config/food_assets.csv'
DISHES={'blue_century_pork_congee':('blue','century_pork_congee'),'yellow_salted_bone_congee':('yellow','salted_bone_congee'),'red_fish_congee':('red','fish_congee'),'green_mungbean':('green','mungbean'),'orange_redbean':('orange','redbean'),'yellow_tremella':('yellow','tremella'),'green_corn_rib_soup':('green','corn_rib_soup')}

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def upsert_row(record):
 fields=['asset_id','color_id','view_id','dish_id','rgba_filled','source_hash','mask_hash','prompt_hash','seed','status']
 lock=ROOT/'config/.food_assets.lock'
 with lock.open('a+') as guard:
  fcntl.flock(guard.fileno(),fcntl.LOCK_EX)
  rows=list(csv.DictReader(CSV.open(encoding='utf-8-sig'))) if CSV.exists() else []
  rows=[r for r in rows if r['asset_id']!=record['asset_id']]+[record]
  temp=None
  try:
   with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8-sig',newline='',dir=CSV.parent,prefix='.food_assets.',suffix='.tmp',delete=False) as f:
    temp=f.name;w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows);f.flush();os.fsync(f.fileno())
   os.replace(temp,CSV)
  finally:
   if temp and os.path.exists(temp):os.unlink(temp)
   fcntl.flock(guard.fileno(),fcntl.LOCK_UN)
def main():
 p=argparse.ArgumentParser();p.add_argument('--job',choices=DISHES);p.add_argument('--execute',action='store_true');p.add_argument('--approved-mask-hash');a=p.parse_args()
 if not a.job:print('Specify a job; existing orange reuse is preserved');return
 color,dish=DISHES[a.job];products=list(csv.DictReader((ROOT/'config/product_assets.csv').open(encoding='utf-8-sig')));row=next(r for r in products if r['color_id']==color);base=Path(row['base_image']);inner=Path(row['inner_mask']);core=Path(row['core_mask']);empty=Path(row['rgba_empty']);maskhash=sha(inner)
 if sha(row['source_photo'])!=row['source_hash']:raise ValueError('Source photograph hash mismatch')
 if not all(Image.open(x).size==(1024,1024) for x in [base,inner,core,empty]):raise ValueError('Image and masks must share 1024×1024 coordinates')
 inner_arr=np.array(Image.open(inner).convert('L'));core_arr=np.array(Image.open(core).convert('L'))>=128
 if not (inner_arr>0).any() or not core_arr.any():raise ValueError('Inner or core mask is empty')
 if np.any((inner_arr>0)&core_arr):raise ValueError('Paint mask overlaps protected core')
 prompt=resolve_food_prompt(dish)
 override_path=ROOT/'prompts/food_overrides.yaml';overrides=yaml.safe_load(override_path.read_text()) if override_path.exists() else {};override=(overrides or {}).get(a.job,{})
 if 'prompt' in override:
  override_prompt=override['prompt']; validation=lint_prompt('food',override_prompt)
  if validation['errors']:raise ValueError(f'Invalid food override {a.job}: {validation["errors"]}')
  prompt=override_prompt
 validation=lint_prompt('food',prompt)
 if validation['errors']:raise ValueError(f'Invalid food prompt {a.job}: {validation["errors"]}')
 g=make_a();g['7']['inputs']['text']=prompt;g['12']['inputs']['seed']=override.get('seed',20261103+list(DISHES).index(a.job))
 for k in ['3','14','16','17','18']:g.pop(k)
 identity={'source_hash':row['source_hash'],'base_hash':sha(base),'inner_hash':maskhash,'core_hash':sha(core),'prompt_hash':hashlib.sha256(prompt.encode()).hexdigest(),'seed':g['12']['inputs']['seed'],'prompt_version':2,'dish_id':dish,'region_type':'food'}
 revision=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()[:20]
 g['15']['inputs']['filename_prefix']='ComfyProductPipeline/listing_v3/prompt_v2/'+a.job+'/'+revision
 c=ComfyClient();info=c.get('/object_info');checks=check_graph(g,info);u=ui(g,info,'Q6 food asset','Only the approved inner mask is painted. Outer product pixels are restored. Visual review required.')
 log=LOG/'prompt_v2'/a.job/('attempt_'+revision);log.mkdir(parents=True,exist_ok=True)
 workflow=ROOT/'workflows/food_v2'/a.job/revision;workflow.mkdir(parents=True,exist_ok=True)
 if (workflow/'ui.json').exists():u['id']=json.loads((workflow/'ui.json').read_text())['id']
 task={'job':a.job,'prompt':prompt,'identity':identity,'prompt_lint':validation,'base':str(base),'inner_mask':str(inner),'inner_mask_sha256':maskhash,'core':str(core),'checks':checks,'graph':g}
 def write_once(path,data):
  text=json.dumps(data,ensure_ascii=False,indent=2)
  if path.exists():
   if json.loads(path.read_text())!=data:raise ValueError(f'Existing revision differs: {path}')
  else:path.write_text(text)
 for suffix,data in [('api',g),('ui',u)]:write_once(workflow/f'{suffix}.json',data)
 write_once(log/'task.json',task);write_once(log/'identity.json',identity)
 print('prepared',log/'task.json',flush=True)
 if not a.execute:return
 if a.approved_mask_hash!=maskhash:raise ValueError('Provide the reviewed mask SHA256 to execute this asset')
 OUT.mkdir(parents=True,exist_ok=True)
 sub=log/'submission.json';result=log/'result.json'
 if result.exists():
  old=json.loads(result.read_text())
  if old.get('identity')!=identity or not Path(old.get('output','')).is_file() or sha(old['output'])!=old.get('output_sha256'):raise ValueError('Cached result does not match this revision')
  print('already complete',result);return
 if sub.exists():pid=c.reconcile(sub)
 else:
  q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('Queue is occupied')
  g['1']['inputs']['image']=c.upload(base);g['2']['inputs']['image']=c.upload(inner)
  check_graph(g,info); synced=sync_ui(g,u,info)
  for node_id in ('1','2'):
   visual=next(n for n in synced['nodes'] if str(n['id'])==node_id)
   if visual['widgets_values'][0]!=g[node_id]['inputs']['image']:raise ValueError('UI/API upload name mismatch')
  (log/'ui_api_validation.json').write_text(json.dumps({'status':'passed','uploaded_inputs':{k:g[k]['inputs']['image'] for k in ('1','2')},'ui_and_api_match':True},ensure_ascii=False,indent=2))
  pid=c.submit(g,synced,sub)
 print('submitted',pid,flush=True)
 import subprocess
 backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip())
 try:
  h,m=c.wait(pid,log,backend,7200);files=c.download(h,log/'downloads');raw=files['15'][0]
  import shutil
  backend_log=Path('/Users/luohuiwu/ComfyUI-Installs/E-commerce image workflow/logs/comfyui.log')
  if backend_log.is_file():shutil.copyfile(backend_log,log/'comfyui_full.log')
  # Restore every pixel outside the inner mask; core must match exactly.
  src=np.array(Image.open(base).convert('RGB'));gen=np.array(Image.open(raw).convert('RGB'));alpha=np.array(Image.open(inner).convert('L'),dtype=np.float32)[:,:,None]/255
  combined=np.rint(src*(1-alpha)+gen*alpha).clip(0,255).astype('uint8');C=np.array(Image.open(core).convert('L'))>=128;combined[C]=src[C]
  submission=json.loads(sub.read_text());request=submission['request'];actual_graph=request['prompt'];actual_ui=request['extra_data']['extra_pnginfo']['workflow']
  actual_graph_hash=hashlib.sha256(json.dumps(actual_graph,sort_keys=True).encode()).hexdigest();ui_hash=hashlib.sha256(json.dumps(actual_ui,sort_keys=True).encode()).hexdigest()
  alpha_hash=sha(empty);alpha_pixel_hash=hashlib.sha256(Image.open(empty).convert('RGBA').getchannel('A').tobytes()).hexdigest();model_inventory=json.loads((ROOT/'work/diagnostics/model_inventory.json').read_text());model_hashes={v['path']:v.get('sha256') for v in model_inventory['models']}
  metadata={'prompt_version':2,'dish_id':dish,'region_type':'food','prompt':actual_graph,'workflow':actual_ui,'graph_sha256':actual_graph_hash,'ui_sha256':ui_hash,'identity':identity,'empty_rgba_sha256':alpha_hash,'alpha_pixel_sha256':alpha_pixel_hash,'model_hashes':model_hashes}
  image=Image.fromarray(combined,'RGB').convert('RGBA');image.putalpha(Image.open(empty).convert('RGBA').getchannel('A'));out=OUT/(a.job+'_'+revision+'.png');pnginfo=PngImagePlugin.PngInfo();pnginfo.add_text('prompt',json.dumps(actual_graph,ensure_ascii=False));pnginfo.add_text('workflow',json.dumps(actual_ui,ensure_ascii=False));image.save(out,pnginfo=pnginfo)
  decoded=np.array(Image.open(out).convert('RGBA'));diff=np.abs(decoded[:,:,:3].astype('int16')-src.astype('int16'))[C];core_diff=int(diff.max());diffcount=int(np.any(diff,axis=1).sum())
  if core_diff or not np.array_equal(decoded[:,:,3],np.array(Image.open(empty).convert('RGBA'))[:,:,3]):raise ValueError('Saved PNG failed core or alpha validation')
  (out.with_suffix('.json')).write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
  record={'asset_id':a.job+'_v2_'+revision,'color_id':color,'view_id':row['view_id'],'dish_id':dish,'rgba_filled':str(out),'source_hash':row['source_hash'],'mask_hash':maskhash,'prompt_hash':hashlib.sha256(prompt.encode()).hexdigest(),'seed':str(g['12']['inputs']['seed']),'status':'generated_pending_review'}
  upsert_row(record)
  result.write_text(json.dumps({'status':'generated_pending_review','identity':identity,'prompt_id':pid,'files':files,'output':str(out),'output_sha256':sha(out),'core_count':int(C.sum()),'core_hash':sha(core),'core_diff_max':core_diff,'core_diff_count':diffcount,'empty_rgba_sha256':alpha_hash,'alpha_pixel_sha256':alpha_pixel_hash,'actual_graph_hash':actual_graph_hash,'actual_ui_hash':ui_hash,'model_hashes':model_hashes,'measurements':m},ensure_ascii=False,indent=2));print('completed',out,'core_diff_max',core_diff,flush=True)
 except Exception as e:
  (log/'failure.json').write_text(json.dumps({'prompt_id':pid,'error':str(e)},ensure_ascii=False,indent=2));raise
if __name__=='__main__':main()
