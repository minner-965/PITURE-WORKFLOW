
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission layout --legacy multishop_A_hero_color_v3 -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
from PIL import Image,ImageDraw
from scipy import ndimage as ndi
import numpy as np,json,hashlib
B=Path('/Users/luohuiwu/codex/ComfyProductPipeline');D=B/'work/diagnostics/multishop_20261103'; O=D/'blue_green_candidates_v3'; reg=json.load(open(B/'config/multishop_scene_assets.json')); report=json.load(open(D/'color_audit_v1/report.json'))
# Carefully traced colored exterior, source pixel coordinates. Inward feather keeps mask strictly inside outline.
regions={'A_hero':{'blue':[[(380,317),(391,324),(405,330),(420,335),(439,340),(460,344),(485,347),(510,348),(533,346),(555,343),(579,338),(603,330),(625,323),(642,318),(640,335),(635,351),(628,365),(619,378),(608,389),(597,398),(583,407),(579,418),(568,424),(552,429),(533,431),(510,433),(487,433),(470,429),(460,425),(451,421),(444,416),(441,410),(441,405),(435,401),(430,398),(425,394),(420,390),(415,385),(410,379),(405,373),(400,366),(395,357),(390,346),(385,333),(382,322)]]}}
def tolab(x):
 x=x/255.;x=np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4);z=x@np.array([[.4124564,.2126729,.0193339],[.3575761,.7151522,.119192],[.1804375,.0721750,.9503041]]);z/=np.array([.95047,1,1.08883]);f=np.where(z>(6/29)**3,np.cbrt(z),z/(3*(6/29)**2)+4/29);return np.stack([116*f[...,1]-16,500*(f[...,0]-f[...,1]),200*(f[...,1]-f[...,2])],-1)
def torgb(l):
 fy=(l[:,:,0]+16)/116;f=np.stack([fy+l[:,:,1]/500,fy,fy-l[:,:,2]/200],-1);z=np.where(f>6/29,f**3,3*(6/29)**2*(f-4/29))*np.array([.95047,1,1.08883]);x=z@np.linalg.inv(np.array([[.4124564,.2126729,.0193339],[.3575761,.7151522,.119192],[.1804375,.0721750,.9503041]]));x=np.clip(x,0,1);return np.rint(np.where(x<=.0031308,12.92*x,1.055*x**(1/2.4)-.055)*255).clip(0,255).astype('uint8')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def record(p):return {'path':str(p),'sha256':sha(p)}
all=[]
for scene,colors in regions.items():
 shop,key=scene.split('_',1);e=reg[shop][key];p=Path(e['path']);a=np.array(Image.open(p).convert('RGB'));h,w=a.shape[:2];L=tolab(a.astype(float));out=a.copy();maskall=np.zeros((h,w),np.uint8);details=[];refs=[];dest=O/scene;dest.mkdir(parents=True,exist_ok=True)
 for color,polys in colors.items():
  m=Image.new('L',(w,h));d=ImageDraw.Draw(m)
  for poly in polys:d.polygon(poly,fill=255)
  interior=np.asarray(m)>0
  # Whole ceramic interior receives the same continuous color transform.
  distance=ndi.distance_transform_edt(interior);alpha=np.clip((distance-1)/2,0,1);mask=np.rint(alpha*255).astype('uint8');maskall=np.maximum(maskall,mask)
  rr=[x for x in report['rows'] if x['scene']==scene and x['color']==color and 'sample'in x];ref=report['references']['side_'+color];s=rr[0]['sample']['lab_median'] if rr else ([50,-5,-20] if color=='blue' else [50,-12,38]);v=ref['lab_median']
  deltaL=min(15,max(7,(v[0]-s[0])*.45));da=float(np.clip((v[1]-s[1])*.8,-22,22));db=float(np.clip((v[2]-s[2])*.8,-22,22)); tone=np.clip((95-L[:,:,0])/35,0,1);tmp=L.copy();tmp[:,:,0]+=deltaL*alpha*tone;tmp[:,:,1]+=da*alpha*tone;tmp[:,:,2]+=db*alpha*tone;rgb=torgb(tmp);out[mask>0]=rgb[mask>0];Image.fromarray(mask).save(dest/f'{color}_mask.png');details.append({'color':color,'polygon_source_pixels':polys,'delta_L':round(deltaL,2),'delta_a':round(da,2),'delta_b':round(db,2),'highlight_taper':'clamp((95-L)/35,0,1)','edge_feather_px':2,'sample_lab':s,'reference_lab':v});refs.append(record(ref['path']))
 maskpath=dest/'mask.png';output=dest/'candidate.png';Image.fromarray(maskall).save(maskpath);Image.fromarray(out).save(output);overlay=Image.composite(Image.blend(Image.fromarray(a),Image.new('RGB',(w,h),(255,0,255)),.5),Image.fromarray(a),Image.fromarray(maskall));overlay.save(dest/'overlay.png');before=Image.new('RGB',(w*2,h));before.paste(Image.fromarray(a),(0,0));before.paste(Image.fromarray(out),(w,0));before.save(dest/'before_after.png');changed=np.any(a!=out,2);outside=int((changed&(maskall==0)).sum());gens=[e['generation_result']]+e.get('additional_generation_results',[])
 obj={'status':'pending_root_visual_review','source_original':record(p),'mask':record(maskpath),'output':record(output),'additional_sources':refs,'generation_results':gens,'generation_result_hashes':[record(g) for g in gens],'color_parameters':{'space':'CIELAB D65','method':'Reference-driven bounded Lab offsets applied continuously over traced ceramic surface; highlight taper, inward feather, sRGB gamut clipping','details':details},'outside_mask_exact':outside==0,'outside_changed_pixels':outside}
 if e.get('composition_provenance'):obj['upstream_composition_provenance']=record(e['composition_provenance'])
 (dest/'composition.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2));all.append({'scene':scene,'output':str(output),'outside_changed_pixels':outside})
print(json.dumps(all,ensure_ascii=False,indent=2))
