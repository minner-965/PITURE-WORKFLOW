#!/usr/bin/env python3
"""Prepare a pending-review D20 layout and an unsubmitted, deterministic Comfy graph."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission layout --legacy prepare_replica_d20_dimensions -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

import hashlib,io,json
from pathlib import Path
from PIL import Image,ImageCms,ImageDraw,ImageFont,ImageOps
from build_workflows import node,check_graph,ui

R=Path(__file__).resolve().parents[2];P=R/'input/supplied_20261102/测试品/sku实拍';WORK=R/'work/diagnostics/taobao_replica_20261103/D20_dimensions';OUT=R/'output/TAOBAO_REPLICA_20261103/drafts';WF=R/'workflows/taobao_replica_20261103';FONT='/System/Library/Fonts/STHeiti Medium.ttc'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def picture(path,box):
 with Image.open(path) as source:
  if source.size!=(6240,4160):raise ValueError('Unexpected source dimensions: '+str(path))
  im=ImageOps.exif_transpose(source);icc=im.info.get('icc_profile')
  if icc:im=ImageCms.profileToProfile(im,ImageCms.ImageCmsProfile(io.BytesIO(icc)),ImageCms.createProfile('sRGB'),outputMode='RGB')
  else:im=im.convert('RGB')
  real=tuple(round(v*6.24) for v in box);return im.crop(real).resize((box[2]-box[0],box[3]-box[1]),Image.Resampling.LANCZOS),real

def main():
 for d in (WORK,OUT,WF):d.mkdir(parents=True,exist_ok=True)
 base=Image.new('RGB',(750,1350),'white');top,topbox=picture(P/'IMG_1104.jpg',(230,100,770,560));side,sidebox=picture(P/'IMG_1108.jpg',(240,330,780,650));base.paste(top,(65,170));base.paste(side,(65,820));base_path=WORK/'D20_base.png';base.save(base_path)
 rgba=Image.new('RGBA',base.size,(0,0,0,0));d=ImageDraw.Draw(rgba);black='#202020';red='#c92a32';records=[]
 def text(xy,value,size,anchor='la',pad=False):
  font=ImageFont.truetype(FONT,size);box=d.textbbox(xy,value,font=font,anchor=anchor)
  if min(box[0],box[1])<0 or box[2]>=750 or box[3]>=1350:raise ValueError('Clipped text: '+value)
  if pad:d.rounded_rectangle((box[0]-7,box[1]-4,box[2]+7,box[3]+4),radius=3,fill='white')
  d.text(xy,value,font=font,fill=black,anchor=anchor);records.append({'text':value,'bbox':list(box)})
 def arrow(p1,p2):
  import math
  d.line((p1,p2),fill=black,width=3)
  for tip,other in ((p1,p2),(p2,p1)):
   dx=other[0]-tip[0];dy=other[1]-tip[1];n=math.hypot(dx,dy);ux,uy=dx/n,dy/n;tail=(tip[0]+ux*12,tip[1]+uy*12);d.polygon([tip,(tail[0]-uy*5,tail[1]+ux*5),(tail[0]+uy*5,tail[1]-ux*5)],fill=black)
 text((65,30),'产品参数',45);d.rounded_rectangle((65,96,125,103),radius=2,fill=red);text((65,112),'w1125 双耳粥碗',26)
 # Photo crop and arrows follow the supplied coordinates; ticks outside the panels.
 for x in (117,553):d.line((x,405,x,726),fill=black,width=2)
 arrow((117,710),(553,710));text((335,746),'长 16.5 cm',27,anchor='mm',pad=True)
 for y in (221,590):d.line((605,y,665,y),fill=black,width=2)
 arrow((650,221),(650,590));text((650,405),'宽 12.8 cm',22,anchor='mm',pad=True)
 for y in (870,1102):d.line((605,y,665,y),fill=black,width=2)
 arrow((650,870),(650,1102));text((650,985),'高 8 cm',24,anchor='mm',pad=True)
 text((375,1222),'容量 550 ml   ·   重量 207 g   ·   6.5 英寸',25,anchor='mm');text((375,1273),'尺寸、容量与重量均为单只参数',22,anchor='mm')
 alpha=rgba.getchannel('A');solid=Image.new('RGB',base.size,'black');solid.paste(rgba.convert('RGB'),(0,0));source_path=WORK/'D20_overlay_rgb.png';mask_path=WORK/'D20_overlay_mask.png';overlay_path=WORK/'D20_overlay_rgba.png';solid.save(source_path);alpha.save(mask_path);rgba.save(overlay_path)
 # LoadImageMask red reads direct whiteness, avoiding LoadImage's inverted alpha mask.
 local=Image.composite(solid,base,alpha);draft=OUT/'D20_dimensions.png';local.save(draft)
 graph={'1':node('LoadImage','D20 照片底图',image='PENDING_UPLOAD_D20_BASE.png'),'2':node('LoadImage','D20 标注颜色层',image='PENDING_UPLOAD_D20_OVERLAY_RGB.png'),'3':node('LoadImageMask','D20 标注不透明度（白=覆盖）',image='PENDING_UPLOAD_D20_MASK.png',channel='red'),'4':node('ImageCompositeMasked','D20 确定性合成',destination=['1',0],source=['2',0],mask=['3',0],x=0,y=0,resize_source=False),'5':node('SaveImage','D20 草稿输出',images=['4',0],filename_prefix='ComfyProductPipeline/taobao_replica/D20_dimensions_draft')}
 schema=json.loads((R/'work/diagnostics/object_info.json').read_text());checks=check_graph(graph,schema);visual=ui(graph,schema,'D20 确定性文字测量线','待上传三个本地输入；红通道白色表示覆盖，不使用 LoadImage 反相 alpha。仅准备，合成后仍需 root 审核。')
 for n in visual['nodes']:
  if n['id'] in (1,2,3):n['pos']=[0,(n['id']-1)*300]
  elif n['id']==4:n['pos']=[500,250]
  elif n['id']==5:n['pos']=[900,250]
 (WF/'D20_dimensions.api.json').write_text(json.dumps(graph,ensure_ascii=False,indent=2)+'\n');(WF/'D20_dimensions.ui.json').write_text(json.dumps(visual,ensure_ascii=False,indent=2)+'\n')
 report={'deliverable_id':'D20','status':'pending_root_review','method':'本地排版预览；Comfy图已准备，未上传未提交','input_originals':[{'path':str((P/'IMG_1104.jpg').resolve()),'sha256':digest(P/'IMG_1104.jpg'),'crop_6240':topbox,'placement':[65,170],'rendered_size':[540,460]},{'path':str((P/'IMG_1108.jpg').resolve()),'sha256':digest(P/'IMG_1108.jpg'),'crop_6240':sidebox,'placement':[65,820],'rendered_size':[540,320]}],'source_dimensions':'/Users/luohuiwu/Desktop/粥碗尺寸表.xlsx Sheet1!E2:E6；/Users/luohuiwu/Desktop/粥碗尺寸表.numbers Sheet1!E2:E6','single_unit_values':{'length_cm':16.5,'width_cm':12.8,'height_cm':8,'capacity_ml':550,'weight_g':207,'inches':6.5},'notes':['照片灰色背景保留；图像区域不声称纯白抠图。','线位按用户提供的近似坐标；需 root 看实际标注和原图后确认。','透明层 alpha 单独导出为灰度红通道白=覆盖；避免 LoadImage alpha 自动反相。','仅已确认数值作为单只参数；截图样式和商品最终画面待审核。'],'text_boxes':records,'local_inputs':[{'path':str(p),'sha256':digest(p)} for p in (base_path,source_path,mask_path,overlay_path)],'workflow_api':str(WF/'D20_dimensions.api.json'),'workflow_ui':str(WF/'D20_dimensions.ui.json'),'schema_checks':checks,'draft':str(draft),'draft_sha256':digest(draft),'comfy_submitted':False}
 (OUT/'D20_dimensions.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'draft':str(draft),'draft_sha256':digest(draft),'text_boxes':records,'comfy_submitted':False},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
