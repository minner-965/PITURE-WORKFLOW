
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission scene --legacy prepare_multishop_extra_scenes -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
from PIL import Image,ImageOps,ImageDraw
import json,hashlib
R=Path(__file__).resolve().parents[2];W=R/'work/diagnostics/multishop_20261103/scene_inputs'
H=R/'output/TAOBAO_REPLICA_HD_20261103/01_参考底稿/详情/detail_modules'
REF2=R/'work/diagnostics/taobao_replica_20261103/klein_first_sample/reference_real_red_bowl.png';SRC2=R/'input/supplied_20261102/测试品/sku实拍/IMG_1105.jpg'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,o):Path(p).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
core='Create a new commercial photograph of the physical product in image 2. Each vessel has a deep rounded colored body, a white interior and white upper collar, a thin opening edge, a low circular foot, and two solid flat horizontal tab handles. Each bowl has the same actual dimensions and shape as image 2. Image 1 supplies general photography context; use the following new composition. '
sets={'A':'Warm cream cafe wall, honey oak tabletop, warm natural window light from upper left, ivory linen accents.','B':'Muted sage wall, pale limestone tabletop, fresh soft morning daylight from upper right, grey linen accents.','C':'Powder blue wall, matte white stone tabletop, cool diffused daylight from the left, pastel blue linen accents.'}
srcs={'food':R/'work/diagnostics/taobao_replica_hd_20261103/main_inputs/M02_overlay_recovered_v2.png','empty':H/'B01_参考模块.png','underside':H/'A08_参考模块.png'}
desc={
'food':{
'A':'Five separate bowls in an open crescent with generous clear gaps: RED at front center filled with glossy flowing reddish-brown red bean syrup and a few soft beans half submerged; ORANGE at back left with clear pale golden tremella syrup and three ivory lotus seeds; YELLOW at back right with creamy mango sago; GREEN at middle left with smooth olive-green mung bean puree; BLUE at middle right with glossy black sesame paste. Camera 35 degrees above tabletop. All five bowls and tabs completely inside the frame. One orange soup spoon lies diagonally at the lower right, folded ivory cloth at far left. A simple wood serving board supports the back pair. Natural delicate liquid reflections.',
'B':'Five separate bowls arranged in a diagonal zigzag from back left to front right, clear space between vessels. ORANGE at back left filled with golden pumpkin millet porridge, GREEN at back right filled with smooth ivory rice congee and four small dark century egg pieces half submerged, BLUE in middle filled with creamy fish congee and three thin white fish slices, YELLOW at front left filled with silky ivory rice congee, RED at front right filled with creamy congee and two small braised ribs half submerged. Each food has a glossy wet surface and gentle broad window highlights. All five bowls and tabs fully inside the frame. A pale rectangular tray angled left supports two rear bowls, grey cloth and a blue spoon at front left. Camera 40 degrees above table.',
'C':'Five separate bowls in a loose S-shaped arrangement, all fully visible with clear gaps: BLUE at front left filled with milky white coconut dessert and three purple taro cubes, GREEN at front right with white coconut milk and red dragon fruit cubes, YELLOW at middle left with pale golden clear peach gum syrup and three ivory lotus seeds, ORANGE at back left with creamy mango puree and a few mango cubes, RED at back right with glossy reddish-brown red bean sweet soup. Small sago pearls are suspended in the liquid. Camera 35 degrees above table. One white spoon on a blue folded cloth at the right margin. Soft realistic highlights and food moisture.'},
'empty':{
'A':'An uncluttered empty-bowl collection on the wood tabletop: a stack of three bowls at back left, ORANGE on top then GREEN then BLUE; one empty RED bowl separately at front left, one empty YELLOW bowl at front right. Exactly five bowls. A low round woven mat lies beneath the stack, and a single orange spoon rests diagonally on an ivory cloth at far right. Camera at a modest downward angle reveals empty white interiors, every bowl entirely inside the photo. Broad clear space separates the stack and the two foreground bowls. Warm natural grounded shadows.',
'B':'Five empty bowls on a breakfast counter. Two compact stacks at the back: YELLOW over RED at back right, BLUE over ORANGE at back left. One separate empty GREEN bowl at lower center. Exactly five bowls. A rectangular light wood tray supports the right stack, a blue spoon lies diagonally on a grey linen napkin at lower left. The camera looks down at 30 degrees. Every white interior, real tab shape, rounded deep body and low foot is clearly visible. All bowls fully framed with generous space between groups.',
'C':'A collection of exactly five empty bowls, arranged in three separated groups on white stone. A tall three-bowl stack at back right with BLUE on top, YELLOW in the middle and RED at bottom. An empty ORANGE bowl at front left, and an empty GREEN bowl at front right. The left orange bowl sits on a small round white riser. A pastel blue cloth runs diagonally beneath the front green bowl; one white spoon lies at far left. Slight downward camera angle, full view of all bowl contours and empty white interiors.'},
'underside':{
'A':'An adult left hand enters from the upper left and grips the left flat tab of an inverted BLUE bowl, gently tilting its deep rounded underside toward the camera. The low circular foot is clearly visible. On the table below are three upright empty bowls: an ORANGE bowl at front right and a stack of RED over GREEN at back right. Exactly four bowls. Hand fingers wrap naturally around the flat tab. A yellow spoon lies on ivory cloth at lower left. All bowls are fully visible. Clear gap between held bowl and table bowls. Realistic hand contact and melamine surface.',
'B':'An adult right hand enters from the upper right and holds the right flat tab of an upside-down GREEN bowl above the counter, its circular foot ring facing the viewer. Three upright bowls rest on the counter below: a separate YELLOW empty bowl at front left, and a stack of BLUE over RED on a rectangular wood board at back left. Exactly four bowls. Five natural fingers grip the solid tab with correct contact. One blue spoon on grey folded linen at bottom right. Clear space separates each group, all bowl contours inside frame.',
'C':'An adult hand enters from the left, supporting an inverted YELLOW bowl from its left flat tab and turning its low circular foot toward the viewer at upper center. On the counter sit three empty bowls: a separate BLUE bowl at front right and a stack of ORANGE over GREEN at back right. Exactly four bowls. The hand makes a relaxed natural grip on the flat tab; the bowl underside is fully visible. A white spoon and folded pale blue napkin lie at lower left. Fresh soft shadows, generous spacing, all product contours inside the frame.'}}
configs=[]
for family in ['food','empty','underside']:
 src=srcs[family];im=Image.open(src).convert('RGB')
 if family=='food':
  ImageDraw.Draw(im).rectangle((0,0,614,153),fill=(128,150,102));size=(832,832)
 elif family=='empty':im=im.crop((0,45,900,1068));size=(768,1024)
 else:im=im.crop((18,380,882,1410));size=(768,1024)
 im=ImageOps.fit(im,size,method=Image.Resampling.LANCZOS);ref=W/(family+'_guide.png');im.save(ref)
 for shop in ['A','B','C']:
  prompt=core+sets[shop]+' '+desc[family][shop]+' A continuous photographic scene fills the entire image, with plain background surfaces.'
  c={'job_id':f'{shop}_{family}_v1','mode':'edit','start_step':0,'reference1':str(ref),'reference2':str(REF2),'reference1_source':str(src),'reference2_source':str(SRC2),'width':size[0],'height':size[1],'reference_size':512,'seed':20261104000+100*['food','empty','underside'].index(family)+ord(shop),'prompt':prompt,'root_input_review':{'status':'approved','reviewer':'root','prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),'reference1_sha256':sha(ref),'reference2_sha256':sha(REF2),'note':'Root checked source photography and physical reference; regenerated scene changes concrete composition, color positions, food and hand action. Typography added as separate deterministic layer.'}}
  p=W/(c['job_id']+'.json');save(p,c);configs.append(str(p))
save(W/'extra_scene_batch.json',configs)
