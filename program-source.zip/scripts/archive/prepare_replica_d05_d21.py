#!/usr/bin/env python3
"""Prepare two pending-review replica drafts and unsubmitted deterministic graphs."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission multishop --legacy prepare_replica_d05_d21 -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

import argparse,csv,hashlib,json,math
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from build_workflows import node,check_graph,ui

R=Path(__file__).resolve().parents[2];FONT='/System/Library/Fonts/STHeiti Medium.ttc';OUT=R/'output/TAOBAO_REPLICA_20261103/drafts';WF=R/'workflows/taobao_replica_20261103';WORK=R/'work/diagnostics/taobao_replica_20261103';assets={v['color_id']:v for v in csv.DictReader((R/'config/product_assets.csv').open(encoding='utf-8-sig'))}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bowl(color,size):
 a=assets[color];p=Path(a['rgba_empty']);img=Image.open(p).convert('RGBA');box=img.getchannel('A').getbbox()
 if not box:raise ValueError('empty alpha '+str(p))
 img=img.crop(box);img.thumbnail(size,Image.Resampling.LANCZOS);return img,{'color_id':color,'asset_path':str(p),'asset_sha256':sha(p),'alpha_bbox':box,'rendered_size':img.size,'source_photo':a['source_photo'],'source_photo_sha256':sha(a['source_photo'])}
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--task',choices=('D05','D21'));args=parser.parse_args()
 OUT.mkdir(parents=True,exist_ok=True);WF.mkdir(parents=True,exist_ok=True);info=json.loads((R/'work/diagnostics/object_info.json').read_text())
 for ident,height in [('D05',850),('D21',1000)]:
  if args.task and ident!=args.task:continue
  work=WORK/(ident+'_replica');work.mkdir(parents=True,exist_ok=True);base=Image.new('RGBA',(750,height),'white');overlay=Image.new('RGBA',(750,height),(0,0,0,0));draw=ImageDraw.Draw(overlay);sources=[];labels=[]
  def text(pos,value,size,color='#202020',anchor='la'):
   f=ImageFont.truetype(FONT,size);box=draw.textbbox(pos,value,font=f,anchor=anchor)
   if box[0]<0 or box[1]<0 or box[2]>=750 or box[3]>=height:raise ValueError('clipped text '+value)
   draw.text(pos,value,font=f,fill=color,anchor=anchor);labels.append({'text':value,'bbox':box})
  if ident=='D05':
   d=ImageDraw.Draw(base);points=[(540,180)]
   # Fill the supplied closed cubic path, behind the product photograph.
   def cubic(p0,p1,p2,p3):
    for i in range(1,81):
     t=i/80;u=1-t;points.append((u**3*p0[0]+3*u*u*t*p1[0]+3*u*t*t*p2[0]+t**3*p3[0],u**3*p0[1]+3*u*u*t*p1[1]+3*u*t*t*p2[1]+t**3*p3[1]))
   cubic((540,180),(500,250),(165,300),(165,480));cubic((165,480),(165,740),(640,740),(640,480));cubic((640,480),(640,345),(600,260),(540,180));d.polygon(points,fill='#f0f2f3')
   im,source=bowl('red',(480,350));base.alpha_composite(im,(135+(480-im.width)//2,350+(350-im.height)//2));sources.append(source)
   text((90,90),'不易碎',46);draw.rectangle((65,745,125,805),fill='#cb4170');text((95,775),'2',32,color='white',anchor='mm')
   notes=['标题复用用户公司已发布参考图的可读文字。','参考图小字无法辨认，暂留空待核；整体参考对齐待审。','红碗使用现成实拍透明素材，当前为3/4视角，与参考侧视存在差异；IMG_1108侧视暂无已验证可用alpha。','大块浅灰水滴背板在碗后。']
  else:
   text((65,55),'商品参数',42);d=ImageDraw.Draw(overlay);d.line((65,125,685,125),fill='#d7d7d7',width=2)
   rows=[('型号','w1125'),('颜色','红 / 橙 / 绿 / 黄 / 蓝（内白）'),('长 × 宽 × 高','16.5 × 12.8 × 8 cm'),('容量','550 ml'),('重量','207 g'),('尺寸','6.5 英寸')]
   for i,(key,value) in enumerate(rows):
    y=155+i*80;text((85,y),key,25);text((295,y),value,25);d.line((65,y+58,685,y+58),fill='#dedede',width=1)
   text((65,665),'五色实拍展示',25);cols=['red','orange','green','yellow','blue'];names=['红色','橙色','绿色','黄色','蓝色']
   for i,(color,name) in enumerate(zip(cols,names)):
    im,source=bowl(color,(120,105));x=55+i*140+(120-im.width)//2;y=730+(105-im.height)//2;base.alpha_composite(im,(x,y));sources.append(source);text((115+i*140,860),name,21,anchor='mm')
   text((375,945),'尺寸、容量与重量均为单只参数',21,anchor='mm');notes=['尺寸、容量、重量为已确认的单只参数，不依据截图测算。','颜色小图来自摄影师原片的透明空碗素材，等比例缩放。']
  base=base.convert('RGB');basepath=work/'base.png';rgbpath=work/'overlay_rgb.png';maskpath=work/'overlay_mask.png';base.save(basepath);overlay.convert('RGB').save(rgbpath);overlay.getchannel('A').save(maskpath);overlay.save(work/'overlay_rgba.png');draft=OUT/(ident+'_replica_draft.png');Image.composite(overlay.convert('RGB'),base,overlay.getchannel('A')).save(draft)
  graph={'1':node('LoadImage',ident+' 底图',image='PENDING_UPLOAD_BASE.png'),'2':node('LoadImage',ident+' 标注颜色层',image='PENDING_UPLOAD_OVERLAY.png'),'3':node('LoadImageMask',ident+' 标注遮罩',image='PENDING_UPLOAD_MASK.png',channel='red'),'4':node('ImageCompositeMasked',ident+' 确定性合成',destination=['1',0],source=['2',0],mask=['3',0],x=0,y=0,resize_source=False),'5':node('SaveImage',ident+' 草稿输出',images=['4',0],filename_prefix='ComfyProductPipeline/taobao_replica/'+ident+'_draft')};checks=check_graph(graph,info);visual=ui(graph,info,ident+' 确定性合成','仅准备，上传前需 root 审核；mask 红通道白色表示覆盖，不使用 LoadImage 反相 alpha。')
  for n in visual['nodes']:
   if n['id'] in (1,2,3):n['pos']=[0,(n['id']-1)*300]
   elif n['id']==4:n['pos']=[500,250]
   elif n['id']==5:n['pos']=[900,250]
  api=WF/(ident+'_replica.api.json');uip=WF/(ident+'_replica.ui.json');api.write_text(json.dumps(graph,ensure_ascii=False,indent=2)+'\n');uip.write_text(json.dumps(visual,ensure_ascii=False,indent=2)+'\n')
  report={'task_id':ident,'status':'pending_root_review','draft':str(draft),'draft_sha256':sha(draft),'reference_path':str(R/('input/taobao_reference_20261103/download ('+('4' if ident=='D05' else '20')+').png')),'notes':notes,'source_assets':sources,'labels':labels,'source_dimensions':'/Users/luohuiwu/Desktop/粥碗尺寸表.xlsx 和 /Users/luohuiwu/Desktop/粥碗尺寸表.numbers，Sheet1!E2:E6' if ident=='D21' else None,'comfy_submitted':False,'schema_checks':checks,'workflow_api':str(api),'workflow_ui':str(uip),'local_inputs':[{'path':str(p),'sha256':sha(p)} for p in (basepath,rgbpath,maskpath,draft,api,uip)]};(work/'preparation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(OUT/(ident+'_replica_draft.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(ident,'draft',draft,'size',base.size,'sources',len(sources))
if __name__=='__main__':main()
