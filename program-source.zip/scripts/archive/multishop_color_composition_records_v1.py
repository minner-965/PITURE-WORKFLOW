
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission layout --legacy multishop_color_composition_records_v1 -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
import json,hashlib
B=Path('/Users/luohuiwu/codex/ComfyProductPipeline'); D=B/'work/diagnostics/multishop_20261103'; reg=json.load(open(B/'config/multishop_scene_assets.json')); audit=json.load(open(D/'color_audit_v1/report.json')); folder=D/'blue_green_candidates_v1'; meta=json.load(open(folder/'provenance.json'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def item(p):return {'path':str(p),'sha256':sha(p)}
def write(scene,src,mask,out,params,outside,refs,target):
 shop,key=scene.split('_',1);entry=reg[shop][key]; paths=[entry['generation_result']]+entry.get('additional_generation_results',[])
 obj={'status':'pending_root_visual_review','source_original':item(src),'mask':item(mask),'output':item(out),'additional_sources':[item(p) for p in refs],'generation_results':[str(p) for p in paths],'generation_result_hashes':[item(p) for p in paths],'color_parameters':params,'outside_mask_exact':outside}
 if entry.get('composition_provenance'):obj['upstream_composition_provenance']=item(entry['composition_provenance'])
 target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(obj,ensure_ascii=False,indent=2))
for e in meta['entries']:
 name=e['scene']; refs=[audit['references']['side_'+d['color']]['path'] for d in e['details']];write(name,e['source'],folder/f'{name}_mask.png',e['output'],{'method':meta['method'],'details':e['details']},e['changed_outside_mask']==0,refs,folder/name/'composition.json')
b=D/'B_underside_color_v2';p=json.load(open(b/'provenance.json'));write('B_underside',p['source'],p['mask'],p['output'],p['parameters'],p['pixels_changed_outside_mask']==0,[p['reference']],b/'composition.json')
print('wrote',len(meta['entries'])+1,'composition records')
