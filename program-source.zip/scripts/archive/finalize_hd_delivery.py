"""Record root's completed visual review of the first full HD replica set."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission export --legacy finalize_hd_delivery -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
import json,hashlib,shutil,datetime
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'output/TAOBAO_REPLICA_HD_20261103'
META=OUT/'05_交付清单'
report=json.loads((META/'技术核对.json').read_text())
assert report['status']=='passed' and report['passed_count']==22
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
module_ids=['A01','A02','A03','A04','A05','A06','A07','A08','B01','B02','C01','C02','C03','C04','C05']
module_manifest=json.loads((OUT/'01_参考底稿/详情/detail_modules/manifest.json').read_text())
modules={m['module_id']:m for m in module_manifest['modules']}
items=[]
for item in report['items']:
 ident=item['id'];path=Path(item['path']);assert sha(path)==item['actual_sha256']
 method=item.get('method','photograph_dimension_parameter_master')
 review={'reviewer':'root','reviewed_at_utc':now,'status':'accepted_for_first_full_replica_set','output':str(path),'sha256':sha(path),'size':item['size'],'method':method,'criteria':['完整构图和原版内容顺序','碗数量、颜色顺序及机位','碗沿、实心双耳与手部连续性','中文、编号和既有刻字保留','无可见大块拼接或变形','尺寸与参数依据用户确认资料'],'pixel_identical_claim':False,'notes':'按参考完成整套复刻；AI照片的反光、食物表面与细微材质纹理存在差异，原版文字及报告层保留。'}
 if ident in ('D20','D21'):review['notes']='已审核的实拍尺寸/参数补充母版；三条测量线与用户尺寸表一致。'
 if method=='source_layout_reconstruction':review['notes']='用户公司的正式文字排版或真实门店/厂房照片，经ComfyUI等比导出保留。不是AI重新创造的场景。'
 if ident.startswith('M') or ident in [f'D{i:02}' for i in range(1,16)]:
  save(OUT/f'04_工作流/{ident}/export/root_review.json',review)
 if ident.startswith('D') and int(ident[1:])<=15:
  mod=modules[module_ids[int(ident[1:])-1]];review['reference_module']=mod['module_id'];review['reference_crop_in_strip']=mod['source_bbox_xyxy']
 review['id']=ident
 items.append(review)
review_all={'status':'completed_first_full_replica_set','reviewer':'root','reviewed_at_utc':now,'count':22,'counts':{'main':5,'detail':15,'supplementary_dimensions_parameters':2},'scope':'五张主图、高清滚屏中可见的全部详情内容、尺寸与参数补充图','technical_report':str(META/'技术核对.json'),'independent_main_review':str(META/'主图独立复核.json'),'pixel_identical_claim':False,'items':items}
save(META/'最终复核.json',review_all)
save(META/'交付清单.json',review_all)
cfgp=ROOT/'config/taobao_replica_hd_20261103.json';cfg=json.loads(cfgp.read_text())
cfg.update(status='completed_first_full_replica_set',required_final_counts={'main':5,'detail':15,'dimensions':2},generated_outputs=items,final_review=str(META/'最终复核.json'),method='Klein 4B 截图构图+商品实拍双参考，多数照片由参考潜图初始化执行后2步；原版中文、报告与刻字层由ComfyUI确定性合成；真实门店/工厂及纯文字页保留来源图文',status_note='22张全套初版已实际导出并经root复核。AI照片有光影/表面细节差异，不声称像素完全一致；原低清阶段26配额已废弃。')
byid={x['id']:x for x in report['items']}
for task in cfg['main_tasks']:
 x=byid[task['task_id']];task.update(status='completed_root_reviewed',output_path=x['path'],sha256=x['actual_sha256'])
cfg['detail_tasks']=[{'task_id':f'D{i:02}','reference_module':module_ids[i-1],'source_strip':modules[module_ids[i-1]]['source_strip'],'source_bbox_xyxy':modules[module_ids[i-1]]['source_bbox_xyxy'],'output_path':byid[f'D{i:02}']['path'],'sha256':byid[f'D{i:02}']['actual_sha256'],'status':'completed_root_reviewed'} for i in range(1,16)]
save(cfgp,cfg)
lines=['# 高清淘宝复刻图片交付','', '全套初版共22张：5张主图、15张详情图、2张尺寸/参数补充图，均已实际经过ComfyUI导出并核对。','', '主图800×800；详情宽750，保持各参考模块比例。长16.5 cm、宽12.8 cm、高8 cm的测量线、207 g与550 ml参数按用户确认的尺寸表制作。','', '照片采用截图构图与商品实拍双参考复刻，中文字、检测报告、既有刻字按原图保留。门店、工厂及纯文字页使用公司来源图文。AI照片存在少量光影和表面纹理变化，未声称像素完全相同。','', '## 图片目录','', '| 编号 | 图片 | 像素 | 方法 |','|---|---|---|---|']
for x in items:
 p=Path(x['output']);label=p.name;size='×'.join(map(str,x['size']));method={'generated_mask_composite':'AI照片＋原版图文合成','source_layout_reconstruction':'公司来源图文还原','photograph_dimension_parameter_master':'实拍尺寸/参数母版'}[x['method']]
 lines.append(f'| {p.stem.split("_")[0]} | [{label}]({p}) | {size} | {method} |')
lines+=['','## 对照与工作流','',f'- [主图总览]({OUT}/03_对照审核/主图总览.jpg)',f'- [详情总览1]({OUT}/03_对照审核/详情总览_01.jpg)',f'- [详情总览2]({OUT}/03_对照审核/详情总览_02.jpg)',f'- [尺寸参数总览]({OUT}/03_对照审核/尺寸参数总览.jpg)',f'- [逐张对照]({OUT}/03_对照审核/逐张对照)',f'- [工作流与生成参考]({OUT}/04_工作流)',f'- [执行方案]({ROOT}/docs/淘宝高清复刻方案_20261103.md)','', '28张截图包含重复滚动区域。原截图和对应切分坐标保存在01_参考底稿；未把网页导航和价格说明当作商品图，也未推测截图未展示的内容。','', '旧低清样片和“不易碎”错误标题的历史草稿均未混入本次成品目录。']
(META/'输出索引.md').write_text('\n'.join(lines)+'\n')
(OUT/'查看说明.md').write_text('\n'.join(lines[:7])+f'\n\n[打开完整图片索引]({META}/输出索引.md)\n')
current=ROOT/'docs/CURRENT_TASK.md';old=current.read_text();heading='## 2026-11-03 高清全套执行结果'
if heading not in old:
 current.write_text(old+'\n'+heading+'\n\n五张主图、十五张详情模块及两张尺寸/参数母版已实际导出，共22张；技术核对22/22通过，root逐图复核已记录。当前完成的是第一套完整复刻，AI照片存在少量光影/表面细节差异，不声称像素完全相同。\n\n入口：`output/TAOBAO_REPLICA_HD_20261103/02_ComfyUI复刻/`；最终清单：`05_交付清单/交付清单.json`、`最终复核.json`、`输出索引.md`。15件含AI照片合成，5件真实场景/信息页保留来源图文，2件为补充母版。低清配额、旧D05及中间生成图不在成品目录。\n')
plan=ROOT/'docs/淘宝高清复刻方案_20261103.md';s=plan.read_text()
if heading not in s:plan.write_text(s+'\n'+heading+'\n\n全套22张已完成实际导出与root复核。生成过程发现全重绘会改变手持碗边和倒扣角度，后续照片以参考图潜空间初始化、保留原4步调度的后2步完成重建。中文、报告和刻字用原版图层合成，编号保护贴合圆角形状，避免矩形补丁。详细图片清单及逐图对照见输出目录。\n')
shutil.copy2(plan,META/'淘宝高清复刻方案.md')
desktop=Path('/Users/luohuiwu/Desktop/淘宝商品图复刻_20261103')
if not desktop.exists() and not desktop.is_symlink():desktop.symlink_to(OUT,target_is_directory=True)
print(json.dumps({'count':len(items),'output_root':str(OUT),'desktop_shortcut':str(desktop),'status':review_all['status']},ensure_ascii=False))
