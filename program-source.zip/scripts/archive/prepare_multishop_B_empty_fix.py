
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission multishop --legacy prepare_multishop_B_empty_fix -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
from PIL import Image,ImageOps
import json,hashlib
R=Path(__file__).resolve().parents[2];W=R/'work/diagnostics/multishop_20261103/scene_inputs';src=R/'work/diagnostics/multishop_20261103/generation/B_empty_v1/6738f066eb855b2d8d11f078/downloads/23_0_6738f066eb855b2d8d11f078_00001_.png';ref=W/'B_empty_padded_guide.png';ImageOps.pad(Image.open(src),(832,832),Image.Resampling.LANCZOS,color=(205,209,197)).save(ref);ref2=R/'work/diagnostics/multishop_20261103/product_refs/五色器型_1024.png';c=json.loads((W/'B_empty_v1.json').read_text());p='A natural commercial photograph of the empty double-tab melamine bowls in image 1, framed farther away so every bowl and both side tabs fit completely within the photo with generous clear margins. Use the exact deep rounded bowl shape, white collar, white interior and low foot shown in image 2. Keep the sage wall, pale stone tabletop, wood board and blue spoon. The single bowl at middle left is BLUE. The single bowl at middle right is ORANGE, entirely inside the image including its right tab. The separate bowl in front is GREEN. A compact stack of four bowls stands behind them, colored RED then YELLOW then ORANGE then RED from top to bottom. Exactly seven bowls. A continuous natural photographic background fills all edges. Soft morning daylight and grounded contact shadows.';c.update(job_id='B_empty_v2',reference1=str(ref),reference2=str(ref2),reference1_source=str(src),reference2_source=str(R/'output/LISTING_V3/w1125/assets/empty_bowls/red.png'),width=832,height=832,reference_size=768,prompt=p,seed=20261106701);c['root_input_review']={'status':'approved','reviewer':'root','prompt_sha256':hashlib.sha256(p.encode()).hexdigest(),'reference1_sha256':hashlib.sha256(ref.read_bytes()).hexdigest(),'reference2_sha256':hashlib.sha256(ref2.read_bytes()).hexdigest(),'note':'Previous B empty rejected due to missing blue and right-tab crop. Padded composition requests complete contours and exact all-five color collection; root must inspect new output.'};(W/'B_empty_v2.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
