#!/usr/bin/env python3
"""Prepare or run an auditable, deterministic ComfyUI reference-layout export.

--prepare never submits. --run requires root's execution lease to be acknowledged
with --lease-granted and refuses an occupied Comfy queue. --resume only reconciles
an existing submission; it never creates a new one. Mask white selects generated.
"""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission export --source-run RUN --node NODE --output NEW.png [--config CONFIG]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from PIL import Image, ImageOps
from build_workflows import node, check_graph, ui
from comfy_client import ComfyClient, sync_ui

ROOT = Path(__file__).resolve().parents[2]
OUTPUT_ROOT = ROOT / 'output/TAOBAO_REPLICA_HD_20261103'
WORKFLOW_ROOT = OUTPUT_ROOT / '04_工作流'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def resolve_file(value, key):
    if not isinstance(value, str) or not value:
        raise ValueError(f'{key} must be an image path')
    p = Path(value).expanduser()
    if not p.is_absolute():
        p = ROOT / p
    p = p.resolve(strict=True)
    if not p.is_file():
        raise ValueError(f'{key} must be a file')
    with Image.open(p) as img:
        img.verify()
    with Image.open(p) as img:
        size = ImageOps.exif_transpose(img).size
    return p, size


def read_config(path):
    cfg = json.loads(Path(path).read_text(encoding='utf-8'))
    asset = cfg.get('asset_id')
    if not isinstance(asset, str) or not re.fullmatch(r'[A-Za-z0-9_-]+', asset):
        raise ValueError('asset_id must contain only ASCII letters, digits, underscore or hyphen')
    ref, (width, height) = resolve_file(cfg.get('reference'), 'reference')
    gen_value, mask_value = cfg.get('generated'), cfg.get('generated_mask')
    if bool(gen_value) != bool(mask_value):
        raise ValueError('generated and generated_mask must be supplied together')
    inputs = {'reference': {'path': str(ref), 'sha256': sha(ref), 'size': [width, height]}}
    if gen_value:
        for key, value in [('generated', gen_value), ('generated_mask', mask_value)]:
            file, size = resolve_file(value, key)
            inputs[key] = {'path': str(file), 'sha256': sha(file), 'size': list(size)}
    output_width = cfg.get('output_width')
    if isinstance(output_width, bool) or output_width not in (750, 800):
        raise ValueError('output_width must be 750 or 800')
    if not isinstance(cfg.get('output_path'), str) or not cfg['output_path']:
        raise ValueError('output_path is required')
    target = Path(cfg['output_path']).expanduser()
    if not target.is_absolute():
        target = ROOT / target
    target = target.resolve()
    if not target.is_relative_to((OUTPUT_ROOT / '02_ComfyUI复刻').resolve()) or target.suffix.lower() != '.png':
        raise ValueError('output_path must be a PNG under 02_ComfyUI复刻')
    output_height = max(1, round(height * output_width / width))
    identity = {'asset_id': asset, 'inputs': inputs, 'output_width': output_width,
                'output_height': output_height, 'output_path': str(target),
                'method': 'generated_mask_composite' if gen_value else 'source_layout_reconstruction',
                'mask_semantics': 'white selects generated, black selects reference' if gen_value else None}
    return cfg, identity


def build_graph(identity):
    w, h = identity['inputs']['reference']['size']
    g = {'1': node('LoadImage', 'REFERENCE', image='ComfyProductPipeline/prepared_reference.png')}
    if identity['method'] == 'generated_mask_composite':
        g.update({
            '2': node('LoadImage', 'GENERATED', image='ComfyProductPipeline/prepared_generated.png'),
            '3': node('LoadImage', 'MASK_IMAGE', image='ComfyProductPipeline/prepared_mask.png'),
            '4': node('ImageScale', 'SCALE_GENERATED_TO_REFERENCE', image=['2', 0], upscale_method='lanczos', width=w, height=h, crop='disabled'),
            '5': node('ImageScale', 'SCALE_MASK_TO_REFERENCE', image=['3', 0], upscale_method='nearest-exact', width=w, height=h, crop='disabled'),
            '6': node('ImageToMask', 'MASK_RED_CHANNEL', image=['5', 0], channel='red'),
            '7': node('ImageCompositeMasked', 'GENERATED_OVER_REFERENCE', destination=['1', 0], source=['4', 0], mask=['6', 0], x=0, y=0, resize_source=False),
        })
        src = ['7', 0]
    else:
        src = ['1', 0]
    g['8'] = node('ImageScale', 'EXPORT_SCALE', image=src, upscale_method='lanczos', width=identity['output_width'], height=identity['output_height'], crop='disabled')
    g['9'] = node('SaveImage', 'EXPORT', images=['8', 0], filename_prefix='ComfyProductPipeline/taobao_replica_hd/' + identity['asset_id'])
    return g


def queue_empty(client):
    q = client.get('/queue')
    if q.get('queue_running') or q.get('queue_pending'):
        raise RuntimeError('Comfy queue occupied; no submission made')


def backend_pid():
    return int(subprocess.check_output(['lsof', '-t', '-nP', '-iTCP:8188', '-sTCP:LISTEN'], text=True).strip())


def prepare(cfg, identity, client, log):
    if (log / 'submission.json').exists():
        raise FileExistsError('This asset already has a submission; use --resume')
    log.mkdir(parents=True, exist_ok=True)
    existing = log / 'identity.json'
    if existing.exists() and json.loads(existing.read_text()) != identity:
        raise ValueError('Existing preparation has different inputs; use a new asset_id')
    info = client.get('/object_info')
    graph = build_graph(identity)
    checks = check_graph(graph, info)
    visual = ui(graph, info, 'HD replica deterministic export', identity['method'] + '; result pending root review')
    save(existing, identity)
    save(log / 'input_config.json', cfg)
    save(log / 'prepared.api.json', graph)
    save(log / 'prepared.ui.json', visual)
    save(log / 'schema_checks.json', checks)
    return graph, visual, info


def verify_inputs(identity):
    for key, item in identity['inputs'].items():
        if sha(item['path']) != item['sha256']:
            raise ValueError(f'{key} file changed since preparation')


def install_no_overwrite(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_name('.' + target.name + '.partial')
    if temp.exists():
        raise FileExistsError(f'Partial output already exists: {temp}')
    try:
        with Path(source).open('rb') as src, temp.open('xb') as dst:
            shutil.copyfileobj(src, dst, 1024 * 1024)
            dst.flush()
            os.fsync(dst.fileno())
        os.link(temp, target)  # Atomic create; fails if destination exists.
    finally:
        if temp.exists():
            temp.unlink()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--config', required=True, type=Path)
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument('--prepare', action='store_true')
    mode.add_argument('--run', action='store_true')
    mode.add_argument('--resume', action='store_true')
    ap.add_argument('--lease-granted', action='store_true', help='Confirm root has granted the shared execution lease')
    args = ap.parse_args()
    cfg, identity = read_config(args.config)
    log = WORKFLOW_ROOT / identity['asset_id'] / 'export'
    client = ComfyClient()
    if args.prepare:
        prepare(cfg, identity, client, log)
        print('prepared', log)
        return
    if not (log / 'identity.json').is_file():
        raise FileNotFoundError('Prepare the asset before running or resuming')
    if json.loads((log / 'identity.json').read_text()) != identity:
        raise ValueError('Current input/config does not match preparation')
    verify_inputs(identity)
    target = Path(identity['output_path'])
    result_path = log / 'result.json'
    if result_path.exists():
        previous = json.loads(result_path.read_text())
        if previous['identity'] != identity or not target.is_file() or sha(target) != previous['output_sha256']:
            raise ValueError('Existing result does not match output or inputs')
        print('already_complete', result_path)
        return
    submission = log / 'submission.json'
    if args.resume:
        if not submission.is_file():
            raise FileNotFoundError('No submission exists; --resume never submits')
        if not (log / 'actual.api.json').is_file() or not (log / 'actual.ui.json').is_file():
            raise FileNotFoundError('Existing submission lacks actual workflow evidence')
        pid = client.reconcile(submission)
    else:
        if not args.lease_granted:
            raise ValueError('Wait for root execution lease, then pass --lease-granted')
        if submission.exists():
            raise FileExistsError('Existing submission requires --resume')
        if target.exists():
            raise FileExistsError('Output exists; it will not be overwritten')
        graph = json.loads((log / 'prepared.api.json').read_text())
        visual = json.loads((log / 'prepared.ui.json').read_text())
        queue_empty(client)
        for node_id, key in [('1', 'reference'), ('2', 'generated'), ('3', 'generated_mask')]:
            if key in identity['inputs']:
                graph[node_id]['inputs']['image'] = client.upload(identity['inputs'][key]['path'])
        info = client.get('/object_info')
        check_graph(graph, info)
        visual = sync_ui(graph, visual, info)
        for node_id in ('1', '2', '3'):
            if node_id in graph:
                v = next(n for n in visual['nodes'] if str(n['id']) == node_id)
                if v['widgets_values'][0] != graph[node_id]['inputs']['image']:
                    raise ValueError('UI/API image binding mismatch')
        save(log / 'actual.api.json', graph)
        save(log / 'actual.ui.json', visual)
        queue_empty(client)
        pid = client.submit(graph, visual, submission)
    history, measurements = client.wait(pid, log, backend_pid(), timeout=600)
    images = client.download(history, log / 'downloads').get('9', [])
    if len(images) != 1:
        raise ValueError('Expected exactly one exported image')
    downloaded = Path(images[0])
    with Image.open(downloaded) as image:
        image.load()
        if image.size != (identity['output_width'], identity['output_height']):
            raise ValueError('Downloaded image dimensions differ from requested export')
    if target.exists():
        if sha(target) != sha(downloaded):
            raise FileExistsError('Existing output differs from downloaded result')
    else:
        install_no_overwrite(downloaded, target)
    if sha(target) != sha(downloaded):
        raise ValueError('Output copy hash differs from Comfy download')
    result = {'asset_id': identity['asset_id'], 'status': 'awaiting_root_review',
              'method': identity['method'], 'prompt_id': pid, 'identity': identity,
              'output_path': str(target), 'output_sha256': sha(target),
              'download_sha256': sha(downloaded), 'measurements': measurements,
              'root_review': cfg.get('root_review'), 'visual_pass': None}
    save(result_path, result)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
