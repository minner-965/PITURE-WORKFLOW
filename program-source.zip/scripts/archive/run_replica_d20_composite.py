#!/usr/bin/env python3
"""Submit only D20's prepared composition graph; never overwrite the local draft."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission export --source-run RUN --node NODE --output NEW.png [--config CONFIG]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

import argparse,hashlib,json,os,subprocess
from pathlib import Path
import numpy as np
from PIL import Image
from build_workflows import check_graph
from comfy_client import ComfyClient,sync_ui

R=Path(__file__).resolve().parents[2];WORK=R/'work/diagnostics/taobao_replica_20261103/D20_dimensions';WF=R/'workflows/taobao_replica_20261103';OUT=R/'output/TAOBAO_REPLICA_20261103/drafts';LOG=WORK/'comfy_composite_run'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def require_idle(client):
 queue=client.get('/queue')
 if queue.get('queue_running') or queue.get('queue_pending'):raise RuntimeError('ComfyUI queue is occupied; submission not made')
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--run',action='store_true',help='explicitly submit when queue is idle');args=parser.parse_args()
 if not args.run:parser.error('--run required after the queue is confirmed idle')
 approval=json.loads((WORK/'composite_preparation.json').read_text(encoding='utf-8'));local=OUT/'D20_dimensions.png';target=OUT/'D20_dimensions_comfy.png'
 if target.exists():raise FileExistsError('Comfy output already exists; preserve it and inspect the previous run')
 for item in approval['files']:
  p=Path(item['path'])
  if not p.is_file() or sha(p)!=item['sha256']:raise ValueError('Prepared input changed: '+str(p))
 graph=json.loads((WF/'D20_dimensions.api.json').read_text());frontend=json.loads((WF/'D20_dimensions.ui.json').read_text());classes=[graph[str(i)]['class_type'] for i in range(1,6)]
 if classes!=['LoadImage','LoadImage','LoadImageMask','ImageCompositeMasked','SaveImage'] or graph['3']['inputs']['channel']!='red':raise ValueError('Prepared graph differs from authorized deterministic composition')
 if graph['4']['inputs']!={'destination':['1',0],'source':['2',0],'mask':['3',0],'x':0,'y':0,'resize_source':False}:raise ValueError('Unexpected composite settings')
 client=ComfyClient();LOG.mkdir(parents=True,exist_ok=True);record=LOG/'submission.json'
 if record.exists():
  if not (LOG/'actual.api.json').is_file() or not (LOG/'actual.ui.json').is_file():raise RuntimeError('Existing submission lacks its bound workflow; inspect before retry')
  pid=client.reconcile(record)
 else:
  require_idle(client)
  for ident,name in [('1','D20_base.png'),('2','D20_overlay_rgb.png'),('3','D20_overlay_mask.png')]:graph[ident]['inputs']['image']=client.upload(WORK/name)
  info=client.get('/object_info');check_graph(graph,info);bound=sync_ui(graph,frontend,info)
  for ident in ('1','2','3'):
   visual=next(n for n in bound['nodes'] if str(n['id'])==ident)
   if visual['widgets_values'][0]!=graph[ident]['inputs']['image']:raise ValueError('API/UI image binding mismatch: '+ident)
  save(LOG/'actual.api.json',graph);save(LOG/'actual.ui.json',bound);require_idle(client);pid=client.submit(graph,bound,record)
 backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());history,measure=client.wait(pid,LOG,backend,timeout=600);files=client.download(history,LOG/'downloads');images=files.get('5',[])
 if len(images)!=1:raise ValueError('Expected exactly one composed output')
 generated=Path(images[0]);
 with Image.open(local) as a,Image.open(generated) as b:
  aa=np.asarray(a.convert('RGB'));bb=np.asarray(b.convert('RGB'))
 if aa.shape!=bb.shape:raise ValueError('Comfy and local output dimensions differ')
 delta=np.abs(aa.astype(np.int16)-bb.astype(np.int16));changed=int(np.any(delta!=0,axis=2).sum());maxdiff=int(delta.max());target.write_bytes(generated.read_bytes())
 report={'status':'pending_root_final_layout_review','prompt_id':pid,'local_preview':str(local),'local_sha256':sha(local),'comfy_output':str(target),'comfy_sha256':sha(target),'size':[aa.shape[1],aa.shape[0]],'different_rgb_pixels':changed,'max_channel_difference':maxdiff,'mask_polarity':'LoadImageMask red channel; white means overlay opacity','api':str(LOG/'actual.api.json'),'ui':str(LOG/'actual.ui.json'),'measurements':measure,'visual_approval':'not implied'};save(LOG/'comparison.json',report);print(json.dumps(report,ensure_ascii=False,indent=2))
 if changed:raise SystemExit('RGB mismatch; inspect comparison before use')
if __name__=='__main__':main()
