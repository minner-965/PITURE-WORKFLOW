"""Guard hero placements, or explicitly register a layout after root's visual review."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission multishop --legacy shop_hero_history -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

import argparse
import fcntl
import hashlib
import io
import json
import os
import re
import tempfile
from pathlib import Path

from PIL import Image, ImageOps

HISTORY = Path(__file__).resolve().parents[2] / "config/shop_hero_layout_history.json"


def same_footprint(first, second, tolerance=0.07):
    """Match boxes regardless of ordering. All four edges must be close."""
    if len(first) != len(second) or not first:
        return False
    options = [
        [index for index, other in enumerate(second)
         if max(abs(a - b) for a, b in zip(box, other)) <= tolerance]
        for box in first
    ]
    # Each old subject must match one distinct new subject.
    assigned = {}

    def pair(subject, visited):
        for candidate in options[subject]:
            if candidate in visited:
                continue
            visited.add(candidate)
            if candidate not in assigned or pair(assigned[candidate], visited):
                assigned[candidate] = subject
                return True
        return False

    return all(pair(i, set()) for i in range(len(first)))


def check_layout_history(sku, shop, product_sha256, reference_dhash, boxes):
    """Allow a shop to revisit its own accepted layout. Retired repeats always fail."""
    records = json.loads(HISTORY.read_text(encoding="utf-8")).get(sku, [])
    _check_records(records, sku, shop, product_sha256, reference_dhash, boxes)


def _check_records(records, sku, shop, product_sha256, reference_dhash, boxes):
    for record in records:
        if shop == record.get("shop") and record["status"] == "assigned":
            continue
        same_source = product_sha256 == record["reference_sha256"]
        near_source = (reference_dhash ^ int(record["reference_dhash"], 16)).bit_count() <= 3
        repeats_positions = any(
            same_footprint(boxes, previous) for previous in record["box_sets"]
        )
        if same_source or near_source or repeats_positions:
            raise ValueError(
                f"{sku}/{shop} 沿用已登记构图「{record['label']}」。"
                "请换主体数量、拍摄动作或明显不同的前后与左右关系，再看商品参考图。"
            )


def normalized_sets(groups):
    """Validate without rounding, canonicalize subject and group order for retries."""
    if not isinstance(groups, list) or not groups:
        raise ValueError("box_sets 至少需要一组主体位置")
    result = []
    for boxes in groups:
        if not isinstance(boxes, list) or not boxes:
            raise ValueError("每组至少需要一个 [左,上,右,下] 框")
        for box in boxes:
            if (not isinstance(box, list) or len(box) != 4
                    or any(type(v) not in (float, int) or not 0 <= v <= 1 for v in box)
                    or box[0] >= box[2] or box[1] >= box[3]):
                raise ValueError(f"无效的归一化位置框 {box}")
        group = sorted(boxes)
        if group not in result:
            result.append(group)
    return sorted(result)


def image_identity(path):
    """Decode and fingerprint the same bytes, using the batch runner's 64-bit dHash."""
    data = path.read_bytes()
    with Image.open(io.BytesIO(data)) as im:
        reduced = ImageOps.exif_transpose(im).convert("L").resize((9, 8))
    pixels = list(reduced.tobytes())
    signature = sum((pixels[y*9+x] > pixels[y*9+x+1]) << (y*8+x)
                    for y in range(8) for x in range(8))
    return hashlib.sha256(data).hexdigest(), signature


def batch_boxes(directory, sku, shop, ref_sha, photo_sha):
    """Bind the supplied files to the batch receipt, including legacy identity records."""
    identity = json.loads((directory / "identity.json").read_text(encoding="utf-8"))
    receipt = json.loads((directory / "layout_result.json").read_text(encoding="utf-8"))
    old_sku = identity.get("sku", {})
    if (identity.get("sku_id", old_sku.get("id")) != sku or identity.get("shop") != shop
            or identity.get("product_sha256") != ref_sha or receipt.get("source_sha256") != photo_sha):
        raise ValueError("批次 SKU、店铺、商品参考或无字照片与登记输入不一致")
    composition = identity.get("composition") or old_sku.get("shops", {}).get(shop, {}).get("composition", {})
    boxes = composition.get("bounds")
    if boxes is None:
        return []
    if composition.get("subject_count") != len(boxes):
        raise ValueError("批次中的主体数与位置框数量不一致")
    return [boxes]


def _photo_identity(record):
    if record.get("photo_dhash") is not None:
        return record["photo_sha256"], int(record["photo_dhash"], 16)
    # The original four records stored repo-relative paths without photo fingerprints.
    return image_identity(HISTORY.parents[1] / record["photo"])


def register(sku, shop, label, reference, photo, *, root_reviewed, groups=None,
             batch=None, history=HISTORY):
    if not root_reviewed:
        raise ValueError("登记前须由 root 实看并确认当前无字照片与构图")
    if not all(re.fullmatch(r"[A-Za-z0-9_-]+", value) for value in (sku, shop)) or not label.strip():
        raise ValueError("SKU、店铺须为有效 ID，label 须为非空描述")
    reference, photo = (Path(p).expanduser().resolve(strict=True) for p in (reference, photo))
    ref_sha, dhash = image_identity(reference)
    photo_sha, photo_dhash = image_identity(photo)
    batch_groups = batch_boxes(Path(batch), sku, shop, ref_sha, photo_sha) if batch else []
    if groups is not None:
        batch_groups.extend(normalized_sets(groups))
    groups = normalized_sets(batch_groups)
    record = {"label": label.strip(), "shop": shop, "status": "assigned",
              "reference_sha256": ref_sha, "reference_dhash": f"{dhash:016x}",
              "reference": str(reference), "photo": str(photo), "photo_sha256": photo_sha,
              "photo_dhash": f"{photo_dhash:016x}",
              "box_sets": groups, "reviewer": "root"}

    history = Path(history).resolve()
    history.parent.mkdir(parents=True, exist_ok=True)
    # Lock a stable sibling, since the history inode is replaced on every commit.
    with history.with_name("." + history.name + ".lock").open("a+b") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        data = json.loads(history.read_text(encoding="utf-8")) if history.exists() else {}
        records = data.setdefault(sku, [])
        for group in groups:
            _check_records(records, sku, shop, ref_sha, dhash, group)
        for old in records:
            old_sha, old_dhash = _photo_identity(old)
            if old_sha != photo_sha and (photo_dhash ^ old_dhash).bit_count() > 3:
                continue
            if old.get("shop") != shop or old["status"] != "assigned":
                raise ValueError(f"无字照片已用于已登记构图「{old['label']}」")
            if (old_sha == photo_sha and old["reference_sha256"] == ref_sha and old["label"] == record["label"]
                    and normalized_sets(old["box_sets"]) == groups):
                return "already_registered"
        records.append(record)
        temporary = None
        try:
            with tempfile.NamedTemporaryFile("w", dir=history.parent, encoding="utf-8", delete=False) as stream:
                temporary = Path(stream.name)
                if history.exists():
                    os.fchmod(stream.fileno(), history.stat().st_mode & 0o777)
                json.dump(data, stream, ensure_ascii=False, indent=2, allow_nan=False)
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, history)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
    return "registered"


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for field in ("sku", "shop", "label", "reference", "photo"):
        parser.add_argument("--" + field, required=True)
    parser.add_argument("--box-sets", type=Path, help="UTF-8 JSON 文件，例如 [[[0.1,0.2,0.6,0.7]]]，可补充无字照片实测位置")
    parser.add_argument("--batch-dir", type=Path, help="含 identity.json 与 layout_result.json 的批次目录")
    parser.add_argument("--history", type=Path, default=HISTORY, help="历史清单路径")
    parser.add_argument("--root-reviewed", action="store_true", required=True,
                        help="仅在 root 已实看并确认指定无字照片与构图后登记")
    args = parser.parse_args()
    try:
        explicit = json.loads(args.box_sets.read_text(encoding="utf-8")) if args.box_sets else None
        print(register(args.sku, args.shop, args.label, args.reference, args.photo,
                       root_reviewed=args.root_reviewed, groups=explicit,
                       batch=args.batch_dir, history=args.history))
    except (OSError, ValueError, KeyError, TypeError) as exc:
        parser.exit(2, str(exc) + "\n")
