#!/usr/bin/env python3
"""Measure current registered scene hashes using the reviewed exterior sample regions.

This is a triage report, never a visual approval. Preserve the frozen pre-correction
report, and require root to interpret lighting, remaining flags and small stacked bands.
"""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission export --legacy build_multishop_final_color_reports -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
import hashlib, json
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
DIAG = ROOT / 'work/diagnostics/multishop_20261103'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def lab(rgb):
    x = rgb / 255.
    x = np.where(x <= .04045, x / 12.92, ((x + .055) / 1.055) ** 2.4)
    xyz = x @ np.array([[.4124564,.2126729,.0193339], [.3575761,.7151522,.119192], [.1804375,.0721750,.9503041]])
    xyz /= np.array([.95047, 1., 1.08883])
    f = np.where(xyz > (6/29)**3, np.cbrt(xyz), xyz / (3*(6/29)**2) + 4/29)
    return np.stack([116*f[...,1]-16, 500*(f[...,0]-f[...,1]), 200*(f[...,1]-f[...,2])], -1)

def main():
    baseline = DIAG / 'color_audit_v1/report.json'
    old = json.loads(baseline.read_text())
    registry = json.loads((ROOT / 'config/multishop_scene_assets.json').read_text())
    folder = DIAG / 'color_audit_final'
    folder.mkdir(exist_ok=True)
    summaries = []
    for shop in 'ABC':
        for kind in ('hero','food','empty','underside','flatlay'):
            name = shop + '_' + kind
            scene = registry[shop][kind]
            if sha(scene['path']) != scene['sha256']:
                raise ValueError('Registry image changed: ' + name)
            arr = np.asarray(Image.open(scene['path']).convert('RGB')).astype(float)
            h, w = arr.shape[:2]
            colors = lab(arr)
            chroma = np.hypot(colors[...,1], colors[...,2])
            rows = []
            for previous in old['rows']:
                if previous['scene'].replace('C_underside_v3','C_underside') != name:
                    continue
                reference = previous.get('reference')
                sample = previous.get('sample')
                if not reference or not sample:
                    rows.append({'color':previous['color'], 'status':'insufficient_sample_root_required'})
                    continue
                if sha(reference['path']) != reference['sha256']:
                    raise ValueError('Reference changed: ' + reference['path'])
                color = previous['color']
                box = sample['box_256']
                x1,y1,x2,y2 = [int(v*s/256) for v,s in zip(box,(w,h,w,h))]
                mask = np.zeros((h,w), bool)
                mask[y1:y2,x1:x2] = True
                low_l = 20 if name in ('A_empty', 'B_food') and color == 'red' else 30
                mask &= (colors[...,0]>=low_l) & (colors[...,0]<=85) & (chroma >= (8 if color=='blue' else 18)) & (arr.max(2)<245)
                maskpath = folder / (name + '_' + color + '_sample_mask.png')
                Image.fromarray(mask.astype('uint8')*255).save(maskpath)
                row = {'color':color, 'reference':reference, 'sample_box_256':box,
                       'sample_mask':{'path':str(maskpath), 'sha256':sha(maskpath)},
                       'sample_pixels':int(mask.sum()), 'baseline_delta_e76':previous.get('delta_e76'),
                       'sample_limitation':'dark shadow sample; root interprets separately' if low_l==20 else 'different scene lighting and reference angle'}
                if mask.sum() < 10:
                    row.update(status='insufficient_sample_root_required', flag=True)
                else:
                    center = np.median(colors[mask], axis=0)
                    difference = center - np.array(reference['lab_median'])
                    delta = float(np.linalg.norm(difference))
                    row.update(lab_median=np.round(center,2).tolist(), delta_L=round(float(difference[0]),2),
                               delta_a=round(float(difference[1]),2), delta_b=round(float(difference[2]),2),
                               delta_ab=round(float(np.linalg.norm(difference[1:])),2), delta_e76=round(delta,2),
                               flag=delta>15, status='root_threshold_review_required' if delta>15 else 'within_triage_threshold_root_visual_review_required')
                rows.append(row)
            if not rows:
                raise ValueError('Missing scene sample coverage: ' + name)
            report = {'scene':name, 'image':{'path':scene['path'], 'sha256':scene['sha256']},
                      'status':'awaiting_root_color_review', 'method':'sRGB D65 CIELAB median exterior samples; Delta E 76',
                      'threshold_delta_e76':15, 'threshold_scope':'project triage trigger, not calibrated color fidelity certification',
                      'baseline_report':{'path':str(baseline), 'sha256':sha(baseline)},
                      'sample_coverage':'major visible colored faces; thin stacked bands also require root visual inspection',
                      'rows':rows}
            path = folder / (name + '.json')
            path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
            summaries.append({'scene':name, 'report':str(path), 'sha256':sha(path),
                              'image_sha256':scene['sha256'], 'flags':sum(x.get('flag',True) for x in rows)})
    (folder/'index.json').write_text(json.dumps({'status':'root_review_required', 'scenes':summaries},ensure_ascii=False,indent=2)+'\n')
    print('Measured 15 current scenes; reports never automatically approve images.')

if __name__ == '__main__':
    main()
