#!/usr/bin/env python3
"""Q6 Fill on one reviewed whole photograph; preserves the inverse-mask area."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission food --legacy run_whole_photo_fill -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

import argparse, hashlib, json, re, shutil, subprocess, time
from pathlib import Path
import numpy as np
from PIL import Image, PngImagePlugin
from build_workflows import make_a, node, check_graph, ui
from comfy_client import ComfyClient, sync_ui
from regional_whole_photo_graph import build as build_regional, bind_uploaded_masks, validate_regions
from original_region_restore import validate_restore
from crop_context_graph import build as build_crop, preview as preview_crop, validate_crop
from prompt_rules import resolve_food_prompt, lint_prompt

ROOT=Path(__file__).resolve().parents[2]
LOGS=ROOT/'work/logs/whole_photo_v5'
OUTPUT=ROOT/'output/LISTING_V3/w1125/assets/whole_photo_candidates'
BACKEND_LOG=ROOT/'work/diagnostics/headless_backend_20261103/comfyui.log'

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def digest(value): return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def save(path, data):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,ensure_ascii=False,indent=2))
def load_image(path,mode):
 p=Path(path)
 if not p.is_absolute() or not p.is_file():raise ValueError('Input must be an existing absolute path: '+str(p))
 image=Image.open(p).convert(mode)
 if image.size!=(1024,1024):raise ValueError(f'{p}: expected 1024×1024')
 return np.asarray(image)
def diff_report(image,base,region):
 d=np.abs(image.astype('int16')-base.astype('int16'))[region]
 if not len(d):raise ValueError('Protection region is empty')
 return {'pixels':int(len(d)),'max_abs_difference':int(d.max()),'different_pixels':int(np.any(d!=0,axis=1).sum())}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--tier',choices=('crop','preview','final'),default='final');ap.add_argument('--sampling-size',type=int,choices=(512,768,1024));ap.add_argument('--job-config',required=True);mode=ap.add_mutually_exclusive_group(required=True);mode.add_argument('--prepare-only',action='store_true');mode.add_argument('--run',action='store_true');a=ap.parse_args()
 config_path=Path(a.job_config)
 if not config_path.is_absolute():raise ValueError('job-config must be an absolute path')
 cfg=json.loads(config_path.read_text());legacy=cfg.get('allow_legacy_baseline') is True
 if legacy and a.tier=='final':raise ValueError('Legacy baseline is limited to crop/preview')
 if cfg.get('test_only') is True and a.tier=='final':raise ValueError('Test-only source is limited to crop/preview')
 if cfg.get('prompt_mode')=='regional_required' and not cfg.get('regions'):raise ValueError('Mixed dishes require independent regions and dish_id')
 if cfg.get('regions'):
  for region in cfg['regions']:
   if not region.get('dish_id'):raise ValueError('Every food region requires dish_id')
   region['prompt']=resolve_food_prompt(region['dish_id'],region.get('prompt_variant'))
  cfg['prompt']='Regional food conditioning by dish_id'
 elif cfg.get('dish_id'):
  cfg['prompt']=resolve_food_prompt(cfg['dish_id'],cfg.get('prompt_variant'))
 elif legacy:
  if not cfg.get('prompt'):raise ValueError('Legacy baseline requires historical prompt')
 elif cfg.get('region_type')=='background' or 'background' in cfg.get('job_id','').lower():
  verdict=lint_prompt('background',cfg.get('prompt'));
  if verdict['errors']:raise ValueError('Invalid background prompt: '+str(verdict['errors']))
 else:raise ValueError('Food jobs require dish_id; legacy comparison needs allow_legacy_baseline')
 required=['job_id','source','base_png','paint_mask','inverse_paste_mask','prompt','seed','output_prefix','root_mask_review']
 missing=[k for k in required if k not in cfg]
 if missing:raise ValueError('Missing config fields: '+', '.join(missing))
 job=cfg['job_id'];prefix=cfg['output_prefix']
 if not isinstance(job,str) or not re.fullmatch(r'[A-Za-z0-9_-]+',job):raise ValueError('Invalid job_id')
 if not isinstance(prefix,str) or not re.fullmatch(r'[A-Za-z0-9_-]+',prefix):raise ValueError('output_prefix must be a simple filename prefix')
 source=Path(cfg['source']);base=Path(cfg['base_png']);paint=Path(cfg['paint_mask']);paste=Path(cfg['inverse_paste_mask'])
 if not source.is_absolute() or not source.is_file():raise ValueError('source must be an existing absolute path')
 B=load_image(base,'RGB');M=load_image(paint,'L');P=load_image(paste,'L')
 if not np.array_equal(P,255-M):raise ValueError('inverse_paste_mask must be exactly 255 - paint_mask')
 if not np.any(M) or not np.any(M==0):raise ValueError('Mask needs both painted and protected areas')
 if not isinstance(cfg['prompt'],str) or not cfg['prompt'].strip():raise ValueError('prompt must not be empty')
 if not isinstance(cfg['seed'],int) or isinstance(cfg['seed'],bool) or cfg['seed']<0:raise ValueError('seed must be a non-negative integer')
 denoise=cfg.get('denoise',1.0)
 if isinstance(denoise,bool) or not isinstance(denoise,(int,float)) or not 0<denoise<=1:raise ValueError('denoise must be a number > 0 and <= 1')
 denoise=float(denoise)
 models=json.loads((ROOT/'work/diagnostics/model_inventory.json').read_text())['models'];model_hashes={x['path']:x['sha256'] for x in models}
 identity={'source_path':str(source),'source_sha256':sha(source),'base_path':str(base),'base_sha256':sha(base),'paint_path':str(paint),'paint_sha256':sha(paint),'paste_path':str(paste),'paste_sha256':sha(paste),'prompt_sha256':hashlib.sha256(cfg['prompt'].encode()).hexdigest(),'seed':cfg['seed'],'model_hashes':model_hashes,'settings':{'width':1024,'height':1024,'steps':20,'cfg':1.0,'guidance':30.0,'sampler':'euler','scheduler':'normal','denoise':denoise},'output_prefix':prefix}
 parent_id=cfg.get('parent_prompt_id');parent_hash=cfg.get('parent_exact_sha256');prep_path=cfg.get('base_preparation_path')
 if prep_path is not None:
  prep_sha=cfg.get('base_preparation_sha256')
  if not isinstance(prep_sha,str):raise ValueError('base_preparation_sha256 is required')
  checked=validate_restore(Path(prep_path),prep_sha);prep=json.loads(Path(prep_path).read_text())
  if prep.get('root_review')!='approved' or prep.get('root_review_mask_sha256')!=checked['paint_sha256']:raise ValueError('Preparation or new mask lacks matching root approval')
  if checked['parent_prompt_id']!=parent_id or checked['parent_exact_sha256']!=parent_hash:raise ValueError('Preparation parent identity mismatch')
  if checked['reset_output_sha256']!=identity['base_sha256'] or checked['paths']['reset_output']!=str(base.resolve()):raise ValueError('Prepared base does not match validated reset output')
  if checked['paint_sha256']!=identity['paint_sha256'] or checked['paths']['paint_mask']!=str(paint.resolve()) or checked['paths']['inverse_mask']!=str(paste.resolve()):raise ValueError('Prepared masks do not match validated inputs')
  identity.update(parent_prompt_id=parent_id,parent_exact_sha256=parent_hash,base_preparation_path=str(Path(prep_path).resolve()),base_preparation_sha256=prep_sha)
 elif parent_id is not None or parent_hash is not None:
  if not isinstance(parent_id,str) or not parent_id or not isinstance(parent_hash,str) or parent_hash!=identity['base_sha256']:raise ValueError('Parent prompt ID and matching parent exact base hash are both required')
  identity['parent_prompt_id']=parent_id;identity['parent_exact_sha256']=parent_hash
 regions=cfg.get('regions');crop=cfg.get('crop_context');regional_details=None;mask_nodes={}
 if a.sampling_size is not None and (crop is None or a.tier=='final'):raise ValueError('--sampling-size is only for crop_context diagnostics in crop/preview tiers')
 if a.tier in ('preview','crop') and regions is not None:raise ValueError('regional preview is not implemented; use independently bounded crop_context')
 if crop is not None:
  crop=dict(crop);crop['sampling_width']=crop['sampling_height']=a.sampling_size or {'crop':512,'preview':768,'final':1024}[a.tier]
 identity['tier']=a.tier;identity['settings']['steps']=20 if a.tier=='final' else 12
 identity['test_only']=cfg.get('test_only',False);identity['region_component']=cfg.get('region_component');identity['dish_id']=cfg.get('dish_id');identity['prompt_variant']=cfg.get('prompt_variant');identity['resolved_prompt']=cfg['prompt'];identity['allow_legacy_baseline']=legacy;identity['prompt_rules_sha256']=sha(ROOT/'scripts/prompt_rules.py');identity['food_templates_sha256']=sha(ROOT/'prompts/foods.yaml')
 if a.tier=='crop' and crop is None:raise ValueError('crop tier requires crop_context')
 if a.tier=='preview' and crop is None:identity['settings'].update(width=768,height=768)
 if crop is not None:identity['settings'].update(width=crop['sampling_width'],height=crop['sampling_height'])
 if regions is not None and crop is not None:raise ValueError('regions and crop_context may not be combined')
 if crop is not None:
  validate_crop(crop,str(paint));identity['crop_context']=crop;identity['crop_context_helper_sha256']=sha(ROOT/'scripts/crop_context_graph.py');identity['runner_version']='crop_context_v1'
 if regions is not None:
  regional_details=validate_regions(regions,str(paint))
  identity['runner_version']='regional_v1'
  identity['regional_helper_sha256']=sha(ROOT/'scripts/regional_whole_photo_graph.py')
  identity['regions']=[{**{k:r[k] for k in ('index','mask_path','mask_sha256','prompt_sha256','area')},'dish_id':src.get('dish_id'),'prompt_variant':src.get('prompt_variant'),'resolved_prompt':r['prompt']} for r,src in zip(regional_details,regions)]
 revision=digest(identity)[:24];log=(ROOT/'work/diagnostics/preview_tiers'/a.tier/job/revision if a.tier in ('crop','preview') else LOGS/job/revision);log.mkdir(parents=True,exist_ok=True)
 info=json.loads((ROOT/'work/diagnostics/object_info.json').read_text())
 if regions is not None:g,u,regional_details,_,mask_nodes=build_regional(regions,info,str(paint))
 elif crop is not None:g,u,crop_geometry,_=build_crop(crop,str(paint),info)
 else:g=make_a();u=None
 if a.tier=='preview' and crop is None:
  g['20']=node('ImageScale','PREVIEW_SOURCE',image=['1',0],upscale_method='lanczos',width=768,height=768,crop='disabled')
  g['21']=node('MaskToImage','PREVIEW_MASK_IMAGE',mask=['2',0])
  g['22']=node('ImageScale','PREVIEW_MASK_SCALE',image=['21',0],upscale_method='nearest-exact',width=768,height=768,crop='disabled')
  g['23']=node('ImageToMask','PREVIEW_MASK',image=['22',0],channel='red')
  g['11']['inputs'].update(pixels=['20',0],mask=['23',0])
  g['24']=node('ImageScale','PREVIEW_TO_ORIGINAL_SIZE',image=['13',0],upscale_method='lanczos',width=1024,height=1024,crop='disabled')
  g['14']['inputs']['destination']=['24',0];g['15']['inputs']['images']=['24',0]
 g['1']['inputs']['image']='ComfyProductPipeline/whole_photo_base.png';g['2']['inputs'].update(image='ComfyProductPipeline/whole_photo_paint.png',channel='red');g['3']['inputs'].update(image='ComfyProductPipeline/whole_photo_inverse.png',channel='red');g['7']['inputs']['text']=cfg['prompt'];g['12']['inputs'].update(seed=cfg['seed'],steps=identity['settings']['steps'],cfg=1.0,sampler_name='euler',scheduler='normal',denoise=denoise)
 if regions is None:g['8']['inputs']['guidance']=30.0
 g['15']['inputs']['filename_prefix']=f'ComfyProductPipeline/whole_photo_v5/{job}/{revision}_raw';g['16']['inputs']['filename_prefix']=f'ComfyProductPipeline/whole_photo_v5/{job}/{revision}_restored'
 if crop is not None:g['30']['inputs']['filename_prefix']=f'ComfyProductPipeline/whole_photo_v5/{job}/{revision}_native_crop'
 # Preview nodes are unnecessary for API execution; they can create temporary outputs.
 for node_id in ('17','18'):g.pop(node_id,None)
 checks=check_graph(g,info)
 if regions is None and crop is None:u=ui(g,info,'Whole photo Q6 Fill','真实整张照片；仅白色区域生成，反向蒙版保护并恢复原图；结果等待 root 视觉审核。')
 else:u=sync_ui(g,u,info)
 save(log/'identity.json',identity);save(log/'job_config.json',cfg);save(log/'prepared.api.json',g);save(log/'prepared.ui.json',u);save(log/'schema_checks.json',checks)
 if crop is not None:preview_crop(base,paint,crop,log/'crop_input_preview')
 print('prepared',log,flush=True)
 if a.prepare_only:return
 if cfg.get('draft_only') is True or cfg.get('needs_root_food_approval') is True:raise ValueError('Draft or pending root food approval: submission blocked')
 review=cfg['root_mask_review']
 if not isinstance(review,dict) or review.get('status')!='approved' or review.get('mask_sha256')!=identity['paint_sha256']:raise ValueError('root_mask_review must be {status: approved, mask_sha256: <current paint hash>}')
 c=ComfyClient();info=c.get('/object_info');check_graph(g,info);sub=log/'submission.json';result=log/'result.json'
 if result.exists():
  previous=json.loads(result.read_text())
  if previous.get('identity')!=identity or any(not Path(v['path']).is_file() or sha(v['path'])!=v['sha256'] for v in previous['outputs'].values()):raise ValueError('Completed result identity/output mismatch')
  print('already complete',result,flush=True);return
 if sub.exists():
  record=json.loads(sub.read_text());g=record['request']['prompt'];u=record['request']['extra_data']['extra_pnginfo']['workflow'];pid=c.reconcile(sub)
 else:
  q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('ComfyUI queue is occupied; no submission made')
  for node_id,path in [('1',base),('2',paint),('3',paste)]:g[node_id]['inputs']['image']=c.upload(path)
  if regions is not None:
   uploaded={str(i+1):c.upload(Path(r['mask_path'])) for i,r in enumerate(regions)}
   bind_uploaded_masks(g,mask_nodes,uploaded)
  check_graph(g,info);u=sync_ui(g,u,info)
  for node_id in ('1','2','3',*mask_nodes.values()):
   visual=next(n for n in u['nodes'] if str(n['id'])==node_id)
   if visual['widgets_values'][0]!=g[node_id]['inputs']['image']:raise ValueError('UI/API uploaded input mismatch: '+node_id)
  save(log/'actual.api.json',g);save(log/'actual.ui.json',u);pid=c.submit(g,u,sub)
 print('submitted',pid,flush=True)
 backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip())
 try:
  started=time.monotonic();history,measure=c.wait(pid,log,backend,7200);wall=time.monotonic()-started;measure.update(wait_seconds=wall,seconds_per_iteration=measure['wall_seconds']/identity['settings']['steps'],tier=a.tier,steps=identity['settings']['steps']);save(log/'measurements.json',measure);files=c.download(history,log/'downloads')
  if BACKEND_LOG.is_file():shutil.copyfile(BACKEND_LOG,log/'comfyui_full.log')
  if len(files.get('15',[]))!=1 or len(files.get('16',[]))!=1:raise ValueError('Expected one raw and one restored image')
  if crop is not None and len(files.get('30',[]))!=1:raise ValueError('Expected one native crop image')
  raw_path=Path(files['15'][0]);rest_path=Path(files['16'][0]);raw=load_image(raw_path,'RGB');rest=load_image(rest_path,'RGB');region=M==0
  checks_out={'raw':diff_report(raw,B,region),'restored':diff_report(rest,B,region),'paint_nonzero_pixels':int(np.count_nonzero(M)),'paint_zero_pixels':int(region.sum()),'mask_min':int(M.min()),'mask_max':int(M.max()),'raw_min':int(raw.min()),'raw_max':int(raw.max()),'restored_min':int(rest.min()),'restored_max':int(rest.max()),'width':1024,'height':1024}
  save(log/'pixel_checks_preliminary.json',checks_out)
  if checks_out['restored']['max_abs_difference']>1:raise ValueError('Protected area differs by more than rounding; inspect raw and restored output')
  folder=(ROOT/'work/diagnostics/preview_tiers'/a.tier/job/revision/'outputs' if a.tier in ('crop','preview') else OUTPUT/job/revision);folder.mkdir(parents=True,exist_ok=True);outputs={}
  for name,src in [('raw',raw_path),('restored',rest_path)]+([('native_crop',Path(files['30'][0]))] if crop is not None else []):
   dest=folder/(prefix+'_'+name+'.png');shutil.copyfile(src,dest);outputs[name]={'path':str(dest),'sha256':sha(dest)}
  dest=folder/(prefix+'_exact.png')
  if checks_out['restored']['different_pixels']:
   exact=rest.copy();exact[region]=B[region];meta=PngImagePlugin.PngInfo();meta.add_text('prompt',json.dumps(g,ensure_ascii=False));meta.add_text('workflow',json.dumps(u,ensure_ascii=False));Image.fromarray(exact).save(dest,pnginfo=meta)
  else:shutil.copyfile(rest_path,dest)
  decoded=load_image(dest,'RGB');checks_out['exact']=diff_report(decoded,B,region)
  if checks_out['exact']['different_pixels']:raise ValueError('Exact protected pixels differ after saving')
  outputs['exact']={'path':str(dest),'sha256':sha(dest)}
  report={'status':'awaiting_root_visual_review','identity':identity,'job_id':job,'prompt_id':pid,'outputs':outputs,'pixel_checks':checks_out,'measurements':measure,'history':str(log/'history.json'),'actual_api':str(log/'actual.api.json'),'actual_ui':str(log/'actual.ui.json'),'visual_pass':None}
  save(result,report);save(folder/(prefix+'_metadata.json'),{'identity':identity,'prompt':cfg['prompt'],'api':g,'ui':u,'result':report});print('completed',str(result),'prompt_id',pid,'protected_diff_max',checks_out['restored']['max_abs_difference'],'outputs',json.dumps({k:v['path'] for k,v in outputs.items()},ensure_ascii=False),flush=True)
 except Exception as e:
  if BACKEND_LOG.is_file():shutil.copyfile(BACKEND_LOG,log/'comfyui_full.log')
  save(log/'failure.json',{'prompt_id':pid,'error':str(e),'time':time.time()});raise
if __name__=='__main__':main()
