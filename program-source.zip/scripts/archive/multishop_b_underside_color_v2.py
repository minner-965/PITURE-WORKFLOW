
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission layout --legacy multishop_b_underside_color_v2 -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from PIL import Image, ImageDraw, ImageFilter
import numpy as np, colorsys, json, hashlib
from pathlib import Path
base=Path('/Users/luohuiwu/codex/ComfyProductPipeline')
src=base/'work/diagnostics/multishop_20261103/B_underside_true_stamp/B_underside_true_stamp.png'
ref=base/'work/diagnostics/multishop_20261103/scene_inputs/green_underside_identity.png'
out=base/'work/diagnostics/multishop_20261103/B_underside_color_v2'
out.mkdir(exist_ok=True,parents=True)
a=np.asarray(Image.open(src).convert('RGB')); h,w=a.shape[:2]
# Connected green surface separates bowl from skin and neutral surroundings.
from scipy import ndimage as ndi
rgb16=a.astype(np.int16); r,g,b=rgb16[:,:,0],rgb16[:,:,1],rgb16[:,:,2]
roi=np.zeros((h,w),bool); roi[280:782,170:660]=True
candidate=roi & (g>=r-5) & (g>=b+22)
labels,n=ndi.label(candidate); label=np.bincount(labels.ravel())[1:].argmax()+1; connected=labels==label
# Reflections and lettering are holes within connected bowl; fill them, retaining the outer edge.
connected=ndi.binary_fill_holes(connected)
# Cut table contact shadow below actual convex silhouette, retain green along the rim.
limit=Image.new('L',(w,h)); ImageDraw.Draw(limit).polygon([(170,280),(660,280),(660,500),(610,550),(606,590),(594,630),(578,665),(555,700),(530,725),(500,747),(470,762),(440,771),(410,778),(380,779),(350,775),(320,765),(290,750),(260,729),(235,704),(215,676),(195,640),(184,604),(176,565),(170,530)], fill=255)
connected &= np.asarray(limit)>0
# Soften only inward. Mask remains restricted to the detected bowl.
distance=ndi.distance_transform_edt(connected); mask=np.rint(np.minimum(distance/2,1)*255).astype('uint8')
# Convert to HSV and boost saturation while preserving luminance and highlights.
rgb=a.astype(np.float32)/255.; mx=rgb.max(2); mn=rgb.min(2); delta=mx-mn
# RGB green is increased relative to blue, red mildly increased; chroma-weighted blend preserves neutral reflections.
chroma=np.clip((delta-.035)/.24,0,1); lum=np.clip((mx-.12)/.2,0,1)*np.clip((1.01-mx)/.18,0,1)
strength=(mask/255.)*chroma*lum
# Color adjustment targets brighter yellow-green reference while holding source shading.
adj=np.empty_like(rgb); adj[:,:,0]=np.clip(rgb[:,:,0]*1.045+0.025,0,1);adj[:,:,1]=np.clip(rgb[:,:,1]*1.16+0.015,0,1);adj[:,:,2]=np.clip(rgb[:,:,2]*0.72,0,1)
res=np.rint((rgb*(1-strength[:,:,None])+adj*strength[:,:,None])*255).clip(0,255).astype('uint8')
Image.fromarray(mask).save(out/'bowl_mask.png');Image.fromarray(res).save(out/'B_underside_color.png')
vis=Image.fromarray(a.copy()); overlay=Image.new('RGB',(w,h),(255,0,255)); vis=Image.composite(Image.blend(vis,overlay,.45),vis,Image.fromarray(mask));vis.save(out/'mask_overlay.png')
thumb=Image.new('RGB',(1536,1024));thumb.paste(Image.fromarray(a),(0,0));thumb.paste(Image.fromarray(res),(768,0));thumb.save(out/'before_after.png')
sha=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
changed=np.any(a!=res,2); outside=mask==0
meta={'status':'pending_root_visual_review','source':str(src),'source_sha256':sha(src),'reference':str(ref),'reference_sha256':sha(ref),'mask':str(out/'bowl_mask.png'),'mask_sha256':sha(out/'bowl_mask.png'),'output':str(out/'B_underside_color.png'),'output_sha256':sha(out/'B_underside_color.png'),'parameters':{'method':'RGB channel affine, chroma and luminance weighted, inward soft mask','red':[1.045,0.025],'green':[1.16,0.015],'blue':[0.72,0],'edge_blur_px':2,'segmentation':'connected g >= r - 5 and g >= b + 22, ROI x170:660 y280:782, filled internal holes, 2px inward feather; manual lower silhouette cutoff'},'pixels_changed':int(changed.sum()),'pixels_changed_outside_mask':int((changed&outside).sum()),'scope':'hand/background/spoon excluded by green connected component; root visual confirmation required'}
(out/'provenance.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
print(json.dumps(meta,ensure_ascii=False,indent=2))
