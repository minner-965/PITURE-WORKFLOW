
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission scene --legacy prepare_scene_v7_inputs -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
import hashlib,json
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import distance_transform_edt

P=Path(__file__).resolve().parents[2]; O=P/'work/diagnostics/scene_v7/inputs'; O.mkdir(parents=True,exist_ok=True)
paths={'base':P/'work/base/LISTING_orange/Base_Image.png','inner':P/'work/masks/LISTING_orange/inner_mask.png','empty':P/'output/LISTING_V3/w1125/assets/empty_bowls/orange.png','food':P/'output/LISTING_V3/w1125/assets/filled_bowls/orange_plain_congee.png'}
ims={k:Image.open(v).copy() for k,v in paths.items()}
assert all(i.size==(1024,1024) for i in ims.values())
alpha=ims['empty'].getchannel('A'); foodalpha=ims['food'].getchannel('A')
alpha_match = np.array_equal(np.asarray(alpha),np.asarray(foodalpha))
# Pillow inverse affine: output coordinate maps to source coordinate.
s=1.35; tx=-179; ty=-130
coeff=(1/s,0,-tx/s,0,1/s,-ty/s)
def trans(im, res=Image.Resampling.BICUBIC): return im.transform((1024,1024),Image.Transform.AFFINE,coeff,resample=res,fillcolor=0)
def save(a,name): Image.fromarray(a.astype('uint8')).save(O/name)
# RGB sampled from source base; the supplied improved spline alpha is the sole outer silhouette.
empty=ims['base'].convert('RGBA'); empty.putalpha(alpha); empty=trans(empty)
food=ims['food'].copy(); food.putalpha(alpha); food=trans(food)
a=np.asarray(empty.getchannel('A')).astype(np.uint16); ia=np.asarray(trans(ims['inner'].convert('L'))).astype(np.uint16)
# Inner mask is clipped to the real bowl alpha. White means repaint.
inner=np.minimum(ia,a); shell=np.rint(a*(255-inner)/255).astype(np.uint8)
paint=255-shell
core=(distance_transform_edt(shell>=254)>=4).astype(np.uint8)*255
acore=(distance_transform_edt(a>=254)>=4).astype(np.uint8)*255
empty.save(O/'direct_B_bowl_rgba.png'); food.save(O/'A_food_rgba.png')
bg=Image.new('RGBA',(1024,1024),(128,128,128,255)); bg.alpha_composite(empty); base=bg.convert('RGB'); base.save(O/'direct_B_base.png')
save(paint,'direct_B_paint.png'); save(shell,'direct_B_paste_mask.png'); save(core,'direct_B_protect_core.png'); save(acore,'A_food_core.png'); save(inner,'transformed_inner_mask.png')
def overlay(mask,color,name):
 layer=Image.new('RGBA',(1024,1024),color+(0,)); layer.putalpha(Image.fromarray((mask.astype(float)*0.5).astype('uint8'))); out=base.convert('RGBA'); out.alpha_composite(layer); out.convert('RGB').save(O/name)
overlay(paint,(255,0,0),'direct_B_paint_overlay.png'); overlay(core,(0,255,0),'direct_B_core_overlay.png'); overlay(inner,(0,128,255),'inner_overlay.png')
# Contact sheet with source and masks.
items=[('B base',base),('B paint: white=repaint',Image.fromarray(paint).convert('RGB')),('B paint overlay',Image.open(O/'direct_B_paint_overlay.png')),('B core overlay',Image.open(O/'direct_B_core_overlay.png')),('A food',Image.alpha_composite(Image.new('RGBA',(1024,1024),(128,128,128,255)),food).convert('RGB')),('A core',Image.fromarray(acore).convert('RGB'))]
thumb=340; sheet=Image.new('RGB',(thumb*3,(thumb+25)*2),'white'); d=ImageDraw.Draw(sheet)
for i,(label,im) in enumerate(items):
 x=(i%3)*thumb;y=(i//3)*(thumb+25);sheet.paste(im.resize((thumb,thumb),Image.Resampling.LANCZOS),(x,y+25));d.text((x+5,y+5),label,fill='black')
sheet.save(O/'comparison_preview.jpg',quality=94)
# Native crops are unscaled and include mask overlays for review.
for name,box in {'rim':(300,440,730,590),'right_ear':(675,450,850,650),'bottom':(300,685,730,880)}.items():
 for label,im in [('base',base),('paint_overlay',Image.open(O/'direct_B_paint_overlay.png')),('core_overlay',Image.open(O/'direct_B_core_overlay.png'))]: im.crop(box).save(O/f'crop_{name}_{label}.png')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bbox(arr):
 ys,xs=np.where(arr>0);return [int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)] if len(xs) else None
originner=np.asarray(ims['inner']); origalpha=np.asarray(alpha)
report={'transform':{'scale':s,'translate':[tx,ty],'canvas':[1024,1024],'resample':'Pillow bicubic inverse affine','bbox_convention':'left,top,right,bottom exclusive'},'source_sha256':{k:sha(v) for k,v in paths.items()},'source_alpha_bbox':list(alpha.getbbox()),'transformed_alpha_bbox':bbox(a),'inner_original_bbox':list(ims['inner'].getbbox()),'inner_transformed_bbox':bbox(inner),'original_inner_pixels_outside_alpha':int(np.count_nonzero((originner>0)&(origalpha==0))),'transformed_inner_pixels_outside_alpha_before_clip':int(np.count_nonzero((ia>0)&(a==0))),'alpha_matches_food_source':bool(alpha_match),'source_alpha_differing_pixels':int(np.count_nonzero(np.asarray(alpha)!=np.asarray(foodalpha))),'grey_background_rgb':[128,128,128],'outside_alpha_non_grey_pixels':int(np.count_nonzero(np.any(np.asarray(base)[a==0]!=128,axis=1))),'paint_outside_alpha_min':int(paint[a==0].min()),'paint_outside_alpha_max':int(paint[a==0].max()),'shell_core_pixels':int(np.count_nonzero(core)),'food_core_pixels':int(np.count_nonzero(acore)),'core_definition':'distance >= 4 pixels from non-opaque shell/bowl; visual review required','risk':'Existing inner mask is inherited and may include rim or omit inner reflections; inspect overlays at native size. Bicubic introduces fractional boundary pixels; paste mask is derived from transformed source alpha and transformed inner mask.'}
(O/'checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
