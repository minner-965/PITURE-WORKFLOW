
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission multishop --legacy prepare_multishop_C_under_refine -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
import numpy as np
from PIL import Image,ImageFilter,ImageChops
import json,hashlib
R=Path(__file__).resolve().parents[2];D=R/'work/diagnostics/multishop_20261103/C_underside_true_bowl_guide';W=R/'work/diagnostics/multishop_20261103/scene_inputs';prep=json.loads((D/'prep.json').read_text());src=Image.open(prep['source_original']['path']).convert('RGB');guide=Image.open(D/'C_underside_guide.png').convert('RGB');a=np.asarray(src).astype(float);h,w=a.shape[:2];yy,xx=np.mgrid[:h,:w];x=xx/w;y=yy/h;f=np.stack([np.ones_like(x),x,y,x*y,x*x,y*y],-1);field=np.zeros_like(a)
for lower in [False,True]:
 sel=((yy>=535)&(a.max(2)-a.min(2)<38)&(a.min(2)>160)) if lower else ((yy<530)&(a[:,:,2]-a[:,:,0]>38)&(a[:,:,2]-a[:,:,1]>5))
 sel &= ((xx%5==0)&(yy%5==0));coef=np.linalg.lstsq(f[sel],a[sel],rcond=None)[0];out=f@coef;region=yy>=531 if lower else yy<531;field[region]=out[region]
field=np.uint8(np.clip(field,0,255));bg=Image.fromarray(field);mask=Image.open(D/'background_replacement_mask.png').convert('L').filter(ImageFilter.GaussianBlur(9));merged=Image.composite(bg,src,mask)
# Paste the actual yellow vessel and restore original skin in front.
bowl=Image.open(R/'work/diagnostics/multishop_20261103/flatlay_refs/yellow.png').convert('RGBA').rotate(-35,resample=Image.Resampling.BICUBIC,expand=True);bowl=bowl.crop(bowl.getchannel('A').getbbox()).resize((469,510),Image.Resampling.LANCZOS);merged=merged.convert('RGBA');merged.alpha_composite(bowl,(166,295));merged=Image.composite(src,merged.convert('RGB'),Image.open(D/'hand_mask.png').convert('L'));ref=D/'C_underside_clean_guide.png';merged.save(ref)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
c=json.loads((W/'C_underside_v2.json').read_text());p='Refine this commercial product photograph with the exact yellow physical bowl, hand contact, contours, circular foot-ring proportions and embossed lettering shown in image 1. A left hand grips the upper-left flat tab; the opposite flat tab points to the lower right. The convex underside and small central circular foot are visible. The photographic scene has one continuous powder-blue wall and matte white tabletop with the existing blue linen and white spoon. Integrate soft cool daylight and realistic gentle reflections, smooth the background transitions and natural hand contact. The exact physical shape and color in image 2 match the bowl in image 1.';c.update(job_id='C_underside_v3',mode='refine',start_step=1,reference1=str(ref),reference1_source=prep['source_original']['path'],prompt=p,seed=20261106903,evidence_files=[str(D/'prep.json')]);c['root_input_review']={'status':'approved','reviewer':'root','prompt_sha256':hashlib.sha256(p.encode()).hexdigest(),'reference1_sha256':sha(ref),'reference2_sha256':sha(c['reference2']),'note':'Root rejected generated plate geometry; conditioning image now contains actual yellow product cutout with opposite tabs and correct low-foot ratio. Background reconstructed from photographed wall/table color field. Final shape and contact reviewed after 3-step refinement.'};(W/'C_underside_v3.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
