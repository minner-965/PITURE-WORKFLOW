
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission export --legacy multishop_color_audit_v1 -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib, math
B=Path('/Users/luohuiwu/codex/ComfyProductPipeline'); D=B/'work/diagnostics/multishop_20261103'; O=D/'color_audit_v1'; O.mkdir(parents=True,exist_ok=True)
reg=json.load(open(B/'config/multishop_scene_assets.json'))
# Boxes on 256x256 coordinate system, hand-selected on colored exterior, avoiding rims, food and scene.
boxes={
'A_hero':{'blue':(143,94,190,108),'yellow':(160,175,199,185),'orange':(48,222,93,233)},
'A_food':{'orange':(80,100,111,110),'yellow':(171,100,199,109),'green':(29,149,59,161),'red':(99,193,139,205),'blue':(183,155,204,167)},
'A_empty':{'blue':(75,135,110,145),'yellow':(179,165,214,175),'red':(70,201,110,210)},
'A_underside':{'blue':(91,101,120,116),'orange':(75,195,101,205),'green':(200,177,223,184)},
'B_hero':{'red':(115,102,147,113),'blue':(49,202,80,215),'green':(170,211,201,222)},
'B_food':{'orange':(52,102,79,112),'green':(184,115,207,125),'blue':(124,137,145,144),'yellow':(101,190,123,198),'red':(200,188,224,198)},
'B_empty':{'blue':(63,128,91,140),'orange':(184,144,208,155),'green':(119,197,144,205)},
'B_underside':{'green':(105,106,130,130)},
'C_hero':{'yellow':(38,139,66,149),'green':(143,170,173,180),'orange':(47,205,80,216)},
'C_food':{'orange':(63,99,91,109),'red':(179,112,207,124),'blue':(67,195,93,205),'yellow':(111,147,137,157),'green':(191,185,215,195)},
'C_empty':{'orange':(53,144,88,154),'red':(160,127,192,139),'green':(169,183,202,194)},
'C_underside_v3':{'yellow':(120,133,145,150)},
'A_flatlay':{'blue':(121,33,137,48),'red':(192,67,208,80),'yellow':(47,69,62,81),'green':(190,132,207,145),'orange':(119,183,136,197)},
'B_flatlay':{'red':(67,37,83,48),'blue':(168,37,182,48),'orange':(75,106,90,118),'green':(175,107,190,118),'yellow':(65,179,80,191)},
'C_flatlay':{'yellow':(56,32,70,44),'blue':(151,56,165,68),'red':(58,94,72,105),'orange':(63,153,76,164),'green':(158,177,173,188)}}
# D65 sRGB -> CIELAB; Delta E 76 for triage rather than calibration pass/fail.
def lab(rgb):
 x=rgb/255.; x=np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4)
 xyz=x@np.array([[.4124564,.2126729,.0193339],[.3575761,.7151522,.119192],[.1804375,.0721750,.9503041]])
 xyz=xyz/np.array([.95047,1,1.08883]); f=np.where(xyz>(6/29)**3,np.cbrt(xyz),xyz/(3*(6/29)**2)+4/29)
 return np.stack([116*f[...,1]-16,500*(f[...,0]-f[...,1]),200*(f[...,1]-f[...,2])],axis=-1)
def sample(path,box,name):
 im=Image.open(path).convert('RGB'); arr=np.array(im); h,w=arr.shape[:2]; x1,y1,x2,y2=[int(v*s/256) for v,s in zip(box,(w,h,w,h))]; mask=np.zeros((h,w),bool);mask[y1:y2,x1:x2]=True
 labs=lab(arr.astype(float)); chroma=np.hypot(labs[:,:,1],labs[:,:,2]); mask &= (labs[:,:,0]>=(20 if name=='A_empty_red' else 30))&(labs[:,:,0]<=85)&(chroma>=8 if 'blue' in name else chroma>=18)&(np.max(arr,2)<245)
 Image.fromarray(mask.astype('uint8')*255).save(O/f'{name}_sample_mask.png')
 if mask.sum()<10:return None
 return {'lab_median':np.round(np.median(labs[mask],axis=0),2).tolist(),'sample_pixels':int(mask.sum()),'box_256':box}
refs={}
for c in ['blue','green','red','yellow','orange']:
 p=B/f'work/masks/LISTING_{c}/empty_bowl_cutout.png'; refs[('side',c)]=sample(p,(105,165,152,180),f'ref_side_{c}')|{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 p=D/f'flatlay_refs/{c}.png'; refs[('bottom',c)]=sample(p,(95,95,160,160),f'ref_bottom_{c}')|{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
# Explicit identity references for handheld undersides.
for c in ['green','yellow']:
 p=D/f'scene_inputs/{c}_underside_identity.png'; refs[('identity',c)]=sample(p,(90,90,160,160),f'ref_identity_{c}')|{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
rows=[]
for name,colors in boxes.items():
 if name=='C_underside_v3':p=D/'generation/C_underside_v3/51d482f498283db8805ed253/downloads/23_0_51d482f498283db8805ed253_00001_.png'
 else:
  shop,scene=name.split('_',1);p=Path(reg[shop][scene]['path'])
 for c,box in colors.items():
  kind='bottom' if 'flatlay' in name else 'identity' if name in ('B_underside','C_underside_v3') else 'side'
  s=sample(p,box,f'{name}_{c}');ref=refs[(kind,c)]
  if not s:rows.append({'scene':name,'color':c,'status':'insufficient_sample'});continue
  de=float(np.linalg.norm(np.array(s['lab_median'])-ref['lab_median'])); rows.append({'scene':name,'color':c,'scene_path':str(p),'scene_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'sample':s,'reference':ref,'reference_kind':kind,'delta_e76':round(de,2),'delta_L':round(s['lab_median'][0]-ref['lab_median'][0],2),'delta_a':round(s['lab_median'][1]-ref['lab_median'][1],2),'delta_b':round(s['lab_median'][2]-ref['lab_median'][2],2),'delta_ab':round(float(np.linalg.norm(np.array(s['lab_median'][1:])-ref['lab_median'][1:])),2),'flag':de>15,'status':'root_review_required' if de>15 else 'within_triage_threshold_visual_review_required'})
result={'method':'Hand-chosen exterior rectangles with mask filter L* 30–85, chroma >=18, max RGB <245; median CIELAB D65; Euclidean Delta E 76. Flag >15 as provisional triage, not calibrated color accuracy or automatic acceptance. Boxes may contain reflections; masks must be visually checked. Lighting and angles differ.','threshold_delta_e76':15,'references':{f'{k[0]}_{k[1]}':v for k,v in refs.items()},'rows':rows}
(O/'report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
lines=['# 三店碗体颜色初筛','',result['method'],'','阈值 ΔE76 > 15 提请 root 复核；阈值内仍需视觉审核。场景和实拍光照不同，数值不是色彩校准结论。','', '| 场景 | 颜色 | 场景 Lab 中位数 | 实拍 Lab 中位数 | ΔL* | Δa* | Δb* | Δab | ΔE76 | 状态 |','|---|---|---|---|---:|---:|---:|---:|---:|---|']
for r in rows:
 if 'delta_e76' in r:lines.append(f"| {r['scene']} | {r['color']} | {r['sample']['lab_median']} | {r['reference']['lab_median']} | {r['delta_L']} | {r['delta_a']} | {r['delta_b']} | {r['delta_ab']} | {r['delta_e76']} | {'超阈值，请 root 复核' if r['flag'] else '阈值内，仍需视觉审核'} |")
 else:lines.append(f"| {r['scene']} | {r['color']} | — | — | — | — | — | — | — | 采样不足 |")
(O/'report.md').write_text('\n'.join(lines)+'\n'); print('rows',len(rows),'flagged',sum(r.get('flag',False) for r in rows))
