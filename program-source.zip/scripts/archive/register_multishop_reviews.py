
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission export --legacy register_multishop_reviews -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[2];G=R/'work/diagnostics/multishop_20261103/generation';cfg=R/'config/multishop_scene_assets.json';C=json.loads(cfg.read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(shop,key,job,rev,notes):
 d=G/job/rev;r=json.loads((d/'result.json').read_text());p=Path(r['outputs']['generated']['path']);review={'status':'approved','reviewer':'root','scope':'scene_visual','sha256':sha(p),'notes':notes};(d/'root_review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');C[shop][key]={'path':str(p),'sha256':sha(p),'generation_result':str(d/'result.json'),'root_review':str(d/'root_review.json')}
add('C','food','C_food_v1','ea6237778ff8a2e36069374c','Six vessels show all five required colors. Actual count is accepted for food-combination module; original reference also repeated colors. White collars, flat tabs and low feet are coherent. Coconut/rice dessert, purple root cubes, mango and bean soup are plausible, all key contours contained. Food names remain generic in listing text.')
add('A','empty','A_empty_v1','b2481e32e6690da1791f537d','Three-bowl stack and two foreground empty bowls, five colors, intact white interiors and solid flat tabs. The textured reflection on the lower blue wall corresponds to the woven mat immediately below, accepted as scene reflection. Natural grounded shadows and new grouping.')
d=R/'work/diagnostics/multishop_20261103/accepted_scenes';p=d/'B_food_composed.png';comp=json.loads((d/'B_food_composition.json').read_text());review={'status':'approved','reviewer':'root','scope':'composed_scene_visual','sha256':sha(p),'notes':'Six bowls, all five colors. Replaced over-regular grains and four black lumps in rear green bowl with a donor crop containing liquid congee only; inspected 3x crop to remove donor rim, leaving no extra white ring. Other foods and product geometry preserved. Count six accepted as five-color assortment.'};(d/'B_food_root_review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');C['B']['food']={'path':str(p),'sha256':sha(p),'generation_result':comp['generation_results'][0],'additional_generation_results':[],'composition_provenance':str(d/'B_food_composition.json'),'root_review':str(d/'B_food_root_review.json')};cfg.write_text(json.dumps(C,ensure_ascii=False,indent=2)+'\n')
