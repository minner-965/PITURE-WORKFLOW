
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission scene --legacy prepare_multishop_flatlays -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[2];W=R/'work/diagnostics/multishop_20261103/scene_inputs';F=R/'work/diagnostics/multishop_20261103/flatlay_refs'
ref2=R/'work/diagnostics/multishop_20261103/product_refs/五色器型_1024.png';src=R/'input/supplied_20261102/测试品/详情页实拍/IMG_5899.jpg'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for s in ['A','B','C']:
 ref=F/f'layout_{s}_pending.png'
 surface={'A':'light honey oak tabletop with very subtle fine wood grain, warm soft window light','B':'pale sage-grey limestone tabletop, diffuse fresh morning light','C':'smooth pale blue matte tabletop, cool soft daylight'}[s]
 p='A top-down commercial product flatlay photographed on '+surface+'. The six physical bowls have exactly the positions, scale, orientation, colors and shapes visible in image 1. Five colored bowls face upside down, showing their real shallow circular foot and molded lettering; one bowl faces upward showing its white interior. Each colored bowl has two flat solid side tabs. The physical product identity matches image 2. Refine the tabletop texture, soften cutout edges, and add delicate natural contact shadows immediately underneath each bowl. All six bowls stay fully visible with clear gaps. A realistic overhead studio photograph with a continuous tabletop filling the image.'
 c={'job_id':s+'_flatlay_v1','mode':'refine','start_step':2,'reference1':str(ref),'reference2':str(ref2),'reference1_source':str(src),'reference2_source':str(R/'output/LISTING_V3/w1125/assets/empty_bowls/red.png'),'width':768,'height':1184,'reference_size':512,'seed':20261104500+ord(s),'prompt':p,'evidence_files':[str(F/'cutouts.json'),str(F/f'layout_{s}_pending.json')],'root_input_review':{'status':'approved','reviewer':'root','prompt_sha256':hashlib.sha256(p.encode()).hexdigest(),'reference1_sha256':sha(ref),'reference2_sha256':sha(ref2),'note':'Root inspected all three contact sheets; real product cutouts were corrected to remove floating pieces. Two-step refinement for photographic integration, subject to final shape and text review.'}}
 (W/(c['job_id']+'.json')).write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
