
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission layout --legacy multishop_first5_color_v2 -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from pathlib import Path
from PIL import Image,ImageDraw
from scipy import ndimage as ndi
import numpy as np,json,hashlib
B=Path('/Users/luohuiwu/codex/ComfyProductPipeline');D=B/'work/diagnostics/multishop_20261103'; O=D/'blue_green_candidates_v2'; reg=json.load(open(B/'config/multishop_scene_assets.json')); report=json.load(open(D/'color_audit_v1/report.json'))
# Carefully traced colored exterior, source pixel coordinates. Inward feather keeps mask strictly inside outline.
regions={
'A_hero':{'blue':[[(380,317),(401,328),(435,338),(476,344),(523,345),(562,340),(600,333),(635,322),(644,318),(640,338),(630,358),(617,376),(598,394),(581,406),(578,418),(564,425),(536,431),(485,431),(457,426),(443,420),(441,413),(421,404),(408,391),(395,376),(386,356)]]},
'A_food':{'green':[[(49,448),(69,461),(97,470),(131,474),(165,471),(197,463),(222,450),(250,439),(246,463),(237,487),(226,507),(213,521),(197,532),(188,541),(178,546),(133,550),(112,545),(103,538),(84,529),(71,515),(60,493),(53,471)]], 'blue':[[(571,470),(590,482),(619,493),(654,501),(691,505),(729,503),(759,494),(780,485),(772,511),(760,532),(745,550),(730,560),(718,568),(711,575),(689,579),(654,578),(637,575),(625,567),(605,557),(590,543),(580,525)]]},
'A_empty':{'blue':[[(157,478),(184,487),(220,495),(257,499),(298,499),(338,494),(373,484),(403,471),(399,496),(392,520),(381,542),(366,560),(349,574),(332,582),(321,591),(293,596),(264,595),(239,591),(222,583),(203,573),(184,556),(171,536),(163,515)]], 'green':[[(158,413),(181,423),(213,433),(249,439),(286,441),(324,437),(359,428),(392,414),(384,427),(365,438),(340,448),(311,455),(273,458),(240,456),(210,450),(184,441),(167,430)]]},
'A_underside':{'blue':[[(273,282),(288,294),(307,312),(326,328),(346,345),(368,365),(391,385),(414,403),(438,421),(465,442),(489,457),(483,462),(467,455),(461,474),(450,492),(438,505),(420,514),(399,519),(380,520),(364,516),(357,527),(348,535),(331,532),(306,519),(283,503),(260,485),(242,468),(236,457),(242,445),(250,440),(240,428),(235,413),(235,396),(240,377),(248,361),(256,346),(259,329),(259,311),(264,300)]], 'green':[[(551,664),(580,672),(614,675),(648,675),(683,671),(710,665),(732,656),(727,679),(720,701),(713,720),(699,738),(683,751),(674,758),(673,767),(657,772),(629,775),(614,772),(611,762),(604,755),(602,742),(611,721),(615,699),(611,681)] ]},
'B_hero':{'blue':[[(102,648),(126,657),(158,665),(195,669),(230,670),(266,665),(299,656),(334,640),(330,663),(322,687),(309,708),(293,724),(277,734),(275,743),(260,749),(241,752),(195,750),(176,746),(162,741),(160,733),(144,724),(129,710),(117,692),(109,674)]], 'green':[[(490,656),(516,666),(550,674),(585,679),(623,679),(658,673),(688,663),(709,652),(706,675),(698,694),(687,712),(670,727),(654,735),(650,744),(637,750),(617,754),(579,755),(557,751),(541,745),(540,738),(523,729),(510,716),(500,701),(493,682)]]}}
def tolab(x):
 x=x/255.;x=np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4);z=x@np.array([[.4124564,.2126729,.0193339],[.3575761,.7151522,.119192],[.1804375,.0721750,.9503041]]);z/=np.array([.95047,1,1.08883]);f=np.where(z>(6/29)**3,np.cbrt(z),z/(3*(6/29)**2)+4/29);return np.stack([116*f[...,1]-16,500*(f[...,0]-f[...,1]),200*(f[...,1]-f[...,2])],-1)
def torgb(l):
 fy=(l[:,:,0]+16)/116;f=np.stack([fy+l[:,:,1]/500,fy,fy-l[:,:,2]/200],-1);z=np.where(f>6/29,f**3,3*(6/29)**2*(f-4/29))*np.array([.95047,1,1.08883]);x=z@np.linalg.inv(np.array([[.4124564,.2126729,.0193339],[.3575761,.7151522,.119192],[.1804375,.0721750,.9503041]]));x=np.clip(x,0,1);return np.rint(np.where(x<=.0031308,12.92*x,1.055*x**(1/2.4)-.055)*255).clip(0,255).astype('uint8')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def record(p):return {'path':str(p),'sha256':sha(p)}
all=[]
for scene,colors in regions.items():
 shop,key=scene.split('_',1);e=reg[shop][key];p=Path(e['path']);a=np.array(Image.open(p).convert('RGB'));h,w=a.shape[:2];L=tolab(a.astype(float));out=a.copy();maskall=np.zeros((h,w),np.uint8);details=[];refs=[];dest=O/scene;dest.mkdir(parents=True,exist_ok=True)
 for color,polys in colors.items():
  m=Image.new('L',(w,h));d=ImageDraw.Draw(m)
  for poly in polys:d.polygon(poly,fill=255)
  interior=np.asarray(m)>0
  # Exclude non-ceramic pixels at boundaries using color discrimination, filling enclosed reflections.
  if color=='blue': ceramic=(L[:,:,2]<-4) & (a[:,:,2].astype(int)>a[:,:,0].astype(int)+5)
  else: ceramic=(L[:,:,2]>12) & (L[:,:,1]<4) & (a[:,:,1].astype(int)>a[:,:,2].astype(int)+18)
  if scene=='A_empty' and color=='green':
   ceramic &= (a[:,:,1].astype(int)>a[:,:,0].astype(int)+5)
   interior &= ceramic
  elif scene=='A_hero' and color=='blue':
   yy,xx=np.indices((h,w)); interior &= ceramic | ((xx>=423)&(yy<408))
  elif scene=='A_underside' and color=='blue':
   yy,xx=np.indices((h,w)); interior &= ceramic | (yy>=360)
  elif scene=='A_underside' and color=='green':
   yy,xx=np.indices((h,w)); interior &= ceramic & (a[:,:,1].astype(int)>a[:,:,0].astype(int)+5) & ((yy<680)|(xx>np.minimum(656,600+(yy-680)*.75)))
  # Remaining traced silhouettes are restricted to bowl exteriors.
  interior=ndi.binary_fill_holes(ndi.binary_closing(interior,iterations=2)) & (np.asarray(m)>0)
  distance=ndi.distance_transform_edt(interior);alpha=np.clip((distance-1)/2,0,1);mask=np.rint(alpha*255).astype('uint8');maskall=np.maximum(maskall,mask)
  rr=[x for x in report['rows'] if x['scene']==scene and x['color']==color and 'sample'in x];ref=report['references']['side_'+color];s=rr[0]['sample']['lab_median'] if rr else ([50,-5,-20] if color=='blue' else [50,-12,38]);v=ref['lab_median']
  deltaL=min(15,max(7,(v[0]-s[0])*.45));da=float(np.clip((v[1]-s[1])*.8,-22,22));db=float(np.clip((v[2]-s[2])*.8,-22,22)); tone=np.clip((95-L[:,:,0])/35,0,1);tmp=L.copy();tmp[:,:,0]+=deltaL*alpha*tone;tmp[:,:,1]+=da*alpha*tone;tmp[:,:,2]+=db*alpha*tone;rgb=torgb(tmp);out[mask>0]=rgb[mask>0];Image.fromarray(mask).save(dest/f'{color}_mask.png');details.append({'color':color,'polygon_source_pixels':polys,'delta_L':round(deltaL,2),'delta_a':round(da,2),'delta_b':round(db,2),'highlight_taper':'clamp((95-L)/35,0,1)','edge_feather_px':2,'sample_lab':s,'reference_lab':v});refs.append(record(ref['path']))
 maskpath=dest/'mask.png';output=dest/'candidate.png';Image.fromarray(maskall).save(maskpath);Image.fromarray(out).save(output);overlay=Image.composite(Image.blend(Image.fromarray(a),Image.new('RGB',(w,h),(255,0,255)),.5),Image.fromarray(a),Image.fromarray(maskall));overlay.save(dest/'overlay.png');before=Image.new('RGB',(w*2,h));before.paste(Image.fromarray(a),(0,0));before.paste(Image.fromarray(out),(w,0));before.save(dest/'before_after.png');changed=np.any(a!=out,2);outside=int((changed&(maskall==0)).sum());gens=[e['generation_result']]+e.get('additional_generation_results',[])
 obj={'status':'pending_root_visual_review','source_original':record(p),'mask':record(maskpath),'output':record(output),'additional_sources':refs,'generation_results':gens,'generation_result_hashes':[record(g) for g in gens],'color_parameters':{'space':'CIELAB D65','method':'Reference-driven bounded Lab offsets, retain light/shadow structure, highlights tapered, inward feather, sRGB gamut clipping','details':details},'outside_mask_exact':outside==0,'outside_changed_pixels':outside}
 if e.get('composition_provenance'):obj['upstream_composition_provenance']=record(e['composition_provenance'])
 (dest/'composition.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2));all.append({'scene':scene,'output':str(output),'outside_changed_pixels':outside})
print(json.dumps(all,ensure_ascii=False,indent=2))
