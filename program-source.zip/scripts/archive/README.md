# 旧主图入口归档与迁移

商品主图统一入口为 `python3 -m fission`。这里保留 54 个原脚本；归档入口仅由统一调度器进入，直接运行会打印迁移命令。主图规则见 `../../docs/商品主图制作规则.md`。

生成适配器保留原参数、模型和审查条件，仅调整项目根路径；新增生成经过公共缓存和运行台账。旧导出中的 ComfyUI 图像节点提交已退出执行路径，使用 CPU 导出/排版读取已核验源图。

## 参数迁移

- `RUN` 是已有生成目录，含 `submission.json`、`history.json` 和下载图。`NODE` 为该目录中输出节点编号。`NEW.png` 使用新的目标路径。
- `CONFIG` 沿用 reference/generated_mask/output_width 字段，由 CPU 执行遮罩合成和缩放。无合成时省略。
- 近景重排：`python3 -m fission export --mode recrop -- --source RUN --crop X Y W H --version NEW`。
- 多店交付：`python3 -m fission export --mode publish -- --plan PLAN --selected SELECTED --output DEST`；末尾加 `--publish` 才安装已核验包。
- 店铺文案排版：`python3 -m fission layout --mode shop-hero -- --image IMAGE --copy COPY --out NEW.png [原样式参数]`。
- 表中 CPU 迁移使用统一的源图/配置接口；不接受旧导出脚本的 `--run`/`--resume`。纯 CPU 历史审查、修补、收尾功能可用表内 --legacy 入口调用；其历史默认路径保留，调用前应核对原参数。

## 旧脚本 → 新子命令

| 旧脚本 | 新入口 | 说明 |
| --- | --- | --- |
| `audit_multishop_delivery.py` | `python3 -m fission export --legacy audit_multishop_delivery -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `auto_shop_reference.py` | `python3 -m fission multishop --legacy auto_shop_reference -- [原参数]` | 原生成/准备参数保持 |
| `batch_shop_hero.py` | `python3 -m fission multishop --legacy batch_shop_hero -- [原参数]` | 原生成/准备参数保持 |
| `build_multishop_final_color_reports.py` | `python3 -m fission export --legacy build_multishop_final_color_reports -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `compose_multishop_A_food.py` | `python3 -m fission layout --legacy compose_multishop_A_food -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `compose_multishop_B_food.py` | `python3 -m fission layout --legacy compose_multishop_B_food -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `finalize_hd_delivery.py` | `python3 -m fission export --legacy finalize_hd_delivery -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `finalize_multishop_delivery.py` | `python3 -m fission export --legacy finalize_multishop_delivery -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `multishop_A_hero_color_v3.py` | `python3 -m fission layout --legacy multishop_A_hero_color_v3 -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `multishop_B_hero_color_v4.py` | `python3 -m fission layout --legacy multishop_B_hero_color_v4 -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `multishop_B_hero_color_v5.py` | `python3 -m fission layout --legacy multishop_B_hero_color_v5 -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `multishop_b_food_orange_v3.py` | `python3 -m fission multishop --legacy multishop_b_food_orange_v3 -- [原参数]` | 原生成/准备参数保持 |
| `multishop_b_underside_color_v1.py` | `python3 -m fission layout --legacy multishop_b_underside_color_v1 -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `multishop_b_underside_color_v2.py` | `python3 -m fission layout --legacy multishop_b_underside_color_v2 -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `multishop_blue_green_bc_v2.py` | `python3 -m fission multishop --legacy multishop_blue_green_bc_v2 -- [原参数]` | 原生成/准备参数保持 |
| `multishop_blue_green_candidates_v1.py` | `python3 -m fission multishop --legacy multishop_blue_green_candidates_v1 -- [原参数]` | 原生成/准备参数保持 |
| `multishop_color_audit_v1.py` | `python3 -m fission export --legacy multishop_color_audit_v1 -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `multishop_color_composition_records_v1.py` | `python3 -m fission layout --legacy multishop_color_composition_records_v1 -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `multishop_first5_color_v2.py` | `python3 -m fission layout --legacy multishop_first5_color_v2 -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `multishop_other4_color_v3.py` | `python3 -m fission layout --legacy multishop_other4_color_v3 -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `prepare_hd_detail_exports.py` | `python3 -m fission export --legacy prepare_hd_detail_exports -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `prepare_hd_detail_jobs.py` | `python3 -m fission master --legacy prepare_hd_detail_jobs -- [原参数]` | 原生成/准备参数保持 |
| `prepare_hd_main_exports.py` | `python3 -m fission export --legacy prepare_hd_main_exports -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `prepare_hd_main_jobs.py` | `python3 -m fission master --legacy prepare_hd_main_jobs -- [原参数]` | 原生成/准备参数保持 |
| `prepare_multishop_B_empty_fix.py` | `python3 -m fission multishop --legacy prepare_multishop_B_empty_fix -- [原参数]` | 原生成/准备参数保持 |
| `prepare_multishop_C_under_refine.py` | `python3 -m fission multishop --legacy prepare_multishop_C_under_refine -- [原参数]` | 原生成/准备参数保持 |
| `prepare_multishop_exports.py` | `python3 -m fission export --legacy prepare_multishop_exports -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `prepare_multishop_extra_scenes.py` | `python3 -m fission scene --legacy prepare_multishop_extra_scenes -- [原参数]` | 原生成/准备参数保持 |
| `prepare_multishop_flatlays.py` | `python3 -m fission scene --legacy prepare_multishop_flatlays -- [原参数]` | 原生成/准备参数保持 |
| `prepare_multishop_food_fix.py` | `python3 -m fission multishop --legacy prepare_multishop_food_fix -- [原参数]` | 原生成/准备参数保持 |
| `prepare_multishop_hero_v2.py` | `python3 -m fission multishop --legacy prepare_multishop_hero_v2 -- [原参数]` | 原生成/准备参数保持 |
| `prepare_multishop_scenes.py` | `python3 -m fission scene --legacy prepare_multishop_scenes -- [原参数]` | 原生成/准备参数保持 |
| `prepare_replica_d05_d21.py` | `python3 -m fission multishop --legacy prepare_replica_d05_d21 -- [原参数]` | 原生成/准备参数保持 |
| `prepare_replica_d20_dimensions.py` | `python3 -m fission layout --legacy prepare_replica_d20_dimensions -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `prepare_scene_v7_A.py` | `python3 -m fission scene --legacy prepare_scene_v7_A -- [原参数]` | 原生成/准备参数保持 |
| `prepare_scene_v7_inputs.py` | `python3 -m fission scene --legacy prepare_scene_v7_inputs -- [原参数]` | 原生成/准备参数保持 |
| `register_multishop_reviews.py` | `python3 -m fission export --legacy register_multishop_reviews -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `render_multishop_layouts.py` | `python3 -m fission layout --legacy render_multishop_layouts -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `render_replica_dimensions.py` | `python3 -m fission layout --legacy render_replica_dimensions -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `render_shop_hero.py` | `python3 -m fission layout --legacy render_shop_hero -- [原参数]` | 纯 CPU 适配器；原参数保持，自动写运行台账 |
| `run_food_assets.py` | `python3 -m fission food --legacy run_food_assets -- [原参数]` | 原生成/准备参数保持 |
| `run_hd_replica_export.py` | `python3 -m fission export --source-run RUN --node NODE --output NEW.png [--config CONFIG]` | 历史 Comfy 导出迁移为 CPU 复用 |
| `run_multishop_export.py` | `python3 -m fission export --source-run RUN --node NODE --output NEW.png [--config CONFIG]` | 历史 Comfy 导出迁移为 CPU 复用 |
| `run_multishop_export_batch.py` | `python3 -m fission export --source-run RUN --node NODE --output NEW.png [--config CONFIG]` | 历史 Comfy 导出迁移为 CPU 复用 |
| `run_multishop_generation.py` | `python3 -m fission multishop --legacy run_multishop_generation -- [原参数]` | 原生成/准备参数保持 |
| `run_replica_composite.py` | `python3 -m fission export --source-run RUN --node NODE --output NEW.png [--config CONFIG]` | 历史 Comfy 导出迁移为 CPU 复用 |
| `run_replica_d20_composite.py` | `python3 -m fission export --source-run RUN --node NODE --output NEW.png [--config CONFIG]` | 历史 Comfy 导出迁移为 CPU 复用 |
| `run_scene_v7_background.py` | `python3 -m fission scene --legacy run_scene_v7_background -- [原参数]` | 原生成/准备参数保持 |
| `run_scene_v7_background_02.py` | `python3 -m fission scene --legacy run_scene_v7_background_02 -- [原参数]` | 原生成/准备参数保持 |
| `run_taobao_reference_edit.py` | `python3 -m fission multishop --legacy run_taobao_reference_edit -- [原参数]` | 原生成/准备参数保持 |
| `run_taobao_reference_refine.py` | `python3 -m fission multishop --legacy run_taobao_reference_refine -- [原参数]` | 原生成/准备参数保持 |
| `run_taobao_replica.py` | `python3 -m fission multishop --legacy run_taobao_replica -- [原参数]` | 原生成/准备参数保持 |
| `run_whole_photo_fill.py` | `python3 -m fission food --legacy run_whole_photo_fill -- [原参数]` | 原生成/准备参数保持 |
| `shop_hero_history.py` | `python3 -m fission multishop --legacy shop_hero_history -- [原参数]` | 原生成/准备参数保持 |

## 公共函数迁移

- `build_multishop_final_color_reports.lab` → `fission.color.lab`。
- `run_taobao_reference_edit.graph` → `fission.graphs.graph`，模型常量保持原值。
- `render_shop_hero` 的纯 CPU 渲染实现 → `fission.layout_shop_hero`。
- `scripts/comfy_client.py`、`scripts/build_workflows.py` 及其他公共库保留原位。
- `fission/legacy_map.json` 保存整理前 SHA-256、归档路径和完整命令映射。

根目录 Python 脚本数：106 → 52。
