"""Build a product-position reference using photographed, transparent SKU assets."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission multishop --legacy auto_shop_reference -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]


from dataclasses import dataclass
from hashlib import sha256
from io import BytesIO
from pathlib import Path

from PIL import Image, ImageOps

SIDE = 1024
# (horizontal center, baseline, width), relative to the photographic frame.
CLOSE = ((0.58, 0.79, 0.72),)
PAIR = ((0.71, 0.57, 0.33), (0.30, 0.81, 0.53))
THREE = ((0.24, 0.48, 0.30), (0.69, 0.53, 0.34), (0.53, 0.82, 0.48))
HERO_PAIR = ((0.23, 0.60, 0.30), (0.69, 0.80, 0.55))
HELD = ((0.50, 0.70, 0.92),)
TABLE_SHOTS = {
    "oblique": (CLOSE, PAIR, THREE),
    "front": (
        ((0.36, 0.74, 0.62),),
        ((0.28, 0.69, 0.43), (0.75, 0.70, 0.41)),
        ((0.16, 0.68, 0.28), (0.50, 0.70, 0.35), (0.84, 0.68, 0.26)),
    ),
    "side": (
        ((0.58, 0.68, 0.63),),
        ((0.22, 0.58, 0.30), (0.67, 0.82, 0.57)),
        ((0.17, 0.48, 0.25), (0.46, 0.62, 0.31), (0.78, 0.81, 0.39)),
    ),
    "overhead": (
        ((0.39, 0.82, 0.70),),
        ((0.30, 0.50, 0.40), (0.69, 0.82, 0.40)),
        ((0.48, 0.40, 0.31), (0.23, 0.79, 0.40), (0.76, 0.78, 0.38)),
    ),
}
ROLE_NAMES = {"single", "empty", "food", "held", "action", "stack"}
VIEW_NAMES = {"oblique", "front", "side", "overhead"}


@dataclass(frozen=True)
class Source:
    path: Path
    role: str
    view: str
    description: str


def _sources(paths, metadata):
    if metadata is not None and len(paths) != len(metadata):
        raise ValueError("Every product image needs its own metadata entry.")
    result = []
    for i, path in enumerate(paths):
        item = metadata[i] if metadata is not None else {}
        item = item if isinstance(item, dict) else {}
        role, view = item.get("role", "single"), item.get("view", "oblique")
        if role not in ROLE_NAMES or view not in VIEW_NAMES:
            raise ValueError(
                f"Unknown photographic role/view for {path}: {role} / {view}"
            )
        description = str(item.get("description", Path(path).stem)).strip()
        result.append(Source(Path(path), role, view, description))
    if not result:
        raise ValueError("At least one transparent product photograph is required.")
    return result


def _plans(sources):
    """Only advertise arrangements supported by actual product views. Never clone a grip."""
    plans = []
    for view in sorted({s.view for s in sources}):
        same_view = [s for s in sources if s.view == view]
        table = [s for s in same_view if s.role in {"single", "empty", "food"}]
        food = [s for s in table if s.role == "food"]
        empty = [s for s in table if s.role != "food"]
        if table:
            palette = (empty or table) * 3
            one, two, three = TABLE_SHOTS[view]
            plans.append((f"{view}_single_close", one, [(food or table)[0]]))
            plans.append(
                (f"{view}_pair_display", two, [palette[0], (food or palette[1:])[0]])
            )
            plans.append(
                (
                    f"{view}_three_separate",
                    three,
                    [palette[0], palette[1], (food or palette[2:])[0]],
                )
            )
        for role in ("held", "action", "stack"):
            matching = [s for s in same_view if s.role == role]
            if not matching:
                continue
            first = matching[0]
            pose = {
                "held": HELD,
                "action": ((0.40, 0.79, 0.76),),
                "stack": ((0.36, 0.82, 0.55),),
            }[role]
            plans.append((f"{view}_{role}", pose, [first]))
            if role == "stack" and table:
                plans.append(
                    (
                        f"{view}_stack_with_serving",
                        HERO_PAIR,
                        [first, (food or table)[0]],
                    )
                )
    return plans


def build(paths, index, metadata=None):
    sources = _sources(paths, metadata)
    plans = _plans(sources)
    if not 0 <= index < len(plans):
        raise ValueError(
            f"现有实拍可自动生成 {len(plans)} 种摆法，本次需要第 {index + 1} 种。"
            "请补入另一实拍视角、真实端持/使用动作、叠放实拍或独立构图参考。"
        )
    name, slots, selected = plans[index]
    canvas = Image.new("RGBA", (SIDE, SIDE), (238, 240, 240, 255))
    boxes, notes = [], []
    for i, ((center, baseline, width), source) in enumerate(zip(slots, selected)):
        with Image.open(source.path) as original:
            cutout = ImageOps.exif_transpose(original).convert("RGBA")
        alpha = cutout.getchannel("A")
        tight = alpha.getbbox()
        if not tight or alpha.getextrema()[0] == 255:
            raise ValueError(
                f"Expected a transparent cutout of the actual product: {source.path}"
            )
        cutout = cutout.crop(tight)
        max_height = baseline if source.role in ("held", "action") else baseline - 0.04
        scale = min(width * SIDE / cutout.width, max_height * SIDE / cutout.height)
        size = (
            max(1, round(cutout.width * scale)),
            max(1, round(cutout.height * scale)),
        )
        x = round(center * SIDE - size[0] / 2)
        y = 0 if source.role in ("held", "action") else round(baseline * SIDE - size[1])
        canvas.alpha_composite(cutout.resize(size, Image.Resampling.LANCZOS), (x, y))
        bounds = [round(v / SIDE, 4) for v in (x, y, x + size[0], y + size[1])]
        boxes.append(bounds)
        notes.append(
            f"Group {i + 1} shows {source.description} ({source.role}, "
            f"photographed {source.view} view), centered at x={center:.2f}, "
            f"foot/lower edge y={bounds[3]:.2f}, width={size[0] / SIDE:.2f} of the frame."
        )
    encoded = BytesIO()
    canvas.convert("RGB").save(encoded, format="PNG")
    data = encoded.getvalue()
    return {
        "name": name,
        "bytes": data,
        "sha256": sha256(data).hexdigest(),
        "bounds": boxes,
        "count": len(slots),
        "capacity": len(plans),
        "sources": [str(s.path) for s in selected],
        "view": selected[0].view,
        "stacking": "实拍叠放组"
        if any(s.role == "stack" for s in selected)
        else "无堆叠",
        "placement_text": " ".join(notes),
    }
