
# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission layout --legacy multishop_b_underside_color_v1 -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

from PIL import Image, ImageDraw, ImageFilter
import numpy as np, colorsys, json, hashlib
from pathlib import Path
base=Path('/Users/luohuiwu/codex/ComfyProductPipeline')
src=base/'work/diagnostics/multishop_20261103/B_underside_true_stamp/B_underside_true_stamp.png'
ref=base/'work/diagnostics/multishop_20261103/scene_inputs/green_underside_identity.png'
out=base/'work/diagnostics/multishop_20261103/B_underside_color_v1'
out.mkdir(exist_ok=True,parents=True)
a=np.asarray(Image.open(src).convert('RGB')); h,w=a.shape[:2]
# Conservative inner outline: excludes hand, surrounding scene, and subpixel edge.
pts=[(200,340),(205,328),(225,306),(239,294),(253,291),(278,296),(314,306),(351,299),(382,295),(402,297),(402,306),(395,319),(391,337),(398,359),(411,369),(431,370),(451,359),(466,345),(485,335),(506,340),(525,351),(548,367),(574,382),(600,390),(622,395),(637,408),(649,427),(650,446),(643,466),(631,489),(617,510),(609,530),(605,560),(598,594),(588,627),(573,662),(555,693),(531,719),(505,740),(475,756),(447,767),(416,773),(383,775),(353,772),(322,763),(295,750),(269,732),(245,709),(225,682),(208,651),(194,619),(185,586),(180,551),(179,518),(181,485),(187,452),(196,426),(204,407),(207,392),(202,375),(197,355)]
m=Image.new('L',(w,h));ImageDraw.Draw(m).polygon(pts,fill=255)
# An inward-only soft edge never expands beyond the conservative outline.
blur=m.filter(ImageFilter.GaussianBlur(2)); mask=np.minimum(np.asarray(m),np.asarray(blur)).astype(np.uint8)
# Convert to HSV and boost saturation while preserving luminance and highlights.
rgb=a.astype(np.float32)/255.; mx=rgb.max(2); mn=rgb.min(2); delta=mx-mn
# RGB green is increased relative to blue, red mildly increased; chroma-weighted blend preserves neutral reflections.
chroma=np.clip((delta-.035)/.24,0,1); lum=np.clip((mx-.12)/.2,0,1)*np.clip((1.01-mx)/.18,0,1)
strength=(mask/255.)*chroma*lum
# Color adjustment targets brighter yellow-green reference while holding source shading.
adj=np.empty_like(rgb); adj[:,:,0]=np.clip(rgb[:,:,0]*1.045+0.025,0,1);adj[:,:,1]=np.clip(rgb[:,:,1]*1.16+0.015,0,1);adj[:,:,2]=np.clip(rgb[:,:,2]*0.72,0,1)
res=np.rint((rgb*(1-strength[:,:,None])+adj*strength[:,:,None])*255).clip(0,255).astype('uint8')
Image.fromarray(mask).save(out/'bowl_mask.png');Image.fromarray(res).save(out/'B_underside_color.png')
vis=Image.fromarray(a.copy()); overlay=Image.new('RGB',(w,h),(255,0,255)); vis=Image.composite(Image.blend(vis,overlay,.45),vis,Image.fromarray(mask));vis.save(out/'mask_overlay.png')
thumb=Image.new('RGB',(1536,1024));thumb.paste(Image.fromarray(a),(0,0));thumb.paste(Image.fromarray(res),(768,0));thumb.save(out/'before_after.png')
sha=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
changed=np.any(a!=res,2); outside=mask==0
meta={'status':'pending_root_visual_review','source':str(src),'source_sha256':sha(src),'reference':str(ref),'reference_sha256':sha(ref),'mask':str(out/'bowl_mask.png'),'mask_sha256':sha(out/'bowl_mask.png'),'output':str(out/'B_underside_color.png'),'output_sha256':sha(out/'B_underside_color.png'),'parameters':{'method':'RGB channel affine, chroma and luminance weighted, inward soft mask','red':[1.045,0.025],'green':[1.16,0.015],'blue':[0.72,0],'edge_blur_px':2,'polygon':pts},'pixels_changed':int(changed.sum()),'pixels_changed_outside_mask':int((changed&outside).sum()),'scope':'hand/background/spoon excluded by conservative polygon; root visual confirmation required'}
(out/'provenance.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
print(json.dumps(meta,ensure_ascii=False,indent=2))
