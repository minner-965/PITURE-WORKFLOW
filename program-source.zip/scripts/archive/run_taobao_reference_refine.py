#!/usr/bin/env python3
"""FLUX.2 Klein two-reference low-strength img2img experiment; no blind retries."""

# Archived entry: execution is dispatched exclusively by python3 -m fission.
import os as _archive_os
import sys as _archive_sys
from pathlib import Path as _ArchivePath
if _archive_os.environ.get("FISSION_ENTRYPOINT") != "1":
    raise SystemExit("Archived entry; use: python3 -m fission multishop --legacy run_taobao_reference_refine -- [原参数]")
_archive_root = _ArchivePath(__file__).resolve().parents[2]
_archive_sys.path[:0] = [str(_archive_root), str(_archive_root / "scripts"), str(_archive_root / "scripts/archive")]

import argparse,copy,hashlib,json,re,subprocess,time
from pathlib import Path
from PIL import Image
from build_workflows import ROOT,node,check_graph,ui
from comfy_client import ComfyClient,sync_ui

WF=ROOT/'workflows/taobao_replica/klein_refine_draft'
LOGS=ROOT/'work/diagnostics/taobao_replica_20261103/klein_refine_runs'
MODEL_SPECS={'unet':('UnetLoaderGGUF','unet_name','flux-2-klein-4b-Q5_K_M.gguf',Path('/Users/luohuiwu/ComfyUI-Shared/models/unet/flux-2-klein-4b-Q5_K_M.gguf'),'58c01c75fee2272eadb127f53e26dd05a5a8e7f812e37c36fa44603301f91e54'),'clip':('CLIPLoaderGGUF','clip_name','Qwen3-4B-Q4_K_M.gguf',Path('/Users/luohuiwu/ComfyUI-Shared/models/text_encoders/Qwen3-4B-Q4_K_M.gguf'),'f6f851777709861056efcdad3af01da38b31223a3ba26e61a4f8bf3a2195813a'),'vae':('VAELoader','vae_name','flux2-vae.safetensors',Path('/Users/luohuiwu/ComfyUI-Shared/models/vae/flux2-vae.safetensors'),'868fe7b343cc8f3a19dbcfcafbc3d5f888802be3f89bd81b65b3621a066ce8f3')}
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
 return h.hexdigest()
def save(p,x):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def graph(c,rev):
 n=node;return {
 '1':n('LoadImage','REFERENCE_1_LAYOUT',image='PENDING_UPLOAD_REF1.png'),'2':n('LoadImage','REFERENCE_2_PRODUCT',image='PENDING_UPLOAD_REF2.png'),
 '3':n('UnetLoaderGGUF','KLEIN_4B_Q5',unet_name=MODEL_SPECS['unet'][2]),'4':n('CLIPLoaderGGUF','QWEN3_4B_Q4',clip_name=MODEL_SPECS['clip'][2],type='flux2'),'5':n('VAELoader','FLUX2_VAE',vae_name=MODEL_SPECS['vae'][2]),
 '6':n('ImageScale','SCALE_REF1',image=['1',0],upscale_method='lanczos',width=c['width'],height=c['height'],crop='disabled'),'7':n('ImageScale','SCALE_REF2',image=['2',0],upscale_method='lanczos',width=c['reference_size'],height=c['reference_size'],crop='disabled'),
 '8':n('CLIPTextEncode','POSITIVE',clip=['4',0],text=c['prompt']),'9':n('ConditioningZeroOut','NEGATIVE',conditioning=['8',0]),'10':n('VAEEncode','ENCODE_REF1',pixels=['6',0],vae=['5',0]),'11':n('VAEEncode','ENCODE_REF2',pixels=['7',0],vae=['5',0]),
 '12':n('ReferenceLatent','POS_REF1',conditioning=['8',0],latent=['10',0]),'13':n('ReferenceLatent','NEG_REF1',conditioning=['9',0],latent=['10',0]),'14':n('ReferenceLatent','POS_REF2',conditioning=['12',0],latent=['11',0]),'15':n('ReferenceLatent','NEG_REF2',conditioning=['13',0],latent=['11',0]),
 '16':n('CFGGuider','GUIDER',model=['3',0],positive=['14',0],negative=['15',0],cfg=1.0),'18':n('Flux2Scheduler','SCHEDULER',steps=4,width=c['width'],height=c['height']),
 '19':n('RandomNoise','SEED',noise_seed=c['seed']),'20':n('KSamplerSelect','SAMPLER',sampler_name='euler'),'21':n('SamplerCustomAdvanced','SAMPLE',noise=['19',0],guider=['16',0],sampler=['20',0],sigmas=['24',1],latent_image=['10',0]),'22':n('VAEDecode','DECODE',samples=['21',0],vae=['5',0]),'23':n('SaveImage','SAVE',images=['22',0],filename_prefix=f'ComfyProductPipeline/taobao_klein_refine/{c["job_id"]}/{rev}'), '24':n('SplitSigmas','START_STEP',sigmas=['18',0],step=c['start_step'])}
def validated_config(p):
 c=json.loads(p.read_text())
 c.setdefault('width',512);c.setdefault('height',512);c.setdefault('reference_size',512);c.setdefault('start_step',2)
 if isinstance(c['start_step'],bool) or not isinstance(c['start_step'],int) or c['start_step'] not in (1,2,3):raise ValueError('start_step must be 1, 2 or 3')
 for key in ('width','height'):
  if isinstance(c[key],bool) or not isinstance(c[key],int) or not 64<=c[key]<=1536 or c[key]%16:raise ValueError(key+' must be a multiple of 16 in 64..1536')
 if c['width']*c['height']>1100000:raise ValueError('Output exceeds 1,100,000 pixels')
 if isinstance(c['reference_size'],bool) or not isinstance(c['reference_size'],int) or c['reference_size'] not in (512,768,1024):raise ValueError('reference_size must be one of 512, 768, 1024')
 for k in ('job_id','reference1','reference2','reference1_source','reference2_source','prompt','seed'):
  if k not in c:raise ValueError('Missing '+k)
 if not re.fullmatch(r'[A-Za-z0-9_-]+',c['job_id']):raise ValueError('Invalid job_id')
 if not isinstance(c['prompt'],str) or not c['prompt'].strip():raise ValueError('Empty prompt')
 if isinstance(c['seed'],bool) or not isinstance(c['seed'],int) or not 0<=c['seed']<2**64:raise ValueError('Invalid seed')
 for k in ('reference1','reference2','reference1_source','reference2_source'):
  q=Path(c[k]);
  if not q.is_absolute() or not q.is_file():raise ValueError(k+' must be an absolute existing file')
 with Image.open(c['reference1']) as im:
  if im.width*c['height']!=im.height*c['width']:raise ValueError('reference1 aspect ratio must match output; prepare crop or pad without stretching')
 with Image.open(c['reference2']) as im:
  if im.width!=im.height:raise ValueError('reference2 must be pre-cropped square; avoid stretching')
 for q in c.get('evidence_files',[]):
  if not Path(q).is_absolute() or not Path(q).is_file():raise ValueError('evidence file missing: '+q)
 return c

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--job-config',required=True);m=ap.add_mutually_exclusive_group(required=True);m.add_argument('--prepare',action='store_true');m.add_argument('--run',action='store_true');m.add_argument('--resume',action='store_true');a=ap.parse_args();p=Path(a.job_config)
 if not p.is_absolute() or not p.is_file():raise ValueError('job-config must be an existing absolute file')
 c=validated_config(p);files={k:{'path':c[k],'sha256':sha(c[k])} for k in ('reference1','reference2','reference1_source','reference2_source')};evidence=[{'path':x,'sha256':sha(x)} for x in c.get('evidence_files',[])];models={k:{'filename':v[2],'path':str(v[3]),'expected_sha256':v[4]} for k,v in MODEL_SPECS.items()};identity={'job_id':c['job_id'],'inputs':files,'evidence_files':evidence,'prompt':c['prompt'],'prompt_sha256':hashlib.sha256(c['prompt'].encode()).hexdigest(),'seed':c['seed'],'settings':{'width':c['width'],'height':c['height'],'reference_size':c['reference_size'],'reference1_scaled_size':[c['width'],c['height']],'reference2_scaled_size':[c['reference_size'],c['reference_size']],'steps':4,'init_from_reference':True,'start_step':c['start_step'],'effective_steps':4-c['start_step'],'cfg':1.0,'sampler':'euler'},'models':models,'runner_sha256':sha(__file__),'status':'test_pending_visual_review','reference_limitation':'Output is a reconstruction; reference resolution and preparation must be assessed from its provenance.'};rev=hashlib.sha256(json.dumps(identity,sort_keys=True,ensure_ascii=False).encode()).hexdigest()[:24];log=LOGS/c['job_id']/rev;workflow=WF/c['job_id']/rev;log.mkdir(parents=True,exist_ok=True);workflow.mkdir(parents=True,exist_ok=True);client=ComfyClient();info=client.get('/object_info');g=graph(c,rev)
 # Only during prepare, allow the three selected model names in a metadata copy; record missing options explicitly.
 schema=copy.deepcopy(info);missing=[]
 for role,(name,key,filename,path,expected) in MODEL_SPECS.items():
  spec=schema[name]['input']['required'][key];opts=spec[0] if isinstance(spec[0],list) else spec[1]['options']
  if filename not in opts:
   missing.append(filename)
   if a.prepare:opts.append(filename)
 if missing and not a.prepare:raise ValueError('Model choices not present in live backend: '+', '.join(missing))
 checks=check_graph(g,schema);visual=sync_ui(g,ui(g,schema,'Klein 4B 参考图低强度试验','参考1既是初始化图也是构图参考；参考2为真实碗形；整个图像参与图生图，结果待 root 视觉审核。'),schema);save(log/'identity.json',identity);save(log/'job_config.json',c);save(log/'schema_checks.json',{'checks':checks,'model_options_missing':missing,'note':'prepare may bypass missing filenames in a local metadata copy only; no runtime validation'});save(workflow/'prepared.api.json',g);save(workflow/'prepared.ui.json',visual);print('prepared',log,'missing_model_choices',missing,flush=True)
 if a.prepare:return
 review=c.get('root_input_review',{})
 if review.get('status')!='approved' or review.get('reviewer')!='root' or review.get('prompt_sha256')!=identity['prompt_sha256'] or review.get('reference1_sha256')!=files['reference1']['sha256'] or review.get('reference2_sha256')!=files['reference2']['sha256']:raise ValueError('Root review must match prompt and both reference hashes')
 for role,(_,_,filename,path,expected) in MODEL_SPECS.items():
  if not path.is_file() or sha(path)!=expected:raise ValueError(f'Model {role} missing or hash mismatch: {path}')
 sub=log/'submission.json';result=log/'result.json'
 if result.exists():
  r=json.loads(result.read_text())
  if r['identity']!=identity or any(not Path(v['path']).is_file() or sha(v['path'])!=v['sha256'] for v in r['outputs'].values()):raise ValueError('Existing result mismatch')
  print('already complete',result);return
 if a.resume:
  if not sub.exists():raise ValueError('No existing submission')
  record=json.loads(sub.read_text());g=record['request']['prompt'];visual=record['request']['extra_data']['extra_pnginfo']['workflow'];pid=client.reconcile(sub)
 else:
  if sub.exists():raise RuntimeError('Existing submission; use --resume, never blindly resubmit')
  q=client.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('Queue occupied; no submission')
  for id,key in [('1','reference1'),('2','reference2')]:g[id]['inputs']['image']=client.upload(c[key])
  check_graph(g,info);visual=sync_ui(g,visual,info);save(log/'actual.api.json',g);save(log/'actual.ui.json',visual);save(workflow/'actual.api.json',g);save(workflow/'actual.ui.json',visual);pid=client.submit(g,visual,sub)
 print('submitted_or_resumed',pid,flush=True)
 try:
  backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());history,measure=client.wait(pid,log,backend,7200);files_out=client.download(history,log/'downloads')
  if len(files_out.get('23',[]))!=1:raise ValueError('Expected one output')
  im=Path(files_out['23'][0]);
  with Image.open(im) as x:
   if x.size!=(c['width'],c['height']):raise ValueError('Unexpected output size')
  measure['seconds_per_iteration']=measure['wall_seconds']/(4-c['start_step']);save(log/'measurements.json',measure);save(result,{'status':'awaiting_root_visual_review','visual_pass':None,'prompt_id':pid,'identity':identity,'outputs':{'generated':{'path':str(im),'sha256':sha(im)}},'measurements':measure,'actual_api':str(log/'actual.api.json'),'actual_ui':str(log/'actual.ui.json')});print('completed',result,flush=True)
 except Exception as e:save(log/'failure.json',{'prompt_id':pid,'error':str(e),'time':time.time()});raise
if __name__=='__main__':main()
