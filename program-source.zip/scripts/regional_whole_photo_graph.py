#!/usr/bin/env python3
"""Build visible native ComfyUI regional conditioning, without submitting jobs.

Identity must include, in order, each region's mask SHA256, prompt SHA256 and
{x,y,width,height}, plus the whole source/base/paint/inverse/model/seed identity.
The caller uploads masks and binds returned names with bind_uploaded_masks().
"""
import argparse, hashlib, json
from pathlib import Path
import numpy as np
from PIL import Image
from build_workflows import ROOT,make_a,node,check_graph,ui


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def validate_regions(regions,paint_mask):
 if not isinstance(regions,list) or not 1<=len(regions)<=8:raise ValueError('One to eight regions are required')
 output=[];sizes=[];masks=[]
 for i,r in enumerate(regions):
  path=Path(r['mask_path'])
  if not path.is_absolute() or not path.is_file():raise ValueError(f'region {i+1}: mask must be an existing absolute path')
  mask=Image.open(path).convert('L')
  if mask.size!=(1024,1024):raise ValueError(f'region {i+1}: mask must be 1024×1024')
  pixels=np.asarray(mask);masks.append(pixels);ys,xs=np.nonzero(pixels)
  if not len(xs):raise ValueError(f'region {i+1}: empty mask')
  prompt=r.get('prompt')
  if not isinstance(prompt,str) or not prompt.strip():raise ValueError(f'region {i+1}: prompt missing')
  area=r['area']; keys=('x','y','width','height')
  if any(not isinstance(area.get(k),int) or isinstance(area[k],bool) or area[k]%8 for k in keys):raise ValueError(f'region {i+1}: coordinates and dimensions must be integer multiples of 8')
  x,y,w,h=(area[k] for k in keys)
  if x<0 or y<0 or w<64 or h<64 or x+w>1024 or y+h>1024:raise ValueError(f'region {i+1}: area outside canvas or smaller than 64')
  if xs.min()<x or xs.max()>=x+w or ys.min()<y or ys.max()>=y+h:raise ValueError(f'region {i+1}: area does not contain its entire mask')
  sizes.append((w,h));output.append({'index':i+1,'mask_path':str(path),'mask_sha256':sha(path),'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),'prompt':prompt,'area':{k:area[k] for k in keys},'mask_bounds':[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)],'area_margin_pixels':[int(xs.min()-x),int(ys.min()-y),int(x+w-1-xs.max()),int(y+h-1-ys.max())]})
 if len(set(sizes))!=len(sizes):raise ValueError('Every area must have a distinct width/height pair')
 total=Path(paint_mask)
 if not total.is_absolute() or not total.is_file():raise ValueError('paint_mask must be an existing absolute path')
 image=Image.open(total).convert('L')
 if image.size!=(1024,1024):raise ValueError('paint_mask must be 1024×1024')
 stack=np.stack(masks);overlap=int(np.count_nonzero(np.sum(stack>0,axis=0)>1))
 if overlap:raise ValueError(f'Region masks overlap at {overlap} pixels')
 mismatch=int(np.count_nonzero(np.max(stack,axis=0)!=np.asarray(image)))
 if mismatch:raise ValueError(f'Pixelwise maximum of region masks differs from total paint mask at {mismatch} pixels')
 return output

def build(regions,info,paint_mask):
 details=validate_regions(regions,paint_mask);g=make_a()
 # Keep node 7 solely as the original zeroed negative, and remove unused common guidance.
 for nid in ('8','17','18'):g.pop(nid)
 area_nodes=[];mask_nodes={}
 for i,(r,d) in enumerate(zip(regions,details)):
  start=100+i*5;mask_id=str(start);text_id=str(start+1);guidance_id=str(start+2);setmask_id=str(start+3);area_id=str(start+4);label=f'REGION_{i+1:02d}'
  g[mask_id]=node('LoadImageMask',label+'_MASK',image=f'ComfyProductPipeline/region_{i+1:02d}_mask.png',channel='red')
  g[text_id]=node('CLIPTextEncode',label+'_PROMPT',clip=['6',0],text=r['prompt'])
  g[guidance_id]=node('FluxGuidance',label+'_GUIDANCE',conditioning=[text_id,0],guidance=30.0)
  g[setmask_id]=node('ConditioningSetMask',label+'_SET_MASK',conditioning=[guidance_id,0],mask=[mask_id,0],strength=1.0,set_cond_area='default')
  g[area_id]=node('ConditioningSetArea',label+'_SET_AREA',conditioning=[setmask_id,0],**r['area'],strength=1.0)
  area_nodes.append(area_id);mask_nodes[str(i+1)]=mask_id
 combined=area_nodes[0]
 for i,area_id in enumerate(area_nodes[1:]):
  nid=str(200+i);g[nid]=node('ConditioningCombine',f'COMBINE_{i+1:02d}',conditioning_1=[combined,0],conditioning_2=[area_id,0]);combined=nid
 g['11']['inputs']['positive']=[combined,0]
 checks=check_graph(g,info);workflow=ui(g,info,'Regional whole-photo Q6 Fill','每只碗独立文本、mask与完整上下文范围；总paint蒙版负责重绘，inverse负责恢复。区域组合行为与画质须实测及审核。')
 # Keep the seven sets and the combine chain visible and navigable in the saved UI.
 for n in workflow['nodes']:
  nid=n['id']
  if 100<=nid<100+len(regions)*5:
   i=(nid-100)//5;col=(nid-100)%5;n['pos']=[col*440,1600+i*450]
  elif 200<=nid<=205:n['pos']=[2450+(nid-200)*350,2400]
 workflow['last_node_id']=max(n['id'] for n in workflow['nodes'])
 return g,workflow,details,checks,mask_nodes

def bind_uploaded_masks(graph,mask_nodes,uploaded):
 if set(uploaded)!=set(mask_nodes):raise ValueError('Upload mapping must cover every region index')
 for index,node_id in mask_nodes.items():
  name=uploaded[index]
  if not isinstance(name,str) or not name:raise ValueError('Invalid uploaded mask name: '+index)
  if graph[node_id]['class_type']!='LoadImageMask' or graph[node_id]['_meta']['title']!=f'REGION_{int(index):02d}_MASK':raise ValueError('Regional node identity mismatch')
  graph[node_id]['inputs']['image']=name
 return graph

def main():
 p=argparse.ArgumentParser();p.add_argument('--job-config',required=True);p.add_argument('--output-prefix',required=True);a=p.parse_args();cfg=json.loads(Path(a.job_config).read_text());info=json.loads((ROOT/'work/diagnostics/object_info.json').read_text());g,u,details,checks,mask_nodes=build(cfg['regions'],info,cfg['paint_mask']);out=Path(a.output_prefix)
 if not out.is_absolute():raise ValueError('output-prefix must be absolute')
 out.parent.mkdir(parents=True,exist_ok=True)
 for suffix,data in [('api.json',g),('ui.json',u),('regions.json',{'regions':details,'mask_nodes':mask_nodes,'schema_checks':checks,'identity_requirement':'include ordered mask_sha256, prompt_sha256 and area for each region in the whole-photo identity','batching_note':'same-shape compatible areas may be batched by the sampler based on memory; varying area shapes reduces but does not eliminate batching'})]:Path(str(out)+'.'+suffix).write_text(json.dumps(data,ensure_ascii=False,indent=2))
 print('prepared',out,flush=True)
if __name__=='__main__':main()
