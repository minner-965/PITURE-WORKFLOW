#!/usr/bin/env python3
"""Build traceable assets from five independent product photographs."""
import csv, json, shutil, sys
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from prepare_inputs import prepare, sha
from build_masks import masks
R=Path(__file__).resolve().parents[1]; P=R/'input/supplied_20261102/测试品/sku实拍'; O=R/'output/LISTING_V3/w1125/assets/empty_bowls'
# Hand-traced in each image's 1024px coordinates, reviewed as drafts.
DATA=[('red','红色','1105',[(340,550),(341,530),(350,513),(370,499),(396,488),(424,481),(455,477),(489,475),(522,476),(555,479),(587,485),(616,494),(641,505),(661,518),(673,531),(678,547),(700,550),(713,555),(719,566),(723,580),(723,590),(718,595),(705,599),(689,604),(679,611),(666,624),(660,644),(651,665),(640,683),(625,699),(606,713),(583,725),(576,737),(565,745),(545,750),(524,753),(495,753),(475,751),(455,746),(443,739),(434,728),(418,720),(399,708),(382,694),(370,679),(362,663),(356,644),(350,625),(339,615),(328,606),(314,601),(301,598),(295,594),(293,587),(294,572),(298,558),(304,553),(319,550)],[(347,528),(352,517),(365,506),(382,497),(407,489),(435,483),(464,480),(500,479),(533,480),(563,484),(591,490),(615,498),(636,508),(653,519),(665,531),(670,543),(670,552),(662,564),(648,573),(630,582),(606,589),(576,595),(547,599),(514,602),(480,602),(448,599),(418,594),(393,587),(373,578),(359,568),(351,556),(347,542)]),
('blue','蓝白','1084',[(335,536),(338,520),(348,505),(365,492),(389,481),(419,470),(451,462),(482,456),(515,453),(548,454),(581,458),(612,466),(641,477),(663,489),(681,503),(692,518),(697,535),(718,538),(735,543),(742,553),(746,567),(747,578),(744,586),(737,591),(718,597),(704,602),(690,612),(679,625),(673,645),(664,665),(653,682),(637,699),(620,712),(598,725),(588,739),(577,748),(555,754),(530,757),(501,757),(477,754),(459,749),(448,742),(439,730),(418,720),(399,708),(383,694),(371,680),(362,664),(354,645),(348,626),(336,613),(324,603),(310,597),(294,592),(288,587),(286,579),(287,566),(290,553),(297,544),(311,541)],[(342,524),(350,510),(364,498),(384,488),(408,479),(438,471),(470,465),(503,461),(537,461),(568,465),(599,472),(626,481),(650,492),(667,503),(679,516),(685,530),(684,543),(678,556),(665,568),(648,579),(626,588),(600,596),(571,602),(539,607),(506,608),(472,606),(440,602),(411,595),(386,587),(367,577),(353,565),(345,552),(341,538)]),
('yellow','黄白','1091',[(322,520),(326,503),(338,489),(355,476),(380,464),(410,455),(443,448),(476,444),(510,442),(544,444),(575,449),(604,457),(630,468),(650,480),(665,493),(674,507),(678,522),(697,525),(711,529),(718,536),(722,548),(725,560),(723,567),(718,572),(706,576),(688,582),(675,591),(664,603),(657,622),(649,641),(637,658),(623,674),(607,688),(589,700),(574,708),(565,721),(554,728),(535,733),(512,736),(486,736),(462,733),(443,728),(431,721),(423,709),(404,699),(386,686),(370,672),(357,656),(348,640),(341,623),(336,605),(324,593),(311,582),(297,575),(282,571),(275,566),(273,559),(275,545),(279,532),(285,526),(302,523)],[(329,510),(335,496),(349,483),(367,473),(391,464),(419,457),(449,452),(480,449),(513,448),(544,450),(574,455),(600,462),(623,472),(642,482),(655,494),(664,507),(667,520),(664,532),(655,544),(642,554),(624,562),(602,570),(576,576),(548,580),(518,582),(487,582),(457,580),(430,576),(405,570),(383,563),(364,554),(349,544),(338,533),(332,522)]),
('green','绿白','1098',None,[(350,526),(357,512),(371,500),(391,490),(415,482),(445,476),(477,472),(509,470),(540,471),(571,475),(599,481),(623,489),(645,499),(661,510),(672,523),(677,536),(675,548),(669,559),(657,570),(640,579),(618,587),(593,594),(565,599),(535,602),(504,603),(474,601),(445,598),(419,592),(397,585),(379,577),(365,567),(356,555),(351,542)]),
('orange','橙白','1076',None,None)]
def polygon(points):
 im=Image.new('L',(1024,1024));ImageDraw.Draw(im).polygon(points,fill=255);return im
O.mkdir(parents=True,exist_ok=True); rows=[]
for cid,name,num,outer,inner in DATA:
 src=P/f'IMG_{num}.jpg'; base=R/f'work/base/LISTING_{cid}'; md=R/f'work/masks/LISTING_{cid}';md.mkdir(parents=True,exist_ok=True)
 if cid=='orange':
  base.mkdir(parents=True,exist_ok=True)
  for f in ['Base_Image.png','transform.json']:shutil.copy2(R/'work/base/FIRST_BOWL_V2'/f,base/f)
  for f in ['bowl_mask.png','inner_mask.png','core_mask.png','protect_hard.png','paint_mask.png','paste_mask.png','core_overlay.png','masks.json','empty_bowl_cutout.png']:shutil.copy2(R/'work/masks/FIRST_BOWL_V2'/f,md/f)
 else:
  prepare(src,base)
  if cid=='green': outer=json.loads((R/'output/multi_bowl_draft/record.json').read_text())['green_polygon_on_1024_base']
  polygon(outer).save(md/'outer_input.png'); ia=np.asarray(polygon(inner)).copy(); ia[np.asarray(polygon(outer).filter(ImageFilter.MinFilter(5)))<128]=0; Image.fromarray(ia).save(md/'inner_input.png');masks(base/'Base_Image.png',md/'outer_input.png',md/'inner_input.png',md)
 # Soften subpixel alpha edge while preserving image RGB exactly.
 im=Image.open(base/'Base_Image.png').convert('RGBA'); bm=Image.open(md/'bowl_mask.png').convert('L'); arr=np.asarray(bm.filter(ImageFilter.GaussianBlur(1.1))).copy(); arr[np.asarray(bm)<128]=0; arr[np.asarray(bm.filter(ImageFilter.MinFilter(5)))>=128]=255; arr[np.asarray(Image.open(md/'core_mask.png'))>0]=255; im.putalpha(Image.fromarray(arr)); out=O/f'{cid}.png';im.save(out)
 core=np.asarray(Image.open(md/'core_mask.png'))>0
 assert np.array_equal(np.asarray(im)[...,:3][core],np.asarray(Image.open(base/'Base_Image.png').convert('RGB'))[core])
 rows.append(dict(product_family='w1125',color_id=cid,color_name=name,view_id='angled',source_photo=str(src.resolve()),base_image=str((base/'Base_Image.png').resolve()),bowl_mask=str((md/'bowl_mask.png').resolve()),inner_mask=str((md/'inner_mask.png').resolve()),core_mask=str((md/'core_mask.png').resolve()),rgba_empty=str(out.resolve()),source_hash=sha(src),source_verified='yes_photo;name_user_confirmed' if cid=='red' else 'yes_photo',camera_angle='斜俯视',light_direction='柔光',status='manual_mask_review_required'))
with open(R/'config/product_assets.csv','w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
with open(R/'config/skus.csv','w',newline='',encoding='utf-8-sig') as f:
 fields=['sku_id','product_family','color_id','color_name','source_table_row','size_id','length_cm','width_cm','height_cm','capacity_ml','weight_g','pack_label','sales_pack_status']
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for row,i in zip([rows[0],rows[4],rows[3],rows[2],rows[1]],range(2,7)):
  w.writerow(dict(sku_id=f'w1125_row{i}',product_family='w1125',color_id=row['color_id'],color_name=row['color_name'],source_table_row=i,size_id='6.5inch',length_cm=16.5,width_cm=12.8,height_cm=8,capacity_ml=550,weight_g=207,pack_label='批量采购',sales_pack_status='user_bulk_qty_unspecified'))
print('Built',len(rows),'photo assets; core pixels match base.')

# Rasterize source-specific closed cubic contours at 4x, constrained to the
# original mask's two-pixel boundary. Inner/core files are not touched here.
from scipy.interpolate import splprep, splev
from scipy.ndimage import distance_transform_edt
for cid, name, num, outer, inner in DATA:
    if cid == 'orange':  # Existing orange mask has no saved contour vertices.
        continue
    if cid == 'green':
        outer = json.loads((R/'output/multi_bowl_draft/record.json').read_text())['green_polygon_on_1024_base']
    points=np.asarray(outer,dtype=float); points=np.vstack([points,points[0]])
    tck,_=splprep([points[:,0],points[:,1]],s=0,per=True,k=3)
    sx,sy=splev(np.linspace(0,1,len(outer)*24,endpoint=False),tck)
    hi=Image.new('L',(4096,4096));ImageDraw.Draw(hi).polygon([(round(x*4),round(y*4)) for x,y in zip(sx,sy)],fill=255)
    alpha=np.asarray(hi.resize((1024,1024),Image.Resampling.LANCZOS)).copy()
    md=R/f'work/masks/LISTING_{cid}'; b=np.asarray(Image.open(md/'bowl_mask.png'))>=128
    alpha[b & (distance_transform_edt(b)>2)]=255
    alpha[(~b) & (distance_transform_edt(~b)>2)]=0
    alpha[np.asarray(Image.open(md/'core_mask.png'))>0]=255
    im=Image.open(R/f'work/base/LISTING_{cid}/Base_Image.png').convert('RGBA')
    im.putalpha(Image.fromarray(alpha));im.save(O/f'{cid}.png')
