import argparse,json
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
DEFAULT_FONT='/System/Library/Fonts/STHeiti Medium.ttc'
def make(cutout,out,label='',font=DEFAULT_FONT,size=800,occupancy=.72):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);im=Image.open(cutout).convert('RGBA');box=im.getchannel('A').getbbox()
    if not box:raise ValueError('Empty bowl alpha')
    im=im.crop(box);im.thumbnail((int(size*occupancy),int(size*.65)),Image.Resampling.LANCZOS);xy=((size-im.width)//2,(size-im.height)//2-20)
    white=Image.new('RGB',(size,size),'white');white.paste(im,xy,im.getchannel('A'))
    alpha=Image.new('L',(size,size));alpha.paste(im.getchannel('A'),xy);bg=np.array(alpha)==0
    if not np.all(np.array(white)[bg]==255):raise ValueError('Background not pure white')
    white.save(out/'white.png');white.save(out/'white.jpg',quality=95,subsampling=0)
    sku=white.copy();status='未添加文字：未提供经核实的 SKU 标签'
    if label.strip():
        for fs in range(30,13,-1):
            f=ImageFont.truetype(font,fs);lines=['']
            for c in label:
                if c=='\n':lines.append('');continue
                if f.getlength(lines[-1]+c)>size*.8:lines.append(c)
                else:lines[-1]+=c
            if len(lines)*(fs+7)<=100:break
        else:raise ValueError('SKU label too long for reserved area')
        draw=ImageDraw.Draw(sku);text='\n'.join(lines);draw.multiline_text((size//2,size-95),text,font=f,fill='#202020',anchor='ma',align='center',spacing=7);status='CSV verified label rendered'
    sku.save(out/'sku.png');sku.save(out/'sku.jpg',quality=95,subsampling=0)
    report=dict(size=[size,size],background_rgb=[255,255,255],background_pixels=int(bg.sum()),sku_label=label,status=status,font=font)
    (out/'layout.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));return report
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('cutout');p.add_argument('out');p.add_argument('--label',default='');p.add_argument('--font',default=DEFAULT_FONT);a=p.parse_args();print(make(a.cutout,a.out,a.label,a.font))
