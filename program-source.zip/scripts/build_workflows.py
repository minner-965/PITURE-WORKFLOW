import json,uuid,copy
from pathlib import Path
import requests,yaml
ROOT=Path(__file__).resolve().parents[1]
URL='http://127.0.0.1:8188'
PROMPT='Commercial food photograph of the single bowl in the input image, containing mung bean dessert soup inside its visible inner cavity, a level liquid surface below the rim, natural texture and viscosity, no overflowing or spilling, realistic perspective matching the input camera angle, on a clean wooden restaurant table, soft side lighting matching the original bowl, natural contact shadow under the bowl, simple softly blurred background.'
def node(cls,title,**inputs):return dict(class_type=cls,_meta={'title':title},inputs=inputs)
def make_a():
    return {
    '1':node('LoadImage','IN_IMAGE',image='ComfyProductPipeline/Base_Image.png'),
    '2':node('LoadImageMask','IN_PAINT_MASK',image='ComfyProductPipeline/paint_mask.png',channel='red'),
    '3':node('LoadImageMask','IN_PASTE_MASK',image='ComfyProductPipeline/paste_mask.png',channel='red'),
    '4':node('UnetLoaderGGUF','MODEL_FILL_GGUF',unet_name='flux1-fill-dev-Q6_K.gguf'),
    '5':node('DifferentialDiffusion','MODEL_MASKED',model=['4',0],strength=1.0),
    '6':node('DualCLIPLoaderGGUF','MODEL_TEXT_GGUF',clip_name1='clip_l.safetensors',clip_name2='t5-v1_1-xxl-encoder-Q5_K_M.gguf',type='flux'),
    '7':node('CLIPTextEncode','IN_PROMPT',clip=['6',0],text=PROMPT),
    '8':node('FluxGuidance','FLUX_GUIDANCE',conditioning=['7',0],guidance=30.0),
    '9':node('ConditioningZeroOut','NEG_ZERO',conditioning=['7',0]),
    '10':node('VAELoader','MODEL_VAE',vae_name='ae.safetensors'),
    '11':node('InpaintModelConditioning','FILL_CONDITION',positive=['8',0],negative=['9',0],vae=['10',0],pixels=['1',0],mask=['2',0],noise_mask=True),
    '12':node('KSampler','IN_SEED',model=['5',0],positive=['11',0],negative=['11',1],latent_image=['11',2],seed=20261102,steps=20,cfg=1.0,sampler_name='euler',scheduler='normal',denoise=1.0),
    '13':node('VAEDecode','DECODE',samples=['12',0],vae=['10',0]),
    '14':node('ImageCompositeMasked','RESTORE_BOWL',destination=['13',0],source=['1',0],mask=['3',0],x=0,y=0,resize_source=False),
    '15':node('SaveImage','OUT_RAW',images=['13',0],filename_prefix='ComfyProductPipeline/scene_raw'),
    '16':node('SaveImage','OUT_SAVE',images=['14',0],filename_prefix='ComfyProductPipeline/scene_restored'),
    '17':node('MaskToImage','MASK_PREVIEW',mask=['2',0]),
    '18':node('PreviewImage','CHECK_PAINT_POLARITY',images=['17',0])}

def check_graph(graph,info):
    checks=[]
    for nid,n in graph.items():
        schema=info[n['class_type']];inputs=n['inputs'];req=schema['input'].get('required',{});opt=schema['input'].get('optional',{})
        for k in req:
            if k not in inputs:raise ValueError(f'{nid} missing {k}')
        for k,v in inputs.items():
            spec=(req|opt)[k]
            if isinstance(v,list) and len(v)==2 and str(v[0]) in graph:
                source=info[graph[v[0]]['class_type']]['output'][v[1]]
                if source!=spec[0]:raise ValueError(f'{nid}.{k}: {source} != {spec[0]}')
            elif isinstance(spec[0],list) and k!='image' and v not in spec[0]:raise ValueError(f'{nid}.{k} missing option {v}')
        checks.append({'id':nid,'class_type':n['class_type'],'status':'schema/model option checked'})
    return checks

def ui(graph,info,title,note):
    nodes=[];links=[];byid={}
    positions={'1':(0,550),'2':(0,930),'3':(2200,900),'4':(0,0),'5':(400,0),'6':(0,220),'7':(430,240),'8':(900,230),'9':(900,420),'10':(450,1000),'11':(1250,450),'12':(1650,250),'13':(2050,300),'14':(2550,650),'15':(2500,120),'16':(2950,650),'17':(430,1350),'18':(850,1250),'19':(850,850),'20':(2150,1250),'21':(2500,1250)}
    for order,(nid,n) in enumerate(graph.items()):
        schema=info[n['class_type']];widgets=[];sockets=[]
        for kind in ('required','optional'):
            for name,spec in schema['input'].get(kind,{}).items():
                if name not in n['inputs']:continue
                value=n['inputs'][name];typ=spec[0]
                islink=isinstance(value,list) and len(value)==2 and str(value[0]) in graph
                if islink:sockets.append({'name':name,'type':typ,'link':None})
                else:
                    widgets.append(value)
                    if len(spec)>1 and isinstance(spec[1],dict) and spec[1].get('control_after_generate'):widgets.append('fixed')
        size=[310,180]
        if n['class_type']=='CLIPTextEncode':size=[410,245]
        if n['class_type']=='KSampler':size=[330,310]
        if n['class_type'] in ['LoadImage','SaveImage','PreviewImage']:size=[360,300]
        obj=dict(id=int(nid),type=n['class_type'],pos=list(positions.get(nid,(int(nid)*350,0))),size=size,flags={},order=order,mode=0,inputs=sockets,outputs=[{'name':name,'type':typ,'links':[]} for name,typ in zip(schema.get('output_name',schema['output']),schema['output'])],properties={'Node name for S&R':n['class_type']},widgets_values=widgets,title=n['_meta']['title'])
        if n['class_type'] in ['LoadImage','LoadImageMask']:obj.update(color='#354a62',bgcolor='#243242')
        byid[nid]=obj;nodes.append(obj)
    for nid,n in graph.items():
        for name,value in n['inputs'].items():
            if not (isinstance(value,list) and len(value)==2 and str(value[0]) in graph):continue
            source,slot=value;target=byid[nid];idx=next(i for i,x in enumerate(target['inputs']) if x['name']==name);typ=target['inputs'][idx]['type'];lid=len(links)+1
            links.append([lid,int(source),slot,int(nid),idx,typ]);target['inputs'][idx]['link']=lid;byid[source]['outputs'][slot]['links'].append(lid)
    nodes.append(dict(id=99,type='Note',pos=[0,-430],size=[800,350],flags={},order=99,mode=0,inputs=[],outputs=[],properties={},widgets_values=[note],title=title,color='#554330',bgcolor='#332b22'))
    return dict(id=str(uuid.uuid4()),revision=0,last_node_id=99,last_link_id=len(links),nodes=nodes,links=links,groups=[],config={},extra={'ds':{'scale':.35,'offset':[150,600]},'frontendVersion':'1.57.4'},version=.4)

def main():
    info=requests.get(URL+'/object_info',timeout=45).json();(ROOT/'work/diagnostics/object_info.json').write_text(json.dumps(info,ensure_ascii=False,indent=2))
    A=make_a();B={'1':node('LoadImage','MASK_EDITOR_INPUT',image='ComfyProductPipeline/Base_Image.png'),'17':node('MaskToImage','MASK_TO_GRAYSCALE',mask=['1',1]),'16':node('SaveImage','SAVE_EDITED_MASK',images=['17',0],filename_prefix='ComfyProductPipeline/manual_mask')}
    # Detail graph is prepared but execution is gated on a selected, stable scene master.
    C=copy.deepcopy(A)
    for key in ['2','3','17','18']:C.pop(key)
    C['1']['inputs']['image']='ComfyProductPipeline/selected_master.png'
    C['19']=node('ImagePadForOutpaint','PAD_DETAIL',image=['1',0],left=0,top=256,right=0,bottom=256,feathering=16)
    C['11']['inputs'].update(pixels=['19',0],mask=['19',1],noise_mask=False)
    C['20']=node('InvertMask','ORIGINAL_REGION',mask=['19',1])
    C['21']=node('ImageCrop','ORIGINAL_BLEND_MASK',image=['22',0],width=1024,height=1024,x=0,y=256)
    C['22']=node('MaskToImage','PAD_MASK_IMAGE',mask=['20',0])
    C['23']=node('ImageToMask','ORIGINAL_BLEND_MASK_GRAY',image=['21',0],channel='red')
    C['14']['inputs'].update(mask=['23',0],x=0,y=256)
    C['15']['inputs']['filename_prefix']='ComfyProductPipeline/detail_raw';C['16']['inputs']['filename_prefix']='ComfyProductPipeline/detail_restored'
    manifest={}
    for letter,graph,description in [
      ('A',A,'场景 A · 等待真实照片与人工蒙版\n\n1. Base 必须是等比例缩放补边的 1024×1024 PNG。\n2. IN_PAINT_MASK 白=内腔及背景重绘；IN_PASTE_MASK 白=原碗贴回。\n3. 当前模型为已有、哈希核验通过的 Fill Q6_K，未下载 Q5。\n4. 单张 20步 / cfg1 / euler / normal / guidance30。\n5. OUT_RAW 保留原始生成，OUT_SAVE 贴回原碗；scripts/restore_and_check.py 再做核心整数像素恢复。\n6. 图片未提供前不可运行；尚无真实推理、速度或画质验收。'),
      ('B',B,'蒙版 B · 原生 Mask Editor\n\n右键 LoadImage → Open in MaskEditor。只编辑 MASK 层，不编辑 RGB。\n分别标记整碗与内腔，运行本图保存 MASK 灰度图，检查白色含义和极性。\n用 build_masks.py 生成 protect / paint / paste / core 与彩色覆盖预览。\n原始 Base 不得被修改。'),
      ('C',C,'详情 C · 准备稿，A 稳定并选中母版后才运行\n\n上下各补 256，1024×1536，noise_mask=false。\n原图回贴 x=0, y=256。原图矩形边缘有16px过渡。\nrun_detail.py 重新恢复正确位移的原图核心与碗保护像素。\n未执行真实扩图；不可推断内存与画质。')]:
        checks=check_graph(graph,info);name={'A':'A_flux_fill_scene','B':'B_manual_masks','C':'C_flux_fill_detail'}[letter]
        (ROOT/f'workflows/{name}.api.json').write_text(json.dumps(graph,ensure_ascii=False,indent=2));u=ui(graph,info,description.split('\n')[0],description);(ROOT/f'workflows/{name}.ui.json').write_text(json.dumps(u,ensure_ascii=False,indent=2))
        manifest[letter]={'name':name,'nodes':{n['_meta']['title']:{'id':nid,'class_type':n['class_type']} for nid,n in graph.items()},'checks':checks,'status':'schema通过；等待真实商品输入；推理未验证'}
    (ROOT/'workflows/manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    config=dict(url=URL,project=str(ROOT),python='/Users/luohuiwu/ComfyUI-Installs/E-commerce image workflow/ComfyUI/.venv/bin/python3',width=1024,height=1024,steps=20,cfg=1.0,guidance=30,sampler='euler',scheduler='normal',candidates=1,timeout_seconds=7200,retries=0,font='/System/Library/Fonts/STHeiti Medium.ttc',output_size=800,models={'unet':'flux1-fill-dev-Q6_K.gguf','clip_l':'clip_l.safetensors','t5':'t5-v1_1-xxl-encoder-Q5_K_M.gguf','vae':'ae.safetensors'})
    (ROOT/'config/pipeline.yaml').write_text(yaml.safe_dump(config,allow_unicode=True,sort_keys=False));(ROOT/'prompts/scene.txt').write_text(PROMPT)
    if not (ROOT/'input/products.csv').exists():(ROOT/'input/products.csv').write_text('sku,photo,angle,dish,scene,sku_label\n')
    print('Built A/B/C UI + API; schema and available model options checked.')
if __name__=='__main__':main()
