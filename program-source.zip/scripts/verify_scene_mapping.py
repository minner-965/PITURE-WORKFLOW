"""Verify existing Comfy input mappings and write inspectable API/UI JSON; never submit."""
import argparse, hashlib, io, json
from pathlib import Path
from PIL import Image
from comfy_client import ComfyClient, bind, sync_ui
from build_workflows import ROOT, check_graph

p=argparse.ArgumentParser(description=__doc__)
for title in ('IN_IMAGE','IN_PAINT_MASK','IN_PASTE_MASK'):
    p.add_argument('--'+title.lower().replace('_','-'), nargs=2, required=True, metavar=('LOCAL_FILE','COMFY_INPUT_PATH'))
p.add_argument('--out', required=True, help='New directory for JSON review artifacts')
a=p.parse_args()
client=ComfyClient(); info=client.get('/object_info')
graph=json.loads((ROOT/'workflows/A_flux_fill_scene.api.json').read_text())
ui=json.loads((ROOT/'workflows/A_flux_fill_scene.comfy_saved.ui.json').read_text())
manifest=json.loads((ROOT/'workflows/manifest.json').read_text())['A']
report=[]
for title in ('IN_IMAGE','IN_PAINT_MASK','IN_PASTE_MASK'):
    local,remote=getattr(a,title.lower()); local=Path(local)
    remote_path=Path(remote)
    if remote_path.is_absolute() or '..' in remote_path.parts: raise ValueError('Invalid Comfy input path')
    response=client.session.get(client.url+'/view',params={'filename':remote_path.name,'subfolder':str(remote_path.parent) if str(remote_path.parent)!='.' else '', 'type':'input'},timeout=30)
    response.raise_for_status(); data=response.content; original=local.read_bytes()
    if hashlib.sha256(data).digest()!=hashlib.sha256(original).digest(): raise ValueError(title+': local and API file differ')
    with Image.open(io.BytesIO(data)) as im:
        if im.size!=(1024,1024):raise ValueError(title+': expected 1024x1024')
    bind(graph,manifest,title,{'image':remote})
    report.append(dict(title=title,node_id=manifest['nodes'][title]['id'],local=str(local.resolve()),comfy_input=remote,sha256=hashlib.sha256(data).hexdigest(),size=[1024,1024]))
check_graph(graph,info); ui=sync_ui(graph,ui,info)
out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
for name,obj in [('mapping.json',report),('scene.api.json',graph),('scene.ui.json',ui)]:
    (out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2))
print('Verified; no prompt submitted:',out)
