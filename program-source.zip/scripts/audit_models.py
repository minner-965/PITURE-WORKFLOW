"""Read-only audit. Replays this instance's ordered path configs; never loads weights into torch."""
import argparse, hashlib, json, os, struct, sys
from pathlib import Path
from collections import defaultdict
import requests
ROOT=Path(__file__).resolve().parents[1]
ENV=json.loads((ROOT/'config/environment.json').read_text())
sys.path.insert(0,ENV['source'])
import folder_paths
from utils.extra_config import load_extra_path_config

def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
def paths():
    configs=[Path(ENV['source'])/'extra_model_paths.yaml',Path(ENV['startup_config'])]
    for p in configs:
        if p.exists():load_extra_path_config(str(p))
    # Same registration performed at module import by city96 nodes.py.
    for key,src in [('unet_gguf','diffusion_models'),('clip_gguf','text_encoders')]:
        folder_paths.folder_names_and_paths[key]=(folder_paths.get_folder_paths(src),{'.gguf'})
    return {k:list(v[0]) for k,v in folder_paths.folder_names_and_paths.items()}
def header(p):
    size=p.stat().st_size
    with p.open('rb') as f:
        start=f.read(512)
        if start.startswith(b'version https://git-lfs.github.com/spec/v1'):raise ValueError('Git LFS pointer, not weights')
        if not size or p.suffix in ['.part','.incomplete']:raise ValueError('empty/incomplete')
        if start[:4]==b'GGUF':
            import gguf
            r=gguf.GGUFReader(str(p),'r')
            fields={}
            for k,v in r.fields.items():
                if k.startswith('GGUF.'):continue
                value=v.contents()
                fields[k]={'count':len(value),'note':'tokenizer array omitted'} if k.startswith('tokenizer.') and isinstance(value,list) else value
            tensors=[dict(name=t.name,shape=t.shape.tolist(),type=str(t.tensor_type),bytes=int(t.n_bytes)) for t in r.tensors]
            maxend=max(int(t.data_offset)+int(t.n_bytes) for t in r.tensors)
            if maxend>size:raise ValueError('tensor extends past EOF')
            return dict(format='GGUF',metadata=fields,tensor_count=len(tensors),tensors=tensors)
        f.seek(0); n=struct.unpack('<Q',f.read(8))[0]
        if n>32*1024*1024 or n<2 or n>size-8:raise ValueError('invalid bounded safetensors header')
        data=json.loads(f.read(n));tensors={k:v for k,v in data.items() if k!='__metadata__'}
        if max(v['data_offsets'][1] for v in tensors.values())+8+n!=size:raise ValueError('safetensors data length mismatch')
        return dict(format='safetensors',metadata=data.get('__metadata__',{}),tensor_count=len(tensors),tensors=tensors)
def upstream(repo,name,cache):
    dest=cache/(repo.replace('/','__')+'.json')
    if not dest.exists():
        r=requests.get('https://huggingface.co/api/models/'+repo,params={'blobs':'true'},timeout=45);r.raise_for_status();dest.write_text(json.dumps(r.json(),indent=2))
    data=json.loads(dest.read_text());v=next(x for x in data['siblings'] if x['rfilename']==name)
    return dict(repo=repo,revision=data['sha'],filename=name,sha256=v.get('lfs',{}).get('sha256'),bytes=v.get('size'),url=f"https://huggingface.co/{repo}/blob/{data['sha']}/{name}")
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--refresh',action='store_true');args=ap.parse_args()
    diag=ROOT/'work/diagnostics'; cache=diag/'upstream';cache.mkdir(exist_ok=True)
    registered=paths();(diag/'effective_paths.json').write_text(json.dumps(registered,indent=2))
    objects=requests.get(ENV['url']+'/object_info',timeout=40).json()
    models=[]
    roots=[Path('/Users/luohuiwu/ComfyUI-Shared/models'),Path(ENV['source'])/'models',Path('/Users/luohuiwu/Downloads')]
    for root in roots:
        for p in root.rglob('*'):
            if not p.is_file() or p.suffix.lower() not in ['.gguf','.safetensors','.part','.incomplete']:continue
            item=dict(path=str(p),realpath=str(p.resolve()),symlink=p.is_symlink(),readable=os.access(p,os.R_OK),bytes=p.stat().st_size,load_result='未验证：尚未执行真实商品推理',repair='复用；不移动、不删除、不覆盖')
            print('Auditing',p,flush=True)
            try:item['header']=header(p);item['file_check']='结构通过'
            except (ValueError,ImportError,KeyError,StopIteration) as e:item['file_check']=str(e)
            item['sha256']=sha(p)
            if p.name.startswith('flux1-fill'):role='Fill 主模型';repo='YarvixPA/FLUX.1-Fill-dev-GGUF';name=p.name;loader='UnetLoaderGGUF';field='unet_name';cat='unet_gguf'
            elif p.name.startswith('t5-v1_1'):role='T5 文本编码器';repo='city96/t5-v1_1-xxl-encoder-gguf';name=p.name;loader='DualCLIPLoaderGGUF';field='clip_name1';cat='clip_gguf'
            elif p.name=='clip_l.safetensors':role='CLIP-L';repo='comfyanonymous/flux_text_encoders';name=p.name;loader='DualCLIPLoaderGGUF';field='clip_name2';cat='text_encoders'
            elif p.name=='ae.safetensors':role='FLUX VAE';repo='Comfy-Org/Lumina-Image-2';name='split_files/vae/ae.safetensors';loader='VAELoader';field='vae_name';cat='vae'
            else:role='待识别';repo=None;loader=None;field=None;cat=None
            item.update(role=role,loader=loader,category=cat)
            if repo:
                try:
                    source=upstream(repo,name,cache);item['source']=source
                    item['integrity']='SHA256 与固定 revision 上游完全匹配' if source['sha256']==item['sha256'] else '完整性尚未完全核实：上游哈希缺失或不符'
                except (requests.RequestException,ValueError,StopIteration) as e:item['integrity']='完整性尚未完全核实：'+str(e)
            item['search_membership']=[]
            if cat:
                for priority,base in enumerate(registered[cat]):
                    try:rel=str(p.relative_to(base));item['search_membership'].append(dict(priority=priority,root=base,option=rel))
                    except ValueError:continue
                option=item['search_membership'][0]['option'] if item['search_membership'] else None
                req=objects.get(loader,{}).get('input',{}).get('required',{})
                options=req.get(field,[[]])[0]
                item['loader_option']=option;item['node_visible']=option in options if option else False
                item['resolved_file']=folder_paths.get_full_path(cat,option) if option else None
            models.append(item)
    groups=defaultdict(list)
    for m in models:groups[Path(m['path']).name].append(m)
    for group in groups.values():
        if len(group)>1:
            for m in group:m['same_name']='同名同哈希冗余，保留' if len({x['sha256'] for x in group})==1 else '同名不同哈希冲突，禁止覆盖'
    result=dict(models=models,registered_paths=registered,inference='未验证',scope=[str(p) for p in roots])
    (diag/'model_inventory.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,default=lambda x:x.tolist() if hasattr(x,'tolist') else str(x)))
    lines=['# 模型位置检查报告','', '审计为只读；模型未移动、未覆盖、未删除。文件结构及哈希检查不等于推理加载通过。','', '|用途|绝对路径 / realpath|字节|Loader / 选项|完整性|节点可见|加载|','|---|---|---:|---|---|---|---|']
    for m in models:lines.append(f"|{m['role']}|{m['path']} / {m['realpath']}|{m['bytes']}|{m['loader']} / {m.get('loader_option')}|{m.get('integrity','未核实')}|{m.get('node_visible')}|未验证|")
    for m in models:
        lines+=['',f"## {m['path']}",f"- SHA256: `{m['sha256']}`",f"- 结构: {m['file_check']}",f"- 搜索匹配顺序: {m.get('search_membership')}",f"- 真正解析到: {m.get('resolved_file')}",f"- 同名检查: {m.get('same_name','无同名冲突')}",f"- 来源: {m.get('source')}",f"- 动作: {m['repair']}"]
    lines+=['','## 结论','现有主模型 Q6_K 已保留。它不是方案首选 Q5_K_S：先不重复下载；商品基准前评估 Q6 内存风险，不能声称 Q5 基准完成。T5 两份相同内容则仅报告冗余。clip 与 text_encoders 均为有效别名，实际加载优先级见上表与 effective_paths.json。','未进行真实商品推理；节点可见与实际加载分开记录。']
    (ROOT/'docs/模型位置检查.md').write_text('\n'.join(lines))
    print('Saved',diag/'model_inventory.json')
if __name__=='__main__':main()
