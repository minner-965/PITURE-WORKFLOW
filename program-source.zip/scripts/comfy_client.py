import copy,json,subprocess,time,uuid,sys
sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parents[1]))
from pathlib import Path
import requests
from urllib.parse import urlparse

class ComfyClient:
    def __init__(self,url='http://127.0.0.1:8188'):
        self.url=url.rstrip('/');self.session=requests.Session();self.client_id=str(uuid.uuid4());self.submit_timing=None
        # Local ComfyUI traffic must stay local even when the desktop exports a proxy.
        if urlparse(self.url).hostname in ('127.0.0.1', 'localhost', '::1'):
            self.session.trust_env=False
    def get(self,route):
        r=self.session.get(self.url+route,timeout=30);r.raise_for_status();return r.json()
    def upload(self,path):
        path=Path(path)
        with path.open('rb') as f:r=self.session.post(self.url+'/upload/image',files={'image':(path.name,f,'image/png')},data={'type':'input','subfolder':'ComfyProductPipeline','overwrite':'false'},timeout=60)
        r.raise_for_status();v=r.json();return '/'.join(filter(None,[v.get('subfolder'),v['name']]))
    def submit(self,api,ui,record):
        from fission.bridge import submit
        return submit(self,api,ui,record)
    def _submit_uncached(self,api,ui,record):
        # Commit submission intent before POST. An ambiguous POST is never auto-retried.
        record=Path(record);data={'client_id':self.client_id,'status':'submitting','prompt_id':None,'request':{'prompt':api,'client_id':self.client_id,'extra_data':{'extra_pnginfo':{'workflow':ui},'comfy_product_pipeline':True}}}
        backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip())
        self.submit_timing={'start_time':time.time(),'initial':self.metrics(backend)};data['timing']=self.submit_timing
        record.write_text(json.dumps(data,ensure_ascii=False,indent=2))
        try:
            r=self.session.post(self.url+'/prompt',json=data['request'],timeout=60)
            if not r.ok:
                data.update(status='rejected',error=r.text);record.write_text(json.dumps(data,ensure_ascii=False,indent=2));r.raise_for_status()
        except requests.RequestException:
            if data['status']=='submitting':
                data.update(status='submission_unknown',error='Do not resubmit; reconcile queue/history by client_id first.');record.write_text(json.dumps(data,indent=2))
            raise
        answer=r.json();data.update(status='queued',prompt_id=answer['prompt_id'],response=answer);record.write_text(json.dumps(data,ensure_ascii=False,indent=2));return answer['prompt_id']
    def reconcile(self,record):
        from fission.bridge import reconcile
        return reconcile(self,record)
    def _reconcile_uncached(self,record):
        record=Path(record);data=json.loads(record.read_text());self.submit_timing=data.get('timing')
        if data.get('prompt_id'):return data['prompt_id']
        queue=self.get('/queue');history=self.get('/history?max_items=200');matches=[]
        entries=queue['queue_running']+queue['queue_pending']+[v['prompt'] for v in history.values()]
        for item in entries:
            extra=item[3] if len(item)>3 else {}
            if extra.get('client_id')==data['client_id']:matches.append(item[1])
        if len(set(matches))==1:
            data.update(prompt_id=matches[0],status='reconciled');record.write_text(json.dumps(data,indent=2));return matches[0]
        raise RuntimeError('Submission unresolved; review project submission record and local queue/history. No automatic resubmission.')
    def wait(self,prompt_id,logdir,pid,timeout=7200):
        from fission.bridge import wait
        return wait(self,prompt_id,logdir,pid,timeout)
    def _wait_uncached(self,prompt_id,logdir,pid,timeout=7200):
        logdir=Path(logdir);logdir.mkdir(parents=True,exist_ok=True);start=time.monotonic();samples=[];maxrss=0;initial=self.submit_timing['initial'] if self.submit_timing else self.metrics(pid);start_wall=self.submit_timing['start_time'] if self.submit_timing else time.time()
        with (logdir/'memory_samples.jsonl').open('a') as f:
            while True:
                h=self.get('/history/'+prompt_id)
                m=self.metrics(pid);samples.append(m);maxrss=max(maxrss,m.get('rss_kib',0));f.write(json.dumps(m)+'\n');f.flush()
                if prompt_id in h:
                    result=h[prompt_id];(logdir/'history.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
                    status=result.get('status',{});errors=[x for x in status.get('messages',[]) if x[0] in ['execution_error','execution_interrupted']]
                    report=dict(prompt_id=prompt_id,start_time=start_wall,wall_seconds=time.time()-start_wall,status=status.get('status_str'),error=errors,rss_peak_sampled_bytes=maxrss*1024,sample_interval_seconds=5,initial=initial,final=m,mps_process_allocation_peak='未测：未在后端进程植入采样',visual_pass=None)
                    report['swap_delta_bytes']=(m['swap_used_bytes']-initial['swap_used_bytes']) if m['swap_used_bytes'] is not None and initial['swap_used_bytes'] is not None else None
                    backend_times={k:v.get('timestamp') for k,v in status.get('messages',[]) if k in ['execution_start','execution_success']}
                    report['backend_event_timestamps_ms']=backend_times
                    if backend_times.get('execution_success') and backend_times.get('execution_start'):report['backend_wall_seconds']=(backend_times['execution_success']-backend_times['execution_start'])/1000
                    (logdir/'measurements.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
                    if status.get('status_str')!='success':raise RuntimeError(json.dumps(errors,ensure_ascii=False))
                    return result,report
                if time.monotonic()-start>timeout:raise TimeoutError(f'{prompt_id}: task may still be running; resume via existing prompt_id')
                time.sleep(5)
    @staticmethod
    def metrics(pid):
        def command(args):return subprocess.run(args,capture_output=True,text=True).stdout.strip()
        rss=command(['ps','-o','rss=','-p',str(pid)])
        swap=command(['sysctl','vm.swapusage'])
        import re
        used=re.search(r'used = ([\d.]+)([MG])',swap)
        swap_bytes=round(float(used[1])*(1024**2 if used[2]=='M' else 1024**3)) if used else None
        # -Q only queries; no memory-pressure load is generated.
        raw_level=command(['sysctl','-n','kern.memorystatus_vm_pressure_level'])
        try:level=int(raw_level)
        except (TypeError,ValueError):level=None
        return dict(time=time.time(),rss_kib=int(rss) if rss else 0,swap=swap,swap_used_bytes=swap_bytes,memory_pressure=command(['memory_pressure','-Q']),vm_pressure_level_raw=level,vm_pressure_level_name={1:'normal',2:'warning',4:'critical'}.get(level))
    def download(self,result,out):
        from fission.bridge import download
        return download(self,result,out)
    def _download_uncached(self,result,out):
        out=Path(out);out.mkdir(parents=True,exist_ok=True);files={}
        for nid,values in result.get('outputs',{}).items():
            for idx,item in enumerate(values.get('images',[])):
                r=self.session.get(self.url+'/view',params=item,timeout=120);r.raise_for_status();p=out/(nid+'_'+str(idx)+'_'+Path(item['filename']).name);p.write_bytes(r.content);files.setdefault(nid,[]).append(str(p))
        return files
    def stop_project(self,prompt_ids):
        ids=set(prompt_ids);queue=self.get('/queue');pending=[p[1] for p in queue['queue_pending'] if p[1] in ids]
        if pending:self.session.post(self.url+'/queue',json={'delete':pending},timeout=30).raise_for_status()
        for p in queue['queue_running']:
            if p[1] in ids:self.session.post(self.url+'/interrupt',json={'prompt_id':p[1]},timeout=30).raise_for_status()

def bind(graph,manifest,title,value):
    target=manifest['nodes'][title];n=graph[target['id']]
    if n['class_type']!=target['class_type'] or n['_meta']['title']!=title:raise ValueError('Node identity mismatch: '+title)
    n['inputs'].update(value)

def sync_ui(graph,ui,info):
    ui=copy.deepcopy(ui)
    seen=set()
    for n in ui['nodes']:
        if str(n['id']) not in graph:continue
        data=graph[str(n['id'])];values=[]
        if n.get('type')!=data['class_type'] or n.get('title')!=data['_meta']['title']:
            raise ValueError('UI node identity mismatch: '+str(n['id']))
        seen.add(str(n['id']))
        for kind in ('required','optional'):
            for name,spec in info[data['class_type']]['input'].get(kind,{}).items():
                if name not in data['inputs']:continue
                v=data['inputs'][name]
                if isinstance(v,list) and len(v)==2 and str(v[0]) in graph:continue
                values.append(v)
                if len(spec)>1 and isinstance(spec[1],dict) and spec[1].get('control_after_generate'):values.append('fixed')
        # Frontend adds a non-API upload widget to image loaders.
        if data['class_type'] in ('LoadImage','LoadImageMask') and n.get('widgets_values', [])[-1:] == ['image']:
            values.append('image')
        n['widgets_values']=values
    if seen != set(graph):raise ValueError('UI missing graph nodes: '+str(set(graph)-seen))
    return ui
