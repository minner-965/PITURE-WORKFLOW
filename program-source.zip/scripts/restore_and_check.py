import argparse,json
from pathlib import Path
import numpy as np
from PIL import Image

def restore(base,generated,paste,core,out,already_composited=False):
    b=Image.open(base).convert('RGB');g=Image.open(generated).convert('RGB');p=Image.open(paste).convert('L');c=Image.open(core).convert('L')
    if not b.size==g.size==p.size==c.size:raise ValueError('Image/mask coordinate mismatch')
    B=np.array(b);G=np.array(g);C=np.array(c)>=128
    if not C.any():raise ValueError('Core is empty')
    if already_composited:F=G.copy()
    else:
        alpha=np.array(p,dtype='float32')[:,:,None]/255;F=np.rint(B*alpha+G*(1-alpha)).clip(0,255).astype('uint8')
    F[C]=B[C];out=Path(out);out.parent.mkdir(parents=True,exist_ok=True);Image.fromarray(F).save(out)
    decoded=np.array(Image.open(out).convert('RGB'));diff=np.abs(decoded.astype('int16')-B.astype('int16'))[C]
    report=dict(core_pixels=int(C.sum()),core_diff_max=int(diff.max()),core_diff_count=int(np.any(diff,axis=1).sum()),source='OUT_SAVE' if already_composited else 'OUT_RAW',visual_pass=None)
    out.with_suffix('.check.json').write_text(json.dumps(report,indent=2))
    if report['core_diff_max']!=0:raise ValueError(report)
    return report
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('base');p.add_argument('generated');p.add_argument('paste');p.add_argument('core');p.add_argument('out');p.add_argument('--already-composited',action='store_true');a=p.parse_args();print(restore(a.base,a.generated,a.paste,a.core,a.out,a.already_composited))
