import argparse,hashlib,json,subprocess
from pathlib import Path
import numpy as np
from PIL import Image
from comfy_client import ComfyClient,bind,sync_ui
from build_workflows import check_graph
ROOT=Path(__file__).resolve().parents[1]
def main():
    ap=argparse.ArgumentParser();ap.add_argument('picks');ap.add_argument('--execute',action='store_true');a=ap.parse_args()
    picks=json.loads(Path(a.picks).read_text());client=ComfyClient();info=client.get('/object_info');manifest=json.loads((ROOT/'workflows/manifest.json').read_text())['C']
    if not picks:raise SystemExit('No selected scene; detail not run')
    for item in picks:
        scene=(ROOT/item['master']).resolve()
        if not scene.is_relative_to(ROOT/'work/masters'):raise ValueError('Select project master only')
        base=Image.open(scene).convert('RGB')
        if base.size!=(1024,1024):raise ValueError('Detail requires 1024×1024 master')
        if not item.get('visual_pass'):raise ValueError('Scene must pass visual review before detail')
        corepath=ROOT/'work/masks'/item['sku']/'core_mask.png';core=np.array(Image.open(corepath).convert('L'))>=128
        graph=json.loads((ROOT/'workflows/C_flux_fill_detail.api.json').read_text());identity=hashlib.sha256(scene.read_bytes()+json.dumps(graph,sort_keys=True).encode()).hexdigest()[:20];log=ROOT/'work/logs'/('detail_'+identity);log.mkdir(exist_ok=True);record=log/'submission.json'
        if not a.execute:print('Detail ready',identity);continue
        if record.exists():pid=client.reconcile(record)
        else:
            q=client.get('/queue')
            if q['queue_running'] or q['queue_pending']:raise RuntimeError('Queue not empty')
            bind(graph,manifest,'IN_IMAGE',{'image':client.upload(scene)});check_graph(graph,client.get('/object_info'));ui=sync_ui(graph,json.loads((ROOT/'workflows/C_flux_fill_detail.ui.json').read_text()),info);pid=client.submit(graph,ui,record)
        backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());h,m=client.wait(pid,log,backend);files=client.download(h,ROOT/'work/candidates'/('detail_'+identity));raw=np.array(Image.open(files['16'][0]).convert('RGB'))
        if raw.shape!=(1536,1024,3):raise ValueError('Detail output dimensions incorrect')
        B=np.array(base);region=raw[256:1280];hard=np.zeros((1024,1024),bool);hard[16:-16,16:-16]=True;hard|=core;region[hard]=B[hard]
        out=ROOT/'work/masters'/item['sku']/('detail_'+identity+'.png');Image.fromarray(raw).save(out);actual=np.array(Image.open(out))[256:1280];diff=np.abs(actual.astype('int16')-B.astype('int16'))[hard]
        report=dict(master=str(out),padding={'top':256,'bottom':256,'left':0,'right':0},original_offset={'x':0,'y':256},core_pixels=int(hard.sum()),core_diff_max=int(diff.max()),core_diff_count=int(np.any(diff,axis=1).sum()),visual_pass=None,measurements=m)
        out.with_suffix('.check.json').write_text(json.dumps(report,indent=2));print(out)
if __name__=='__main__':main()
