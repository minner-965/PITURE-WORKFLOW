"""Remove a documented foreground prop patch using a smooth local backdrop fit; never touch the bowl."""
import argparse,json
from pathlib import Path
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import spsolve
from PIL import Image,ImageFilter

def clean(source,base,bowl,core,out):
    im=np.array(Image.open(source).convert('RGB'));B=np.array(Image.open(bowl).convert('L'))>=128;C=np.array(Image.open(core).convert('L'))>=128
    h,w=im.shape[:2]
    if (h,w)!=(1024,1024) or B.shape!=(h,w):raise ValueError('This patch is specific to the reviewed 1024px V2 frame')
    yy,xx=np.mgrid[:h,:w];raw=(xx>=85)&(xx<550)&(yy>=640)&(yy<920)
    exclusion=np.array(Image.fromarray(B.astype('uint8')*255).filter(ImageFilter.MaxFilter(21)))>0
    mask=raw&~exclusion
    small=np.array(Image.fromarray(im).resize((256,256),Image.Resampling.BOX)).astype('float64')
    M=np.array(Image.fromarray(mask.astype('uint8')*255).resize((256,256),Image.Resampling.NEAREST))>0
    yy2,xx2=np.where(M);index=np.full((256,256),-1,int);index[yy2,xx2]=np.arange(len(xx2));A=lil_matrix((len(xx2),len(xx2)));rhs=np.zeros((len(xx2),3))
    for k,(y2,x2) in enumerate(zip(yy2,xx2)):
        A[k,k]=4
        for ny,nx in [(y2-1,x2),(y2+1,x2),(y2,x2-1),(y2,x2+1)]:
            if M[ny,nx]:A[k,index[ny,nx]]=-1
            else:rhs[k]+=small[ny,nx]
    small[yy2,xx2]=spsolve(A.tocsr(),rhs)
    bg=np.array(Image.fromarray(np.clip(small,0,255).astype('uint8')).resize((1024,1024),Image.Resampling.BICUBIC),dtype='float64')
    alpha=np.array(Image.fromarray(mask.astype('uint8')*255).filter(ImageFilter.GaussianBlur(12)),dtype='float64')/255;alpha[exclusion]=0
    # Fully remove props inside the patch while keeping a soft transition at its perimeter.
    interior=(xx>=110)&(xx<520)&(yy>=665)&(yy<895)&~exclusion;alpha[interior]=1
    result=np.rint(im*(1-alpha[:,:,None])+bg*alpha[:,:,None]).astype('uint8');result[C]=np.array(Image.open(base).convert('RGB'))[C]
    target=Path(out);Image.fromarray(result).save(target);decoded=np.array(Image.open(target));diff=np.abs(decoded.astype('int16')-np.array(Image.open(base).convert('RGB')).astype('int16'))[C]
    report=dict(core_pixels=int(C.sum()),core_diff_max=int(diff.max()),core_diff_count=int(np.any(diff,axis=1).sum()),source=str(source),postprocess='reviewed background props removed by harmonic interpolation of surrounding backdrop; bowl +10px exclusion',patch=[85,640,550,920],visual_pass=None)
    target.with_suffix('.check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(target)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('base');p.add_argument('bowl');p.add_argument('core');p.add_argument('out');a=p.parse_args();clean(a.source,a.base,a.bowl,a.core,a.out)
