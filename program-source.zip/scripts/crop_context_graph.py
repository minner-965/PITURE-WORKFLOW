#!/usr/bin/env python3
"""Build a native crop-context Q6 graph; never submit or manipulate generated food."""
from pathlib import Path
import json
import numpy as np
from PIL import Image,ImageDraw
from build_workflows import make_a,node,check_graph,ui

def validate_crop(crop,paint_path):
 keys=('x','y','width','height','sampling_width','sampling_height')
 if any(not isinstance(crop.get(k),int) or isinstance(crop[k],bool) or crop[k]%16 for k in keys):raise ValueError('All crop and sampling dimensions must be multiples of 16')
 x,y,w,h,sw,sh=(crop[k] for k in keys)
 if x<0 or y<0 or w<=0 or h!=w or x+w>1024 or y+h>1024 or sw not in (512,768,1024) or sh!=sw:raise ValueError('Expected an in-bounds square crop and 512, 768 or 1024 square sampling')
 p=Path(paint_path)
 if not p.is_absolute() or not p.is_file():raise ValueError('paint path must exist and be absolute')
 mask=Image.open(p).convert('L')
 if mask.size!=(1024,1024):raise ValueError('paint mask must be 1024×1024')
 m=np.asarray(mask);ys,xs=np.nonzero(m)
 if not len(xs) or xs.min()<x or xs.max()>=x+w or ys.min()<y or ys.max()>=y+h:raise ValueError('All nonzero paint must be inside the crop')
 return {'crop_xyxy':[x,y,x+w,y+h],'mask_bbox_xyxy':[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)],'mask_nonzero_pixels':int(len(xs)),'forward_scale':sw/w,'inverse_scale':w/sw,'inverse_offset_xy':[x,y],'bowl_extent':'whole bowl must be verified visually against preview; no outer-bowl segmentation supplied'}

def build(crop,paint_path,info):
 geometry=validate_crop(crop,paint_path);g=make_a()
 for nid in ('14','17','18'):g.pop(nid)
 g['3']['_meta']['title']='IN_INVERSE_MASK_REFERENCE_ONLY'
 x,y,w,h,sw,sh=(crop[k] for k in ('x','y','width','height','sampling_width','sampling_height'))
 g['20']=node('ImageCrop','CROP_SOURCE_CONTEXT',image=['1',0],x=x,y=y,width=w,height=h)
 g['21']=node('ImageScale','UPSCALE_CROP_FOR_FILL',image=['20',0],upscale_method='lanczos',width=sw,height=sh,crop='disabled')
 g['22']=node('CropMask','CROP_PAINT_MASK',mask=['2',0],x=x,y=y,width=w,height=h)
 g['23']=node('MaskToImage','CROP_MASK_IMAGE',mask=['22',0])
 g['24']=node('ImageScale','UPSCALE_PAINT_MASK',image=['23',0],upscale_method='nearest-exact',width=sw,height=sh,crop='disabled')
 g['25']=node('ImageToMask','FILL_PAINT_MASK',image=['24',0],channel='red')
 g['11']['inputs'].update(pixels=['21',0],mask=['25',0])
 g['26']=node('ImageScale','DOWNSCALE_GENERATED_PATCH',image=['13',0],upscale_method='lanczos',width=w,height=h,crop='disabled')
 g['27']=node('ImageCompositeMasked','RAW_PATCH_IN_FULL_IMAGE',destination=['1',0],source=['26',0],x=x,y=y,resize_source=False)
 g['28']=node('ImageCompositeMasked','RESTORED_PAINT_ONLY',destination=['1',0],source=['26',0],mask=['22',0],x=x,y=y,resize_source=False)
 g['15']['inputs']['images']=['27',0];g['16']['inputs']['images']=['28',0]
 g['30']=node('SaveImage','OUT_CROP_NATIVE_1024',images=['13',0],filename_prefix='ComfyProductPipeline/whole_photo_v5/crop_native')
 options=info['ImageToMask']['input']['required']['channel'];allowed=options[1].get('options',[]) if options[0]=='COMBO' else options[0]
 if 'red' not in allowed:raise ValueError('ImageToMask red channel unavailable')
 checks=check_graph(g,info);workflow=ui(g,info,'Crop-context Q6 Fill','整只碗同一原片裁切、等比放大；本地图生成后缩回原坐标，原始裁切mask限制回填；图像待视觉审核。')
 for n in workflow['nodes']:
  if n['id'] in range(20,31):n['pos']=[(n['id']-20)*410,1900 if n['id']<=25 else 2300]
 workflow['last_node_id']=max(n['id'] for n in workflow['nodes'])
 return g,workflow,geometry,checks

def preview(base_path,paint_path,crop,outdir):
 geometry=validate_crop(crop,paint_path);out=Path(outdir);out.mkdir(parents=True,exist_ok=True);source=Image.open(base_path).convert('RGB');mask=Image.open(paint_path).convert('L')
 if source.size!=(1024,1024):raise ValueError('source base must be 1024×1024')
 box=tuple(geometry['crop_xyxy']);size=crop['sampling_width'];im=source.crop(box).resize((size,size),Image.Resampling.LANCZOS);m=mask.crop(box).resize((size,size),Image.Resampling.NEAREST);red=Image.new('RGBA',im.size,(255,0,0,0));red.putalpha(m.point(lambda v:round(v*.42)));overlay=Image.alpha_composite(im.convert('RGBA'),red).convert('RGB')
 # Label is outside the image so no source content is hidden.
 canvas=Image.new('RGB',(size,size+36),'white');canvas.paste(overlay,(0,36));ImageDraw.Draw(canvas).text((10,10),'MASK OVERLAY - INPUT PREVIEW - NOT INFERENCE',fill='black')
 im.save(out/f'source_crop_{size}_preview.png');canvas.save(out/'source_crop_mask_overlay_preview.png');(out/'geometry.json').write_text(json.dumps({'status':'preprocessing_preview_not_inference',**geometry},ensure_ascii=False,indent=2));return geometry
