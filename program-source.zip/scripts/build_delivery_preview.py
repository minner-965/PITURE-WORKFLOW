#!/usr/bin/env python3
"""Manifest-led previews; PNG/JPG pairs are one deliverable."""
import qa_state
import html,os
from pathlib import Path
from urllib.parse import quote
from PIL import Image,ImageDraw
from compose_scene import OUT,read_csv

GROUPS=[('main','主图','main'),('detail','详情模块','detail'),('sku','采购规格图','sku'),('white_by_color','各色白底图','colors'),('extra','多碗白底附加图','extra')]

def href(path):
    return quote(os.path.relpath(path,OUT),safe='/')
def target(row):
    raw=row.get('reused_from') if row.get('status')=='reused' and row.get('reused_from') else row.get('planned_path')
    if not raw: return None
    p=Path(raw); return p if p.is_absolute() else OUT/p

def make_sheet(files,path):
    cols=3; cellw=300; cellh=345; sheet=Image.new('RGB',(cols*cellw,((len(files)+cols-1)//cols)*cellh),'white'); d=ImageDraw.Draw(sheet)
    for i,p in enumerate(files):
        with Image.open(p) as src: im=src.convert('RGB')
        im.thumbnail((280,300),Image.Resampling.LANCZOS); x=(i%cols)*cellw+(cellw-im.width)//2; y=(i//cols)*cellh; sheet.paste(im,(x,y)); d.text(((i%cols)*cellw+5,y+305),p.stem[:38],fill='black')
    sheet.save(path,quality=90)

def main():
    manifest=OUT/'manifest.csv'; rows=read_csv(manifest) if manifest.is_file() else []
    relevant=[r for r in rows if r.get('role') in {g[0] for g in GROUPS}]
    passed=lambda r: not qa_state.issues(r['deliverable_id'])
    complete=bool(relevant) and all(passed(r) and target(r) and target(r).is_file() for r in relevant)
    label='全部已审' if complete else '待审'; sections=[]; preview=OUT/'05_preview'; preview.mkdir(parents=True,exist_ok=True)
    for role,title,key in GROUPS:
        group=[r for r in rows if r.get('role')==role]; present=[(r,target(r)) for r in group if target(r) and target(r).is_file()]
        reviewed=sum(passed(r) for r,p in present); cards=[]
        for r,p in present:
            url=html.escape(href(p),quote=True); master=p.with_suffix('.png'); png=f' · <a href="{html.escape(href(master),quote=True)}">PNG 母版</a>' if master.is_file() else ''
            status='已审' if passed(r) else '已退回' if r.get('qa_result')=='visual_rejected' else '待审'; name=html.escape(r.get('deliverable_id') or p.stem)
            cards.append(f'<figure><a href="{url}"><img loading="lazy" src="{url}" alt="{name}"></a><figcaption>{name} · {status}<br><a href="{url}">查看 JPG</a>{png}</figcaption></figure>')
        sections.append(f'<section><h2>{title}</h2><p>已有 {len(present)} / 计划 {len(group)} · 已审 {reviewed}</p><div class="grid">'+''.join(cards)+'</div></section>')
        approved_files=[p for r,p in present if passed(r)]
        if approved_files: make_sheet(approved_files,preview/f'{key}_overview.jpg')
        elif (preview/f'{key}_overview.jpg').exists(): (preview/f'{key}_overview.jpg').unlink()
    doc='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>w1125 商品图预览</title><style>body{font:16px/1.6 -apple-system,BlinkMacSystemFont,sans-serif;background:#f6f5f1;margin:0;color:#26332b}main{max-width:1200px;margin:auto;padding:clamp(16px,4vw,48px)}h1{font-size:clamp(26px,5vw,38px)}h2{margin:0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,210px),1fr));gap:18px}section{margin:36px 0}figure{margin:0;background:white;border-radius:12px;padding:12px;min-width:0}img{display:block;width:100%;height:220px;object-fit:contain}figcaption{padding:10px 3px;overflow-wrap:anywhere}a{color:#325b48}p{color:#596a60}@media(max-width:480px){.grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}img{height:150px}figure{padding:8px}figcaption{font-size:14px}}</style><main>'''
    (OUT/'index.html').write_text(doc+f'<h1>w1125 商品图预览</h1><p>审核状态：{label}</p>'+''.join(sections)+'</main></html>',encoding='utf-8')
if __name__=='__main__': main()
