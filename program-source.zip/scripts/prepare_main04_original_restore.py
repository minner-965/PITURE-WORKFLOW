#!/usr/bin/env python3
"""Prepare or explicitly run a CPU ComfyUI original-pixel restore; no model nodes."""
import argparse,hashlib,json,subprocess,sys,shutil
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
from PIL import Image,PngImagePlugin
from build_workflows import node,check_graph,ui
from comfy_client import ComfyClient,sync_ui
from original_region_restore import validate_restore
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'work/diagnostics/whole_photo_v5/MAIN04_final_restore';PREP=ROOT/'work/diagnostics/whole_photo_v5/MAIN04_v2/pumpkin_repair_crop_v3/prep.json';PARENT='34ad9fbb-e4c5-4492-a038-85e6e2b68c24'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def prepare():
 d=json.loads(PREP.read_text());verified=validate_restore(str(PREP),sha(PREP))
 expected={'parent_exact_sha256':'b649922fe32e4a5a5a1f40b61dc5ef8a8a84531778504ad4892f0c5b7aa4ad10','base_sha256':'eb8f0ce27a9afef33378c9a546b7c4bca245cae79d4fe33e01c87bdc82542b94','restore_mask_sha256':'b2061e809aea3583cf2921f29b5076d16bec9cbdaaa3964843e5d65b97b9d3ed'}
 if any(d.get(k)!=v for k,v in expected.items()) or d['parent_prompt_id']!=PARENT:raise ValueError('Unexpected source identity')
 D.mkdir(parents=True,exist_ok=True);m=np.asarray(Image.open(d['restore_mask']).convert('L'))>0
 if int(m.sum())!=10140:raise ValueError('Unexpected restore mask area')
 binary=D/'restore_binary.png';inverse=D/'restore_binary_inverse.png';Image.fromarray(m.astype('uint8')*255).save(binary);Image.fromarray((~m).astype('uint8')*255).save(inverse)
 graph={'1':node('LoadImage','父Q6食品实拍',image='PENDING_UPLOAD_PARENT.png'),'2':node('LoadImage','原摄影base',image='PENDING_UPLOAD_ORIGINAL.png'),'3':node('LoadImageMask','二值原内腔恢复蒙版',image='PENDING_UPLOAD_MASK.png',channel='red'),'4':node('ImageCompositeMasked','只恢复原蓝碗内腔',destination=['1',0],source=['2',0],mask=['3',0],x=0,y=0,resize_source=False),'5':node('SaveImage','输出确定性原片恢复',images=['4',0],filename_prefix='ComfyProductPipeline/whole_photo_v5/MAIN04_original_restore')}
 info=json.loads((ROOT/'work/diagnostics/object_info.json').read_text());checks=check_graph(graph,info);workflow=ui(graph,info,'MAIN04 原内腔确定性恢复','食品来自之前Q6结果；本支仅将失败蓝碗内腔恢复到原摄影像素，不生成食品。真实输出需核对内外区及parent链。')
 identity={'stage_kind':'deterministic_original_restore','source_path':d['base'],'source_sha256':d['base_sha256'],'base_path':d['parent_exact'],'base_sha256':d['parent_exact_sha256'],'paint_path':str(binary),'paint_sha256':sha(binary),'paste_path':str(inverse),'paste_sha256':sha(inverse),'parent_prompt_id':PARENT,'parent_exact_sha256':d['parent_exact_sha256'],'original_mask_path':d['restore_mask'],'original_mask_sha256':d['restore_mask_sha256'],'reference_reset_path':d['reset_output'],'reference_reset_sha256':d['reset_output_sha256'],'source_prep':str(PREP),'source_prep_sha256':sha(PREP)}
 for n,obj in [('identity.json',identity),('prepared.api.json',graph),('prepared.ui.json',workflow),('schema_checks.json',checks)]:save(D/n,obj)
 print('Prepared deterministic workflow:',D)
def run():
 # Explicit separate entry point; this script is not run by --prepare.
 identity=json.loads((D/'identity.json').read_text());g=json.loads((D/'prepared.api.json').read_text());u=json.loads((D/'prepared.ui.json').read_text())
 for p,k in [('source_path','source_sha256'),('base_path','base_sha256'),('paint_path','paint_sha256'),('paste_path','paste_sha256'),('original_mask_path','original_mask_sha256'),('reference_reset_path','reference_reset_sha256'),('source_prep','source_prep_sha256')]:
  if sha(identity[p])!=identity[k]:raise ValueError('Input changed: '+p)
 if (D/'submission.json').exists():raise ValueError('Existing submission record; inspect instead of resubmitting')
 c=ComfyClient();info=c.get('/object_info');g['1']['inputs']['image']=c.upload(identity['base_path']);g['2']['inputs']['image']=c.upload(identity['source_path']);g['3']['inputs']['image']=c.upload(identity['paint_path']);check_graph(g,info);u=sync_ui(g,u,info);save(D/'actual.api.json',g);save(D/'actual.ui.json',u);pid=c.submit(g,u,D/'submission.json');backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());history,measurement=c.wait(pid,D,backend);files=c.download(history,D/'downloads');saved=Path(files['5'][0]);out=D/'exact.png';out.write_bytes(saved.read_bytes())
 original=np.asarray(Image.open(identity['source_path']).convert('RGB'));parent=np.asarray(Image.open(identity['base_path']).convert('RGB'));arr=np.asarray(Image.open(out).convert('RGB'));ref=np.asarray(Image.open(identity['reference_reset_path']).convert('RGB'));mask=np.asarray(Image.open(identity['paint_path']).convert('L'))>0
 if any(x.shape!=(1024,1024,3) for x in (original,parent,arr,ref)) or mask.shape!=(1024,1024):raise ValueError('Dimensions invalid')
 def check(target,region):
  d=np.abs(arr.astype('int16')-target.astype('int16')).max(2)[region];return {'pixels':int(region.sum()),'different_pixels':int(np.count_nonzero(d)),'max_abs_difference':int(d.max())}
 inside=check(original,mask);outside=check(parent,~mask);reference=check(ref,np.ones(mask.shape,bool))
 if inside['pixels']!=10140 or outside['pixels']!=1038436 or any(c['different_pixels'] for c in (inside,outside,reference)):raise ValueError('Restore verification failed')
 report={'status':'awaiting_root_visual_review','stage_kind':'deterministic_original_restore','identity':identity,'prompt_id':pid,'outputs':{'exact':{'path':str(out),'sha256':sha(out)}},'pixel_checks':{'exact':outside},'original_restore':{'source_path':identity['source_path'],'source_sha256':identity['source_sha256'],'original_mask_path':identity['original_mask_path'],'original_mask_sha256':identity['original_mask_sha256'],'binary_mask_path':identity['paint_path'],'binary_mask_sha256':identity['paint_sha256'],'inside':inside,'outside':outside,'reference':reference},'measurements':measurement,'history':str(D/'history.json'),'actual_api':str(D/'actual.api.json'),'actual_ui':str(D/'actual.ui.json'),'note':'No model or KSampler; deterministic original pixel restoration, not new food generation.'}
 save(D/'result.json',report);print('Completed restore',out)
def finalize_existing():
 # Read the already completed Comfy request and perform no HTTP operation.
 identity=json.loads((D/'identity.json').read_text());history=json.loads((D/'history.json').read_text());submission=json.loads((D/'submission.json').read_text());pid='999e6f77-9ed2-49e9-b989-c39d28e907d5'
 if submission.get('prompt_id')!=pid or history.get('prompt',[None,None])[1]!=pid or history.get('status',{}).get('status_str')!='success' or history.get('status',{}).get('completed') is not True:raise ValueError('Saved prompt/history does not show the expected successful request')
 for p,k in [('source_path','source_sha256'),('base_path','base_sha256'),('paint_path','paint_sha256'),('paste_path','paste_sha256'),('original_mask_path','original_mask_sha256'),('reference_reset_path','reference_reset_sha256'),('source_prep','source_prep_sha256')]:
  if sha(identity[p])!=identity[k]:raise ValueError('Input changed: '+p)
 images=history.get('outputs',{}).get('5',{}).get('images',[])
 if len(images)!=1:raise ValueError('Expected one saved Comfy output')
 raw_download=D/'downloads'/('5_0_'+images[0]['filename'])
 if not raw_download.is_file() or sha(raw_download)!=sha(D/'exact.png'):raise ValueError('Downloaded Comfy output missing or differs from existing failed output')
 with Image.open(raw_download) as im:
  metadata={k:v for k,v in im.info.items() if isinstance(v,str)};raw=np.asarray(im.convert('RGB'))
 if 'prompt' not in metadata or 'workflow' not in metadata:raise ValueError('Comfy prompt/workflow metadata missing')
 source=np.asarray(Image.open(identity['source_path']).convert('RGB'));parent=np.asarray(Image.open(identity['base_path']).convert('RGB'));reference=np.asarray(Image.open(identity['reference_reset_path']).convert('RGB'));origmask=np.asarray(Image.open(identity['original_mask_path']).convert('L'));binary=np.asarray(Image.open(identity['paint_path']).convert('L'))
 if any(a.shape!=(1024,1024,3) for a in (raw,source,parent,reference)) or binary.shape!=(1024,1024) or origmask.shape!=binary.shape:raise ValueError('Dimensions invalid')
 if not np.array_equal(binary,(origmask>0).astype('uint8')*255):raise ValueError('Binary mask differs from original nonzero support')
 mask=binary>0
 if int(mask.sum())!=10140 or int((~mask).sum())!=1038436:raise ValueError('Unexpected mask region size')
 def compare(a,b,region):
  diff=np.abs(a.astype('int16')-b.astype('int16')).max(2)[region];return {'pixels':int(region.sum()),'different_pixels':int(np.count_nonzero(diff)),'max_abs_difference':int(diff.max())}
 raw_inside=compare(raw,source,mask);raw_outside=compare(raw,parent,~mask)
 if raw_inside['max_abs_difference']>1 or raw_outside['different_pixels']!=0:raise ValueError('Comfy output exceeds allowed quantization discrepancy or changed outside')
 corrected=raw.copy();corrected[mask]=source[mask];inside=compare(corrected,source,mask);outside=compare(corrected,parent,~mask);ref=compare(corrected,reference,np.ones(mask.shape,bool))
 if any(v['different_pixels'] for v in (inside,outside,ref)):raise ValueError('Integer correction did not reproduce exact source/reference pixels')
 floatfile=D/'comfy_float_output.png';exact=D/'exact_integer_restored.png'
 if floatfile.exists() or exact.exists() or (D/'result.json').exists():raise ValueError('Finalization outputs already exist; inspect rather than overwrite')
 shutil.copy2(raw_download,floatfile)
 post={'method':'integer_original_pixel_restore','reason':'Comfy float-to-PNG rounding changed some source bytes by one level','mask_sha256':identity['paint_sha256'],'original_sha256':identity['source_sha256'],'comfy_raw_sha256':sha(floatfile),'float_rounding_different_pixels':raw_inside['different_pixels'],'float_rounding_max_diff':raw_inside['max_abs_difference'],'changed_region_pixels':int(mask.sum())}
 info=PngImagePlugin.PngInfo()
 for k,v in metadata.items():info.add_itxt(k,v)
 info.add_itxt('postprocess_provenance',json.dumps(post,ensure_ascii=False));Image.fromarray(corrected).save(exact,pnginfo=info)
 saved=np.asarray(Image.open(exact).convert('RGB'))
 if not np.array_equal(saved,corrected):raise ValueError('Saved exact bytes failed pixel verification')
 report={'status':'awaiting_root_visual_review','stage_kind':'deterministic_original_restore','identity':identity,'prompt_id':pid,'outputs':{'comfy_raw':{'path':str(floatfile),'sha256':sha(floatfile)},'exact':{'path':str(exact),'sha256':sha(exact)}},'pixel_checks':{'exact':outside},'original_restore':{'source_path':identity['source_path'],'source_sha256':identity['source_sha256'],'original_mask_path':identity['original_mask_path'],'original_mask_sha256':identity['original_mask_sha256'],'binary_mask_path':identity['paint_path'],'binary_mask_sha256':identity['paint_sha256'],'raw_inside':raw_inside,'raw_outside':raw_outside,'inside':inside,'outside':outside,'reference':ref},'postprocess':post,'measurements':json.loads((D/'measurements.json').read_text()),'history':str(D/'history.json'),'actual_api':str(D/'actual.api.json'),'actual_ui':str(D/'actual.ui.json'),'note':'Comfy original restore followed by CPU integer pixel restoration; no model or new food generation.'}
 save(D/'result.json',report)
 failure=D/'failure.json';existing=json.loads(failure.read_text());existing['resolved_by']={'result':str(D/'result.json'),'exact':str(exact),'time_utc':datetime.now(timezone.utc).isoformat(),'note':'Historical initial float-save check failure retained; corrected by integer original-pixel restoration.'};save(failure,existing);print('Finalized existing restore without API submission:',exact)
def main():
 p=argparse.ArgumentParser();g=p.add_mutually_exclusive_group(required=True);g.add_argument('--prepare',action='store_true');g.add_argument('--run',action='store_true');g.add_argument('--finalize-existing',action='store_true');a=p.parse_args();prepare() if a.prepare else finalize_existing() if a.finalize_existing else run()
if __name__=='__main__':main()
