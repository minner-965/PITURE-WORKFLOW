#!/usr/bin/env python3
"""Copy a validated batch to an existing mounted directory, READY last."""
import argparse, json, os, subprocess
from pathlib import Path
from export_video_assets import sha, validate_batch

def push(source,destination):
 if not str(destination).strip(): raise ValueError('destination is empty')
 source=Path(source).resolve(strict=True); base=Path(destination).resolve(strict=True)
 if not base.is_dir(): raise ValueError('destination must be an existing directory')
 manifest,ready=validate_batch(source); name=manifest['batch_id']; dest=base/name
 if dest.resolve()==source or dest.resolve().is_relative_to(source) or source.is_relative_to(dest.resolve()): raise ValueError('source and destination overlap')
 if dest.is_symlink(): raise ValueError('destination batch is a symlink')
 dest.mkdir(exist_ok=True)
 mp=dest/'manifest.json'; done=dest/'READY.json'
 if mp.exists() and sha(mp)!=ready['manifest_sha256']: raise ValueError('destination has a different manifest')
 if done.exists():
  validate_batch(dest,receiver_strict=True)
  if sha(mp)!=ready['manifest_sha256']: raise ValueError('destination has a different batch')
  return dest
 # A partial transfer may be resumed; unexpected or changed files are rejected.
 expected={a['relative_path']:a for a in manifest['assets']}
 for f in dest.rglob('*'):
  if f.is_symlink(): raise ValueError('destination contains a symlink')
  if f.is_file():
   rel=f.relative_to(dest).as_posix()
   if rel=='manifest.json': continue
   if rel not in expected: raise ValueError('destination contains unlisted file: '+rel)
   # rsync --partial can leave incomplete target files; they are replaced by rsync.
 def sync(src,dst): subprocess.run(['rsync','-a','--partial',str(src),str(dst)],check=True)
 (dest/'files').mkdir(exist_ok=True);sync(str(source/'files')+'/',str(dest/'files')+'/')
 for rel,a in expected.items():
  f=dest/rel
  if not f.is_file() or f.stat().st_size!=a['byte_size'] or sha(f)!=a['sha256']: raise ValueError('destination file mismatch: '+rel)
 sync(source/'manifest.json',dest/'manifest.json');validate_batch(dest,False)
 sync(source/'READY.json',dest/'READY.json');validate_batch(dest,receiver_strict=True)
 return dest
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--destination',required=True);a=p.parse_args();print(push(a.source,a.destination))
