#!/usr/bin/env python3
"""Record 24 logical deliverables, without inferring visual approval from files."""
import csv,json
import qa_state
from pathlib import Path
from PIL import Image
R=Path(__file__).resolve().parents[1];OUT=R/'output/LISTING_V3/w1125'
fields=['deliverable_id','role','product_family','scene_id','color_ids','sku_ids','dish_ids','source_asset_ids','planned_path','width','height','status','derived_from','source_files','dependency_status','qa_result','qa_effective','blocker']
with (R/'config/product_assets.csv').open(encoding='utf-8-sig',newline='') as f: assets={x['color_id']:x for x in csv.DictReader(f)}
with (R/'config/skus.csv').open(encoding='utf-8-sig',newline='') as f: skus=list(csv.DictReader(f))
approval_path=R/'config/qa_approvals.json'; approvals=json.loads(approval_path.read_text()) if approval_path.exists() else {}
rows=[]
def add(id,role,path,scene='',colors='',sku='',dish='',reuse='',white=False,blocker=''):
    path=OUT/path;exists=path.is_file();ok=exists and approvals.get(id,{}).get("status")=="passed"
    width=height=''
    if exists:
        try:
            with Image.open(path) as im: width,height=im.size;im.verify()
        except (OSError,ValueError): exists=False;ok=False;blocker=(blocker+'; ' if blocker else '')+'文件读取失败'
    elif role in ('main','sku','white_by_color','extra'):width=height=800
    elif role=='detail':width=750
    entry=approvals.get(id,{}) if isinstance(approvals,dict) else {}
    rejected=exists and isinstance(entry,dict) and entry.get('status')=='visual_rejected'
    status=('visual_rejected' if rejected else 'derived_from_existing_photo' if white and exists else 'passed' if ok else 'pending_review' if exists else 'pending')
    qa=entry.get('status','pending_review')
    rows.append(dict(deliverable_id=id,role=role,product_family='w1125',scene_id=scene,color_ids=colors,sku_ids=sku,dish_ids=dish,planned_path=str(path),width=width,height=height,status=status,derived_from="",source_files=reuse,dependency_status="",qa_result=qa,blocker=blocker))
for n,name in enumerate(['restaurant_multi','all_colors_filled','food_uses','texture_scene','white'],1):
    add(f'MAIN_{n:02}','main',f'01_main/main_{n:02}_{name}.jpg',scene=f'MAIN_{n:02}')
for n in range(1,9):add(f'D{n:02}','detail',f'02_detail/modules/D{n:02}.jpg',scene=f'DETAIL_{n:02}')
for s in skus:add(s['sku_id'],'sku',f"03_sku/{s['sku_id']}.jpg",colors=s['color_id'],sku=s['sku_id'],blocker='批量采购；起订量及箱数未定')
for s in skus:
    color=s['color_id'];add(f'WHITE_{color.upper()}','white_by_color',f'04_white_by_color/{color}.jpg',colors=color,reuse=assets[color]['source_photo'],white=True)
add('EXTRA_01','extra','06_extra/extra_01_multi_bowl_white.jpg',colors='red|orange|green|yellow|blue',blocker='旧双碗草稿未满足三色以上规范；本项为唯一条件附加图')
assert len(rows)==24
# Prefer render metadata; use the explicit layout when no rendered metadata exists.
def enrich(row):
    scene=row['scene_id']; path=Path(row['planned_path']); meta=path.with_suffix('.json')
    layout=None
    if scene.startswith('MAIN_') and scene[-2:].isdigit():layout=R/f'layouts/main_{scene[-2:]}.json'
    elif scene.startswith('DETAIL_') and scene[-2:].isdigit():layout=R/f'layouts/detail_{scene[-2:]}.json'
    doc=json.loads(meta.read_text()) if meta.is_file() else json.loads(layout.read_text()) if layout and layout.is_file() else {}
    if row['deliverable_id']=='MAIN_05' and doc.get('pure_copy') and isinstance(doc.get('reused_from'),dict):row['source_files']=doc['reused_from'].get('jpg','')
    items=doc.get('assets',doc.get('items',[]))
    def values(key):return '|'.join(sorted({str(x[key]) for x in items if x.get(key)}))
    if items:
        row['color_ids']=values('color_id') or row['color_ids']
        row['dish_ids']=values('dish_id') or row['dish_ids']
        row['source_asset_ids']=values('asset_id')
    else:row.setdefault('source_asset_ids','')
    return row
for row in rows:
    enrich(row)
    ident=row['deliverable_id']
    row['derived_from']={'MAIN_05':'WHITE_RED','D01':'MAIN_02','D08':'MAIN_03'}.get(ident,'')
    meta=Path(row['planned_path']).with_suffix('.json')
    if meta.is_file():
        doc=json.loads(meta.read_text())
        sources=[x.get('path','') for x in doc.get('sources',[]) if isinstance(x,dict) and x.get('path')]
        if sources: row['source_files']=';'.join(sources)
        elif doc.get('source_path'): row['source_files']=doc['source_path']
    if row['role']=='sku':
        row['source_files']=str(Path(assets[row['color_ids']]['rgba_empty']).resolve())
    if ident in ('D03','D07','EXTRA_01'):
        row['source_files']=';'.join(str(R/x['rgba_empty']) if not Path(x['rgba_empty']).is_absolute() else x['rgba_empty'] for x in assets.values() if x.get('rgba_empty'))
    if ident in ('D04','D05','D06'):
        names={'D04':['IMG_1075.jpg','IMG_1078.jpg'],'D05':['IMG_1076.jpg'],'D06':['IMG_1082.jpg','IMG_1078.jpg']}[ident]
        row['source_files']=';'.join(str(R/'input/supplied_20261102/测试品/sku实拍'/n) for n in names)
    if ident=='D02': row['dependency_status']='root_confirmed_sources' if qa_state.independent_sources_valid(row,approvals.get(ident,{})) else '待核实'


manifest_by_id={row['deliverable_id']:row for row in rows}
for row in rows:
    row['qa_effective']='passed' if not qa_state.issues(row['deliverable_id'],approvals,manifest_by_id) else 'blocked'
for dest in [R/'delivery_manifest.csv',OUT/'manifest.csv']:
    with dest.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
print('24 logical deliverables:',{s:sum(x['status']==s for x in rows) for s in sorted(set(x['status'] for x in rows))})
