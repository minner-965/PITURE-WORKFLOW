import argparse,copy,hashlib,json,subprocess,time
from pathlib import Path
import yaml
from comfy_client import ComfyClient,sync_ui
from build_workflows import make_a, node, check_graph, ui
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/LISTING_V3/w1125/assets/backgrounds'
LOG=ROOT/'work/logs/listing_v3'
PROMPTS={
'BG01_restaurant':'Photorealistic commercial tableware photography background inside a Cantonese restaurant. A broad, clean, light to medium warm wood tabletop occupies the lower 80 percent of the frame as one continuous empty surface, with enough usable depth for serving bowls in three rows. Camera at approximately 35 degree downward angle. Soft light from the upper front left. In only the upper 20 percent, clearly recognizable yet softly blurred Cantonese restaurant seating and service area. Neutral warm low saturation lighting. No foreground bowls, no food, no utensils, no people, no text, no logos, no watermark.',
'BG02_dessert':'An empty broad light oak tabletop, photographed from a high oblique angle, close-up of the completely bare smooth wooden surface. The empty tabletop fills the lower eighty percent of a square photograph, stretching beyond the left and right edges with no visible front edge. At the very top a softly defocused modern Cantonese dessert shop counter, softly lit in neutral tones. Soft diffused daylight from upper front left. The entire foreground is vacant and uninterrupted wood grain, ready for a product photoshoot. Real commercial interior photograph, neutral whites, gentle realistic contrast.',
'BG01_restaurant_r2':'An empty broad light oak tabletop, photographed from a high oblique angle, close-up of the completely bare smooth wooden surface. The empty tabletop fills the lower eighty percent of a square photograph, stretching beyond the left and right edges with no visible front edge. At the very top a softly defocused modern Cantonese restaurant interior, a few chairs and warm neutral windows. Soft diffused daylight from upper front left. The entire foreground is vacant and uninterrupted wood grain, ready for a product photoshoot. Real commercial interior photograph, neutral whites, gentle realistic contrast.'}
def main():
 p=argparse.ArgumentParser();p.add_argument('--job',choices=[*PROMPTS,'BG02_dessert_masked'],default='BG01_restaurant');p.add_argument('--execute',action='store_true');p.add_argument('--base');p.add_argument('--mask');a=p.parse_args();
 if a.job=='BG02_dessert_masked':return masked_background(a)
 c=ComfyClient();info=c.get('/object_info');g=make_a()
 for k in ['2','3','14','16','17','18']:g.pop(k)
 g['1']=node('EmptyImage','EMPTY_BACKGROUND',width=1024,height=1024,batch_size=1,color=8421504)
 g['19']=node('SolidMask','FULL_CANVAS_MASK',value=1.0,width=1024,height=1024)
 g['11']['inputs']['mask']=['19',0];g['7']['inputs']['text']=PROMPTS[a.job];g['12']['inputs']['seed']=20261112 if a.job=='BG01_restaurant_r2' else (20261113 if a.job=='BG02_dessert' else 20261102);g['15']['inputs']['filename_prefix']='ComfyProductPipeline/listing_v3/'+a.job
 checks=check_graph(g,info);u=ui(g,info,'Q6 background','1024×1024; 20 steps; guidance 30; full-canvas Fill. Visual review required.')
 for suffix,data in [('api',g),('ui',u)]: (ROOT/f'workflows/BG_Q6_scene.{suffix}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
 (ROOT/'prompts/backgrounds.yaml').write_text(yaml.safe_dump(PROMPTS,allow_unicode=True,sort_keys=False))
 log=LOG/a.job;log.mkdir(parents=True,exist_ok=True);existing_submission=log/'submission.json'
 if existing_submission.exists() and json.loads(existing_submission.read_text()).get('request',{}).get('prompt')!=g:raise ValueError('Existing submission uses another workflow; use a new job revision')
 (log/'task.json').write_text(json.dumps({'job':a.job,'prompt':PROMPTS[a.job],'prompt_hash':hashlib.sha256(PROMPTS[a.job].encode()).hexdigest(),'graph':g,'checks':checks,'visual_pass':None},ensure_ascii=False,indent=2))
 print('prepared',log/'task.json',flush=True)
 if not a.execute:return
 submission=log/'submission.json';result=log/'result.json'
 if result.exists():print('already complete',result,flush=True);return
 if submission.exists():pid=c.reconcile(submission)
 else:
  q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('Queue is occupied')
  pid=c.submit(g,sync_ui(g,u,info),submission)
 print('submitted',pid,flush=True)
 backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip())
 try:
  h,m=c.wait(pid,log,backend,7200);files=c.download(h,OUT/a.job)
  import shutil
  backend_log=Path('/Users/luohuiwu/ComfyUI-Installs/E-commerce image workflow/logs/comfyui.log')
  if backend_log.is_file():shutil.copyfile(backend_log,log/'comfyui_full.log')
  record={'status':'generated_pending_review','prompt_id':pid,'files':files,'measurements':m,'visual_pass':None}
  result.write_text(json.dumps(record,ensure_ascii=False,indent=2));print('completed',json.dumps(record,ensure_ascii=False),flush=True)
 except Exception as e:
  (log/'failure.json').write_text(json.dumps({'prompt_id':pid,'error':str(e),'time':time.time()},ensure_ascii=False,indent=2));raise
def masked_background(a):
 import numpy as np
 from PIL import Image,PngImagePlugin
 if not a.base or not a.mask:raise ValueError('BG02 requires reviewed absolute background and upper-region mask paths')
 base=Path(a.base);mask=Path(a.mask)
 if not base.is_absolute() or not mask.is_absolute():raise ValueError('Use absolute paths')
 B=np.array(Image.open(base).convert('RGB'));M=np.array(Image.open(mask).convert('L'))
 if B.shape!=(1024,1024,3) or M.shape!=(1024,1024):raise ValueError('Background and mask must be 1024×1024')
 if not np.any(M) or np.any(M[307:,:]):raise ValueError('Mask must be nonempty and limited to the top 30 percent')
 hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 approval=json.loads((LOG/'BG01_restaurant_r2'/'result.json').read_text())
 if approval.get('status')!='passed' or approval.get('selected_output')!=str(base) or approval.get('selected_output_sha256')!=hashfile(base):raise ValueError('Background selected output is not the reviewed passed version')
 prompt='A small distant, softly defocused Cantonese dessert shop service counter only at the top of the frame, warm neutral interior, gentle natural daylight from upper front left, restrained neutral palette, realistic commercial interior photograph. Avoid large vessels, objects and text. Preserve the existing clean light oak tabletop.'
 identity={'base_path':str(base),'base_hash':hashfile(base),'mask_path':str(mask),'mask_hash':hashfile(mask),'prompt_hash':hashlib.sha256(prompt.encode()).hexdigest(),'seed':20261113}
 revision=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()[:20];log=LOG/'BG02_dessert_masked'/('attempt_'+revision);log.mkdir(parents=True,exist_ok=True)
 c=ComfyClient();info=c.get('/object_info');g=make_a()
 for k in ['3','14','16','17','18']:g.pop(k)
 g['1']=node('LoadImage','IN_BACKGROUND',image='ComfyProductPipeline/selected_background.png');g['19']=node('LoadImageMask','IN_UPPER_MASK',image='ComfyProductPipeline/upper_mask.png',channel='red')
 g['11']['inputs']['mask']=['19',0];g['7']['inputs']['text']=prompt;g['12']['inputs']['seed']=identity['seed'];g['15']['inputs']['filename_prefix']='ComfyProductPipeline/listing_v3/BG02_dessert_masked_'+revision
 checks=check_graph(g,info);u=ui(g,info,'Q6 masked dessert background','Only the top 30% may change; original tabletop is restored exactly and visually reviewed.')
 for suffix,data in [('api',g),('ui',u)]:(ROOT/f'workflows/BG02_masked.{suffix}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
 (log/'task.json').write_text(json.dumps({'identity':identity,'prompt':prompt,'graph':g,'checks':checks},ensure_ascii=False,indent=2));print('prepared',log/'task.json',flush=True)
 if not a.execute:return
 sub=log/'submission.json';done=log/'result.json'
 if done.exists():
  previous=json.loads(done.read_text())
  if previous.get('identity')!=identity or hashfile(Path(previous['output']))!=previous['output_sha256']:raise ValueError('Stored background does not match revision')
  print('already complete',done);return
 if sub.exists():pid=c.reconcile(sub)
 else:
  q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('Queue is occupied')
  g['1']['inputs']['image']=c.upload(base);g['19']['inputs']['image']=c.upload(mask);check_graph(g,info);synced=sync_ui(g,u,info)
  for node_id in ('1','19'):
   visual=next(n for n in synced['nodes'] if str(n['id'])==node_id)
   if visual['widgets_values'][0]!=g[node_id]['inputs']['image']:raise ValueError('UI/API upload mismatch')
  (log/'ui_api_validation.json').write_text(json.dumps({'status':'passed','uploaded_inputs':{k:g[k]['inputs']['image'] for k in ('1','19')}},ensure_ascii=False,indent=2));pid=c.submit(g,synced,sub)
 print('submitted',pid,flush=True)
 backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip())
 try:
  history,measure=c.wait(pid,log,backend,7200);files=c.download(history,log/'downloads');raw=np.array(Image.open(files['15'][0]).convert('RGB'));mix=M.astype('float32')[:,:,None]/255
  import shutil
  backend_log=Path('/Users/luohuiwu/ComfyUI-Installs/E-commerce image workflow/logs/comfyui.log')
  if backend_log.is_file():shutil.copyfile(backend_log,log/'comfyui_full.log')
  pixels=np.rint(B*(1-mix)+raw*mix).clip(0,255).astype('uint8');pixels[M==0]=B[M==0]
  request=json.loads(sub.read_text())['request'];out=OUT/('BG02_dessert_masked_'+revision+'.png');meta=PngImagePlugin.PngInfo();meta.add_text('prompt',json.dumps(request['prompt'],ensure_ascii=False));meta.add_text('workflow',json.dumps(request['extra_data']['extra_pnginfo']['workflow'],ensure_ascii=False));Image.fromarray(pixels).save(out,pnginfo=meta)
  decoded=np.array(Image.open(out).convert('RGB'));diff=np.abs(decoded.astype('int16')-B.astype('int16'))[M==0];report={'status':'generated_pending_review','identity':identity,'prompt_id':pid,'files':files,'output':str(out),'selected_output':str(out),'selected_output_provenance':str(out.with_suffix('.json')),'output_sha256':hashfile(out),'raw_output':files['15'][0],'raw_output_sha256':hashfile(Path(files['15'][0])),'protected_count':int((M==0).sum()),'protected_diff_max':int(diff.max()),'protected_diff_count':int(np.any(diff,axis=1).sum()),'measurements':measure,'visual_pass':None}
  if report['protected_diff_max']!=0:raise ValueError('Saved background failed protected pixel check')
  done.write_text(json.dumps(report,ensure_ascii=False,indent=2));out.with_suffix('.json').write_text(json.dumps({'identity':identity,'request':request,'report':report},ensure_ascii=False,indent=2));print('completed',out,flush=True)
 except Exception as e:
  (log/'failure.json').write_text(json.dumps({'prompt_id':pid,'error':str(e),'time':time.time()},ensure_ascii=False,indent=2));raise
if __name__=='__main__':main()
