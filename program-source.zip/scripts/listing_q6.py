#!/usr/bin/env python3
"""Render reviewed scenes using layouts as the sole selection source."""
import hashlib,json,os,shutil
from pathlib import Path
from PIL import Image
from compose_scene import ROOT,OUT,read_csv,render,export
NAMES={'main_01':'main_01_restaurant_multi','main_02':'main_02_all_colors_filled','main_03':'main_03_food_uses','main_04':'main_04_texture_scene'}
BACKGROUND_JOBS={'BG01_restaurant.png':'BG01_restaurant_r2','BG02_dessert.png':'BG02_dessert_masked'}

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def background_record(job):
    directory=ROOT/'work/logs/listing_v3'/job
    candidates=sorted(directory.glob('attempt_*/result.json')) if job=='BG02_dessert_masked' else [directory/'result.json']
    available=[p for p in candidates if p.is_file()]
    passed=[p for p in available if json.loads(p.read_text()).get('status')=='passed']
    if len(passed)>1: raise ValueError(f'multiple passed background attempts; choose exactly one: {job}')
    if not passed: raise ValueError(f'background awaiting unique visual pass: {job} ({len(available)} results)')
    return passed[0]

def approved_background(layout):
    destination=Path(layout['background']); destination=destination if destination.is_absolute() else ROOT/destination
    if destination.parent != OUT/'assets/backgrounds' or destination.name not in BACKGROUND_JOBS: raise ValueError(f'unrecognized background target: {destination}')
    job=BACKGROUND_JOBS[destination.name]; record=background_record(job)
    result=json.loads(record.read_text())
    if result.get('status')!='passed': raise ValueError('background awaiting visual pass: '+job)
    expected=result.get('sha256','').lower()
    if len(expected)!=64 or any(c not in '0123456789abcdef' for c in expected): raise ValueError('reviewed background sha256 missing: '+job)
    selected=result.get('selected_output')
    if selected: source=Path(selected)
    else:
        try: source=Path(result['files']['15'][0])
        except (KeyError,IndexError,TypeError): raise ValueError('background output missing: '+job)
    if not source.is_absolute(): source=ROOT/source
    if not source.is_file(): raise ValueError('background file missing: '+str(source))
    if sha256(source)!=expected: raise ValueError('background source sha256 mismatch: '+job)
    with Image.open(source) as im: im.verify()
    destination.parent.mkdir(parents=True,exist_ok=True)
    if source.resolve()!=destination.resolve():
        temp=destination.with_suffix('.copying'); shutil.copyfile(source,temp)
        if sha256(temp)!=expected: temp.unlink(missing_ok=True); raise ValueError('background copy sha256 mismatch: '+job)
        os.replace(temp,destination)
    if sha256(destination)!=expected: raise ValueError('background destination sha256 mismatch: '+job)
    return {'job':job,'record':str(record),'source':str(source),'sha256':expected,'destination':str(destination)}

def compose(name):
    layoutpath=ROOT/'layouts'/f'{name}.json'
    if not layoutpath.is_file(): raise ValueError('layout missing: '+name)
    layout=json.loads(layoutpath.read_text()); rows=read_csv(ROOT/'config/food_assets.csv'); byid={r['asset_id']:r for r in rows}
    if len(byid)!=len(rows): raise ValueError('duplicate asset_id in food inventory')
    for item in layout['items']:
        aid=item.get('asset_id'); row=byid.get(aid)
        if not row or row.get('status')!='passed': raise ValueError(f'asset awaiting visual pass: {aid}')
        if any(item.get(k)!=row.get(k) for k in ('color_id','dish_id')): raise ValueError(f'layout/food inventory mismatch: {aid}')
        if not Path(row['rgba_filled']).is_file(): raise ValueError(f'food asset file missing: {aid}')
    background=approved_background(layout); image,used=render(layout,rows)
    path=(OUT/'01_main'/NAMES[name]) if name in NAMES else (OUT/'02_detail/modules'/('D'+name[-2:]))
    export(image,path,(800,800) if name in NAMES else None)
    path.with_suffix('.json').write_text(json.dumps({'layout_file':str(layoutpath),'assets':used,'background':background,'visual_qa':'pending'},ensure_ascii=False,indent=2)); return path

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(); p.add_argument('scene',choices=sorted(NAMES)+['detail_01','detail_02','detail_08']); a=p.parse_args(); print(compose(a.scene))
