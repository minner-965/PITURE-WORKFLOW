import sys, json, subprocess, platform, shutil, importlib.metadata as md
from pathlib import Path
import requests, torch
ROOT=Path(__file__).resolve().parents[1]
COMFY=Path('/Users/luohuiwu/ComfyUI-Installs/E-commerce image workflow/ComfyUI')
CONFIG=Path('/Users/luohuiwu/Library/Application Support/Comfy Desktop/instance-model-paths/inst-1793586287285.yaml')
def cmd(*args):
    p=subprocess.run(args,capture_output=True,text=True);return p.stdout.strip() or p.stderr.strip()
def main():
    diag=ROOT/'work/diagnostics';diag.mkdir(parents=True,exist_ok=True)
    snapshots={}
    for endpoint in ('system_stats','object_info','queue'):
        r=requests.get('http://127.0.0.1:8188/'+endpoint,timeout=30);r.raise_for_status();snapshots[endpoint]=r.json();(diag/(endpoint+'.json')).write_text(json.dumps(r.json(),ensure_ascii=False,indent=2))
    packages={d.metadata['Name']:d.version for d in md.distributions()}
    env=dict(source=str(COMFY),python=sys.executable,python_version=sys.version,platform=platform.platform(),machine=platform.machine(),chip=cmd('sysctl','-n','machdep.cpu.brand_string'),memory_bytes=int(cmd('sysctl','-n','hw.memsize')),macos=cmd('sw_vers'),disk_free_bytes=shutil.disk_usage(ROOT).free,swap=cmd('sysctl','vm.swapusage'),url='http://127.0.0.1:8188',backend_pid=2783,desktop_version='1.1.8',torch=torch.__version__,mps_available=torch.backends.mps.is_available(),mps_built=torch.backends.mps.is_built(),mps_recommended_working_set_bytes=torch.mps.recommended_max_memory(),commit=cmd('git','-C',str(COMFY),'rev-parse','HEAD'),git_status=cmd('git','-C',str(COMFY),'status','--short'),startup_config=str(CONFIG),user_dir=str(COMFY/'user'),custom_nodes=str(COMFY/'custom_nodes'),system_stats=snapshots['system_stats'],gpu=cmd('system_profiler','SPDisplaysDataType'),packages=packages)
    (ROOT/'config/environment.json').write_text(json.dumps(env,ensure_ascii=False,indent=2))
    backup=ROOT/'backups/20261102-initial';backup.mkdir(exist_ok=True)
    for p in [CONFIG,COMFY/'extra_model_paths.yaml',COMFY/'user/comfyui.log']:
        if p.exists() and not (backup/p.name).exists():shutil.copy2(p,backup/p.name)
    if not (backup/'packages.json').exists():(backup/'packages.json').write_text(json.dumps(packages,indent=2))
    shutil.copy2('/Users/luohuiwu/Downloads/ComfyUI_M4_24GB_Codex执行方案.md',ROOT/'docs/archive/执行方案原文.md')
    (ROOT/'docs/环境检查.md').write_text('# 环境检查\n\n'+ '\n'.join(f'- {k}: {v}' for k,v in env.items() if k not in ['packages','system_stats'])+'\n\n启动日志和 /system_stats 均确认 Device=mps，SHARED。推荐工作集不等于空闲内存。未改 GPU 限制和 MPS 环境变量。原有 Manager 远程缓存超时/InvalidChannel 独立记录于启动日志，未因此改动推理环境。\n')
    print(json.dumps({k:v for k,v in env.items() if k not in ['packages','system_stats','gpu','git_status']},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
