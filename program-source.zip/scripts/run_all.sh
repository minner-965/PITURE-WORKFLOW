#!/bin/zsh
set -euo pipefail
project_dir="${0:A:h:h}"
comfy_python='/Users/luohuiwu/ComfyUI-Installs/E-commerce image workflow/ComfyUI/.venv/bin/python3'
# caffeinate exits with the actual serial runner. No persistent background process.
/usr/bin/caffeinate -i "$comfy_python" "$project_dir/scripts/run_scene.py" "$@"
"$comfy_python" "$project_dir/scripts/contact_sheet.py"
