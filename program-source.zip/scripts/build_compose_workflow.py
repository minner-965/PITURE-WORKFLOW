#!/usr/bin/env python3
"""Create an optional ComfyUI preview graph for manifest images; never enqueue."""
import argparse,csv,json,mimetypes
from pathlib import Path
import requests
from build_workflows import check_graph,ui,node,URL,ROOT

def main():
 p=argparse.ArgumentParser();p.add_argument('--allow-incomplete',action='store_true',help='build a partial review graph, explicitly marked pending');a=p.parse_args()
 manifest=ROOT/'output/LISTING_V3/w1125/manifest.csv'
 with manifest.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
 if len(rows)!=24:raise SystemExit(f'Expected 24 logical items, found {len(rows)}')
 missing=[r['deliverable_id'] for r in rows if not Path(r['planned_path']).is_file()]
 if missing and not a.allow_incomplete:raise SystemExit('Pending files; no workflow written or upload performed: '+', '.join(missing))
 info=requests.get(URL+'/object_info',timeout=45);info.raise_for_status();info=info.json(); graph={}; uploaded={};session=requests.Session()
 for row in rows:
  path=Path(row['planned_path'])
  if not path.is_file():continue
  with path.open('rb') as f:response=session.post(URL+'/upload/image',files={'image':(path.name,f,mimetypes.guess_type(path.name)[0] or 'application/octet-stream')},data={'type':'input','subfolder':'ComfyProductPipeline/listing_v3_preview','overwrite':'false'},timeout=60)
  response.raise_for_status();v=response.json();filename='/'.join(filter(None,[v.get('subfolder'),v['name']]));uploaded[row['deliverable_id']]=filename
  i=str(len(graph)+1);j=str(int(i)+1);source=row.get('reused_from') or str(path); extra='｜五色空碗，无Q6' if row['role']=='extra' else ''
  title=f"{row['role']}｜{row['deliverable_id']}{extra}｜来源 {source}"
  graph[i]=node('LoadImage',title,image=filename);graph[j]=node('PreviewImage',f"预览｜{row['deliverable_id']}",images=[i,0])
 check_graph(graph,info);note='分类预览入口；无推理任务。缺失：'+(', '.join(missing) if missing else '无')
 u=ui(graph,info,'商品图分类预览',note)
 for n in u['nodes']:
  if n['type']=='Note':continue
  index=(n['id']-1)//2;n['pos']=[(index%4)*850+(0 if n['id']%2 else 400),(index//4)*400]
 path=ROOT/'workflows/COMPOSE_multi_bowl';path.with_suffix('.api.json').write_text(json.dumps(graph,ensure_ascii=False,indent=2));path.with_suffix('.ui.json').write_text(json.dumps(u,ensure_ascii=False,indent=2))
 print(json.dumps({'uploaded':uploaded,'missing':missing,'queue_submitted':False},ensure_ascii=False))
if __name__=='__main__':main()
