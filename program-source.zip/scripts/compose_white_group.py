#!/usr/bin/env python3
"""Five verified empty bowl assets, on white; one deliverable, PNG and JPEG."""
import csv, json
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
from compose_scene import ROOT,OUT,asset_path,export

def main():
    with open(ROOT/'config/product_assets.csv',encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
    colors={}
    for r in rows:
        p=r.get('rgba_empty',''); c=r.get('color_id','')
        if c and p and asset_path(p).is_file(): colors.setdefault(c,r)
    if len(colors)!=5: raise ValueError(f'Expected five distinct real color cutouts; found {len(colors)}')
    canvas=Image.new('RGBA',(1600,1600),'white'); coverage=Image.new('L',(1600,1600))
    for (color,r),(cx,bottom,width) in zip(colors.items(),[(330,790,580),(800,690,580),(1270,790,580),(550,1230,670),(1080,1230,670)]):
        im=Image.open(asset_path(r['rgba_empty'])).convert('RGBA'); box=im.getchannel('A').getbbox()
        if not box: raise ValueError(f'Empty alpha for {color}')
        im=im.crop(box); im=im.resize((width,round(im.height*width/im.width)),Image.Resampling.LANCZOS)
        xy=(round(cx-width/2),bottom-im.height); canvas.alpha_composite(im,xy)
        layer=Image.new('L',(1600,1600)); layer.paste(im.getchannel('A'),xy); coverage=Image.fromarray(__import__('numpy').maximum(__import__('numpy').asarray(coverage),__import__('numpy').asarray(layer)).astype('uint8'))
    # Main 05 remains a distinct single-color, empty-bowl image.
    r=next(iter(colors.values())); src=Image.open(asset_path(r['rgba_empty'])).convert('RGBA'); src=src.crop(src.getchannel('A').getbbox()); src.thumbnail((1240,1100),Image.Resampling.LANCZOS)
    single=Image.new('RGBA',(1600,1600),'white'); single.alpha_composite(src,((1600-src.width)//2,(1600-src.height)//2)); export(single.convert('RGB'),OUT/'01_main/main_05_white',(800,800))
    path=OUT/'06_extra/extra_01_multi_bowl_white'; path.parent.mkdir(parents=True,exist_ok=True)
    coverage=coverage.resize((800,800),Image.Resampling.LANCZOS); qa=ROOT/'work/diagnostics/white_group_coverage.png'; qa.parent.mkdir(parents=True,exist_ok=True); coverage.save(qa)
    final=canvas.convert('RGB').resize((800,800),Image.Resampling.LANCZOS); arr=__import__('numpy').array(final); arr[__import__('numpy').asarray(coverage)==0]=255; final=Image.fromarray(arr); final.save(path.with_suffix('.png')); final.save(path.with_suffix('.jpg'),quality=95,subsampling=0)
    path.with_suffix('.json').write_text(json.dumps({'colors':list(colors),'visual_qa':'pending','old_draft':'two bowls; PNG only; manual alpha draft'},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
