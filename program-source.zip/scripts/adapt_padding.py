"""Replace only documented padding pixels; keep product and masks in their original coordinates."""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
from PIL import Image

def adapt(base_dir,out_dir,core_path):
    src=Path(base_dir);out=Path(out_dir)
    if out.resolve()==src.resolve():raise ValueError('Use a separate output directory to preserve the original Base')
    t=json.loads((src/'transform.json').read_text());image=Image.open(src/'Base_Image.png');rgb=np.array(image.convert('RGB'));x,y=t['padding_left_top'];w,h=t['scaled_size'];H,W=rgb.shape[:2]
    result=np.pad(rgb[y:y+h,x:x+w],((y,H-y-h),(x,W-x-w),(0,0)),mode='edge');core=np.array(Image.open(core_path).convert('L'))>=128
    if core.shape!=rgb.shape[:2] or not core.any() or not np.array_equal(rgb[core],result[core]):raise ValueError('Padding overlaps protected product or core is invalid')
    out.mkdir(parents=True,exist_ok=True);target=out/'Base_Image.png';Image.fromarray(result).save(target,icc_profile=image.info.get('icc_profile'))
    t.update(padding_mode='edge',derived_from=str((src/'Base_Image.png').resolve()),base_sha256=hashlib.sha256(target.read_bytes()).hexdigest());(out/'transform.json').write_text(json.dumps(t,ensure_ascii=False,indent=2));return target
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('base_dir');p.add_argument('out_dir');p.add_argument('core');a=p.parse_args();print(adapt(a.base_dir,a.out_dir,a.core))
