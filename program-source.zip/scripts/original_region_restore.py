#!/usr/bin/env python3
"""Verify a recorded original-region restore; never modify images or metadata."""
import hashlib,json
from pathlib import Path
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def verified_file(path,digest,label):
 p=Path(path)
 if not p.is_absolute():raise ValueError(f'{label}: expected absolute path')
 p=p.resolve()
 if not p.is_relative_to(ROOT.resolve()) or not p.is_file():raise ValueError(f'{label}: missing or outside project: {p}')
 if not isinstance(digest,str) or sha(p)!=digest:raise ValueError(f'{label}: SHA-256 missing or mismatch')
 return p
def validate_restore(prep_path,prep_sha256):
 p=verified_file(prep_path,prep_sha256,'preparation');d=json.loads(p.read_text())
 if not isinstance(d.get('parent_prompt_id'),str) or not d['parent_prompt_id']:raise ValueError('preparation missing parent_prompt_id')
 files={}
 for name in ('base','parent_exact','restore_mask','reset_output'):
  files[name]=verified_file(d[name],d[name+'_sha256'],name)
 files['paint_mask']=verified_file(d.get('new_mask_path',str(p.parent/'paint_mask.png')),d['new_mask_sha256'],'paint_mask')
 files['inverse_mask']=verified_file(d.get('inverse_mask_path',str(p.parent/'inverse_paste_mask.png')),d['inverse_mask_sha256'],'inverse_mask')
 images={}
 for name in ('base','parent_exact','reset_output'):
  with Image.open(files[name]) as im:
   if im.size!=(1024,1024):raise ValueError(f'{name}: expected 1024x1024')
   images[name]=np.asarray(im.convert('RGB'))
 masks={}
 for name in ('restore_mask','paint_mask','inverse_mask'):
  with Image.open(files[name]) as im:
   if im.size!=(1024,1024):raise ValueError(f'{name}: expected 1024x1024')
   masks[name]=np.asarray(im.convert('L'))
 inside=masks['restore_mask']>0;outside=~inside
 if not inside.any() or not outside.any():raise ValueError('restore mask must have nonempty inside and outside')
 if np.any((masks['paint_mask']>0)&outside):raise ValueError('new paint mask extends outside restore mask')
 if not np.any(masks['paint_mask']>0):raise ValueError('new paint mask is empty')
 if not np.array_equal(masks['inverse_mask'],255-masks['paint_mask']):raise ValueError('inverse paint mask mismatch')
 def compare(a,b,region):
  diff=np.abs(a.astype('int16')-b.astype('int16')).max(2)[region]
  return {'pixels':int(region.sum()),'different_pixels':int(np.count_nonzero(diff)),'max_abs_difference':int(diff.max())}
 inner=compare(images['reset_output'],images['base'],inside);outer=compare(images['reset_output'],images['parent_exact'],outside)
 if inner['different_pixels'] or outer['different_pixels']:raise ValueError('restored pixels differ from required source')
 for check,key in ((inner,'restore_inside'),(outer,'preserved_outside')):
  for field,actual in [('pixels',check['pixels']),('diff_count',check['different_pixels']),('maxdiff',check['max_abs_difference'])]:
   if d.get(key+'_'+field)!=actual:raise ValueError(f'preparation recorded {key}_{field} mismatch')
 if d.get('new_mask_nonzero_pixels')!=int(np.count_nonzero(masks['paint_mask'])) or d.get('new_mask_full_pixels')!=int(np.count_nonzero(masks['paint_mask']==255)) or d.get('new_mask_outside_original_nonzero')!=0:raise ValueError('paint mask recorded checks mismatch')
 return {'preparation_path':str(p),'preparation_sha256':sha(p),'parent_prompt_id':d['parent_prompt_id'],'parent_exact_sha256':sha(files['parent_exact']),'reset_output_sha256':sha(files['reset_output']),'paint_sha256':sha(files['paint_mask']),'paths':{k:str(v) for k,v in files.items()},'inside':inner,'outside':outer,'paint_outside_restore_pixels':0}
