#!/usr/bin/env python3
"""Prepare photographic backgrounds and conservative candidate wall masks; no inference."""
import hashlib,io,json
from pathlib import Path
import numpy as np
from scipy import ndimage
from PIL import Image,ImageOps,ImageCms,ImageDraw,ImageFilter
R=Path(__file__).resolve().parents[1];D=R/'work/diagnostics/scene_rebuild_v4/environments';D.mkdir(parents=True,exist_ok=True)
# Points describe the visible upper outline of each foreground object at 1024px.
# Close below the wall boundary; the editable mask never reaches the tabletop.
SPECS=[{'id':'BG01_restaurant','source':'IMG_5891.jpg','initial_wall_y_1200':370,'wall_y_1024':308,'objects':[
 {'name':'left_green_bowl','outline':[(80,349),(80,339),(88,331),(95,326),(98,306),(103,292),(111,282),(123,274),(141,265),(162,258),(186,254),(210,253),(234,255),(257,259),(278,266),(294,274),(305,283),(313,294),(316,305),(320,312),(328,316),(334,324)],'bottom':370},
 {'name':'rear_red_bowl','outline':[(313,293),(313,283),(320,273),(323,255),(326,241),(334,229),(347,221),(364,214),(383,210),(404,207),(428,207),(451,209),(473,214),(492,221),(506,229),(517,239),(522,249),(527,254),(533,258),(535,269),(531,281),(527,289),(523,296),(520,302),(518,308)],'bottom':370}]},
 {'id':'BG02_dessert','source':'IMG_5889.jpg','initial_wall_y_1200':440,'wall_y_1024':350,'objects':[
 {'name':'plant','outline':[(309,362),(311,351),(315,341),(314,333),(317,326),(321,323),(324,326),(325,315),(329,311),(333,313),(337,309),(341,309),(344,314),(346,307),(350,306),(354,310),(357,308),(361,309),(364,316),(369,313),(374,315),(375,322),(380,320),(385,323),(385,330),(390,330),(392,338),(392,346),(398,350)],'bottom':390},
 {'name':'rear_green_bowl','outline':[(445,316),(445,305),(450,297),(461,293),(471,292),(474,281),(480,273),(491,266),(505,260),(524,255),(544,252),(565,252),(588,254),(609,256),(629,261),(647,267),(659,274),(667,282),(672,292),(676,299),(686,301),(696,306),(701,312),(703,319),(701,326),(694,330),(684,333),(679,338),(676,344),(673,351)],'bottom':390},
 {'name':'stacked_bowls','outline':[(704,231),(705,221),(711,215),(721,211),(732,207),(735,195),(742,186),(753,179),(769,173),(789,169),(811,167),(834,166),(858,167),(881,170),(901,174),(918,181),(930,188),(937,197),(941,205),(952,208),(960,214),(965,223),(965,231),(959,239),(960,247),(964,253),(965,262),(960,271),(959,280),(961,290),(961,299),(959,308),(961,318),(960,329),(951,334),(943,338),(936,343),(930,350)],'bottom':390}]}]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
config=[]
for spec in SPECS:
 src=R/'input/supplied_20261102/测试品/详情页实拍'/spec['source'];im=Image.open(src);icc=im.info.get('icc_profile');im=ImageOps.exif_transpose(im)
 if im.size!=(4160,6240):raise ValueError(f'unexpected oriented size: {src} {im.size}')
 if icc:im=ImageCms.profileToProfile(im,ImageCms.ImageCmsProfile(io.BytesIO(icc)),ImageCms.createProfile('sRGB'),outputMode='RGB');color='embedded ICC converted to sRGB'
 else:im=im.convert('RGB');color='no ICC, assumed sRGB'
 base=im.crop((0,2080,4160,6240)).resize((1024,1024),Image.Resampling.LANCZOS);folder=D/spec['id'];folder.mkdir(exist_ok=True);basepath=folder/'base.png';base.save(basepath)
 # An inward-only feather ensures protected pixels never become editable.
 wall=Image.new('L',(1024,1024));ImageDraw.Draw(wall).rectangle((0,0,1023,spec['wall_y_1024']-1),fill=255)
 protected=Image.new('L',(1024,1024));draw=ImageDraw.Draw(protected)
 rgbpixels=np.asarray(base).astype('int16');red=rgbpixels[:,:,0];green=rgbpixels[:,:,1];blue=rgbpixels[:,:,2]
 white=((red+green+blue)/3>145)&(blue>red*.88)
 chroma=rgbpixels.max(axis=2)-rgbpixels.min(axis=2)
 colored=(chroma>45)&((green>red*1.08)|(red>green*1.20))
 detected=white|colored
 seeds={'left_green_bowl':(280,200),'rear_red_bowl':(230,420),'rear_green_bowl':(275,550),'stacked_bowls':(190,830)}
 for obj in spec['objects']:
  pts=obj['outline'];region=Image.new('L',(1024,1024));rd=ImageDraw.Draw(region)
  # Close each object through the body, rather than extending a handle vertically.
  if obj['name']=='rear_green_bowl': tail=[(672,356),(480,356),(477,340),(471,334),(459,330),(449,326)]
  elif obj['name']=='stacked_bowls': tail=[(930,356),(739,356),(735,344),(728,337),(718,332),(709,327)]
  elif obj['name']=='rear_red_bowl': tail=[(517,314),(333,314),(330,303),(322,298)]
  else:tail=[(pts[-1][0],obj['bottom']),(pts[0][0],obj['bottom'])]
  rd.polygon(pts+tail,fill=255)
  if obj['name']=='plant':
   protected=Image.fromarray(np.maximum(np.asarray(protected),np.asarray(region)));continue
  roi=np.asarray(region.filter(ImageFilter.MaxFilter(3)))>0
  candidate=ndimage.binary_closing(detected&roi,structure=np.ones((3,3)),iterations=1)
  labels,_=ndimage.label(candidate,structure=np.ones((3,3)));seed=seeds[obj['name']];label=labels[seed]
  if not label:raise ValueError(f"seed not found: {obj['name']}")
  component=ndimage.binary_fill_holes(labels==label)
  protected=Image.fromarray(np.maximum(np.asarray(protected),component.astype('uint8')*255))
 # Shadowed white handles and colored body edges fall outside simple color thresholds.
 # Supplement them with local outlines following the photographed silhouette.
 extra=ImageDraw.Draw(protected)
 if spec['id']=='BG01_restaurant':
  extra.polygon([(504,238),(518,238),(525,241),(531,245),(533,251),(528,257),(524,261),(528,267),(528,274),(523,280),(511,285),(498,284),(496,257)],fill=255)
 else:
  extra.polygon([(640,284),(668,285),(674,296),(685,300),(696,304),(701,309),(703,317),(700,325),(693,328),(684,331),(678,336),(675,344),(672,353),(638,353)],fill=255)
  extra.polygon([(912,200),(938,201),(952,207),(962,213),(965,220),(965,229),(959,236),(950,240),(940,244),(930,246),(918,245)],fill=255)
  extra.polygon([(912,239),(938,242),(951,247),(960,253),(964,259),(964,267),(959,273),(950,278),(939,281),(927,284),(915,283)],fill=255)
  extra.polygon([(912,277),(936,281),(949,286),(958,292),(961,298),(961,306),(956,313),(949,317),(940,321),(933,329),(929,354),(914,354)],fill=255)
 protected=protected.filter(ImageFilter.MaxFilter(3));raw=np.asarray(wall).copy();raw[np.asarray(protected)>0]=0
 edge=Image.fromarray(raw).filter(ImageFilter.GaussianBlur(1));soft=np.minimum(np.asarray(edge),raw).astype('uint8');mask=Image.fromarray(soft);maskpath=folder/'wall_mask_v2.png';mask.save(maskpath)
 rgb=np.asarray(base).copy();alpha=soft.astype('float32')/255*.50;overlay=rgb.astype('float32');overlay[:,:,0]=overlay[:,:,0]*(1-alpha)+255*alpha;overlay[:,:,1]*=(1-alpha);overlay[:,:,2]*=(1-alpha);Image.fromarray(overlay.astype('uint8')).save(folder/'mask_overlay_red_v2.png')
 before=Image.open(folder/'mask_overlay_red.png').convert('RGB');after=Image.fromarray(overlay.astype('uint8'));box=(70,190,550,320) if spec['id']=='BG01_restaurant' else (420,150,980,355);left=before.crop(box);right=after.crop(box);comparison=Image.new('RGB',(box[2]-box[0],2*(box[3]-box[1])));comparison.paste(left,(0,0));comparison.paste(right,(0,box[3]-box[1]));comparison.resize((1120,round(comparison.height*1120/comparison.width)),Image.Resampling.LANCZOS).save(folder/'contour_v1_v2_comparison.png')
 assert np.all(soft[spec['wall_y_1024']:]==0) and np.all(soft[np.asarray(protected)>0]==0)
 info={'id':spec['id'],'source_photo':str(src.resolve()),'source_sha256':sha(src),'oriented_size':[4160,6240],'crop_xyxy':[0,2080,4160,6240],'base_path':str(basepath.resolve()),'base_sha256':sha(basepath),'base_size':[1024,1024],'color_handling':color,'initial_wall_y_1200':spec['initial_wall_y_1200'],'initial_wall_y_1024':spec['initial_wall_y_1200']*1024/1200,'actual_conservative_wall_y_1024':spec['wall_y_1024'],'protected_objects':spec['objects'],'protection_dilation_px':1,'edge_feather_px':1,'mask_path':str(maskpath.resolve()),'mask_sha256':sha(maskpath),'overlay_path':str((folder/'mask_overlay_red_v2.png').resolve()),'mask_polarity':'white editable wall; black preserved','status':'pending_root_mask_review','note':'wall lower boundary conservatively raised to preserve wall/table junction; polygon outlines hand traced; inspect at full resolution'}
 (folder/'coordinates.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n');config.append(info)
(R/'config/photographed_environments_v4.json').write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n');print('Prepared',len(config),'1024px bases, candidate masks, overlays; no inference submitted.')
