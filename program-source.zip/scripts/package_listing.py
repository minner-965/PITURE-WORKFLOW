#!/usr/bin/env python3
"""Package only the approved 24 logical deliverables and their delivery support files."""
import argparse,csv,hashlib,importlib.util,json,os,sys,tempfile,zipfile
import qa_state
from collections import Counter
from pathlib import Path
R=Path(__file__).resolve().parents[1];OUT=(R/'output/LISTING_V3/w1125').resolve();manifest=OUT/'manifest.csv'
def image_check(p,size=None,width=None):
 with Image.open(p) as im:im.verify()
 with Image.open(p) as im:
  if size and im.size!=size:raise ValueError(f'{p}: expected {size}, got {im.size}')
  if width and im.width!=width:raise ValueError(f'{p}: expected width {width}, got {im.width}')
def provenance_files(sidecar):
 """Read explicitly referenced source records; never discover other jobs."""
 if not sidecar.is_file():return []
 data=json.loads(sidecar.read_text(encoding='utf-8'))
 refs=data.get('provenance_files',[])
 if not isinstance(refs,list):raise ValueError(f'{sidecar}: provenance_files must be a list')
 result=[]
 for raw in refs:
  if not isinstance(raw,str) or not Path(raw).is_absolute():raise ValueError(f'{sidecar}: provenance path must be absolute: {raw!r}')
  p=Path(raw).resolve()
  if not p.is_relative_to(R.resolve()) or not p.is_file():raise ValueError(f'{sidecar}: provenance must be a regular file within the project: {raw}')
  if p==OUT/'listing_package.zip':raise ValueError('The archive cannot include itself')
  result.append(p)
 return result

def project_hashed(raw,digest,label):
 if not isinstance(raw,str) or not Path(raw).is_absolute():raise ValueError(f'{label}: path must be absolute')
 p=Path(raw).resolve()
 if not p.is_relative_to(R.resolve()) or not p.is_file():raise ValueError(f'{label}: missing or outside project: {raw}')
 if not isinstance(digest,str) or hashlib.file_digest(p.open('rb'),'sha256').hexdigest()!=digest:raise ValueError(f'{label}: SHA-256 missing or mismatch')
 return p

def collect_stage_evidence(result_file):
 data=json.loads(result_file.read_text(encoding='utf-8'));identity=data['identity'];outputs=data['outputs'];collected=set()
 for key in ('source','base','paint','paste'):
  collected.add(project_hashed(identity[key+'_path'],identity[key+'_sha256'],key))
 regions=identity.get('regions',[])
 if not isinstance(regions,list):raise ValueError(f'{result_file}: invalid regions')
 for index,region in enumerate(regions):collected.add(project_hashed(region['mask_path'],region['mask_sha256'],f'region {index} mask'))
 collected.add(project_hashed(outputs['exact']['path'],outputs['exact']['sha256'],'stage exact'))
 if data.get('stage_kind')=='deterministic_original_restore' or identity.get('stage_kind')=='deterministic_original_restore':
  if data.get('stage_kind')!=identity.get('stage_kind'):raise ValueError('restore stage kind mismatch')
  restore=data['original_restore']
  if 'postprocess' in data or 'comfy_raw' in outputs:collected.add(project_hashed(outputs['comfy_raw']['path'],outputs['comfy_raw']['sha256'],'restore Comfy raw'))
  for key in ('source','original_mask','binary_mask'):collected.add(project_hashed(restore[key+'_path'],restore[key+'_sha256'],'restore '+key))
  collected.add(project_hashed(identity['reference_reset_path'],identity['reference_reset_sha256'],'restore reference'))
  collected.add(project_hashed(identity['source_prep'],identity['source_prep_sha256'],'restore source preparation'))
  collected.add(project_hashed(str((R/'scripts/prepare_main04_original_restore.py').resolve()),hashlib.file_digest((R/'scripts/prepare_main04_original_restore.py').open('rb'),'sha256').hexdigest(),'restore script'))
  for name in ('failure.json','failure_diagnostic.json'):
   f=result_file.parent/name
   if not f.is_file():raise ValueError(f'{result_file}: historical failure evidence missing: {name}')
   if name=='failure.json':
    failure=json.loads(f.read_text());resolved=failure.get('resolved_by',{})
    if Path(resolved.get('result','')).resolve()!=result_file.resolve() or Path(resolved.get('exact','')).resolve()!=Path(outputs['exact']['path']).resolve():raise ValueError('restore failure resolution does not point to this result/exact')
   collected.add(project_hashed(str(f.resolve()),hashlib.file_digest(f.open('rb'),'sha256').hexdigest(),name))
 if 'native_crop' in outputs:
  crop=project_hashed(outputs['native_crop']['path'],outputs['native_crop']['sha256'],'stage native crop');image_check(crop,(1024,1024));collected.add(crop)
  geometry=result_file.parent/'crop_input_preview/geometry.json'
  if geometry.is_file():collected.add(project_hashed(str(geometry.resolve()),hashlib.file_digest(geometry.open('rb'),'sha256').hexdigest(),'crop geometry'))
 if 'base_preparation_path' in identity or 'base_preparation_sha256' in identity:
  prep=validate_restore(identity['base_preparation_path'],identity['base_preparation_sha256'])
  if prep['reset_output_sha256']!=identity['base_sha256'] or prep['parent_prompt_id']!=identity.get('parent_prompt_id'):raise ValueError(f'{result_file}: preparation does not match stage')
  collected.add(Path(prep['preparation_path']))
  collected.update(Path(v) for v in prep['paths'].values())
 for name in ('job_config.json','measurements.json','history.json','actual.ui.json','actual.api.json'):
  q=result_file.parent/name
  if q.is_file():collected.add(project_hashed(str(q.resolve()),hashlib.file_digest(q.open('rb'),'sha256').hexdigest(),name))
 return collected

def collect_sidecar_evidence(sidecar):
 refs=set(provenance_files(sidecar));collected=set(refs)
 data=json.loads(sidecar.read_text(encoding='utf-8'))
 if data.get('pure_copy') is True:
  validate_pure_copy(data,sidecar.with_suffix('.png'),sidecar.with_suffix('.jpg'),data.get('deliverable_id'))
 if 'sources' in data:
  if not isinstance(data['sources'],list):raise ValueError(f'{sidecar}: sources must be a list')
  for index,item in enumerate(data['sources']):
   if not isinstance(item,dict):raise ValueError(f'{sidecar}: invalid source {index}')
   collected.add(project_hashed(item['path'],item['sha256'],f'{sidecar} source {index}'))
 for p in refs:
  if p.name=='result.json':collected.update(collect_stage_evidence(p))
 return collected

def main():
 # Keep the documented system-python command usable with the configured Comfy venv.
 if any(importlib.util.find_spec(name) is None for name in ('numpy','PIL')):
  if os.environ.get('LISTING_PACKAGE_VENV_REEXEC')=='1':raise SystemExit('Configured Python is missing numpy or Pillow')
  try:python=json.loads((R/'config/environment.json').read_text(encoding='utf-8'))['python']
  except (OSError,ValueError,KeyError) as exc:raise SystemExit('Configured Python unavailable: '+str(exc))
  if not Path(python).is_absolute() or not Path(python).is_file():raise SystemExit('Configured Python unavailable: '+str(python))
  env=os.environ.copy();env['LISTING_PACKAGE_VENV_REEXEC']='1'
  os.execve(python,[python,str(Path(__file__).resolve()),*sys.argv[1:]],env)
 parser=argparse.ArgumentParser();parser.add_argument('--inspect',nargs='*',metavar='DELIVERABLE_ID',help='read-only evidence collection for approved items; never create ZIP');args=parser.parse_args()
 with manifest.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
 expected={'main':5,'detail':8,'sku':5,'white_by_color':5,'extra':1};roles=Counter(r['role'] for r in rows)
 if len(rows)!=24 or roles!=expected or len({r['deliverable_id'] for r in rows})!=24:raise SystemExit(f'Invalid manifest: {len(rows)} rows, {dict(roles)}')
 canonical=qa_state.rows()
 if set(canonical)!={r['deliverable_id'] for r in rows} or any(r['planned_path']!=canonical[r['deliverable_id']]['planned_path'] or r.get('derived_from')!=canonical[r['deliverable_id']].get('derived_from') for r in rows): raise SystemExit('Manifest mismatch')
 if args.inspect is not None:
  for ident in (args.inspect or [r['deliverable_id'] for r in rows]):
   matches=[r for r in rows if r['deliverable_id']==ident]
   if len(matches)!=1 or qa_state.issues(ident):raise SystemExit(f'{ident}: missing, ambiguous or not approved')
   target=Path(matches[0]['planned_path']).resolve()
   if not target.is_relative_to(OUT) or not target.is_file():raise SystemExit(f'{ident}: missing or external final image')
   from original_region_restore import validate_restore as _restore
   from validate_delivery import validate_pure_copy as _copy
   from PIL import Image as _image
   globals().update(validate_restore=_restore,validate_pure_copy=_copy,Image=_image)
   sidecar=target.with_suffix('.json');files=collect_sidecar_evidence(sidecar) if sidecar.is_file() else set()
   print(json.dumps({'deliverable_id':ident,'sidecar':str(sidecar) if sidecar.is_file() else None,'evidence_files':len(files),'source_records':[str(p.relative_to(R)) for p in sorted(files)]},ensure_ascii=False))
  return
 unapproved=[r['deliverable_id'] for r in rows if qa_state.issues(r['deliverable_id'])]
 if unapproved:raise SystemExit('Visual approval pending: '+', '.join(unapproved))
 from original_region_restore import validate_restore as _restore
 from validate_delivery import validate_pure_copy as _copy
 from PIL import Image as _image
 globals().update(validate_restore=_restore,validate_pure_copy=_copy,Image=_image)
 validation_path=OUT/'validation.json'
 if not validation_path.is_file() or json.loads(validation_path.read_text()).get('delivery_complete') is not True:raise SystemExit('Mechanical validation has not confirmed delivery_complete=true')
 paths=set(); source_paths=set(); masters=[]
 def include(p):
  p=p.resolve()
  if not p.is_file():raise FileNotFoundError(p)
  paths.add(p)
 for r in rows:
  p=Path(r['planned_path']).resolve()
  if not p.is_relative_to(OUT):raise ValueError(f'Not in listing output: {p}')
  sidecar=p.with_suffix('.json')
  if sidecar.is_file():
   include(sidecar)
   source_paths.update(collect_sidecar_evidence(sidecar))
  size=(800,800) if r['role']!='detail' else None;width=750 if r['role']=='detail' else None
  for ext in ('.jpg','.png'):
   f=p.with_suffix(ext);include(f)
   if r['role']=='main' and ext=='.png':
    image_check(f)
    with Image.open(f) as im:
     if im.width!=im.height or im.width<800:raise ValueError(f'{f}: main PNG master must be square and at least 800px')
     masters.append({'deliverable_id':r['deliverable_id'],'path':str(f.relative_to(OUT)),'width':im.width,'height':im.height})
   else:image_check(f,size,width)
 # Full preview, every mapped slice, and map are explicit final outputs.
 full=OUT/'02_detail/full_preview.jpg';include(full);image_check(full,width=750)
 mapping=OUT/'02_detail/slice_map.json';include(mapping);m=json.loads(mapping.read_text())
 if not isinstance(m,list) or len(m)!=8:raise ValueError('Expected eight mapped upload slices')
 for entry in m:
  p=OUT/'02_detail/slices'/entry['slice'];include(p);image_check(p,width=750)
 include(manifest);include(OUT/'index.html')
 previews=[OUT/'05_preview'/f'{name}_overview.jpg' for name in ('main','detail','sku','colors','extra')]
 for p in previews:include(p);image_check(p)
 for p in [R/'output/sku_dimensions/粥碗尺寸表_长宽高.xlsx',R/'config/qa_approvals.json',R/'work/diagnostics/comfy_workflow_readonly/workflow_save_receipt.json',R/'work/diagnostics/comfy_workflow_readonly/workflow_save_receipt_MAIN03.json',R/'work/diagnostics/comfy_workflow_readonly/workflow_save_receipt_MAIN01_MAIN04.json',R/'work/diagnostics/comfy_idle_free_after_listing.json',R/'config/product_assets.csv',R/'config/skus.csv',R/'config/food_assets.csv',R/'scripts/build_asset_inventory.py',R/'scripts/export_all_skus.py',R/'AGENTS.md',R/'docs/products/w1125.md',R/'docs/STATUS.md',R/'docs/统一SKU表标准.md',OUT/'validation.json',R/'scripts/archive/run_whole_photo_fill.py',R/'scripts/regional_whole_photo_graph.py',R/'scripts/crop_context_graph.py',R/'scripts/original_region_restore.py',R/'scripts/export_whole_photo_listing.py',R/'scripts/validate_delivery.py',R/'scripts/package_listing.py']:
  include(p)
 master_index=OUT/'01_main/master_index.json';master_index.write_text(json.dumps(masters,ensure_ascii=False,indent=2)+'\n');include(master_index)
 def arc(p):return str(p.relative_to(OUT)) if p.is_relative_to(OUT) else 'source_records/'+str(p.relative_to(R))
 archive_items=[(arc(p),p) for p in paths]+[('source_records/'+str(p.relative_to(R)),p) for p in source_paths if p not in paths]
 archive_items=sorted(set(archive_items),key=lambda x:x[0])
 if len({name for name,_ in archive_items})!=len(archive_items):raise ValueError('Duplicate archive paths')
 entries=[{'path':name,'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()} for name,p in archive_items]
 mapping_path=OUT/'archive_source_map.json';mapping_path.write_text(json.dumps([{'original_abs':str(p),'archive_path':name,'sha256':entry['sha256']} for (name,p),entry in zip(archive_items,entries)],ensure_ascii=False,indent=2)+'\n')
 entries_path=OUT/'zipentries.json';entries_path.write_text(json.dumps(entries,ensure_ascii=False,indent=2))
 target=OUT/'listing_package.zip';fd,temp=tempfile.mkstemp(prefix='.listing_',suffix='.zip',dir=OUT);os.close(fd)
 try:
  with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
   for name,p in archive_items:z.write(p,name)
   z.write(entries_path,'zipentries.json');z.write(mapping_path,'archive_source_map.json')
  with zipfile.ZipFile(temp) as z:
   bad=z.testzip()
   if bad:raise ValueError('Archive integrity error: '+bad)
  os.replace(temp,target)
 finally:
  if os.path.exists(temp):os.unlink(temp)
 print(f'Packaged 24 approved items, {len(entries)} files: {target}')
if __name__=='__main__':main()
