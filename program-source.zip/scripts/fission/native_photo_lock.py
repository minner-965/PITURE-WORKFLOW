"""Independent deterministic, photo-based layout diagnostic."""
import argparse,json,fcntl,shutil,importlib.util
from pathlib import Path
import torch
from PIL import Image
from build_workflows import node,check_graph,ui
from comfy_client import ComfyClient
from native_multishop import ROOT,sha,write
from fission.deterministic import run
NODE=Path('/Users/luohuiwu/ComfyUI-Installs/E-commerce image workflow/ComfyUI/custom_nodes/fission_photo_lock/__init__.py')

def main():
 p=argparse.ArgumentParser();p.add_argument('--photo',type=Path,required=True);p.add_argument('--background',type=Path,required=True);p.add_argument('--config',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--check',action='store_true');a=p.parse_args()
 photo=a.photo.resolve(strict=True);bg=a.background.resolve(strict=True);out=a.output.resolve();cfg=json.loads(a.config.read_text())
 parent=photo.parent;identity=json.loads((parent/'identity.json').read_text());result=json.loads((parent/'result.json').read_text());record=result['outputs'][photo.name]
 if record['sha256']!=sha(photo) or result['identity_sha256']!=sha(parent/'identity.json'):raise ValueError('Photograph reference provenance mismatch')
 sources=identity['product_sources'];original=Path(sources[0]['file']);
 if sha(original)!=sources[0]['sha256'] or sources[0]['crop_xywh']!=[1400,1600,3500,2000]:raise ValueError('Original photo or crop mismatch')
 bparent=bg.parent;bid=json.loads((bparent/'identity.json').read_text());br=json.loads((bparent/'result.json').read_text())
 if sha(bg)!=br['sha256'] or sha(bparent/'identity.json')!=br['identity_sha256']:raise ValueError('Background provenance mismatch')
 with Image.open(photo) as im:w,h=im.size
 with Image.open(bg) as im:bw,bh=im.size
 spec=importlib.util.spec_from_file_location('photo_lock_node',NODE);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 # Synthetic tensor preflight validates polygon containment, placement, dimensions; no photo pixels processed.
 mod.FissionPhotoLock().layout(torch.zeros((1,h,w,3)),torch.zeros((1,bh,bw,3)),json.dumps(cfg))
 chain={'photo':str(photo),'photo_sha256':sha(photo),'original':str(original),'original_sha256':sha(original),'original_crop_xywh':sources[0]['crop_xywh'],'photo_parent_identity_sha256':sha(parent/'identity.json'),'photo_parent_result_sha256':sha(parent/'result.json'),'background_sha256':sha(bg),'background_identity_sha256':sha(bparent/'identity.json'),'background_result_sha256':sha(bparent/'result.json'),'config_sha256':sha(a.config),'node_sha256':sha(NODE)}
 if a.check:print(json.dumps({'check':'offline_passed','chain':chain},ensure_ascii=False));return
 c=ComfyClient();info=c.get('/object_info');out.mkdir(parents=True,exist_ok=True)
 with (ROOT/'fission/runs/native_gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('Comfy queue is busy')
  graph={'1':node('LoadImage','真实实拍',image=c.upload(photo)),'2':node('LoadImage','已审背景',image=c.upload(bg)),'3':node('FissionPhotoLock','真实轮廓等比排布',photo=['1',0],background=['2',0],layout_json=json.dumps(cfg,ensure_ascii=False)),'4':node('SaveImage','无字无餐排布',images=['3',0],filename_prefix='photo_lock/layout')}
  for i,name in [(1,'product'),(2,'food'),(3,'rim'),(4,'shadow')]:
   graph[str(10+i)]=node('MaskToImage',name+'蒙版',mask=['3',i]);graph[str(20+i)]=node('SaveImage',name+'保存',images=[str(10+i),0],filename_prefix='photo_lock/'+name)
  check_graph(graph,info);visual=ui(graph,info,'实拍盘保形排布','实拍等比缩放，选区待审核。')
  for i,n in enumerate(visual['nodes']):n['pos']=[(i%5)*350,(i//5)*350]
  write(out/'workflow.api.json',graph);write(out/'workflow.ui.json',visual);write(out/'source_chain.json',chain)
  entry,hit=run(c,graph,visual,out,NODE,photo)
  for key,name in [('4','layout.png'),('21','product_mask.png'),('22','food_mask.png'),('23','rim_mask.png'),('24','shadow_zone.png')]:
   dest=out/name;src=Path(entry['files'][key][0]);expected=entry['output_hashes'][str(src)]
   if dest.exists() and sha(dest)!=expected:raise ValueError('Existing output does not match cache')
   if not dest.exists():shutil.copyfile(src,dest)
   if sha(dest)!=expected:raise ValueError('Output hash mismatch')
  hst=entry.get('history');hst=json.loads(Path(hst).read_text()) if isinstance(hst,str) else hst
  if hst and not (out/'history.json').exists():write(out/'history.json',hst)
  source=Path(entry.get('source') or '')
  if hit and (source/'submission.json').is_file() and not (out/'submission.json').exists():shutil.copyfile(source/'submission.json',out/'submission.json')
  write(out/'diagnostics.json',{'cache_hit':hit,'prompt_id':entry['prompt_id'],'outputs':{x:sha(out/x) for x in ['layout.png','product_mask.png','food_mask.png','rim_mask.png','shadow_zone.png']},'status':'pending_visual_review','method':'isotropic scaling of real photo; no generative sampling'})
  print(json.dumps({'cache_hit':hit,'output':str(out),'prompt_id':entry['prompt_id']},ensure_ascii=False))
if __name__=='__main__':main()
