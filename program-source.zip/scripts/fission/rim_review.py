"""Make source-aligned rim proofs and require a review of the actual photo being exported."""
import hashlib
import json
import re
import unicodedata
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

BASE = Path(__file__).resolve().parents[2] / 'fission'
NATIVE_METHODS = ('native_dual_reference','native_color_adjustment')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalized(value):
    return ''.join(unicodedata.normalize('NFKC',str(value)).casefold().split())


def color_name(value):
    return normalized(value).removesuffix('色')


def master_id(row):
    key=row.get('master_id',row['shop'])
    if not isinstance(key,str) or not re.fullmatch(r'[A-Za-z0-9_-]+',key):
        raise ValueError(f'无效实拍母版编号 {key}')
    return key


def facts_path(sku, base=BASE):
    if not isinstance(sku,str) or not re.fullmatch(r'[A-Za-z0-9_-]+',sku):
        raise ValueError(f'无效商品编号 {sku}')
    return base/'products'/sku/'product.json'


def validate_assignments(menu, product, base=BASE):
    """Keep JSON order. A different headline does not change the dish or the product color."""
    previous={}
    catalog={product['product_id']:product}
    rows=[]
    for row in menu:
        sku=row.get('product_id',product['product_id'])
        if sku not in catalog:
            catalog[sku]=json.loads(facts_path(sku,base).read_text())
        facts=catalog[sku]
        if facts['product_id']!=sku:
            raise ValueError(f'{sku} 与商品资料不一致')
        shop=row['shop']
        row=dict(row,product_id=sku)
        key=master_id(row)
        if ('bowl_color' in row)!=('master_id' in row):
            raise ValueError(f'{sku}/{shop} 需同时填写实拍母版和碗色')
        if 'bowl_color' in row:
            selected=row['bowl_color']
        else:
            # Legacy manifests identified the photographed master by the store alone.
            selected=json.loads((base/'masters'/key/'master.json').read_text())['color']
        palette={normalized(k):color_name(v) for k,v in facts['colors'].items()}
        color=palette.get(normalized(selected),color_name(selected))
        if not color or color not in palette.values():
            raise ValueError(f'{sku}/{shop} 的「{selected}」不在本商品登记的真实颜色中')
        if 'bowl_color' in row:
            row['bowl_color']=color
        item=normalized(row.get('food_id',row['dish_id']))
        name=normalized(row['name'])
        if not item or not name:raise ValueError(f'{sku}/{shop} 需填写菜品身份和名称')
        prior=previous.get((sku,shop))
        if prior:
            if len(set(palette.values()))==1:
                raise ValueError(f'{sku}/{shop} 仅有一种实拍颜色，无法为相邻两张换色；请运营决定只出一张或补充真实 SKU 颜色')
            if color==prior[0]:
                raise ValueError(f'{sku}/{shop} 的 {name} 与前一道 {prior[2]} 使用同一碗色 {selected}')
            if item==prior[1] or name==prior[2]:
                raise ValueError(f'{sku}/{shop} 的菜品与前一道 {prior[2]} 相同，请更换食品')
        previous[sku,shop]=(color,item,name)
        rows.append(row)
    return rows


def rows_for(run, product=None, base=BASE):
    raw=json.loads((run/'menu.json').read_text())
    if not raw:raise ValueError('菜品清单为空')
    if product is None:
        manifest=run/'batch.json'
        if manifest.exists():
            product=run/json.loads(manifest.read_text())['product']
        else:
            first=raw[0]
            sku=first.get('product_id') or json.loads((base/'masters'/master_id(first)/'master.json').read_text())['sku']
            product=facts_path(sku,base)
    facts=json.loads(product.read_text())
    return validate_assignments(raw,facts,base)


def master_for(row, base=BASE):
    key=master_id(row)
    folder=base/'masters'/key
    meta=json.loads((folder/'master.json').read_text())
    if meta.get('master_id',meta.get('shop'))!=key or row.get('product_id',meta['sku'])!=meta['sku']:
        raise ValueError(f'{key} 的实拍身份与商品不一致')
    requested=row.get('bowl_color',meta['color'])
    if color_name(requested)!=color_name(meta['color']) and normalized(requested)!=normalized(meta.get('color_key','')):
        raise ValueError(f'{key} 的实拍为{meta["color"]}，本行要求{requested}')
    if digest(base.parent/meta['source'])!=meta['source_sha256']:
        raise ValueError(f'{key} 号摄影原片与母版记录不符')
    return folder


def compare(master_id, photo, target):
    master = BASE / 'masters' / master_id
    source = Image.open(master / 'master_1280.png').convert('RGB')
    result = Image.open(photo).convert('RGB')
    if source.size != result.size:
        raise ValueError('实拍母版与无字照片的像素坐标不一致')
    mask = master / 'food_surface_rim_v2.png'
    x0,y0,x1,y1 = Image.open(mask if mask.is_file() else master/'food_mask_1280.png').getbbox()
    center = (x0 + x1) // 2
    mouth = (max(0,x0-48), max(0,y0-80), min(source.width,x1+48), min(source.height,y1+55))
    front = (center-140,y1-42,center+140,y1+34)
    rear = (center-140,y0-60,center+140,y0+16)
    canvas = Image.new('RGB',(1000,472),'#f6f4ef')
    d = ImageDraw.Draw(canvas)
    font = ImageFont.truetype(str(BASE/'fonts/SourceHanSansSC-Regular.otf'),16)
    for i,(im,name) in enumerate([(source,'实拍原片'),(result,'本次样图')]):
        left=i*500+10
        d.text((left,3),name,font=font,fill='#1f322c')
        crop=im.crop(mouth)
        crop.thumbnail((475,230),Image.Resampling.LANCZOS)
        canvas.paste(crop,(left,30))
        for box,top,label in [(front,270,'前唇'),(rear,370,'后侧内壁')]:
            d.text((left,top),label,font=font,fill='#1f322c')
            canvas.paste(im.crop(box),(left+78,top))
    canvas.save(target,quality=94,subsampling=0)


def require_approval(photo, sheet, review):
    if not review.is_file() or not sheet.is_file():
        raise ValueError(f'未审核实拍和当前碗沿对照图：{photo}')
    record=json.loads(review.read_text())
    if (record.get('approved') is not True or record.get('sha256') != digest(photo)
            or record.get('rim_sheet_sha256') != digest(sheet)):
        raise ValueError(f'碗沿复核与本次实际图像不一致：{photo}')
