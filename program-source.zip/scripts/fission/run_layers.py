"""Render reviewed real-photo masters with one serial ComfyUI queue. Resume by input hash."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'scripts'))
from comfy_client import ComfyClient, sync_ui
from rim_review import NATIVE_METHODS, compare, require_approval, master_for, master_id, rows_for, facts_path
from food_surface import CROP, MASK_NAME, project, texture_graph
from build_workflows import check_graph, ui as build_ui

FISSION = ROOT / 'fission'
LANCZOS = Image.Resampling.LANCZOS
def read(path):
    return json.loads(path.read_text())
def save(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    os.replace(temp, path)
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save_png(img, path):
    temp = path.with_suffix('.partial')
    img.save(temp, format='PNG')
    os.replace(temp, path)

def check_batch_hold(run, promote=False):
    if run is None:  # Single-image repair calls do not enter the batch runner.
        return
    path=run/'quality_hold.json'
    if path.exists():
        hold=read(path)
        if hold.get('hold') is True and not (promote and hold.get('hold_scope')=='legacy_projection'):
            raise SystemExit(hold.get('reason') or '批量出图已暂停')


def render_layer(client, info, pid, slot, src, mask_path, prompt, seed, region, size, steps, label, batch_run=None):
    slot.mkdir(parents=True, exist_ok=True)
    outfile = slot / 'photo.png'
    identity = dict(src=digest(src), mask=digest(mask_path), prompt=prompt, seed=seed,
                    region=list(region),size=list(size), steps=steps,
                    graph=digest(ROOT/'workflows/FOOD_Q6_asset.api.json'))
    record = slot/'identity.json'
    if record.exists() and read(record)!=identity:
        raise RuntimeError(f'Inputs changed in {slot}, choose a fresh revision')
    save(record,identity)
    receipt = slot/'verified.json'
    if receipt.exists():
        if digest(outfile)!=read(receipt)['sha256']:
            raise RuntimeError(f'Bad output in {slot}')
        return outfile
    base=Image.open(src).convert('RGB')
    mask=Image.open(mask_path).convert('L')
    cb=slot/'input.png'; cm=slot/'mask.png'
    base.crop(region).resize(size,LANCZOS).save(cb)
    mask.crop(region).resize(size,LANCZOS).save(cm)
    submission=slot/'submission.json'
    if submission.exists():
        prompt_id=client.reconcile(submission)
    else:
        while any(client.get('/queue').get(k,[]) for k in ['queue_running','queue_pending']):
            time.sleep(5)
        api=read(ROOT/'workflows/FOOD_Q6_asset.api.json')
        api['1']['inputs']['image']=client.upload(cb)
        api['2']['inputs']['image']=client.upload(cm)
        api['7']['inputs']['text']=prompt
        api['12']['inputs'].update(seed=seed, steps=steps)
        api['15']['inputs']['filename_prefix']='fission_abc/'+label
        ui=sync_ui(api,read(ROOT/'workflows/FOOD_Q6_asset.ui.json'),info)
        save(slot/'actual.api.json',api);save(slot/'actual.ui.json',ui)
        check_batch_hold(batch_run)
        prompt_id=client.submit(api,ui,submission)
    result,metrics=client.wait(prompt_id,slot,pid)
    raw=Path(client.download(result,slot/'downloads')['15'][0])
    from fission.ledger import record_cpu
    with record_cpu(label, 'composition', input_hashes={'source':digest(src),'mask':digest(mask_path),'generated':digest(raw)}, result_paths=[str(outfile)]) as cpu_record:
        overlay=base.copy()
        x,y,x1,y1=region
        overlay.paste(Image.open(raw).convert('RGB').resize((x1-x,y1-y),LANCZOS),(x,y))
        photo=Image.composite(overlay,base,mask)
        delta=np.any(np.asarray(base)!=np.asarray(photo),axis=2)
        if delta[np.asarray(mask)==0].any():raise ValueError('edited pixels outside mask')
        save_png(photo,outfile)
        save(receipt,dict(sha256=digest(outfile),prompt_id=prompt_id,raw_sha256=digest(raw),
                          seconds=metrics['wall_seconds'],outside_mask_changed_pixels=0))
    return outfile

from fission.ledger import tracked_cpu

@tracked_cpu('layout')
def make_preview_card(source, row, target):
    from typography_export import BASE, render
    templates = (read(p) for p in (BASE/'templates').glob('*/template.json'))
    template = next(t for t in templates if t['shop'] == row['shop'])
    sku = row.get('product_id') or read(BASE/'masters'/master_id(row)/'master.json')['sku']
    claims = set(read(facts_path(sku,BASE))['allowed_claims'])
    preview = render(source, row['title'], template, claims)
    temporary = target.with_suffix('.partial')
    preview.save(temporary, format='JPEG', quality=94, subsampling=0)
    os.replace(temporary, target)


def reviewed_master(row):
    shop=master_id(row)
    master=master_for(row,FISSION)
    gate=read(master/'root_review.json')
    required={'master_1280.png','props_mask_1280.png','bowl_mask_1280.png',MASK_NAME}
    # Some older master approvals cover the bowl mask through the signed master.json.
    fingerprints=dict(read(master/'master.json')['artifacts'])
    fingerprints.update(gate['files'])
    if gate.get('approved') is not True or MASK_NAME not in gate['files'] or 'master.json' not in gate['files']:
        raise ValueError(f'{shop} 正在等待真实开口定位复核')
    for name in required | set(gate['files']):
        if digest(master/name)!=fingerprints[name]:
            raise ValueError(f'{shop} 的 {name} 已变更，请重新审核')
    return master,gate


def render_texture(client, info, pid, folder, row, seed, prefix, run):
    folder.mkdir(parents=True,exist_ok=True)
    api=texture_graph(row,seed,prefix)
    spec=folder/'actual.api.json'
    if spec.exists() and read(spec)!=api:
        raise ValueError(f'纹理参数已变化，请使用新候选号：{folder}')
    receipt=folder/'纹理记录.json'
    if receipt.exists():
        data=read(receipt)
        donor=folder/data['filename']
        if digest(donor)!=data['sha256'] or digest(spec)!=data['api_sha256']:
            raise ValueError('已生成纹理与记录不一致')
        return donor
    submission=folder/'submission.json'
    if submission.exists():
        prompt=client.reconcile(submission)
        if read(submission)['request']['prompt']!=api:
            raise ValueError('已提交的纹理任务与当前配置不一致')
    else:
        check_graph(api,info)
        visual=sync_ui(api,build_ui(api,info,'菜品纹理','生成俯拍食物表面，用实拍开口蒙版投影。'),info)
        save(spec,api)
        save(folder/'actual.ui.json',visual)
        while True:
            check_batch_hold(run)
            queue=client.get('/queue')
            if not queue['queue_running'] and not queue['queue_pending']:break
            time.sleep(5)
        check_batch_hold(run)
        prompt=client.submit(api,visual,submission)
    result,_metrics=client.wait(prompt,folder,pid)
    donor=Path(client.download(result,folder/'downloads')['23'][0])
    save(receipt,dict(prompt_id=prompt,sha256=digest(donor),filename=str(donor.relative_to(folder)),
                      api_sha256=digest(spec)))
    return donor


def render_candidate(client,info,pid,run,row,variant):
    if variant<2:raise ValueError('旧候选 0、1 已归档，真实开口流程从候选 2 开始')
    shop,dish=row['shop'],row['dish_id']
    master,gate=reviewed_master(row)
    image=master/'master_1280.png';mask=master/MASK_NAME;props_mask=master/'props_mask_1280.png'
    mouth=np.asarray(Image.open(mask))
    props=np.asarray(Image.open(props_mask))
    bowl=np.asarray(Image.open(master/'bowl_mask_1280.png'))
    if mouth.shape!=bowl.shape or mouth.shape!=props.shape or not mouth.any() or np.any((mouth>0)&((bowl==0)|(props>0))):
        raise ValueError('真实开口范围与器型或配菜区域不匹配')
    dish_dir=run/shop/dish
    slot=dish_dir/f'preview_{variant}'
    base_variant=variant%2
    # Resume existing backgrounds from both legacy and corrected trials. Reuse the
    # matching scene's seed and source identity regardless of the new food seed.
    master_sha=digest(image)
    background_slot=next((d for n in range(base_variant,variant,2)
                          if (d:=dish_dir/f'preview_{n}'/'props'/'identity.json').is_file()
                          and read(d).get('src')==master_sha),None)
    props_dir=background_slot.parent if background_slot else slot/'props'
    scene_seed=int(row['seed'])+base_variant*104729
    prefix=f'{shop}_{dish}_preview{variant}'
    print(f'{shop}/{dish} 第 {variant} 版 配菜背景',flush=True)
    background=render_layer(client,info,pid,props_dir,image,props_mask,row['props_prompt'],scene_seed,
                            (0,0,1280,1024),(960,768),12,prefix+'_props',batch_run=run)
    food_seed=int(row['seed'])+variant*104729+1
    print(f'{shop}/{dish} 第 {variant} 版 独立菜品纹理',flush=True)
    donor=render_texture(client,info,pid,slot/'food',row,food_seed,prefix+'_food',run)
    identity=dict(master_sha256=digest(image),mask_sha256=digest(mask),background_sha256=digest(background),
                  texture_sha256=digest(donor),texture_crop=list(CROP))
    identity_path=slot/'composition_inputs.json'
    if identity_path.exists() and read(identity_path)!=identity:
        raise ValueError('已生成候选的合成来源变化，请另用候选号')
    save(identity_path,identity)
    photo=slot/'food/photo.png'
    previous=slot/'result.json'
    if previous.exists() and (read(previous).get('composition')!=identity or digest(photo)!=read(previous)['sha256']):
        raise ValueError('已生成候选与本次合成来源不一致')
    if not previous.exists():
        cooked=project(background,mask,donor)
        protected=(bowl>0)&(mouth==0)
        if not np.array_equal(np.asarray(cooked)[protected],np.asarray(Image.open(image))[protected]):
            raise ValueError('碗体或碗沿原片像素变化')
        save_png(cooked,photo)
        compare(master.name,photo,slot/'实拍碗沿对照.jpg')
        make_preview_card(photo,row,slot/'带字预览.jpg')
        save(previous,dict(photo=str(photo.relative_to(ROOT)),sha256=digest(photo),protected_changed_pixels=0,
                           master=gate,master_id=master.name,bowl_color=read(master/'master.json')['color'],seed=food_seed,stage='preview',composition=identity,
                           background=str(background.relative_to(ROOT)),texture=str(donor.relative_to(ROOT))))


def selected_photo(dish, row=None):
    if row is None:
        menu=rows_for(dish.parents[1],base=FISSION)
        row=next(r for r in menu if (r['shop'],r['dish_id'])==(dish.parent.name,dish.name))
    master,_=reviewed_master(row)
    decision=read(dish/'selection.json')
    run=dish.parents[1]
    hold=read(run/'quality_hold.json') if (run/'quality_hold.json').is_file() else {}
    link=str(dish.relative_to(run))
    if decision.get('method') in NATIVE_METHODS:
        from native_review import verify_native
        locks=[key for key in hold.get('locked_native',[]) if key.startswith(link+'/')]
        if link==hold.get('locked_sample') or (locks and link+'/'+str(decision.get('candidate_id')) not in locks):
            raise ValueError('本链接已明确指定保留版本')
        return verify_native(dish,row,master,decision)
    if 'method' in decision:
        raise ValueError('未知选图方法')
    if (run/'batch.json').is_file() and read(run/'batch.json').get('route')=='native_dual_reference':
        if hold.get('locked_sample')!=link:
            raise ValueError('本批已停用旧贴图，仅保留明确指定的旧样')
    number=decision['variant']
    if not isinstance(number,int) or number<2: raise ValueError('请复核修正开口后的高清候选')
    slot=dish/f'preview_{number}'
    entry=read(slot/'result.json')
    current_hash=digest(master/'master_1280.png')
    bound=entry.get('master',{}).get('files',{}).get('master_1280.png')
    if bound!=current_hash or entry.get('master_id',master.name)!=master.name:
        raise ValueError('已选图来自不同颜色或机位的母版')
    photo=(ROOT/entry['photo']).resolve()
    if not photo.is_relative_to(dish.resolve()) or decision['sha256']!=entry['sha256'] or digest(photo)!=entry['sha256']:
        raise ValueError('选择记录与已审核原图不一致')
    require_approval(photo,slot/'实拍碗沿对照.jpg',slot/'visual_review.json')
    with Image.open(photo) as result:
        if result.size!=(1280,1024) or result.format!='PNG':
            raise ValueError('正式阶段需要已审核的 1280×1024 PNG')
        shell=np.asarray(Image.open(master/'bowl_mask_1280.png'))>0
        food=np.asarray(Image.open(master/MASK_NAME))>0
        protected=shell & ~food
        camera=np.asarray(Image.open(master/'master_1280.png').convert('RGB'))
        if not np.array_equal(np.asarray(result.convert('RGB'))[protected],camera[protected]):
            raise ValueError('选稿的碗体颜色或轮廓与该链接的实拍原片不同')
    if 'composition' in entry:
        inputs=entry['composition']
        for path,field in [(master/'master_1280.png','master_sha256'),(master/MASK_NAME,'mask_sha256'),
                           (ROOT/entry['background'],'background_sha256'),(ROOT/entry['texture'],'texture_sha256')]:
            if digest(path)!=inputs[field]:
                raise ValueError(f'审核候选的来源已变化：{path}')
    return photo,slot/'实拍碗沿对照.jpg'


@tracked_cpu('layout')
def promote_selected(dish, photo, sheet):
    # Preserve the exact bytes that were visually approved, including PNG metadata.
    for source,target in [(photo,dish/'photo_1280.png'),(sheet,dish/'实拍碗沿对照.jpg')]:
        temp=target.with_suffix('.partial')
        shutil.copyfile(source,temp)
        os.replace(temp,target)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run',type=Path,required=True)
    p.add_argument('--shop');p.add_argument('--dish');p.add_argument('--stage',choices=['preview','full'],default='preview')
    p.add_argument('--variant',type=int,action='append')
    p.add_argument('--product',type=Path)
    args=p.parse_args()
    run=args.run.resolve(strict=True)
    check_batch_hold(run,promote=args.stage=='full')
    with (run/'queue.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        menu=rows_for(run,args.product,FISSION)
        client=None
        for row in menu:
            if args.shop and args.shop!=row['shop'] or args.dish and args.dish!=row['dish_id']:continue
            if not re.fullmatch(r'[A-Za-z0-9_-]+',row['shop']) or not re.fullmatch(r'[a-z0-9_]+',row['dish_id']):
                raise ValueError('Invalid shop or dish id')
            check_batch_hold(run,promote=args.stage=='full')
            dish=run/row['shop']/row['dish_id']
            if args.stage=='full' or (dish/'selection.json').is_file():
                photo,sheet=selected_photo(dish,row)
                if args.stage=='full':promote_selected(dish,photo,sheet)
                print(f'{row["shop"]}/{row["dish_id"]} 已复用审核原图',flush=True)
                continue
            if (run/'batch.json').exists() and read(run/'batch.json').get('route')=='native_dual_reference':
                raise ValueError('本批已转原生双参考，请使用原生候选入口')
            if client is None:
                client=ComfyClient()
                client.get('/system_stats');info=client.get('/object_info')
                pid=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip())
            for variant in args.variant or [2,3]:
                render_candidate(client,info,pid,run,row,variant)
if __name__=='__main__':main()
