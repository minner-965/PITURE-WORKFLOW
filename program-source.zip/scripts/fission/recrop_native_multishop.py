"""Export an 800px crop of a verified native image using CPU image operations."""

import argparse
import fcntl
import hashlib
import json
import os
import time
from PIL import Image
from pathlib import Path

from native_multishop import (ROOT, WORKFLOWS, approved_background, crop_rectangle,
                             fingerprint, image_size, read, require, sha, slug, write)

STEM = WORKFLOWS / "03_母图近景取景800"


def source_data(directory):
    # Imports are delayed so the publisher can also reuse verify_recrop.
    from publish_native_multishop import check_fingerprint, verify_workflow

    source = Path(directory).resolve(strict=True)
    identity = read(source / "identity.json")
    require(identity.get("stage") == "product", "The source must be a completed native product generation")
    result = verify_workflow(source, identity)
    approval = identity["background_approval"]
    for item in approval.values():
        check_fingerprint(item)
    require(approved_background(Path(approval["image"]["path"]).parent) == approval,
            "The source background review has changed")
    return source, identity, result


def prepare(source, crop, version):
    source, original, result = source_data(source)
    native = source / "result.png"
    rectangle = crop_rectangle(crop, image_size(native), "native image crop", square=True)
    api_path, ui_path = STEM.with_suffix(".api.json"), STEM.with_suffix(".ui.json")
    identity = {
        "schema_version": 2, "method": "pillow_crop_lanczos", "stage": "recrop", "id": original["id"], "shop": original["shop"],
        "sku": original["sku"], "color": original.get("color"), "version": version,
        "source_directory": str(source), "source_identity": fingerprint(source / "identity.json"),
        "source_generation": {"prompt_id": result["prompt_id"],
                              **{name: fingerprint(source / filename) for name, filename in (
                                  ("workflow_api", "workflow.api.json"), ("workflow_ui", "workflow.ui.json"),
                                  ("submission", "submission.json"), ("history", "history.json"))}},
        "files": [fingerprint(native)], "reference_loaders": ["1"],
        "crop_xywh": rectangle, "output_size": [800, 800],
        "template": fingerprint(api_path), "ui_template": fingerprint(ui_path),
        "image_operations": "Pillow crop, Lanczos resize, PNG export; source generation reused",
        "generation_conditioning": "Recorded in source_generation; this export performs deterministic image operations"
    }
    graph = read(api_path)
    graph["1"]["inputs"]["image"] = native.name
    graph["2"]["inputs"].update(zip(("x", "y", "width", "height"), rectangle))
    token = hashlib.sha256(json.dumps(identity, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]
    graph["4"]["inputs"]["filename_prefix"] = f"product_closeup/multishop/{original['id']}/crop_{version}_{token}"
    return source / "crops" / version, identity, graph, read(ui_path)


def verify_recrop(directory):
    """Verify one crop's original generation, execution evidence and unchanged PNG bytes."""
    from publish_native_multishop import verify_png_graph

    out = Path(directory).resolve(strict=True)
    identity = read(out / "identity.json")
    require(identity.get("stage") == "recrop", "Expected a ComfyUI recrop record")
    source, original, original_result = source_data(identity["source_directory"])
    require(out == source / "crops" / slug(identity["version"], "crop version"), "Crop record is outside its native source")
    require(all(identity[key] == original[key] for key in ("id", "shop", "sku")), "Crop belongs to another product")
    require(identity["source_identity"] == fingerprint(source / "identity.json"), "Original generation identity changed")
    require(identity["source_generation"]["prompt_id"] == original_result["prompt_id"], "Original generation receipt differs")
    require(identity["files"] == [original_result["outputs"]["result.png"]], "Crop input differs from the native photograph")
    require(identity["reference_loaders"] == ["1"], "Crop source loader differs")
    for name, filename in (("workflow_api", "workflow.api.json"), ("workflow_ui", "workflow.ui.json"),
                           ("submission", "submission.json"), ("history", "history.json")):
        require(identity["source_generation"][name] == fingerprint(source / filename),
                f"Original generation evidence differs: {name}")
    if identity.get("method") == "pillow_crop_lanczos":
        result = read(out / "result.json")
        output = out / "result_800.png"
        require(identity.get("schema_version") == 2, "Unknown CPU crop schema")
        require(result.get("type") == "cpu" and result.get("prompt_id") is None, "CPU crop is not a generation")
        require(result["identity_sha256"] == sha(out / "identity.json"), "Crop identity checksum differs")
        require(result["outputs"] == {"result_800.png": fingerprint(output)}, "Crop output checksum differs")
        require(result["native_sha256"] == identity["files"][0]["sha256"], "Crop source hash differs")
        require(image_size(output) == tuple(identity["output_size"]) == (800, 800), "Crop output has the wrong size")
        x, y, width, height = crop_rectangle(identity["crop_xywh"], image_size(source / "result.png"), "native image crop", square=True)
        with Image.open(source / "result.png") as image, Image.open(output) as actual:
            expected = image.convert("RGB").crop((x, y, x + width, y + height)).resize((800, 800), Image.Resampling.LANCZOS)
            require(actual.mode == "RGB" and actual.tobytes() == expected.tobytes(), "CPU crop pixels differ from the recorded transform")
        return result
    graph = read(out / "workflow.api.json")
    require(set(graph) == {"1", "2", "3", "4"}, "The crop workflow must contain exactly four image nodes")
    require(graph["1"]["class_type"] == "LoadImage", "The crop input must load its native photograph")
    crop = crop_rectangle(identity["crop_xywh"], image_size(source / "result.png"), "native image crop", square=True)
    require(graph["2"]["class_type"] == "ImageCrop" and graph["2"]["inputs"]["image"] == ["1", 0]
            and [graph["2"]["inputs"][key] for key in ("x", "y", "width", "height")] == crop,
            "Executed ComfyUI crop differs")
    require(graph["3"]["class_type"] == "ImageScale"
            and graph["3"]["inputs"] == {"image": ["2", 0], "upscale_method": "lanczos", "width": 800,
                                          "height": 800, "crop": "disabled"}, "Executed 800 scaling differs")
    require(graph["4"]["class_type"] == "SaveImage" and graph["4"]["inputs"]["images"] == ["3", 0],
            "The crop output must be saved inside ComfyUI")
    result, receipt, history = (read(out / name) for name in ("result.json", "submission.json", "history.json"))
    require(result["prompt_id"] == receipt["prompt_id"] == history["prompt"][1], "Crop receipt differs")
    require(receipt["request"]["prompt"] == graph == history["prompt"][2], "Crop execution graph differs")
    require(history["status"]["status_str"] == "success", "Crop execution has not completed")
    visual = read(out / "workflow.ui.json")
    require(receipt["request"]["extra_data"]["extra_pnginfo"]["workflow"] == visual, "Crop UI receipt differs")
    require(set(graph) <= {str(node["id"]) for node in visual["nodes"]}, "Crop UI is missing an execution node")
    require(result["identity_sha256"] == sha(out / "identity.json"), "Crop identity checksum differs")
    output = out / "result_800.png"
    require(result["outputs"] == {"result_800.png": fingerprint(output)}, "Crop output checksum differs")
    require(image_size(output) == tuple(identity["output_size"]) == (800, 800), "Crop output has the wrong size")
    verify_png_graph(output, graph, identity)
    return result


def _run(prepared, check_only):
    out, identity, graph, visual = prepared
    if check_only:
        return {"status": "checked_without_upload_or_submission", "output": str(out), "crop_xywh": identity["crop_xywh"]}
    started = time.monotonic()
    # CPU work has its own lock; it never acquires or submits to the GPU queue.
    lock_path = ROOT / "fission/runs/recrop_cpu.lock"
    with lock_path.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        source_data(identity["source_directory"])
        require(sha(identity["source_identity"]["path"]) == identity["source_identity"]["sha256"], "Source identity changed after preflight")
        require(sha(identity["files"][0]["path"]) == identity["files"][0]["sha256"], "Source photograph changed after preflight")
        identity_path = out / "identity.json"
        if identity_path.exists():
            previous = read(identity_path)
            require(all(previous.get(key) == identity.get(key) for key in ("source_identity", "files", "crop_xywh", "output_size", "id", "shop", "sku")),
                    "Crop parameters changed; select a new --version")
            if (out / "result.json").exists():
                verify_recrop(out)
                return {"status": "verified_existing", "output": str(out), "reused_from": str(out / "result.json")}
            require(previous == identity, "An unfinished historical Comfy crop exists; select a new --version for CPU export")
        else:
            require(not (out / "submission.json").exists() and not (out / "result.json").exists(), "Crop identity is missing")
        out.mkdir(parents=True, exist_ok=True)
        write(identity_path, identity)
        x, y, width, height = identity["crop_xywh"]
        with Image.open(identity["files"][0]["path"]) as image:
            cropped = image.convert("RGB").crop((x, y, x + width, y + height)).resize((800, 800), Image.Resampling.LANCZOS)
        temporary = out / "result_800.png.partial"
        cropped.save(temporary, format="PNG")
        os.replace(temporary, out / "result_800.png")
        seconds = time.monotonic() - started
        write(out / "result.json", {"type": "cpu", "prompt_id": None, "identity_sha256": sha(identity_path),
                                    "outputs": {"result_800.png": fingerprint(out / "result_800.png")},
                                    "native_sha256": identity["files"][0]["sha256"],
                                    "reused_from": identity["source_directory"],
                                    "seconds": seconds, "visual_review": "pending",
                                    "image_operations": identity["image_operations"]})
        verify_recrop(out)
        return {"status": "exported_pending_visual_review", "output": str(out), "cpu_seconds": seconds}


def run(prepared, check_only):
    if check_only:
        return _run(prepared, True)
    from fission.ledger import record_cpu
    out, identity, _, _ = prepared
    with record_cpu(identity["sku"], "recrop", input_hashes={"source": identity["files"][0]["sha256"]},
                    size=[800, 800], reused_from=identity["source_directory"]) as record:
        result = _run(prepared, False)
        record.update(result_paths=[str(out / "result_800.png")], cache_hit=result["status"] == "verified_existing")
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--crop", type=int, nargs=4, metavar=("X", "Y", "WIDTH", "HEIGHT"), required=True)
    parser.add_argument("--version", default="c01")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    slug(args.version, "crop version")
    print(json.dumps(run(prepare(args.source, args.crop, args.version), args.check), ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
