"""Run the remaining ABC 01 samples and explicitly requested revisions on one GPU."""
import fcntl
import os
import re
import time
from datetime import datetime, timezone

from native_dual_reference import DEFAULT_RUN, read, run_one, save

RUN = DEFAULT_RUN
STATUS = RUN/'native_supervisor_status.json'
FIRST_THREE = [('A','beef_congee'),('A','seaweed_egg'),('A','seafood_congee')]


def check_route():
    hold = read(RUN/'quality_hold.json')
    if read(RUN/'batch.json').get('route')!='native_dual_reference' or (
        hold.get('hold') and hold.get('hold_scope')!='legacy_projection'
    ):
        raise RuntimeError(hold.get('reason') or '原生路线已暂停')


def retry_items(keys):
    path=RUN/'native_retry_queue.json'
    document=read(path) if path.is_file() else []
    items=document.get('items') if isinstance(document,dict) else document
    if not isinstance(items,list) or any(not isinstance(item,str) for item in items):
        raise ValueError('原生重做清单格式有误')
    requests=[]
    for item in items:
        if not re.fullmatch(r'[ABC]/[a-z0-9_]+/[0-9]{2,3}',item):
            raise ValueError(f'重做目标无效 {item}')
        shop,dish,version=item.split('/')
        if (shop,dish) not in keys or (shop,dish) in FIRST_THREE[:2] or int(version)<2:
            raise ValueError(f'重做目标不属于可生成菜单 {item}')
        if item not in requests:requests.append(item)
    return requests


def main():
    with (RUN/'batch_driver.lock').open('a') as instance:
        fcntl.flock(instance,fcntl.LOCK_EX|fcntl.LOCK_NB)
        keys=[(r['shop'],r['dish_id']) for r in read(RUN/'menu.json')]
        if keys[:3]!=FIRST_THREE or len(keys)!=15 or len(set(keys))!=15:
            raise ValueError('批清单发生变化，重新核对待处理范围')
        normal=[f'{s}/{d}/01' for s,d in keys[3:]]
        previous=read(STATUS) if STATUS.is_file() else {}
        receipts={row['theme']:row for row in previous.get('verified_candidates',[])}
        target=None
        def report(state,detail=None):
            save(STATUS,dict(state=state,pid=os.getpid(),updated_utc=datetime.now(timezone.utc).isoformat(),
                 current=target,detail=detail,verified_candidates=list(receipts.values())))
        def slot_for(item):
            s,d,v=item.split('/')
            return RUN/s/d/'原生双参考'/v
        def render(item):
            nonlocal target
            target=item
            check_route()
            if keys!=[(r['shop'],r['dish_id']) for r in read(RUN/'menu.json')]:
                raise ValueError('菜单身份或顺序变化，需要复核')
            slot=slot_for(item)
            report('waiting_for_inputs')
            while not all((slot/f).is_file() for f in ('prompt.txt','settings.json')):
                check_route();time.sleep(3)
            check_route()
            report('generating_or_verifying')
            photo=run_one(RUN,*item.split('/'),submit=True)
            entry=read(slot/'result.json')
            receipts[item]=dict(theme=item,photo=str(photo.relative_to(RUN)),
                                sha256=entry['sha256'],prompt_id=entry['prompt_id'])
            report('candidate_ready')
        done=set()
        try:
            check_route()
            target='A/seafood_congee/01'
            report('waiting_for_a03')
            start=slot_for(target)/'result.json'
            while not start.is_file():
                check_route();time.sleep(3)
            with (RUN/'queue.lock').open('a') as lock:
                fcntl.flock(lock,fcntl.LOCK_EX)
            run_one(RUN,*FIRST_THREE[-1],'01',submit=False)
            # On restart reattach to an already issued GPU prompt first, even if a
            # higher priority request arrived while its previous observer was offline.
            for item in normal+retry_items(keys):
                slot=slot_for(item)
                if (slot/'submission.json').is_file() and not (slot/'result.json').exists():
                    render(item);done.add(item)
            while True:
                order=retry_items(keys)+normal
                next_item=next((item for item in order if item not in done),None)
                if next_item is None:break
                render(next_item);done.add(next_item)
            target=None
            report('candidates_complete', '已核对全部登记的原生候选，视觉审核另行记录。')
        except (Exception,SystemExit) as error:
            report('stopped',repr(error))
            raise


if __name__=='__main__':main()
