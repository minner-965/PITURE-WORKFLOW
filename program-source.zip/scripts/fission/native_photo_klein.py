"""Single B05 diagnostic: real-layout latent, masked Klein sampling, explicit protection."""
import argparse,fcntl,json,shutil,subprocess
from pathlib import Path
import numpy as np
from PIL import Image
from build_workflows import node,check_graph,ui
from comfy_client import ComfyClient
from native_multishop import ROOT,sha,write,read
BASE=ROOT/'fission/runs/fastplate_20261104/全套重做';SOURCE=BASE/'诊断测试/photo_lock_v02';OUT=BASE/'诊断测试/photo_klein_v01';FRONT=BASE/'B05/product/approved_batch_v04/product_reference.png';BG=BASE/'B05/background/v01/result.png'
POS='A natural realistic restaurant photograph. Image one is the existing two-plate composition; preserve the positions, scale, exact shape and all four rounded corners of both red exterior white interior real plates. Image two is the same real plate and determines the authentic shallow square form, thin red front edge and white surface. Image three is the reviewed restaurant background. Keep the rear plate empty. On the foreground plate serve a low modest portion of cooked green pepper strips and thin pork strips beside flat rice, with authentic texture, natural contact and soft shadows on the plate. Integrate natural table contact shadows beneath both plates, matching existing light. Keep plate edges, colors, four corners and scene arrangement unchanged. No text, hands, extra dishes or underplates.'
NEG='round plate, semicircular front rim, missing corners, deformed plate, extra plate, extra saucer, underplate, changed colors, red inner surface, thick edge, fused plate, floating plate, no contact shadows, floating food, pasted food, plastic food, high mound, artificial seams, blur, halos, text, watermark, hands.'

def graph(names):
 g=read(ROOT/'fission/workflows/商品主图近景/多店铺无字主图/02_商品双参考与800输出.api.json')
 for i in ['17','27','28']:g.pop(i,None)
 g['1']['inputs']['image']=names['layout'];g['2']['inputs']['image']=names['front'];g['7']['inputs'].update(image=['2',0],width=1024,height=592)
 g['8']['inputs']['text']=POS;g['9']['inputs']['text']=NEG;g['19']['inputs']['noise_seed']=202611052201
 g['30']=node('LoadImage','背景参考',image=names['background']);g['31']=node('ImageScale','场景归一化',image=['30',0],upscale_method='lanczos',width=768,height=768,crop='disabled');g['32']=node('VAEEncode','背景编码',pixels=['31',0],vae=['5',0])
 for i,prev in [('33','14'),('34','15')]:g[i]=node('ReferenceLatent','第三参考',conditioning=[prev,0],latent=['32',0])
 g['16']['inputs'].update(positive=['33',0],negative=['34',0])
 for n,k in [('40','product'),('41','food'),('42','rim')]:g[n]=node('LoadImageMask',k+' mask',image=names[k],channel='red')
 g['43']=node('InvertMask','背景许可',mask=['40',0]);g['44']=node('MaskComposite','背景加食物区',destination=['43',0],source=['41',0],x=0,y=0,operation='add');g['45']=node('MaskToImage','初始选区',mask=['44',0]);g['46']=node('ImageBlur','选区柔边',image=['45',0],blur_radius=8,sigma=4.0);g['47']=node('ImageToMask','柔边选区',image=['46',0],channel='red');g['48']=node('ThresholdMask','全部盘沿保护',mask=['42',0],value=0.0);g['49']=node('MaskComposite','扣除盘沿',destination=['47',0],source=['48',0],x=0,y=0,operation='subtract');g['50']=node('SetLatentNoiseMask','区域采样',samples=['10',0],mask=['49',0]);g['21']['inputs']['latent_image']=['50',0]
 g['51']=node('ImageCompositeMasked','恢复保护区',destination=['1',0],source=['22',0],mask=['49',0],x=0,y=0,resize_source=False);g['23']['inputs']['images']=['51',0];g['24']['inputs'].update(image=['51',0],x=0,y=0,width=1024,height=1024)
 g['52']=node('SaveImage','原始采样',images=['22',0],filename_prefix='photo_klein/raw');g['53']=node('MaskToImage','有效蒙版',mask=['49',0]);g['54']=node('SaveImage','保存有效蒙版',images=['53',0],filename_prefix='photo_klein/mask')
 for n in ['23','26']:g[n]['inputs']['filename_prefix']='photo_klein/'+n
 return g

def main():
 p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');a=p.parse_args()
 chain=read(SOURCE/'source_chain.json');diag=read(SOURCE/'diagnostics.json');hist=read(SOURCE/'history.json');receipt=read(SOURCE/'submission.json')
 if hist.get('status',{}).get('status_str')!='success' or hist['prompt'][1]!=receipt['prompt_id'] or receipt['prompt_id']!=diag['prompt_id']:raise ValueError('Layout history/receipt mismatch')
 for name,digest in diag['outputs'].items():
  if sha(SOURCE/name)!=digest:raise ValueError('Layout artifact hash mismatch '+name)
 if sha(FRONT)!=chain['photo_sha256'] or sha(BG)!=chain['background_sha256'] or sha(chain['original'])!=chain['original_sha256']:raise ValueError('Source chain changed')
 paths={'layout':SOURCE/'layout.png','product':SOURCE/'product_mask.png','food':SOURCE/'food_mask.png','rim':SOURCE/'rim_mask.png','front':FRONT,'background':BG};c=ComfyClient();info=c.get('/object_info');preflight=graph({k:str(v) for k,v in paths.items()});check_graph(preflight,info);ui(preflight,info,'实拍盘局部Klein诊断','盘沿保护，仅诊断。')
 if preflight['21']['inputs']['latent_image']!=['50',0] or preflight['50']['inputs']['samples']!=['10',0]:raise ValueError('Source latent must drive masked sampling')
 if any(preflight[k]['inputs']['latent']!=[v,0] for k,v in [('12','10'),('14','11'),('33','32'),('13','10'),('15','11'),('34','32')]):raise ValueError('Reference order mismatch')
 identity={'inputs':{k:{'path':str(v),'sha256':sha(v)} for k,v in paths.items()},'source_chain_sha256':sha(SOURCE/'source_chain.json'),'source_history_sha256':sha(SOURCE/'history.json'),'source_receipt_sha256':sha(SOURCE/'submission.json'),'positive':POS,'negative':NEG,'seed':202611052201,'method':'Klein masked latent; foreground rim protection; model output composited only through effective mask'}
 if a.check:print(json.dumps({'check':'passed','identity':identity},ensure_ascii=False));return
 OUT.mkdir(parents=True,exist_ok=True)
 with (ROOT/'fission/runs/native_gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  receipt_path=OUT/'submission.json'
  if receipt_path.exists():raise RuntimeError('Existing receipt: reconcile explicitly before retry')
  q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('Comfy queue is busy')
  api=graph({k:c.upload(v) for k,v in paths.items()});check_graph(api,info);visual=ui(api,info,'实拍盘局部Klein诊断','盘沿保护，仅诊断。')
  for i,n in enumerate(visual['nodes']):n['pos']=[(i%7)*350,(i//7)*330]
  write(OUT/'identity.json',identity);write(OUT/'workflow.api.json',api);write(OUT/'workflow.ui.json',visual)
  pid=c.submit(api,visual,receipt_path);backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());history,measure=c.wait(pid,OUT,backend);files=c.download(history,OUT/'download')
  for n,name in [('23','result.png'),('26','result_800.png'),('52','raw_generated.png'),('54','edit_mask.png')]:shutil.copyfile(files[n][0],OUT/name)
  before=np.asarray(Image.open(paths['layout']).convert('RGB'));after=np.asarray(Image.open(OUT/'result.png').convert('RGB'));rim=np.asarray(Image.open(paths['rim']).convert('L'));mask=np.asarray(Image.open(OUT/'edit_mask.png').convert('L'));changed=np.any(before!=after,axis=2)
  report={'prompt_id':pid,'seconds':measure.get('backend_wall_seconds'),'changed_pixels':int(changed.sum()),'rim_nonzero_changed_pixels':int(np.sum(changed&(rim>0))),'saved_8bit_zero_mask_changed_pixels':int(np.sum(changed&(mask==0))),'note':'Saved mask is quantized; any nonzero count is reported, not suppressed.','sizes':{n:list(Image.open(OUT/n).size) for n in ['result.png','result_800.png','edit_mask.png']},'outputs':{n:sha(OUT/n) for n in ['result.png','result_800.png','raw_generated.png','edit_mask.png']},'visual_status':'pending'}
  write(OUT/'pixel_check.json',report)
  if report['rim_nonzero_changed_pixels'] or report['sizes']['result.png']!=[1024,1024] or report['sizes']['result_800.png']!=[800,800]:raise ValueError('Protected pixel or dimensions failed')
  print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
