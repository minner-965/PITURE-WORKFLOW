"""FLUX Fill with externally supplied, independently protected plate rim masks."""
import argparse,fcntl,json,subprocess,shutil
from pathlib import Path
import numpy as np
from PIL import Image
from build_workflows import make_a,node,check_graph,ui
from comfy_client import ComfyClient
from native_multishop import ROOT,sha,write
from fission.bridge import equivalent_graph

POS='A natural restaurant photograph: a modest low portion of white rice with fragrant stir-fried pork strips and green peppers, visible natural pork fibers, naturally curled green pepper, distinct rice grains, spread in a low portion over the foreground plate with about 40 percent of the white surface visible. Realistic food contact shadows; soft left-window light and natural plate contact shadow. The rear plate is empty. Exactly two plates; preserve the thin red front edge and all four corners.'
NEG='round plate, oval, deformed rim, raised corners, warped plate, deep bowl, extra rim, color contamination, extra plate, repeated underplate, food beyond plate, food floating, paper-like food, pasted food, clumped food, blurred outline, black edge, blurry meat, oily plastic meat, artificial meat, unrealistic shadows, text, logo'
def graph(names,seed):
 g=make_a();g['1']['inputs']['image']=names['layout'];g.pop('2');g.pop('3');g.pop('14');g.pop('15');g.pop('16');g.pop('17');g.pop('18')
 for n,k in [('20','food_mask'),('21','shadow_zone'),('22','rim_mask')]:g[n]=node('LoadImageMask',k,image=names[k],channel='red')
 g['23']=node('MaskComposite','food plus shadow',destination=['20',0],source=['21',0],x=0,y=0,operation='add');g['24']=node('MaskToImage','mask image',mask=['23',0]);g['25']=node('ImageBlur','soft edge',image=['24',0],blur_radius=8,sigma=4.0);g['26']=node('ImageToMask','soft mask',image=['25',0],channel='red');g['27']=node('MaskComposite','subtract protected rim',destination=['26',0],source=['22',0],x=0,y=0,operation='subtract');g['28']=node('InvertMask','restore outside',mask=['27',0]);g['29']=node('ImageCompositeMasked','restore layout outside sampling area',destination=['13',0],source=['1',0],mask=['28',0],x=0,y=0,resize_source=False)
 g['7']['inputs']['text']=POS;g['9']=node('CLIPTextEncode','negative',clip=['6',0],text=NEG);g['11']['inputs']['mask']=['27',0];g['12']['inputs'].update(cfg=1.05,seed=seed,steps=20,sampler_name='euler',scheduler='normal')
 g['30']=node('SaveImage','raw',images=['13',0],filename_prefix='fission/photo_fill/raw');g['31']=node('SaveImage','final',images=['29',0],filename_prefix='fission/photo_fill/final');g['32']=node('ImageScale','800',image=['29',0],upscale_method='lanczos',width=800,height=800,crop='disabled');g['33']=node('SaveImage','800',images=['32',0],filename_prefix='fission/photo_fill/800');g['34']=node('MaskToImage','effective mask',mask=['27',0]);g['35']=node('SaveImage','effective mask output',images=['34',0],filename_prefix='fission/photo_fill/mask')
 return g

def main():
 p=argparse.ArgumentParser();
 for k in ['layout','food-mask','shadow-zone','rim-mask','output']:p.add_argument('--'+k,type=Path,required=True)
 p.add_argument('--seed',type=int,default=202611051200);p.add_argument('--check',action='store_true');a=p.parse_args();inputs={k:getattr(a,k).resolve(strict=True) for k in ['layout','food_mask','shadow_zone','rim_mask']};out=a.output.resolve()
 for k,path in inputs.items():
  with Image.open(path) as im:
   if im.size!=(1024,1024):raise ValueError(f'{k} must be 1024 square')
 parents={v.parent for v in inputs.values()}
 if len(parents)!=1:raise ValueError('Inputs must share one layout bundle')
 bundle=next(iter(parents));diag=json.loads((bundle/'diagnostics.json').read_text());expected={'layout':'layout.png','food_mask':'food_mask.png','shadow_zone':'shadow_zone.png','rim_mask':'rim_mask.png'}
 for k,n in expected.items():
  if inputs[k].name!=n or diag['outputs'][n]!=sha(inputs[k]):raise ValueError('Bundle hash mismatch: '+k)
 bundle_hashes={n:sha(bundle/n) for n in ['diagnostics.json','source_chain.json','workflow.api.json']}
 names={k:v.name for k,v in inputs.items()};c=ComfyClient();info=c.get('/object_info');g=graph(names,a.seed);check_graph(g,info)
 if a.check:print(json.dumps({'status':'checked_without_submission','input_sha256':{k:sha(v) for k,v in inputs.items()},'bundle_hashes':bundle_hashes,'cfg':1.05,'steps':20,'positive':POS,'negative':NEG},ensure_ascii=False));return
 out.mkdir(parents=True,exist_ok=False)
 with (ROOT/'fission/runs/native_gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('Comfy queue busy')
  names={k:c.upload(v) for k,v in inputs.items()};g=graph(names,a.seed);check_graph(g,info);visual=ui(g,info,'Protected photo fill','Only food and shadow are sampled; rim is protected.')
  write(out/'workflow.api.json',g);write(out/'workflow.ui.json',visual);write(out/'source_chain.json',{'inputs':{k:{'path':str(v),'sha256':sha(v)} for k,v in inputs.items()},'layout_bundle_evidence':bundle_hashes})
  task=c.submit(g,visual,out/'submission.json');pid=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());history,metrics=c.wait(task,out,pid,timeout=7200)
  if not equivalent_graph(history['prompt'][2],g):raise ValueError('History graph mismatch')
  files=c.download(history,out/'download')
  for n,name in [('30','raw.png'),('31','result.png'),('33','result_800.png'),('35','effective_mask.png')]:shutil.copyfile(files[n][0],out/name)
  
  for name in ['raw.png','result.png','effective_mask.png']:
   if Image.open(out/name).size!=(1024,1024):raise ValueError('Unexpected output dimensions '+name)
  if Image.open(out/'result_800.png').size!=(800,800):raise ValueError('Unexpected 800 output dimensions')
  src=np.asarray(Image.open(inputs['layout']).convert('RGB'));dst=np.asarray(Image.open(out/'result.png').convert('RGB'));mask=np.asarray(Image.open(out/'effective_mask.png').convert('RGB'))[:,:,0];rim=np.asarray(Image.open(inputs['rim_mask']).convert('RGB'))[:,:,0];diff=np.any(src!=dst,axis=2);evidence={'outside_mask_changed':int(diff[mask==0].sum()),'rim_changed':int(diff[rim==255].sum()),'rim_protected_pixels':int((rim==255).sum()),'rim_nonzero_effective_mask':int((mask[rim==255]!=0).sum()),'visual_review':'pending','prompt_id':task,'outputs':{n:sha(out/n) for n in ['raw.png','result.png','result_800.png','effective_mask.png']},'metrics':metrics};write(out/'pixel_evidence.json',evidence)
  if evidence['outside_mask_changed'] or evidence['rim_changed'] or evidence['rim_nonzero_effective_mask']:raise ValueError('Protected pixels changed')
  print(json.dumps(evidence,ensure_ascii=False))
if __name__=='__main__':main()
