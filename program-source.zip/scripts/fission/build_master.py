"""Build source-locked w1125 photographic masters and their calibrated masks."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageOps
from scipy.interpolate import splprep, splev
from scipy.ndimage import distance_transform_edt

ROOT = Path(__file__).resolve().parents[2]
INPUT = ROOT / 'input/supplied_20261102/测试品'
TRIAL = ROOT / 'work/diagnostics/fission_trial_claude/v3'
SIZE = (1280, 1024)
# Traces are in a 640x512 proof of each explicitly specified crop.
SHOTS = {
    'A': dict(source='详情页实拍/IMG_5893.jpg', color='黄', crop=(0,2912,4160,6240),
              rim=[(148,217),(152,194),(169,169),(201,147),(239,134),(279,125),(325,122),(374,126),(416,136),(451,151),(481,169),(503,196),(510,219),(504,244),(487,264),(459,284),(418,304),(371,316),(328,320),(280,316),(235,306),(198,288),(169,266),(152,241)],
              shell=[(91,249),(97,221),(111,205),(141,198),(150,182),(171,156),(224,132),(276,122),(327,119),(385,124),(442,144),(485,170),(507,199),(515,222),(522,228),(553,242),(564,258),(563,285),(554,300),(515,313),(484,344),(461,375),(442,395),(411,418),(376,438),(352,447),(320,451),(289,447),(264,435),(239,420),(212,403),(189,379),(171,347),(158,324),(136,297),(121,276),(99,265)],
              shadow=(300,742,1140,974), depth=14, reuse=True),
    'B': dict(source='详情页实拍/IMG_5895.jpg', color='红', crop=(380,3240,4130,6240),
              rim=[(153,218),(159,197),(176,179),(207,160),(245,146),(281,140),(323,138),(367,140),(417,151),(450,163),(477,179),(496,198),(502,217),(500,237),(485,255),(459,273),(422,288),(382,300),(337,305),(297,304),(255,298),(219,288),(188,272),(166,254),(156,238)],
              shell=[(98,257),(104,247),(126,237),(141,228),(148,209),(166,180),(198,158),(244,142),(284,135),(329,134),(374,137),(417,147),(459,164),(490,184),(508,209),(525,215),(540,223),(552,239),(555,256),(547,265),(527,276),(514,294),(499,311),(486,327),(473,358),(456,382),(429,402),(408,416),(394,432),(365,445),(342,451),(314,451),(289,446),(262,436),(244,423),(221,411),(198,389),(181,366),(169,339),(159,316),(146,308),(109,299),(100,286)],
              shadow=(341,741,1260,980), depth=13, reuse=False),
    'C': dict(source='sku实拍/IMG_1084.jpg', color='蓝', crop=(1170,920,5170,4120),
              rim=[(146,202),(153,183),(169,166),(196,151),(234,139),(274,132),(316,129),(352,132),(392,138),(428,150),(459,165),(477,183),(484,201),(480,218),(464,238),(439,251),(408,265),(367,275),(320,280),(282,280),(241,274),(206,263),(179,250),(156,230)],
              shell=[(92,230),(102,216),(122,211),(137,205),(146,182),(173,157),(213,140),(267,128),(314,125),(364,128),(418,141),(456,158),(479,179),(490,201),(505,209),(529,215),(538,225),(540,250),(532,262),(504,270),(485,286),(468,306),(460,336),(439,357),(411,384),(388,401),(370,414),(345,423),(315,426),(284,422),(257,413),(238,401),(209,380),(188,356),(172,333),(157,300),(136,276),(102,265),(92,254)],
              shadow=(345,662,1250,914), depth=14, reuse=False),
}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def smooth_silhouette(points):
    coords=np.array(points+[points[0]],dtype=float).T
    fit,_=splprep(coords,s=0,per=True)
    xs,ys=splev(np.linspace(0,1,1000),fit)
    mask=Image.new('L',SIZE)
    ImageDraw.Draw(mask).polygon(list(zip(xs*2,ys*2)), fill=255)
    return np.asarray(mask)>0

def delta_alpha(binary, feather):
    return Image.fromarray((np.minimum(distance_transform_edt(binary)/feather,1)*255).round().astype('uint8'))

from fission.ledger import tracked_cpu

@tracked_cpu('master')
def make(shop):
    spec=SHOTS[shop]
    out=ROOT/'fission/masters'/shop
    out.mkdir(parents=True,exist_ok=True)
    src=INPUT/spec['source']
    with Image.open(src) as image:
        image=ImageOps.exif_transpose(image).convert('RGB')
        cropped=image.crop(spec['crop']).resize(SIZE,Image.Resampling.LANCZOS)
    if spec['reuse']:
        legacy=Image.open(TRIAL/'master_1280.png').convert('RGB')
        if np.max(np.abs(np.asarray(cropped).astype(int)-np.asarray(legacy)))<=1:
            cropped=legacy
    cropped.save(out/'master_1280.png')
    shell=smooth_silhouette(spec['shell'])
    rim=smooth_silhouette(spec['rim'])
    shell |= rim
    inside=distance_transform_edt(rim)>4
    # The liquid sits below the far rim and meets the near inner wall. Clipping
    # against the real opening prevents a second white arc in front of the fill.
    down=spec['depth']*2
    projected=np.zeros(inside.shape,dtype=bool)
    projected[down:]=inside[:-down]
    food=delta_alpha(inside & projected,4)
    food.save(out/'food_mask_1280.png')
    Image.fromarray((shell*255).astype('uint8')).save(out/'bowl_mask_1280.png')
    props_guard=distance_transform_edt(~shell)<=30
    shadow=Image.new('L',SIZE)
    ImageDraw.Draw(shadow).ellipse(spec['shadow'],fill=255)
    props_guard |= np.asarray(shadow)>0
    props_guard[870:]=True
    props=delta_alpha(~props_guard,12)
    props.save(out/'props_mask_1280.png')
    locked=(np.asarray(props)==0)&(np.asarray(food)==0)
    Image.fromarray((locked*255).astype('uint8')).save(out/'protect_1280.png')
    assert not np.any((np.asarray(food)>0)&(np.asarray(props)>0))
    assert np.all(locked[shell & (np.asarray(food)==0)])
    proof=Image.composite(Image.new('RGB',SIZE,'#078ed3'),cropped,props.point(lambda i:round(i*.32)))
    proof=Image.composite(Image.new('RGB',SIZE,'#f76444'),proof,food.point(lambda i:round(i*.55)))
    proof.thumbnail((800,640));proof.save(out/'mask_review.jpg',quality=92)
    names=['master_1280.png','food_mask_1280.png','props_mask_1280.png','protect_1280.png','bowl_mask_1280.png']
    record=dict(shop=shop,sku='w1125',color=spec['color'],source=str(src.relative_to(ROOT)),source_sha256=digest(src),
                source_exif_orientation='applied before crop',crop_xyxy=spec['crop'],size=SIZE,
                master_kind='photographer original frame with continuous surface and retained contact shadows',
                food_bbox=food.getbbox(),bowl_width_fraction=round((np.where(shell)[1].max()-np.where(shell)[1].min()+1)/1280,3),
                guard='protect=unmodified in all layers; props also excludes full bowl and 30px margin',
                editable_overlap=0,artifacts={n:digest(out/n) for n in names})
    if spec['reuse']:
        record['v3_source_pixel_identical']=bool(np.array_equal(np.asarray(cropped),np.asarray(legacy)))
    (out/'master.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(shop, record['bowl_width_fraction'], record['food_bbox'])
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('shops',nargs='*',default=list(SHOTS))
    for shop in parser.parse_args().shops: make(shop)
