"""Single-sampler regional multi-reference color experiment; preflight and mask QA."""
import argparse,json,shutil,subprocess
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from build_workflows import node,check_graph,ui
from comfy_client import ComfyClient
from native_multishop import ROOT,read,write,sha

def main():
 p=argparse.ArgumentParser();p.add_argument('--config',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--check',action='store_true');p.add_argument('--mask-preview',action='store_true');a=p.parse_args();cfg=read(a.config);out=a.output.resolve();src=Path(cfg['source']).resolve(strict=True);items=cfg['regions'];c=ComfyClient();schema=c.get('/object_info');g={'1':node('LoadImage','已批准原图',image=str(src)),'901':node('EmptyImage','多边形画布',width=1024,height=1024,batch_size=1,color=0),'902':node('SolidMask','空白',value=0.0,width=1024,height=1024),'903':node('ImageToMask','蓝通道',image=['1',0],channel='blue'),'904':node('ImageToMask','红通道',image=['1',0],channel='red'),'905':node('MaskComposite','蓝减红',destination=['903',0],source=['904',0],x=0,y=0,operation='subtract'),'906':node('ThresholdMask','原蓝纹识别',mask=['905',0],value=.035)};olds=[]
 for j,it in enumerate(items):
  spec=read(it['regions']);prev='902';k=0
  for op,polys in [('add',spec['allowed_polygons']),('subtract',spec.get('exclude_polygons',[]))]:
   for poly in polys:
    a1=str(1000+j*100+k*2);a2=str(1001+j*100+k*2);k+=1;d={'outer_polygon':poly,'food_polygon':poly,'placements':[{'x':0,'y':0,'width':1024,'role':'hero'}],'shadow_radius':1};g[a1]=node('FissionPhotoLock','候选多边形',photo=['901',0],background=['901',0],layout_json=json.dumps(d));g[a2]=node('MaskComposite','区域合并',destination=[prev,0],source=[a1,1],x=0,y=0,operation=op);prev=a2
  olds.append(prev)
 masks=[]
 for j,it in enumerate(items):
  n=2000+j*30;g[str(n)]=node('GrowMask','扩大7像素',mask=[olds[j],0],expand=7,tapered_corners=True);g[str(n+1)]=node('MaskComposite','只补原蓝纹',destination=[str(n),0],source=['906',0],x=0,y=0,operation='multiply');prev=str(n+1)
  for k in range(len(items)):
   if k==j:continue
   name=str(n+2+k);g[name]=node('MaskComposite','排除邻碗候选',destination=[prev,0],source=[olds[k],0],x=0,y=0,operation='subtract');prev=name
  g[str(n+7)]=node('MaskComposite','区域并集',destination=[olds[j],0],source=[prev,0],x=0,y=0,operation='add');g[str(n+8)]=node('MaskToImage','硬边',mask=[str(n+7),0]);g[str(n+9)]=node('ImageBlur','柔边2',image=[str(n+8),0],blur_radius=2,sigma=1.0);g[str(n+10)]=node('ImageToMask','柔边',image=[str(n+9),0],channel='red');g[str(n+11)]=node('MaskComposite','限定硬边内',destination=[str(n+10),0],source=[str(n+7),0],x=0,y=0,operation='multiply');g[str(n+12)]=node('MaskToImage','实际mask',mask=[str(n+11),0]);g[str(n+13)]=node('SaveImage','保存mask',images=[str(n+12),0],filename_prefix=f'gaiwan_regional/mask_{j}');masks.append(str(n+11))
 prev=masks[0]
 for j,m in enumerate(masks[1:]):
  n=str(2200+j);g[n]=node('MaskComposite','联合mask',destination=[prev,0],source=[m,0],x=0,y=0,operation='add');prev=n
 g['2210']=node('MaskToImage','联合mask',mask=[prev,0]);g['2211']=node('SaveImage','联合mask保存',images=['2210',0],filename_prefix='gaiwan_regional/union')
 # Model graph references separately and uses one sampler only.
 base=read(ROOT/'fission/workflows/商品主图近景/多店铺无字主图/02_商品双参考与800输出.api.json');base.update(g);g=base;g['1']['inputs']['image']=str(src)
 for n in ['2','7','11','12','13','14','15','17','27','28']:g.pop(n,None)
 for j,it in enumerate(items):
  n=3000+j*30;x,y,w,h=it['context'];photo=Path(it['photo']).resolve(strict=True);g[str(n)]=node('ImageCrop','该碗上下文',image=['1',0],x=x,y=y,width=w,height=h);g[str(n+1)]=node('VAEEncode','上下文编码',pixels=[str(n),0],vae=['5',0]);g[str(n+2)]=node('LoadImage','该碗实拍',image=str(photo));g[str(n+3)]=node('ImageCrop','实拍取景',image=[str(n+2),0],x=1900,y=1650,width=2450,height=2100);g[str(n+4)]=node('ImageScale','实拍等比缩放',image=[str(n+3),0],width=640,height=544,upscale_method='lanczos',crop='disabled');g[str(n+5)]=node('VAEEncode','实拍编码',pixels=[str(n+4),0],vae=['5',0])
  for k,(pol,text) in enumerate([('positive',it['positive']),('negative',it['negative'])]):
   z=n+6+k*5;g[str(z)]=node('CLIPTextEncode',pol+'文本',clip=['4',0],text=text);g[str(z+1)]=node('ReferenceLatent','上下文参考',conditioning=[str(z),0],latent=[str(n+1),0]);g[str(z+2)]=node('ReferenceLatent','商品参考',conditioning=[str(z+1),0],latent=[str(n+5),0]);g[str(z+3)]=node('ConditioningSetAreaPercentage','区域上下文',conditioning=[str(z+2),0],x=x/1024,y=y/1024,width=w/1024,height=h/1024,strength=1.0);g[str(z+4)]=node('ConditioningSetMask','区域条件',conditioning=[str(z+3),0],mask=[masks[j],0],strength=1.0,set_cond_area='default')
 for k,pol in enumerate(['positive','negative']):
  prev=str(3010+k*5)
  for j in range(1,len(items)):
   n=str(3400+k*10+j);g[n]=node('ConditioningCombine','合并区域条件',conditioning_1=[prev,0],conditioning_2=[str(3000+j*30+10+k*5),0]);prev=n
  g['16']['inputs'][pol]=[prev,0]
 g['16']['inputs']['cfg']=1.3;g['18']['inputs']['steps']=4;g['19']['inputs']['noise_seed']=202611060301;g['3500']=node('SetLatentNoiseMask','联合区域采样',samples=['10',0],mask=[str(2200+len(items)-2),0]);g['21']['inputs']['latent_image']=['3500',0];g['3501']=node('ImageCompositeMasked','保护联合区域外',destination=['1',0],source=['22',0],mask=[str(2200+len(items)-2),0],x=0,y=0,resize_source=False);g['23']['inputs']['images']=['3501',0];g['24']['inputs']['image']=['3501',0]
 check_graph(g,schema);visual=ui(g,schema,'整组区域条件预检','一个采样器，五区域参考，待审核。');out.mkdir(parents=True,exist_ok=True);write(out/'sample_check.api.json',g);write(out/'sample_check.ui.json',visual);write(out/'source_chain.json',{'source':str(src),'source_sha256':sha(src),'config_sha256':sha(a.config),'regions':[{'path':x['regions'],'sha256':sha(x['regions']),'photo':x['photo'],'photo_sha256':sha(x['photo']),'context':x['context']} for x in items]})
 if a.check:print('check passed; no sampling');return
 if not a.mask_preview:raise RuntimeError('Only preview is enabled pending approval')
 # Submit only ancestors of mask outputs, with source uploaded; no sampling nodes.
 mg={k:v for k,v in g.items() if k in ['1','901','902','903','904','905','906'] or (1000<=int(k)<2300)};mg['1']['inputs']['image']=c.upload(src);check_graph(mg,schema);mv=ui(mg,schema,'区域mask预览','仅遮罩，无采样。');write(out/'mask_workflow.api.json',mg);write(out/'mask_workflow.ui.json',mv);pid=c._submit_uncached(mg,mv,out/'mask_submission.json');backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());hist,metrics=c._wait_uncached(pid,out/'mask_history',backend);files=c._download_uncached(hist,out/'mask_download');arr=[]
 for j in range(len(items)):
  path=out/f'mask_{j+1}.png';shutil.copyfile(files[str(2013+j*30)][0],path);arr.append(np.asarray(Image.open(path).convert('L')))
 shutil.copyfile(files['2211'][0],out/'union_mask.png');overlap=int((np.sum([z>0 for z in arr],axis=0)>1).sum());baseimg=Image.open(src).convert('RGB').convert('RGBA');palette=[(255,30,30),(0,210,120),(220,50,255),(20,80,255),(255,180,0)];layer=Image.new('RGBA',baseimg.size);pix=np.asarray(layer).copy()
 for z,col in zip(arr,palette):pix[z>0]=(*col,120)
 overlay=Image.alpha_composite(baseimg,Image.fromarray(pix,'RGBA'));draw=ImageDraw.Draw(overlay)
 for it,col in zip(items,palette):x,y,w,h=it['context'];draw.rectangle((x,y,x+w-1,y+h-1),outline=col+(255,),width=2)
 overlay.convert('RGB').save(out/'mask_context_overlay.png');coverage=[]
 for z,it in zip(arr,items):x,y,w,h=it['context'];valid=np.zeros(z.shape,dtype=bool);valid[y:y+h,x:x+w]=True;coverage.append(int(((z>0)&~valid).sum()))
 write(out/'mask_qa.json',{'prompt_id':pid,'overlap_pixels':overlap,'outside_context_pixels':coverage,'masks_sha256':[sha(out/f'mask_{j+1}.png') for j in range(len(items))],'status':'pending_visual_review','blue_missed':'需按可见器型高倍对照，自动选择器仅检测polygon外7px范围'});print(json.dumps(read(out/'mask_qa.json'),ensure_ascii=False))
if __name__=='__main__':main()
