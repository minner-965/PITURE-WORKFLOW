"""Single B05 diagnostic: real-layout latent, masked Klein sampling, explicit protection."""
import argparse,fcntl,json,shutil,subprocess
from pathlib import Path
import numpy as np
from scipy import ndimage
from PIL import Image
from build_workflows import node,check_graph,ui
from comfy_client import ComfyClient
from native_multishop import ROOT,sha,write,read
BASE=ROOT/'fission/runs/fastplate_20261104/全套重做';SOURCE=BASE/'诊断测试/photo_lock_v02';PRIOR=BASE/'诊断测试/photo_klein_v01';OUT=BASE/'诊断测试/photo_klein_v02';FRONT=BASE/'B05/product/approved_batch_v04/product_reference.png';BG=BASE/'B05/background/v01/result.png'
POS='A natural close restaurant photograph. Preserve the existing two real red exterior white interior plates, their positions, four corners, thin rims, rear empty plate, background and tabletop shadows. On the front plate serve a low naturally spread portion of white rice, fully cooked thin pork strips stir-fried with soft cooked green pepper strips and scallions. A light brown savory sauce lightly coats the food and joins the pork, peppers and rice naturally, with realistic food contact shadows and subtle reflections. Leave about forty percent of the white plate interior visible. No large rice ball, whole raw peppers or pink pork. Food should look freshly cooked, moist and appetizing, integrated into the plate and lighting.'
NEG='raw pepper seeds, whole raw green pepper, uncooked pink pork, dry separated strips, food cutout seams, polygonal white patch, floating food, harsh boundary, plastic food, oversized rice mound, blurry food, text, extra plate, deformed rim, round plate.'


def graph(names):
 g=read(ROOT/'fission/workflows/商品主图近景/多店铺无字主图/02_商品双参考与800输出.api.json')
 for i in ['17','27','28']:g.pop(i,None)
 g['1']['inputs']['image']=names['layout'];g['2']['inputs']['image']=names['front'];g['7']['inputs'].update(image=['2',0],width=1024,height=592)
 g['8']['inputs']['text']=POS;g['9']['inputs']['text']=NEG;g['19']['inputs']['noise_seed']=202611052202
 g['30']=node('LoadImage','背景参考',image=names['background']);g['31']=node('ImageScale','场景归一化',image=['30',0],upscale_method='lanczos',width=768,height=768,crop='disabled');g['32']=node('VAEEncode','背景编码',pixels=['31',0],vae=['5',0])
 for i,prev in [('33','14'),('34','15')]:g[i]=node('ReferenceLatent','第三参考',conditioning=[prev,0],latent=['32',0])
 g['16']['inputs'].update(positive=['33',0],negative=['34',0])
 for n,k in [('40','product'),('41','food'),('42','rim')]:g[n]=node('LoadImageMask',k+' mask',image=names[k],channel='red')
 g['43']=node('GrowMask','扩展食物区40',mask=['41',0],expand=40,tapered_corners=True)
 g['44']=node('ThresholdMask','盘体非零保护范围',mask=['40',0],value=0.0)
 g['45']=node('GrowMask','盘体内缩40',mask=['44',0],expand=-40,tapered_corners=True)
 g['46']=node('MaskComposite','食物区限制在盘内',destination=['43',0],source=['45',0],x=0,y=0,operation='multiply')
 g['47']=node('MaskComposite','保护盘沿与其余盘体',destination=['44',0],source=['46',0],x=0,y=0,operation='subtract')
 g['48']=node('MaskToImage','柔化前食物区',mask=['46',0])
 g['55']=node('ImageBlur','食物区柔边8',image=['48',0],blur_radius=8,sigma=4.0)
 g['56']=node('ImageToMask','柔边食物区',image=['55',0],channel='red')
 g['57']=node('MaskComposite','扣除盘体保护',destination=['56',0],source=['47',0],x=0,y=0,operation='subtract')
 g['49']=node('MaskComposite','限制在许可食物区',destination=['57',0],source=['46',0],x=0,y=0,operation='multiply')
 g['50']=node('SetLatentNoiseMask','仅食物区采样',samples=['10',0],mask=['49',0]);g['21']['inputs']['latent_image']=['50',0]
 g['58']=node('SaveImage','扩展食物许可区',images=['48',0],filename_prefix='photo_klein_v02/expanded_food')
 g['59']=node('MaskToImage','新保护区',mask=['47',0]);g['60']=node('SaveImage','保存新保护区',images=['59',0],filename_prefix='photo_klein_v02/protection')
 g['61']=node('ThresholdMask','保护核心',mask=['47',0],value=0.999);g['62']=node('MaskToImage','保护核心图',mask=['61',0]);g['63']=node('SaveImage','保存保护核心',images=['62',0],filename_prefix='photo_klein_v02/protection_core')
 g['51']=node('ImageCompositeMasked','恢复保护区',destination=['1',0],source=['22',0],mask=['49',0],x=0,y=0,resize_source=False);g['23']['inputs']['images']=['51',0];g['24']['inputs'].update(image=['51',0],x=0,y=0,width=1024,height=1024)
 g['52']=node('SaveImage','原始采样',images=['22',0],filename_prefix='photo_klein/raw');g['53']=node('MaskToImage','有效蒙版',mask=['49',0]);g['54']=node('SaveImage','保存有效蒙版',images=['53',0],filename_prefix='photo_klein/mask')
 for n in ['23','26']:g[n]['inputs']['filename_prefix']='photo_klein/'+n
 return g

def main():
 p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');a=p.parse_args()
 chain=read(SOURCE/'source_chain.json');diag=read(SOURCE/'diagnostics.json');hist=read(SOURCE/'history.json');receipt=read(SOURCE/'submission.json')
 if hist.get('status',{}).get('status_str')!='success' or hist['prompt'][1]!=receipt['prompt_id'] or receipt['prompt_id']!=diag['prompt_id']:raise ValueError('Layout history/receipt mismatch')
 for name,digest in diag['outputs'].items():
  if sha(SOURCE/name)!=digest:raise ValueError('Layout artifact hash mismatch '+name)
 if sha(FRONT)!=chain['photo_sha256'] or sha(BG)!=chain['background_sha256'] or sha(chain['original'])!=chain['original_sha256']:raise ValueError('Source chain changed')
 prior=read(PRIOR/'pixel_check.json'); prior_receipt=read(PRIOR/'submission.json');prior_history=read(PRIOR/'history.json')
 if prior['outputs']['result.png']!=sha(PRIOR/'result.png') or prior['prompt_id']!=prior_receipt['prompt_id'] or prior['prompt_id']!=prior_history['prompt'][1] or prior_history['status']['status_str']!='success':raise ValueError('Previous result provenance mismatch')
 paths={'layout':PRIOR/'result.png','product':SOURCE/'product_mask.png','food':SOURCE/'food_mask.png','rim':SOURCE/'rim_mask.png','front':FRONT,'background':BG};c=ComfyClient();info=c.get('/object_info');preflight=graph({k:str(v) for k,v in paths.items()});check_graph(preflight,info);ui(preflight,info,'实拍盘局部Klein诊断','盘沿保护，仅诊断。')
 if preflight['21']['inputs']['latent_image']!=['50',0] or preflight['50']['inputs']['samples']!=['10',0]:raise ValueError('Source latent must drive masked sampling')
 if any(preflight[k]['inputs']['latent']!=[v,0] for k,v in [('12','10'),('14','11'),('33','32'),('13','10'),('15','11'),('34','32')]):raise ValueError('Reference order mismatch')
 identity={'inputs':{k:{'path':str(v),'sha256':sha(v)} for k,v in paths.items()},'prior_result_sha256':sha(PRIOR/'result.png'),'prior_receipt_sha256':sha(PRIOR/'submission.json'),'prior_history_sha256':sha(PRIOR/'history.json'),'original_layout_sha256':sha(SOURCE/'layout.png'),'source_chain_sha256':sha(SOURCE/'source_chain.json'),'source_history_sha256':sha(SOURCE/'history.json'),'source_receipt_sha256':sha(SOURCE/'submission.json'),'positive':POS,'negative':NEG,'seed':202611052202,'method':'Klein masked latent; foreground rim protection; model output composited only through effective mask'}
 if a.check:print(json.dumps({'check':'passed','identity':identity},ensure_ascii=False));return
 OUT.mkdir(parents=True,exist_ok=True)
 with (ROOT/'fission/runs/native_gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  receipt_path=OUT/'submission.json'
  if receipt_path.exists():raise RuntimeError('Existing receipt: reconcile explicitly before retry')
  q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('Comfy queue is busy')
  api=graph({k:c.upload(v) for k,v in paths.items()});check_graph(api,info);visual=ui(api,info,'实拍盘局部Klein诊断','盘沿保护，仅诊断。')
  for i,n in enumerate(visual['nodes']):n['pos']=[(i%7)*350,(i//7)*330]
  write(OUT/'identity.json',identity);write(OUT/'workflow.api.json',api);write(OUT/'workflow.ui.json',visual)
  pid=c.submit(api,visual,receipt_path);backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());history,measure=c.wait(pid,OUT,backend);files=c.download(history,OUT/'download')
  for n,name in [('23','result.png'),('26','result_800.png'),('52','raw_generated.png'),('54','edit_mask.png'),('58','expanded_food_mask.png'),('60','new_protection_mask.png'),('63','protection_core.png')]:shutil.copyfile(files[n][0],OUT/name)
  before=np.asarray(Image.open(paths['layout']).convert('RGB'));after=np.asarray(Image.open(OUT/'result.png').convert('RGB'));rim=np.asarray(Image.open(paths['rim']).convert('L'));mask=np.asarray(Image.open(OUT/'edit_mask.png').convert('L'));changed=np.any(before!=after,axis=2)
  product=np.asarray(Image.open(paths['product']).convert('L'))>0
  protection=np.asarray(Image.open(OUT/'protection_core.png').convert('L'))>0
  expanded=np.asarray(Image.open(OUT/'expanded_food_mask.png').convert('L'))>0
  footprint=np.array([[0,1,0],[1,1,1],[0,1,0]],dtype=bool)
  interior=ndimage.binary_erosion(product,structure=footprint,iterations=40,border_value=1)
  boundary=product & ~interior
  report={'prompt_id':pid,'seconds':measure.get('backend_wall_seconds'),'changed_pixels':int(changed.sum()),'new_protection_core_changed_pixels':int(np.sum(changed&protection)),'product_outer_40px_changed_pixels':int(np.sum(changed&boundary)),'rear_region_y_lt_520_changed_pixels':int(changed[:520].sum()),'expanded_food_y_lt_520_pixels':int(expanded[:520].sum()),'old_rim_changed_pixels_in_allowed_food_area':int(np.sum(changed&(rim>0)&expanded)),'saved_8bit_zero_mask_changed_pixels':int(np.sum(changed&(mask==0))),'note':'Saved 8-bit mask zero count is reported unmodified; soft transition values remain unaltered.','sizes':{n:list(Image.open(OUT/n).size) for n in ['result.png','result_800.png','edit_mask.png','expanded_food_mask.png','new_protection_mask.png','protection_core.png']},'outputs':{n:sha(OUT/n) for n in ['result.png','result_800.png','raw_generated.png','edit_mask.png','expanded_food_mask.png','new_protection_mask.png','protection_core.png']},'visual_status':'pending'}
  write(OUT/'pixel_check.json',report)
  if any(report[k] for k in ['new_protection_core_changed_pixels','product_outer_40px_changed_pixels','rear_region_y_lt_520_changed_pixels','expanded_food_y_lt_520_pixels']) or report['sizes']['result.png']!=[1024,1024] or report['sizes']['result_800.png']!=[800,800]:raise ValueError('Protection, exclusion, or dimensions failed')
  print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
