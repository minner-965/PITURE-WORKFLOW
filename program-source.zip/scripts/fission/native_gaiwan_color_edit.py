"""One native product-color edit with a bounded ComfyUI polygon mask."""
import argparse,fcntl,json,shutil,subprocess
from pathlib import Path
import numpy as np
from PIL import Image
from build_workflows import node,check_graph,ui
from comfy_client import ComfyClient
from native_multishop import ROOT,read,write,sha

def main():
 p=argparse.ArgumentParser();p.add_argument('--config',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--check',action='store_true');p.add_argument('--mask-preview',action='store_true');a=p.parse_args();cfg=read(a.config);out=a.output.resolve();source=Path(cfg['source']).resolve(strict=True);photo=Path(cfg['photo']).resolve(strict=True);regions=read(Path(cfg['regions']));allowed=regions['allowed_polygons'];excluded=regions.get('exclude_polygons',[])
 if sha(source)!=cfg['source_sha256'] or sha(photo)!=cfg['photo_sha256']:raise ValueError('Input hash changed')
 if not allowed:raise ValueError('Allowed polygons required')
 c=ComfyClient();info=c.get('/object_info')
 def mask_graph():
  g={'300':node('EmptyImage','多边形画布',width=1024,height=1024,batch_size=1,color=0),'301':node('SolidMask','空遮罩',value=0.0,width=1024,height=1024)};prev='301';ix=0
  for operation,polys in [('add',allowed),('subtract',excluded)]:
   for poly in polys:
    if len(poly)<3 or any(len(pt)!=2 or not all(0<=z<=1 for z in pt) for pt in poly):raise ValueError('normalized polygon required')
    n=str(310+ix*2);m=str(311+ix*2);ix+=1;spec={'outer_polygon':poly,'food_polygon':poly,'placements':[{'x':0,'y':0,'width':1024,'role':'hero'}],'shadow_radius':1};g[n]=node('FissionPhotoLock','多边形区域',photo=['300',0],background=['300',0],layout_json=json.dumps(spec));g[m]=node('MaskComposite','允许或排除区域',destination=[prev,0],source=[n,1],x=0,y=0,operation=operation);prev=m
  g['500']=node('MaskToImage','边界内许可',mask=[prev,0]);g['501']=node('ImageBlur','2像素柔边',image=['500',0],blur_radius=2,sigma=1.0);g['502']=node('ImageToMask','柔边遮罩',image=['501',0],channel='red');g['503']=node('MaskComposite','限制原边界',destination=['502',0],source=[prev,0],x=0,y=0,operation='multiply');g['504']=node('ThresholdMask','剔除量化微值',mask=['503',0],value=1/255);g['505']=node('MaskComposite','有效遮罩',destination=['503',0],source=['504',0],x=0,y=0,operation='multiply');g['506']=node('MaskToImage','有效遮罩图片',mask=['505',0]);g['507']=node('SaveImage','保存有效遮罩',images=['506',0],filename_prefix='gaiwan_color/mask');return g
 def full_graph(paths):
  g=read(ROOT/'fission/workflows/商品主图近景/多店铺无字主图/02_商品双参考与800输出.api.json');g.update(mask_graph());g.pop('17',None);g['1']['inputs']['image']=paths['source'];g['2']['inputs']['image']=paths['photo'];x,y,w,h=cfg.get('crop_xywh',[1900,1650,2450,2100]);g['27']['inputs'].update(x=x,y=y,width=w,height=h);g['7']['inputs'].update(width=640,height=round(640*h/w/16)*16);g['8']['inputs']['text']=cfg['positive'];g['9']['inputs']['text']=cfg['negative'];g['16']['inputs']['cfg']=1.3;g['18']['inputs']['steps']=(4 if cfg.get('schedule','tail5')=='full4' else 40);g['19']['inputs']['noise_seed']=cfg['seed'];g['510']=node('SplitSigmas','低噪声尾段',sigmas=['18',0],step=35);g['511']=node('SetLatentNoiseMask','仅指定碗外观',samples=['10',0],mask=['505',0]);g['21']['inputs'].update(latent_image=['511',0],sigmas=(['18',0] if cfg.get('schedule','tail5')=='full4' else ['510',1]));g['512']=node('ImageCompositeMasked','保护源图区域',destination=['1',0],source=['22',0],mask=['505',0],x=0,y=0,resize_source=False);g['23']['inputs']['images']=['512',0];g['24']['inputs'].update(image=['512',0],x=0,y=0,width=1024,height=1024);g['513']=node('SaveImage','原始采样',images=['22',0],filename_prefix='gaiwan_color/raw');g['514']=node('SaveImage','源图',images=['1',0],filename_prefix='gaiwan_color/source');
  for n in ['23','26','28']:g[n]['inputs']['filename_prefix']='gaiwan_color/'+n
  return g
 g=full_graph({'source':str(source),'photo':str(photo)});check_graph(g,info);visual=ui(g,info,'逐碗颜色编辑','仅选中外壁和底碟，源图以外均保护。')
 if a.check:print(json.dumps({'check':'passed','source_sha256':sha(source),'photo_sha256':sha(photo),'regions_sha256':sha(cfg['regions']),'seed':cfg['seed'],'steps':(4 if cfg.get('schedule','tail5')=='full4' else 5),'first_sigma':(1.0 if cfg.get('schedule','tail5')=='full4' else 0.533864),'schedule':cfg.get('schedule','tail5'),'cfg':1.3}));return
 out.mkdir(parents=True,exist_ok=True)
 with (ROOT/'fission/runs/native_gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('queue busy')
  if a.mask_preview:
   mg=mask_graph();check_graph(mg,info);mv=ui(mg,info,'逐碗编辑遮罩','无采样预览。');write(out/'mask_workflow.api.json',mg);write(out/'mask_workflow.ui.json',mv);pid=c._submit_uncached(mg,mv,out/'mask_submission.json');backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());hist,metrics=c._wait_uncached(pid,out/'mask_history',backend);files=c._download_uncached(hist,out/'mask_download');shutil.copyfile(files['507'][0],out/'edit_mask.png');base=Image.open(source).convert('RGB');mask=Image.open(out/'edit_mask.png').convert('L');Image.composite(Image.new('RGB',base.size,(255,35,20)),base,mask.point(lambda x:x//2)).save(out/'mask_overlay.png');write(out/'mask_source.json',{'source_sha256':sha(source),'regions_sha256':sha(cfg['regions']),'mask_sha256':sha(out/'edit_mask.png'),'prompt_id':pid});print(json.dumps({'mask':str(out/'edit_mask.png'),'overlay':str(out/'mask_overlay.png')}));return
  review=read(out/'mask_review.json');ms=read(out/'mask_source.json')
  if review.get('status')!='passed' or review.get('mask_sha256')!=sha(out/'edit_mask.png') or ms['regions_sha256']!=sha(cfg['regions']) or ms['source_sha256']!=sha(source):raise ValueError('Mask approval or inputs changed')
  if (out/'submission.json').exists():raise ValueError('Existing receipt')
  g=full_graph({'source':c.upload(source),'photo':c.upload(photo)});check_graph(g,info);visual=ui(g,info,'逐碗颜色编辑','仅选中外壁和底碟，源图以外均保护。');write(out/'workflow.api.json',g);write(out/'workflow.ui.json',visual);write(out/'identity.json',{'source':str(source),'source_sha256':sha(source),'photo':str(photo),'photo_sha256':sha(photo),'regions_sha256':sha(cfg['regions']),'approved_mask_sha256':sha(out/'edit_mask.png'),'config_sha256':sha(a.config),'seed':cfg['seed'],'steps':(4 if cfg.get('schedule','tail5')=='full4' else 5),'first_sigma':(1.0 if cfg.get('schedule','tail5')=='full4' else 0.533864),'schedule':cfg.get('schedule','tail5'),'cfg':1.3,'positive':cfg['positive'],'negative':cfg['negative']});pid=c.submit(g,visual,out/'submission.json');backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());hist,metrics=c.wait(pid,out,backend);files=c.download(hist,out/'download')
  for n,name in {'23':'result.png','26':'result_800.png','28':'photo_reference.png','507':'actual_mask.png','513':'raw_generated.png','514':'source.png'}.items():shutil.copyfile(files[n][0],out/name)
  before=np.asarray(Image.open(out/'source.png').convert('RGB'));after=np.asarray(Image.open(out/'result.png').convert('RGB'));mask=np.asarray(Image.open(out/'actual_mask.png').convert('L'));changed=np.any(before!=after,axis=2);report={'prompt_id':pid,'seconds':metrics.get('backend_wall_seconds'),'outside_zero_mask_changed':int((changed&(mask==0)).sum()),'mask_matches_preview':np.array_equal(np.asarray(Image.open(out/'actual_mask.png').convert('L')),np.asarray(Image.open(out/'edit_mask.png').convert('L'))),'sizes':{n:list(Image.open(out/n).size) for n in ['source.png','result.png','result_800.png','actual_mask.png']},'outputs':{n:sha(out/n) for n in ['source.png','result.png','result_800.png','actual_mask.png','raw_generated.png','photo_reference.png']},'status':'pending_visual_review'};write(out/'pixel_check.json',report);print(json.dumps(report,ensure_ascii=False))
  if not report['mask_matches_preview'] or report['outside_zero_mask_changed'] or report['sizes']['result.png']!=[1024,1024] or report['sizes']['result_800.png']!=[800,800]:raise ValueError('Protection or output dimensions failed')
if __name__=='__main__':main()
