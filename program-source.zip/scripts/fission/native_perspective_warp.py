import fcntl, subprocess, shutil, json, time, importlib.util
from pathlib import Path
import numpy as np
import torch
from PIL import Image
from build_workflows import node,check_graph,ui
from comfy_client import ComfyClient
from native_multishop import ROOT,sha,write
from fission.deterministic import run as deterministic_run
BASE=ROOT/'fission/runs/fastplate_20261104/全套重做'
SRC=BASE/'A01/product/corner_v07/result.png'
OUT=BASE/'A01/product/perspective_warp_v03'
NODE=Path('/Users/luohuiwu/ComfyUI-Installs/E-commerce image workflow/ComfyUI/custom_nodes/fission_perspective/__init__.py')

def graph(image,corner,center):
 return {'1':node('LoadImage','原图',image=image),'2':node('FissionPerspective','局部二维位移',image=['1',0],corner_delta=corner,center_delta=center),'3':node('SaveImage','1024',images=['2',0],filename_prefix='perspective_warp/result'),'4':node('ImageCrop','取景',image=['2',0],x=40,y=40,width=944,height=944),'5':node('ImageScale','800',image=['4',0],upscale_method='lanczos',width=800,height=800,crop='disabled'),'6':node('SaveImage','800输出',images=['5',0],filename_prefix='perspective_warp/800'),'7':node('SaveImage','位移图',images=['2',1],filename_prefix='perspective_warp/displacement')}

def main():
 c=ComfyClient();info=c.get('/object_info');check_graph(graph('source.png',40,14),info)
 spec=importlib.util.spec_from_file_location('perspective_node',NODE);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);n=mod.FissionPerspective()
 # A single synthetic horizontal marker verifies positive forward displacement.
 t=torch.zeros((1,1024,1024,3));t[:,795,:,0]=1
 test,_,diag=n.warp(t,40.,14.);col=test[0,:,140,0];peak=int(torch.argmax(col));assert 833<=peak<=837,(peak,diag)
 OUT.mkdir(parents=True,exist_ok=True)
 with (ROOT/'fission/runs/native_gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  q=c.get('/queue');assert not q['queue_pending'] and not q['queue_running']
  image=c.upload(SRC)
  for corner,center in [(40.,14.)]:
   d=OUT/f'corner_{int(corner):02d}_center_{int(center):02d}';d.mkdir(exist_ok=True)
   api=graph(image,corner,center);check_graph(api,info);visual=ui(api,info,'确定性局部透视','二维位移诊断，非三维校准。')
   for i,item in enumerate(visual['nodes']):item['pos']=[i*350,0]
   write(d/'workflow.api.json',api);write(d/'workflow.ui.json',visual)
   _,_,report=n.warp(torch.zeros((1,1024,1024,3)),corner,center)
   start=time.time();entry,hit=deterministic_run(c,api,visual,d,NODE,SRC);pid=entry['prompt_id'];files=entry['files']
   if hit:
    for key,name in [('3','result.png'),('6','result_800.png'),('7','displacement.png')]:
     if (d/name).exists():
      if sha(d/name)!=sha(Path(files[key][0])):raise RuntimeError('Existing output differs from verified cache: '+str(d/name))
     else:shutil.copyfile(files[key][0],d/name)
    print(json.dumps({'cache_hit':True,'prompt_id':pid,'cache_key':entry['cache_key']},ensure_ascii=False),flush=True);continue
   for key,name in [('3','result.png'),('6','result_800.png'),('7','displacement.png')]:shutil.copyfile(files[key][0],d/name)
   a=np.asarray(Image.open(SRC).convert('RGB'));b=np.asarray(Image.open(d/'result.png').convert('RGB'));diff=np.any(a!=b,axis=2);ys,xs=np.where(diff)
   report=json.loads(report);report.update(input_sha256=sha(SRC),outputs={name:sha(d/name) for name in ['result.png','result_800.png','displacement.png']},node_sha256=sha(NODE),method='Forward y_target = y_source + d(x,y_source); inverse fixed-point sampling; outside support exact source; bilinear interpolation. Local 2D appearance diagnostic, no 3D calibration.',synthetic_marker_input_y=795,synthetic_marker_output_y=peak,changed_pixels=int(diff.sum()),changed_bounds_xyxy=[int(xs.min()),int(ys.min()),int(xs.max()),int(ys.max())],upper_y_500_changed=int(diff[:501].sum()),prompt_id=pid,wall_seconds=time.time()-start)
   write(d/'diagnostics.json',report);print(json.dumps(report,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
