"""Measure matching exterior patches of a native photograph against its true camera source."""
import argparse
import json
import math
from pathlib import Path
import sys

import numpy as np
from PIL import Image, ImageOps

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from fission.color import lab
from rim_review import digest

ROOT = Path(__file__).resolve().parents[2]
THRESHOLD = 15


def median(values):
    center = np.median(values, axis=0)
    return dict(lab=np.round(center, 3).tolist(),
                hue_deg=round(float(math.degrees(math.atan2(center[2], center[1])) % 360), 3))


def patch(image, box, chroma_min):
    if len(box) != 4 or any(type(v) is not int for v in box):
        raise ValueError('色差实测需要整数 xyxy 像素范围')
    x0,y0,x1,y1 = box
    if not (0 <= x0 < x1 <= image.width and 0 <= y0 < y1 <= image.height):
        raise ValueError(f'色差采样区越界 {box}')
    rgb = np.asarray(image.crop(box)).astype(float)
    colors = lab(rgb)
    chroma = np.hypot(colors[...,1], colors[...,2])
    mask = (colors[...,0] >= 30) & (colors[...,0] <= 85) & (chroma >= chroma_min) & (rgb.max(2) < 245)
    # A darkened front face can drop wholly below the project midtone filter.
    # Preserve its unfiltered median for diagnosis and flag the missing midtones.
    return dict(box_xyxy=list(box), pixels=int(mask.size), midtone_pixels=int(mask.sum()),
                midtone=median(colors[mask]) if mask.sum() >= 10 else None,
                all_pixels=median(colors.reshape(-1, 3)))


def distance(ref, sample):
    if not ref or not sample:
        return None
    delta = np.array(sample['lab']) - np.array(ref['lab'])
    return dict(delta_e76=round(float(np.linalg.norm(delta)),3),
                delta_lab=np.round(delta,3).tolist(),
                delta_hue_deg=round((sample['hue_deg'] - ref['hue_deg'] + 180) % 360 - 180,3))


def audit(photo, master, patches):
    meta = json.loads((master/'master.json').read_text())
    original = ROOT/meta['source']
    source = master/'master_1280.png'
    if digest(original) != meta['source_sha256'] or digest(source) != meta['artifacts']['master_1280.png']:
        raise ValueError('实拍原片或母版已变化')
    if len(patches) < 2:
        raise ValueError('至少选择两个独立对应外壁区域')
    if any(len({tuple(p[key]) for p in patches}) != len(patches) for key in ('reference_xyxy','sample_xyxy')):
        raise ValueError('两个测色区域重复')
    chroma_min = 8 if meta['color'] == '蓝' else 18
    with Image.open(original) as im:
        raw = ImageOps.exif_transpose(im).convert('RGB')
    with Image.open(photo) as im:
        generated = im.convert('RGB')
    left,top,right,bottom = meta['crop_xyxy']
    width,height = meta['size']
    rows = []
    for p in patches:
        box = p['reference_xyxy']
        source_box = [round(left+x*(right-left)/width) if i%2==0 else round(top+x*(bottom-top)/height)
                      for i,x in enumerate(box)]
        true = patch(raw,source_box,chroma_min)
        new = patch(generated,p['sample_xyxy'],chroma_min)
        mid = distance(true['midtone'],new['midtone'])
        all_values = distance(true['all_pixels'],new['all_pixels'])
        rows.append(dict(region=p['region'], reference_master_xyxy=box, reference=true, sample=new,
                         midtone=mid, all_pixels=all_values,
                         flag=mid is None or mid['delta_e76'] > THRESHOLD or all_values['delta_e76'] > THRESHOLD))
    return dict(photo_sha256=digest(photo),master_sha256=digest(source),source=str(meta['source']),
                source_sha256=meta['source_sha256'], color=meta['color'], threshold_delta_e76=THRESHOLD,
                method='median D65 sRGB CIELAB; native-resolution true camera pixels after EXIF correction; two corresponding exterior patches; half-open xyxy',
                filters=dict(min_L=30,max_L=85,min_chroma=chroma_min,max_rgb_exclusive=245,min_pixels=10),
                rows=rows, flag=any(r['flag'] for r in rows))


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('slot',type=Path)
    parser.add_argument('patches',type=Path,help='JSON list of region, reference_xyxy in the cropped master, sample_xyxy in native result')
    args=parser.parse_args()
    ident=json.loads((args.slot/'identity.json').read_text())
    result=json.loads((args.slot/'result.json').read_text())
    photo=args.slot/result['filename']
    if digest(photo)!=result['sha256']:
        raise ValueError('候选源图哈希不符')
    report=audit(photo,Path(ident['product']).parent,json.loads(args.patches.read_text()))
    (args.slot/'色差实测.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print([(r['region'],r['midtone'],r['all_pixels']) for r in report['rows']])
