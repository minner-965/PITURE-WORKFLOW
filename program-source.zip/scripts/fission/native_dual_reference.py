"""Prepare or submit exactly one native two-reference restaurant photo."""
import argparse
import fcntl
import hashlib
import re
import subprocess
from pathlib import Path

from PIL import Image

from run_layers import FISSION, ROOT, ComfyClient, digest, make_preview_card, read, reviewed_master, rows_for, save
from native_review import scene_input, verify_source
from build_workflows import check_graph
from comfy_client import sync_ui

ROUTE = 'native_dual_reference'
TEMPLATE = ROOT / 'output/双耳碗背景风格库/主图候选/D4双参考融合/02_白口复核'
DEFAULT_RUN = FISSION / 'runs/abc_20261104'


def ensure_allowed(run, shop, dish, version, new_job):
    if read(run/'batch.json').get('route') != ROUTE:
        raise ValueError('批次清单须指定 route=native_dual_reference')
    hold_path = run/'quality_hold.json'
    hold = read(hold_path) if hold_path.exists() else {}
    if hold.get('hold') is True and hold.get('hold_scope') != 'legacy_projection':
        raise ValueError(hold.get('reason') or '本批图像生成已暂停')
    if not new_job:
        return
    link = f'{shop}/{dish}'
    if (run/shop/dish/'selection.json').is_file() or hold.get('locked_sample')==link or any(
        token.startswith(link+'/') for token in hold.get('locked_native', [])
    ):
        raise ValueError(f'{link} 已选定样图，只可读取已生成版本')


def check_result(slot, row, identity):
    photo=verify_source(slot,row,Path(identity['product']).parent)
    preview=slot/'带字预览.jpg'
    result=read(slot/'result.json')
    if 'preview_sha256' in result and digest(preview)!=result['preview_sha256']:
        raise ValueError('原生预览文件已发生变化')
    with Image.open(preview) as im:
        if im.format!='JPEG' or im.size!=(800,800):raise ValueError('带字预览尺寸不符')
        im.verify()
    return photo


def prepare(run,shop,dish,version):
    if (not re.fullmatch(r'[A-Za-z0-9_-]+',shop) or not re.fullmatch(r'[a-z0-9_]+',dish)
            or not re.fullmatch(r'[0-9]{2,3}',version)):
        raise ValueError('需要明确的店铺、菜品 ID 和两位或以上数字的版本号')
    run=run.resolve(strict=True)
    if not run.is_relative_to((FISSION/'runs').resolve()):
        raise ValueError('批次须位于项目 fission/runs 内')
    rows=[r for r in rows_for(run,base=FISSION) if (r['shop'],r['dish_id'])==(shop,dish)]
    if len(rows)!=1 or rows[0]['product_id']!='w1125':
        raise ValueError('菜品须唯一属于本批 w1125 菜单')
    row=rows[0]
    master,_=reviewed_master(row)
    meta=read(master/'master.json')
    source=(ROOT/meta['source']).resolve(strict=True)
    catalog=(ROOT/'input/supplied_20261102/测试品').resolve()
    if (not source.is_relative_to(catalog) or source.parent.name not in ('sku实拍','详情页实拍')
            or meta['sku']!='w1125' or digest(source)!=meta['source_sha256']):
        raise ValueError('摄影师实拍的 SKU 或来源不匹配')
    slot=run/shop/dish/'原生双参考'/version
    if slot.resolve()!=slot or not slot.is_dir():
        raise ValueError(f'先为本次单图准备版本目录 {slot}')
    settings=read(slot/'settings.json')
    if settings.get('method')=='native_color_adjustment':
        from native_adjustment import prepare_inputs
        return prepare_inputs(slot,row,master,settings)
    prompt=(slot/'prompt.txt').read_text().strip()
    if not prompt:raise ValueError(f'{shop}/{dish}/{version} 缺少本菜的原生双参考提示词')
    w,h=settings['size']
    if (w,h)!=(1280,1024) or type(settings['seed']) is not int or not 0<=settings['seed']<2**64:
        raise ValueError('只接受 1280×1024 及有效的单个种子')
    ref1,lineage=scene_input(slot,row,master,settings)
    ref2=master/'master_1280.png'
    identity=dict(scene=str(ref1),scene_sha256=digest(ref1),product=str(ref2),product_sha256=digest(ref2),
                  photographer=meta['source'],prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                  seed=settings['seed'],size=[w,h],template_sha256=digest(TEMPLATE/'双参考.api.json'),**lineage)
    previous=slot/'identity.json'
    if previous.exists() and read(previous)!=identity:
        raise ValueError('该版本的菜单、参考、提示词或种子已变化，请另建版本')
    if not previous.is_file() and any((slot/f).exists() for f in ('submission.json','result.json')):
        raise ValueError('已有提交或结果缺失来源记录，须人工核对')
    return row,slot,prompt,identity


def run_one(run,shop,dish,version,submit=False):
    run=run.resolve(strict=True)
    row,slot,prompt,identity=prepare(run,shop,dish,version)
    if identity.get('method')=='native_color_adjustment':
        from native_adjustment import run_adjustment
        return run_adjustment(run,row,slot,identity,submit)
    receipt=slot/'submission.json'
    new_job=not receipt.exists()
    if (slot/'result.json').exists():
        result_path=check_result(slot,row,identity)
        print(f'已核对现有原生样 {result_path}',flush=True)
        return result_path
    ensure_allowed(run,shop,dish,version,new_job)
    if not submit:
        print(f'{shop}/{dish}/{version}　{row["bowl_color"]}碗 · {row["name"]}　'+
              ('准备单张新样' if new_job else '已提交，继续时沿用原回执'))
        return
    with (run/'queue.lock').open('a') as lock, (FISSION/'runs'/'native_gpu.lock').open('a') as common:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        fcntl.flock(common,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if (slot/'result.json').exists():return check_result(slot,row,identity)
        client=ComfyClient()
        client.get('/system_stats')
        if receipt.exists():
            if read(receipt)['request']['prompt']!=read(slot/'双参考.api.json'):
                raise ValueError('回执图与此版本保存的工作流不符')
            prompt_id=client.reconcile(receipt)
        else:
            q=client.get('/queue')
            if q['queue_running'] or q['queue_pending']:raise RuntimeError('GPU 正处理其他任务，请等待该任务结束')
            info=client.get('/object_info')
            api=read(TEMPLATE/'双参考.api.json')
            w,h=identity['size']
            for loader,scaler,field in [('1','6','scene'),('2','7','product')]:
                source=Path(identity[field])
                api[loader]['inputs']['image']=client.upload(source)
                with Image.open(source) as im: width,height=im.size
                api[scaler]['inputs'].update(width=round(width*1024/max(width,height)/16)*16,height=round(height*1024/max(width,height)/16)*16)
            for node in ('17','18'):api[node]['inputs'].update(width=w,height=h)
            api['19']['inputs']['noise_seed']=identity['seed']
            api['8']['inputs']['text']=prompt
            api['23']['inputs']['filename_prefix']=f'fission_abc/native_{shop}_{dish}_{version}'
            check_graph(api,info)
            visual=sync_ui(api,read(TEMPLATE/'双参考.ui.json'),info)
            if prepare(run,shop,dish,version)[3]!=identity:
                raise ValueError('单张参考在准备时发生变化')
            ensure_allowed(run,shop,dish,version,True)
            save(slot/'identity.json',identity)
            save(slot/'双参考.api.json',api);save(slot/'双参考.ui.json',visual)
            prompt_id=client.submit(api,visual,receipt)
        print(prompt_id,flush=True)
        backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip())
        hist,metrics=client.wait(prompt_id,slot,backend)
        outputs=client.download(hist,slot/'downloads').get('23',[])
        if len(outputs)!=1:raise ValueError('工作流应只输出一张照片')
        photo=Path(outputs[0])
        with Image.open(photo) as im:
            if im.size!=tuple(identity['size']):raise ValueError('生成尺寸不符')
        preview=slot/'带字预览.jpg'
        make_preview_card(photo,row,preview)
        save(slot/'result.json',dict(filename=str(photo.relative_to(slot)),sha256=digest(photo),
             preview_sha256=digest(preview),method=ROUTE,visual_status='wait_root',
             seconds=metrics['backend_wall_seconds'],prompt_id=prompt_id))
        return check_result(slot,row,identity)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',type=Path,default=DEFAULT_RUN)
    parser.add_argument('--shop',required=True);parser.add_argument('--dish',required=True)
    parser.add_argument('--version',required=True)
    parser.add_argument('--submit',action='store_true',help='实际提交或接续此单张；默认仅核对')
    a=parser.parse_args()
    run_one(a.run,a.shop,a.dish,a.version,a.submit)

if __name__=='__main__':main()
