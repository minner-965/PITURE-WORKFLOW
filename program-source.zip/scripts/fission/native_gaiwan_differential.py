"""Execute one reviewed differential full-frame Klein sample."""
import argparse,fcntl,json,shutil,subprocess
from pathlib import Path
from build_workflows import check_graph,ui
from comfy_client import ComfyClient
from native_multishop import ROOT,read,write,sha

def main():
 p=argparse.ArgumentParser();p.add_argument('--prep',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--check',action='store_true');a=p.parse_args();src=a.prep.resolve(strict=True);out=a.output.resolve();chain=read(src/'source_chain.json');s=read(src/'check.json');g=read(src/'sample_check.api.json')
 for k in ['guide','mask']:
  if sha(chain[k])!=chain[k+'_sha256']:raise ValueError('Source changed '+k)
 g['1']['inputs']['image']=chain['guide'];g['82']['inputs']['image']=chain['mask'];g['2']['inputs']['image']=str(Path(chain['guide']).parent/'reference_3019.png');c=ComfyClient();schema=c.get('/object_info');check_graph(g,schema);v=ui(g,schema,'差分区域六碗试样','整图模型生成，按区域差分去噪。')
 if a.check:print(json.dumps({'check':'passed','sigmas':s['sigmas']}));return
 review=read(src/'review.json')
 if review.get('status')!='passed' or review.get('mask_sha256')!=chain['mask_sha256']:raise ValueError('Mask review missing or changed')
 out.mkdir(parents=True,exist_ok=True)
 with (ROOT/'fission/runs/native_gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('Queue busy')
  if (out/'submission.json').exists():raise RuntimeError('Existing receipt requires reconciliation')
  for n in ['1','2','82']:g[n]['inputs']['image']=c.upload(g[n]['inputs']['image'])
  check_graph(g,schema);v=ui(g,schema,'差分区域六碗试样','整图模型生成，按区域差分去噪。');write(out/'workflow.api.json',g);write(out/'workflow.ui.json',v);write(out/'source_chain.json',chain);write(out/'sigmas.json',s);write(out/'node_schema.json',{k:schema[k] for k in set(n['class_type'] for n in g.values())});write(out/'identity.json',{'source_chain_sha256':sha(out/'source_chain.json'),'mask_review_sha256':sha(src/'review.json'),'cfg':g['16']['inputs']['cfg'],'seed':g['19']['inputs']['noise_seed'],'sigmas':s['sigmas'],'steps':6,'positive':g['8']['inputs']['text'],'negative':g['9']['inputs']['text'],'method':'full-frame differential diffusion, no post-composite'});shutil.copyfile(chain['mask'],out/'actual_mask.png')
  pid=c.submit(g,v,out/'submission.json');backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());hist,metrics=c.wait(pid,out,backend);files=c.download(hist,out/'download')
  for n,name in {'23':'result.png','26':'result_800.png','28':'reference_3019.png'}.items():shutil.copyfile(files[n][0],out/name)
  write(out/'result.json',{'prompt_id':pid,'seconds':metrics.get('backend_wall_seconds'),'outputs':{n:sha(out/n) for n in ['result.png','result_800.png','actual_mask.png']},'identity_sha256':sha(out/'identity.json'),'status':'pending_visual_review'});print(json.dumps(read(out/'result.json'),ensure_ascii=False))
if __name__=='__main__':main()
