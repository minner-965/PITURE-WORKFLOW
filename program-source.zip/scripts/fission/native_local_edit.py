import argparse, fcntl, json, shutil, subprocess
from pathlib import Path
import numpy as np
from PIL import Image
from build_workflows import node, check_graph, ui
from comfy_client import ComfyClient
from native_multishop import ROOT, sha, write, read

RUN=ROOT/'fission/runs/fastplate_20261104/全套重做'
OUT=RUN/'A01/product/local_perspective_v01'
SRC=RUN/'A01/product/corner_v07/result.png'
REFS=[Path('/Users/luohuiwu/Desktop/快餐盘/IMG_4920.jpg'),Path('/Users/luohuiwu/Desktop/快餐盘/IMG_4919.jpg')]
CONFIG=RUN/'四角弧度返修/局部透视_v01.json'
POS='Modify only the foreground near-side perspective of reference 1. Move the left and right near corner junctions slightly downward, and also lower the midpoint of the front edge slightly, creating a more relaxed and flatter front arc. Approximate target near corner junctions y=870 and front midpoint y=950 in the 1024 image. This is a subtle viewpoint adjustment, not a change in physical dimensions. The authentic shallow square plate shape and red exterior white interior come from independent real photographs references 2 and 3. Preserve exactly the same food, one foreground filled plate and one rear empty plate, background and lighting. Do not lower the camera, reinvent corners, add an underplate, black lines or arrows.'
NEG='double rim, extra underplate, raised corner wings, deep U front rim, distorted or elongated plate, invented corners, wrong color, changed food, extra dishes, blur, text, arrows, black lines, altered background'

def graph(paths):
 g=read(ROOT/'fission/workflows/商品主图近景/多店铺无字主图/02_商品双参考与800输出.api.json')
 g['1']['inputs']['image']=paths[0];g['2']['inputs']['image']=paths[1]
 g['27']['inputs'].update(x=1400,y=1600,width=3500,height=2000)
 g['7']['inputs'].update(width=1024,height=592)
 g['8']['inputs']['text']=POS;g['9']['inputs']['text']=NEG
 g['19']['inputs']['noise_seed']=202611051125
 g['30']=node('LoadImage','实拍二',image=paths[2]);g['31']=node('ImageCrop','实拍二取景',image=['30',0],x=1600,y=650,width=3400,height=3400)
 g['32']=node('ImageScale','实拍二缩放',image=['31',0],upscale_method='lanczos',width=768,height=768,crop='disabled')
 g['33']=node('VAEEncode','实拍二编码',pixels=['32',0],vae=['5',0])
 for i,old in [('34','14'),('35','15')]:g[i]=node('ReferenceLatent','第三参考 '+i,conditioning=[old,0],latent=['33',0])
 g['16']['inputs'].update(positive=['34',0],negative=['35',0])
 g.pop('17');g['36']=node('SolidMask','空蒙版',value=0.0,width=1024,height=1024)
 prev='36'
 for j,(x,y,w,h) in enumerate([(70,660,270,340),(720,660,240,340),(70,860,890,150)]):
  a,b=str(37+j*2),str(38+j*2);g[a]=node('SolidMask','局部区域',value=1.0,width=w,height=h);g[b]=node('MaskComposite','合并区域',destination=[prev,0],source=[a,0],x=x,y=y,operation='add');prev=b
 g['43']=node('MaskToImage','蒙版图',mask=[prev,0]);g['44']=node('ImageBlur','柔边',image=['43',0],blur_radius=16,sigma=8.0);g['45']=node('ImageToMask','柔边蒙版',image=['44',0],channel='red')
 g['46']=node('SetLatentNoiseMask','局部采样',samples=['10',0],mask=['45',0]);g['21']['inputs']['latent_image']=['46',0]
 g['47']=node('ImageCompositeMasked','恢复选区外原图',destination=['1',0],source=['22',0],mask=['45',0],x=0,y=0,resize_source=False)
 g['23']['inputs']['images']=['47',0];g['24']['inputs'].update(image=['47',0],x=20,y=20,width=984,height=984)
 for n,im,name in [('48','22','raw_generated'),('49','44','edit_mask'),('50','1','source'),('51','32','product_reference_02')]:g[n]=node('SaveImage',name,images=[im,0],filename_prefix='local_perspective/'+name)
 for n in ['23','26','28']:g[n]['inputs']['filename_prefix']='local_perspective/'+n
 return g

def main():
 p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');a=p.parse_args()
 c=ComfyClient(); info=c.get('/object_info');g=graph([str(SRC),*map(str,REFS)]);check_graph(g,info)
 identity={'source':str(SRC),'source_sha256':sha(SRC),'photos':[{'path':str(x),'sha256':sha(x)} for x in REFS],'parent_identity_sha256':sha(SRC.parent/'identity.json'),'parent_submission_sha256':sha(SRC.parent/'submission.json'),'parent_result_sha256':sha(SRC.parent/'result.json'),'seed':202611051125,'positive':POS,'negative':NEG}
 if a.check:print(json.dumps({'check':'passed','identity':identity},ensure_ascii=False));return
 OUT.mkdir(parents=True,exist_ok=True);CONFIG.parent.mkdir(parents=True,exist_ok=True)
 write(CONFIG,{'positive':POS,'negative':NEG,'seed':202611051125,'rectangles':[[70,660,270,340],[720,660,240,340],[70,860,890,150]],'blur_radius':16,'sigma':8})
 with (ROOT/'fission/runs/native_gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  if (OUT/'submission.json').exists():raise RuntimeError('已有提交回执，停止重复提交')
  q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('队列非空')
  g=graph([c.upload(x) for x in [SRC,*REFS]]);check_graph(g,info)
  v=ui(g,info,'局部透视修正','底图和两张实拍独立参考，局部采样。')
  for i,n in enumerate(v['nodes']):n['pos']=[(i%7)*360,(i//7)*350]
  write(OUT/'identity.json',identity);write(OUT/'workflow.api.json',g);write(OUT/'workflow.ui.json',v)
  pid=c.submit(g,v,OUT/'submission.json');backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip())
  hist,metrics=c.wait(pid,OUT,backend);files=c.download(hist,OUT/'download')
  for n,name in {'23':'result.png','26':'result_800.png','28':'product_reference.png','48':'raw_generated.png','49':'edit_mask.png','50':'source.png','51':'product_reference_02.png'}.items():shutil.copyfile(files[n][0],OUT/name)
  source=np.asarray(Image.open(OUT/'source.png').convert('RGB'));result=np.asarray(Image.open(OUT/'result.png').convert('RGB'));mask=np.asarray(Image.open(OUT/'edit_mask.png').convert('L'))
  changed=np.any(source!=result,axis=2);outside=int(np.sum(changed & (mask==0)))
  sizes={name:list(Image.open(OUT/name).size) for name in ['source.png','result.png','result_800.png','edit_mask.png','product_reference.png','product_reference_02.png']}
  evidence={'sizes':sizes,'outside_mask_changed_pixels':outside,'changed_pixels':int(changed.sum()),'files_sha256':{x:sha(OUT/x) for x in sizes},'prompt_id':pid,'seconds':metrics.get('backend_wall_seconds')}
  write(OUT/'pixel_check.json',evidence)
  if outside or sizes['result.png']!=[1024,1024] or sizes['result_800.png']!=[800,800]:raise RuntimeError('像素或尺寸核验失败')
  print(json.dumps(evidence,ensure_ascii=False))
if __name__=='__main__':main()
