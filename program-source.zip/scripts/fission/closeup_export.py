"""Render reviewed photographs into shop-specific close-ups using CPU operations."""
import argparse
import fcntl
import hashlib
import io
import json
import os
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path

from PIL import Image, ImageDraw, ImageOps

from typography_export import archive, centered, digest, font, read
from rim_review import facts_path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT))
from build_workflows import check_graph, node, ui
from fission.ledger import record_cpu

SIZE = 800
PHOTO_H = 680


def footer(row, style, allowed):
    shop = style["shop"]
    tag, claims = style["tag"], style["claims"]
    if set([tag, *claims]) - allowed:
        raise ValueError(f"{shop} 店文案超出当前商品已核实卖点")
    paper = Image.new("RGB", (SIZE, SIZE), style["title_fill"])
    d = ImageDraw.Draw(paper)
    accent, ink = style["accent"], style["title_color"]
    title = row["title"]
    if not title or len(title) > 24:
        raise ValueError(f"请确认商品标题 {title}")
    box = (35, 686, 590, 750) if shop in "AB" else (70, 684, 730, 750)
    max_width = box[2] - box[0]
    for size in range(53, 28, -1):
        face = font(style["fonts"]["title"], size)
        if d.textlength(title, font=face) < max_width:
            break
    if shop in "AB":
        width = int(d.textlength(title, font=face)) + 3
        centered(d, title, (box[0],box[1],box[0]+width,box[3]), face, ink)
        tag_box = (600, 699, 770, 739)
        d.rounded_rectangle(tag_box, radius=20 if shop == "A" else 4, outline=accent, width=2)
        centered(d, tag, tag_box, font(style["fonts"]["tag"], 23), ink)
        if shop == "A":
            d.rectangle((0,680,799,683), fill=accent)
        else:
            d.rectangle((0,680,11,752), fill=accent)
    else:
        d.line((26,685,774,685), fill=accent, width=2)
        centered(d,title,box,face,ink)
        for x in (43,757):
            d.polygon([(x,710),(x+5,717),(x,724),(x-5,717)],fill=accent)
    d.rectangle((0,754,799,799),fill=style["claim_fill"])
    items = claims if shop in "AB" else [tag, *claims]
    width = SIZE / len(items)
    for index, claim in enumerate(items):
        caption = re.sub(r'(\d+)\s*ml',r'\1 mL',claim,flags=re.I)
        caption = caption.replace("只550", "只 550")
        x0, x1 = round(index*width), round((index+1)*width)
        if index:
            d.line((x0,767,x0,787), fill=style["claim_color"], width=1)
        centered(d,caption,(x0+8,756,x1-8,797),font(style["fonts"]["claim"],24 if len(items)==3 else 21),style["claim_color"])
    return paper


def closeup_graph(photo, layout, crop, prefix):
    x, y, right, bottom = crop
    return {
        "1":node("LoadImage","已选无字原图",image=photo),
        "2":node("ImageCrop","逐图取景（含双耳、碗足、叠放全组）",image=["1",0],width=right-x,height=bottom-y,x=x,y=y),
        "3":node("ImageScale","等比放大至照片区",image=["2",0],upscale_method="lanczos",width=SIZE,height=PHOTO_H,crop="center"),
        "4":node("LoadImage","本商品、本店文字底版",image=layout),
        "5":node("ImageCompositeMasked","合成 800 方图",destination=["4",0],source=["3",0],x=0,y=0,resize_source=False),
        "6":node("SaveImage","保存完整商品主图",images=["5",0],filename_prefix=prefix)
    }


def graph_ui(api, info):
    check_graph(api,info)
    view=ui(api,info,"商品近景 · 裁切与排版","相同位置的 x、y、宽、高均为原照片像素。先框住全组，再微调两耳、碗脚和落影的余量。")
    positions=[(0,0),(405,0),(735,0),(405,320),(1090,60),(1440,60)]
    for n,pos in zip(view["nodes"],positions):
        n["pos"]=list(pos)
    return view


def png_bytes(im):
    s=io.BytesIO()
    im.save(s,format="PNG")
    return s.getvalue()


def validate_bounds(image_size, framing):
    x,y,r,b=framing["crop"]
    sx,sy,sr,sb=framing["subject"]
    if not (0<=x<=sx<sr<=r<=image_size[0] and 0<=y<=sy<sb<=b<=image_size[1]):
        raise ValueError(f"商品超出取景范围 {framing}")
    if abs((r-x)/(b-y)-SIZE/PHOTO_H)>0.007:
        raise ValueError(f"取景比例请按 800×680 标定 {framing}")
    return (x,y,r,b)


def execute(photo,paper,framing,job,proof_dir):
    with record_cpu(str(proof_dir), "layout", input_hashes={str(photo):digest(photo)}, asset=job) as record:
        native,slot,prompt,reused=_execute(photo,paper,framing,job,proof_dir)
        record["result_paths"]=[str(native)]
        record["reused_from"]=str(photo)
        record["cache_hit"]=reused
        record["cache_key"]=slot.name
        return native,slot,prompt


def _execute(photo,paper,framing,job,proof_dir):
    """Reuse a verified source; crop and compose locally without a generation client."""
    started=time.monotonic()
    raw=png_bytes(paper)
    source_sha256=digest(photo)
    signature=hashlib.sha256(json.dumps(["cpu-closeup-v1",source_sha256,hashlib.sha256(raw).hexdigest(),framing,SIZE,PHOTO_H],sort_keys=True).encode()).hexdigest()[:20]
    slot=proof_dir/"执行"/job/signature
    slot.mkdir(parents=True,exist_ok=True)
    stock=slot/(job+"_文字底版.png")
    with Image.open(photo) as im:
        crop=validate_bounds(im.size,framing)
    receipt=slot/"execution.json"
    native=slot/(job+"_CPU排版.png")
    reused=receipt.exists()
    if reused:
        previous=read(receipt)
        if previous["source_sha256"]!=source_sha256 or previous["output_sha256"]!=digest(native):
            raise ValueError(f"已存排版结果或来源发生变化 {job}")
        if digest(stock)!=hashlib.sha256(raw).hexdigest():
            raise ValueError(f"已存文字底版发生变化 {job}")
        print(job,"命中缓存：复用已核验排版",flush=True)
    else:
        stock.write_bytes(raw)
        with Image.open(photo) as im:
            resized=ImageOps.fit(im.convert("RGB").crop(crop),(SIZE,PHOTO_H),method=Image.Resampling.LANCZOS)
        result=paper.convert("RGB").copy()
        result.paste(resized,(0,0))
        temporary=native.with_suffix(".partial")
        result.save(temporary,format="PNG")
        os.replace(temporary,native)
        receipt.write_text(json.dumps(dict(type="cpu",stage="layout",renderer="Pillow",signature=signature,
            source=str(photo),source_sha256=source_sha256,crop=list(crop),output=str(native),
            output_sha256=digest(native),seconds=time.monotonic()-started,prompt_id=None,
            root_review_status="pending"),ensure_ascii=False,indent=2)+"\n")
    with Image.open(native) as im:
        if im.size != (800,800):raise ValueError(f"尺寸有误 {native}")
    return native,slot,None,reused


def make_overview(files, path, columns, tile):
    gap=13
    image=Image.new("RGB",(columns*(tile+gap)+gap,((len(files)+columns-1)//columns)*(tile+30+gap)+gap),"#F1EEE6")
    draw=ImageDraw.Draw(image)
    for i,(key,name,f) in enumerate(files):
        x=gap+(i%columns)*(tile+gap)
        y=gap+(i//columns)*(tile+30+gap)
        with Image.open(f) as im:
            image.paste(im.resize((tile,tile),Image.Resampling.LANCZOS),(x,y))
        centered(draw,key+"  "+name,(x,y+tile+1,x+tile,y+tile+30),font("SourceHanSansSC-Bold.otf",16),"#363833")
    path.parent.mkdir(parents=True,exist_ok=True)
    image.save(path,quality=94,subsampling=0)


def proof(args):
    sources,frames=read(args.sources),read(args.frames)
    if set(sources)!=set(frames) or not sources:
        raise ValueError("每张已选图须有对应取景框")
    templates={t["shop"]:t for t in (read(p) for p in args.templates.glob("*/template.json"))}
    allowed=set(read(facts_path(args.sku))["allowed_claims"])
    work=args.work
    work.mkdir(parents=True,exist_ok=True)
    records=[]
    with (work/".layout.lock").open("a") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        for k,row in sorted(sources.items()):
            if not re.fullmatch(r"[ABC][0-9]{2,3}",k) or row["shop"]!=k[0] or not re.fullmatch(r"[\w·]+",row["name"]):
                raise ValueError(f"商品图编号或名称有误 {k}")
            photo=ROOT/row["photo"]
            if digest(photo)!=row["sha256"]:raise ValueError(f"{k} 选定图片发生变化")
            native,slot,prompt=execute(photo,footer(row,templates[k[0]],allowed),frames[k],k,work)
            path=Path(k[0]+"店")/(k+"_"+row["name"]+".jpg")
            (work/path).parent.mkdir(exist_ok=True)
            with Image.open(native) as im:
                im.convert("RGB").save(work/path,quality=96,subsampling=0,optimize=True)
            records.append(dict(id=k,name=row["name"],shop=row["shop"],photo=row["photo"],source_sha256=row["sha256"],crop=frames[k]["crop"],subject=frames[k]["subject"],file=str(path),sha256=digest(work/path),prompt_id=prompt,job_dir=str(slot.relative_to(work))))
            print(k, path,flush=True)
    files=[(v["id"],v["name"],work/v["file"]) for v in records]
    for shop in sorted({v["shop"] for v in records}):
        make_overview([t for t in files if t[0][0]==shop],work/"预览"/(shop+"店预览.jpg"),3,330)
    make_overview(files,work/"预览"/"三店总览.jpg",5,232)
    manifest=work/"清单.json"
    proof_hashes={p.name:digest(p) for p in (work/"预览").glob("*.jpg")}
    manifest.write_text(json.dumps(dict(sku=args.sku,sources_sha256=digest(args.sources),frames_sha256=digest(args.frames),images=records,previews=proof_hashes),ensure_ascii=False,indent=2)+"\n")
    print("校样清单",digest(manifest))


def publish(args):
    with record_cpu(str(args.work), "export", input_hashes={str(args.work/"清单.json"):digest(args.work/"清单.json")}) as record:
        _publish(args)
        record["result_paths"]=[str(args.output)]
        record["root_review"]="passed"


def _publish(args):
    work,out=args.work,args.output
    manifest=work/"清单.json"
    if not args.reviewed or digest(manifest)!=args.reviewed:
        raise ValueError("请先看过当前总览并传入清单 SHA-256")
    data=read(manifest)
    if digest(args.sources)!=data["sources_sha256"] or digest(args.frames)!=data["frames_sha256"]:
        raise ValueError("选图或取景参数在看样后变动")
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=out.parent) as tmp:
        stage=Path(tmp)/"发布"
        stage.mkdir()
        if out.exists():raise FileExistsError(f"已有同名交付 {out}")
        for v in data["images"]:
            f=work/v["file"]
            if digest(f)!=v["sha256"] or digest(ROOT/v["photo"])!=v["source_sha256"]:raise ValueError(v["id"])
            dest=stage/v["file"]
            dest.parent.mkdir(exist_ok=True)
            shutil.copyfile(f,dest)
        for name,h in data["previews"].items():
            src=work/"预览"/name
            if digest(src)!=h:raise ValueError(name)
            (stage/"预览").mkdir(exist_ok=True)
            shutil.copyfile(src,stage/"预览"/name)
        packs=stage/"压缩包"
        packs.mkdir()
        for shop in sorted({v["shop"] for v in data["images"]}):
            directory=stage/(shop+"店")
            archive(packs/(shop+"店_主图.zip"),sorted(directory.glob("*.jpg")),directory)
        archive(packs/"全部商品主图.zip",sorted(stage.glob("?店/*.jpg")),stage)
        shutil.copyfile(manifest,stage/"交付清单.json")
        os.rename(stage,out)
    print(out)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action",choices=["proof","publish"])
    parser.add_argument("--sources",type=Path,required=True)
    parser.add_argument("--frames",type=Path,required=True)
    parser.add_argument("--work",type=Path,required=True)
    parser.add_argument("--sku",required=True)
    parser.add_argument("--templates",type=Path,default=ROOT/"fission/templates")
    parser.add_argument("--output",type=Path)
    parser.add_argument("--reviewed")
    args=parser.parse_args()
    if args.action=="proof":proof(args)
    elif args.output:publish(args)
    else:parser.error("publish 需要 --output")
