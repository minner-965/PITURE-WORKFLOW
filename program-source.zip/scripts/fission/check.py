"""Validate the single-bowl menu, masks and sources before placing work in the queue."""
import argparse
import hashlib
import json
import re
from pathlib import Path

if __package__:
    from .rim_review import master_for, rows_for, facts_path
else:
    from rim_review import master_for, rows_for, facts_path

import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parents[2]
def json_at(path):
    return json.loads(path.read_text())

def check(run, product=None, shops=None, dish=None):
    menu=rows_for(run,product,ROOT/'fission')
    rows=[r for r in menu if not shops or r['shop'] in shops]
    if not rows: raise ValueError('Empty menu for selected shops')
    facts_by_sku={}
    if product:
        facts=json_at(product)
        facts_by_sku[facts['product_id']]=facts
    ids=set()
    for r in rows:
        shop=r['shop']
        if not re.fullmatch(r'[A-Za-z0-9_-]+', shop) or not re.fullmatch(r'[a-z0-9_]+',r['dish_id']):
            raise ValueError('Invalid shop or dish id')
        key=(shop,r['dish_id'])
        if key in ids: raise ValueError(f'Duplicate dish {key}')
        ids.add(key)
        sku=r['product_id']
        if sku not in facts_by_sku:facts_by_sku[sku]=json_at(facts_path(sku,ROOT/'fission'))
        facts=facts_by_sku[sku]
        if not 1<=len(r['title'])<=7 or r['category'] not in facts['food_fit']:
            raise ValueError(f'Invalid title or food category {key}')
        for field in ['food_prompt','props_prompt']:
            if not r[field].strip():raise ValueError(f'Empty {field} {key}')
    selected=[r for r in rows if dish is None or r['dish_id']==dish]
    if not selected:raise ValueError('没有符合条件的菜品')
    for d in sorted({master_for(r,ROOT/'fission') for r in selected}):
        s=d.name
        mas=Image.open(d/'master_1280.png')
        food=Image.open(d/'food_surface_rim_v2.png')
        props=Image.open(d/'props_mask_1280.png')
        guard=Image.open(d/'protect_1280.png')
        if any(im.size!=(1280,1024) for im in [mas,food,props,guard]):raise ValueError(f'Image size {s}')
        if any(x.mode!='L' or not x.getbbox() for x in [props,food,guard]):raise ValueError(f'Mask {s}')
        if np.any((np.asarray(props)>0)&(np.asarray(food)>0)):raise ValueError(f'Overlapping layers {s}')
        if np.any((np.asarray(props)>0)&(np.asarray(guard)>0)):raise ValueError(f'Unprotected glassware {s}')
        gate=json_at(d/'root_review.json')
        for name in ['master.json','master_1280.png','food_surface_rim_v2.png','props_mask_1280.png','protect_1280.png']:
            if hashlib.sha256((d/name).read_bytes()).hexdigest()!=gate['files'][name]:raise ValueError(f'Stale approval {s} {name}')
        bowl=Image.open(d/'bowl_mask_1280.png')
        if bowl.size!=mas.size or np.any((np.asarray(food)>0)&(np.asarray(bowl)==0)):
            raise ValueError(f'真实开口超出商品外轮廓 {s}')
        if not gate['approved']:raise ValueError(f'Master awaits review {s}')
    notes=[f"{sku} 只有一种真实颜色，每店本次仅可出一张；运营如需增加链接请确认额外的实拍色。"
           for sku,facts in facts_by_sku.items() if len(set(facts['colors'].values()))==1]
    return notes+[f"{r['shop']}  {r['name']}  {r['title']}  {r['bowl_color']}碗（母版 {r['master_id']}）"
            if 'master_id' in r else f"{r['shop']}  {r['name']}  {r['title']}" for r in selected]

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run',type=Path,default=ROOT/'fission/runs/abc_20261104')
    p.add_argument('--product',type=Path)
    p.add_argument('--shops'); p.add_argument('--dish')
    p.add_argument('--dry-run',action='store_true',help='Check the manifest without generating images (default)')
    a=p.parse_args()
    print('\n'.join(check(a.run,a.product,a.shops.split(',') if a.shops else None,a.dish)))
