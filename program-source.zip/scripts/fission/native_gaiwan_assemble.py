"""Deterministic food-only composite and bounded contact shadows, inside ComfyUI."""
import argparse,fcntl,json,math,shutil,subprocess
from pathlib import Path
import numpy as np
from PIL import Image
from build_workflows import node,check_graph,ui
from comfy_client import ComfyClient
from native_multishop import ROOT,sha,read,write
from fission.ledger import append

def main():
 p=argparse.ArgumentParser();p.add_argument('--layout-dir',type=Path,required=True);p.add_argument('--sample-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--check',action='store_true');p.add_argument('--full-interior',action='store_true');a=p.parse_args();L=a.layout_dir.resolve(strict=True);S=a.sample_dir.resolve(strict=True);O=a.output.resolve();ld=read(L/'diagnostics.json');sd=read(S/'pixel_check.json');lr=read(L/'layout_review.json');
 if lr['status']!='passed' or lr['layout_sha256']!=sha(L/'layout.png'):raise ValueError('Unapproved layout')
 for n in ['layout.png','food_mask.png','product_mask.png']+[f'product_{i}_mask.png' for i in range(1,7)]:
  if sha(L/n)!=ld['outputs'][n]:raise ValueError('Layout hash mismatch '+n)
 for n in ['raw_generated.png','effective_mask.png']:
  if sha(S/n)!=sd['outputs'][n]:raise ValueError('Sample hash mismatch '+n)
 if read(S/'source_chain.json')['input_hashes']['layout.png']!=sha(L/'layout.png'):raise ValueError('Sample uses different layout')
 shapes=[]
 for i in range(1,7):
  z=np.asarray(Image.open(L/f'product_{i}_mask.png').convert('L'))>0; yy,xx=np.where(z); bottom=int(yy.max()); footx=np.where(z[max(0,bottom-5):bottom+1])[1];shapes.append({'index':i,'left':int(xx.min()),'right':int(xx.max()),'bottom':bottom,'footcenter':int(np.median(footx)),'width':int(xx.max()-xx.min()+1)})
 c=ComfyClient();schema=c.get('/object_info')
 paths={'layout':L/'layout.png','raw':S/'raw_generated.png','sample_mask':S/'effective_mask.png','food':L/'food_mask.png','product':L/'product_mask.png'}
 def graph(files):
  g={'1':node('LoadImage','原始实拍布局',image=files['layout']),'2':node('LoadImage','原始食品采样',image=files['raw']),'3':node('LoadImageMask','原采样有效遮罩',image=files['sample_mask'],channel='red'),'4':node('LoadImageMask','食品区域',image=files['food'],channel='red'),'5':node('ThresholdMask','食品核心',mask=['4',0],value=.999),'6':node('MaskComposite','仅食品区域',destination=(['4',0] if a.full_interior else ['3',0]),source=['5',0],x=0,y=0,operation='multiply'),'7':node('ThresholdMask','排除低于1像素量化值',mask=['6',0],value=1/255),'8':node('MaskComposite','有界食品有效区',destination=['6',0],source=['7',0],x=0,y=0,operation='multiply'),'9':node('LoadImageMask','商品遮罩',image=files['product'],channel='red'),'10':node('ThresholdMask','商品所有非零像素',mask=['9',0],value=0.0),'11':node('InvertMask','仅桌面可加阴影',mask=['10',0]),'12':node('EmptyImage','黑色阴影画布',width=1024,height=1024,batch_size=1,color=0),'13':node('EmptyImage','环境影椭圆源',width=512,height=(90 if a.full_interior else 66),batch_size=1,color=0),'14':node('EmptyImage','接触影椭圆源',width=512,height=(43 if a.full_interior else 37),batch_size=1,color=0)}
  oval=[[.5+.49*math.cos(2*math.pi*i/64),.5+.49*math.sin(2*math.pi*i/64)] for i in range(64)]
  
  if a.full_interior:
   g['30']=node('LoadImageMask','保存后重载的8位内壁遮罩',image=files.get('normalized',files['food']),channel='red');g['6']['inputs']['destination']=['30',0];g['6']['inputs']['source']=['4',0]
  previous='1'; allm=[]
  for j,s in enumerate(shapes):
   for t,(fraction,rad,alpha) in enumerate(([(.80,10,.28),(.42,2,.65)] if a.full_interior else [(.78,8,.16),(.35,2,.28)])):
    base=100+j*20+t*10;width=round(s['width']*fraction);x=max(0,min(1024-width,s['footcenter']+(8 if t==0 else 0)-width//2));height=round(width*((90 if t==0 else 43) if a.full_interior else (66 if t==0 else 37))/512);y=max(0,min(1024-height,s['bottom']+(3 if t==0 else (1 if a.full_interior else -1))-height//2))
    conf={'outer_polygon':oval,'food_polygon':oval,'placements':[{'role':'hero','x':x,'y':y,'width':width}],'shadow_radius':1}
    g[str(base)]=node('FissionPhotoLock','足下椭圆',photo=[('13' if t==0 else '14'),0],background=['12',0],layout_json=json.dumps(conf));g[str(base+1)]=node('MaskToImage','椭圆',mask=[str(base),1]);g[str(base+2)]=node('ImageBlur','阴影柔化',image=[str(base+1),0],blur_radius=rad,sigma=rad/2);g[str(base+3)]=node('ImageToMask','柔和阴影',image=[str(base+2),0],channel='red');g[str(base+4)]=node('SolidMask','阴影浓度',value=alpha,width=1024,height=1024);g[str(base+5)]=node('MaskComposite','阴影浓度',destination=[str(base+3),0],source=[str(base+4),0],x=0,y=0,operation='multiply');g[str(base+6)]=node('MaskComposite','排除所有商品',destination=[str(base+5),0],source=['11',0],x=0,y=0,operation='multiply');g[str(base+7)]=node('ThresholdMask','排除微值',mask=[str(base+6),0],value=1/255);g[str(base+8)]=node('MaskComposite','有效阴影',destination=[str(base+6),0],source=[str(base+7),0],x=0,y=0,operation='multiply');g[str(base+9)]=node('ImageCompositeMasked','桌面阴影',destination=[previous,0],source=['12',0],mask=[str(base+8),0],x=0,y=0,resize_source=False);previous=str(base+9);allm.append(str(base+8))
  g['500']=node('ImageCompositeMasked','只放回碗内食品',destination=[previous,0],source=['2',0],mask=['8',0],x=0,y=0,resize_source=False);g['501']=node('SaveImage','重组成图',images=['500',0],filename_prefix='gaiwan_assemble/full');g['502']=node('ImageScale','800成图',image=['500',0],upscale_method='lanczos',width=800,height=800,crop='disabled');g['503']=node('SaveImage','800输出',images=['502',0],filename_prefix='gaiwan_assemble/800');g['504']=node('MaskToImage','食品遮罩',mask=['8',0]);g['505']=node('SaveImage','食品遮罩保存',images=['504',0],filename_prefix='gaiwan_assemble/food')
  prev=allm[0]
  for j,n in enumerate(allm[1:]):
   k=str(600+j);g[k]=node('MaskComposite','阴影总区',destination=[prev,0],source=[n,0],x=0,y=0,operation='add');prev=k
  g['620']=node('MaskToImage','阴影遮罩',mask=[prev,0]);g['621']=node('SaveImage','阴影遮罩保存',images=['620',0],filename_prefix='gaiwan_assemble/shadows');g['622']=node('MaskComposite','总修改区',destination=[prev,0],source=['8',0],x=0,y=0,operation='add');g['623']=node('MaskToImage','总修改区',mask=['622',0]);g['624']=node('SaveImage','总修改区保存',images=['623',0],filename_prefix='gaiwan_assemble/combined');return g
 g=graph({k:str(v) for k,v in paths.items()});check_graph(g,schema);v=ui(g,schema,'实拍食品及接触影重组','仅食品和桌面阴影，无采样。')
 if a.check:print(json.dumps({'check':'passed','shapes':shapes},ensure_ascii=False));return
 O.mkdir(parents=True,exist_ok=True)
 with (ROOT/'fission/runs/native_gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('queue busy')
  if (O/'submission.json').exists():raise RuntimeError('existing receipt')
  uploaded={k:c.upload(v) for k,v in paths.items()}
  if a.full_interior:
   mg={'1':node('LoadImageMask','内壁许可',image=uploaded['food'],channel='red'),'2':node('MaskToImage','内壁',mask=['1',0]),'3':node('ImageBlur','内壁柔边2像素',image=['2',0],blur_radius=2,sigma=1.0),'4':node('ImageToMask','柔边',image=['3',0],channel='red'),'5':node('MaskComposite','严格内壁边界',destination=['4',0],source=['1',0],x=0,y=0,operation='multiply'),'6':node('MaskToImage','量化前遮罩',mask=['5',0]),'7':node('SaveImage','量化遮罩保存',images=['6',0],filename_prefix='gaiwan_assemble/interior_mask')}
   check_graph(mg,schema);mv=ui(mg,schema,'内壁遮罩量化','保存8位后重载');write(O/'interior_workflow.api.json',mg);write(O/'interior_workflow.ui.json',mv);mid=c._submit_uncached(mg,mv,O/'interior_submission.json');backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());mh,mm=c._wait_uncached(mid,O/'interior_record',backend);mf=c._download_uncached(mh,O/'interior_download');shutil.copyfile(mf['7'][0],O/'interior_mask_8bit.png');uploaded['normalized']=c.upload(O/'interior_mask_8bit.png')
  g=graph(uploaded);check_graph(g,schema);v=ui(g,schema,'实拍食品及接触影重组','仅食品和桌面阴影，无采样。');write(O/'workflow.api.json',g);write(O/'workflow.ui.json',v);write(O/'source_chain.json',{'inputs':{k:{'path':str(v),'sha256':sha(v)} for k,v in paths.items()},'layout_diagnostics_sha256':sha(L/'diagnostics.json'),'sample_report_sha256':sha(S/'pixel_check.json'),'shadow_shapes':shapes,'previous_zero_mask_changed_pixels':sd['zero_mask_changed_pixels']})
  pid=c._submit_uncached(g,v,O/'submission.json');backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());history,metrics=c._wait_uncached(pid,O,backend);files=c._download_uncached(history,O/'download');outputs={'501':'result.png','503':'result_800.png','505':'food_only_mask.png','621':'shadow_mask.png','624':'combined_mask.png'}
  for k,n in outputs.items():shutil.copyfile(files[k][0],O/n)
  before=np.asarray(Image.open(L/'layout.png').convert('RGB'));after=np.asarray(Image.open(O/'result.png').convert('RGB'));m=np.asarray(Image.open(O/'combined_mask.png').convert('L'));product=np.asarray(Image.open(L/'product_mask.png').convert('L'))>0;food=np.asarray(Image.open(O/'food_only_mask.png').convert('L'))>0;diff=np.any(before!=after,axis=2);report={'prompt_id':pid,'seconds':metrics.get('backend_wall_seconds'),'outside_saved_mask_changed':int((diff&(m==0)).sum()),'product_outside_food_changed':int((diff&product&~food).sum()),'changed_pixels':int(diff.sum()),'outputs':{n:sha(O/n) for n in outputs.values()},'status':'pending_visual_review'};write(O/'pixel_check.json',report);append(dict(type='cpu',task='gaiwan',stage='master/gaiwan-assemble',model=None,gpu_seconds=0,cpu_seconds=metrics.get('backend_wall_seconds',0),prompt_id=pid,result_paths=[str(O/n) for n in outputs.values()],status='success'));print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
