"""Verify a selected native dual-reference photograph, its measured true references and root review."""
import hashlib
import json
import math
from pathlib import Path
import re

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from native_color import audit
from rim_review import digest, require_approval


def read(path):
    return json.loads(path.read_text())


def check(condition, message):
    if not condition:
        raise ValueError(message)


def scene_input(slot, row, master, settings):
    """Resolve an assigned room or a verified earlier output from this exact dish."""
    root = master.parents[2]
    scene = (root/settings['background']).resolve(strict=True)
    check(scene.is_relative_to(root), '场景输入越过项目目录')
    if 'scene_parent_version' not in settings:
        if 'background' in row:
            check(scene == (root/row['background']).resolve(strict=True), '与本菜预定的餐厅背景不符')
        else:
            library = root/'output/双耳碗背景风格库/空背景'
            shop_scene = root/'work/diagnostics/multishop_hero_refresh_v1/backgrounds'/f'{row["shop"]}.png'
            check(scene == shop_scene or scene.is_relative_to(library), '餐厅空背景须来自已登记的风格库或本店场景')
        return scene, {}
    version = settings['scene_parent_version']
    check(isinstance(version,str) and re.fullmatch(r'[0-9]{2,3}',version) and int(version) < int(slot.name),
          '场景母版须为本菜更早的原生版本')
    parent = slot.parent/version
    check(parent.resolve(strict=True) == parent and parent.is_dir(), '场景母版目录无效')
    checked_photo = verify_source(parent,row,master)
    check(scene == checked_photo, '场景参考须为所指母版的原生无字输出')
    result = read(parent/'result.json')
    identity = read(parent/'identity.json')
    lineage = dict(scene_parent_version=version,scene_parent_prompt_id=result['prompt_id'],
                   scene_parent_inputs_sha256=[identity['scene_sha256'],identity['product_sha256']])
    return scene, lineage


def verify_source(slot, row, master):
    """Bind the local PNG to both reference hashes embedded by ComfyUI itself."""
    root = master.parents[2]
    identity = read(slot/'identity.json')
    settings = read(slot/'settings.json')
    meta = read(master/'master.json')
    result = read(slot/'result.json')
    check(result.get('visual_status','wait_root') not in ('rejected','reject','failed'), '结果已被拒绝')
    if result.get('method') == 'native_color_adjustment':
        return verify_adjustment(slot,row,master,identity,settings,result)
    check(result.get('method','native_dual_reference') == 'native_dual_reference', '未知原生路线')
    graph = read(slot/'双参考.api.json')
    expected_product = master/'master_1280.png'
    background, lineage = scene_input(slot,row,master,settings)
    recorded_lineage = {k:v for k,v in identity.items() if k.startswith('scene_parent_')}
    check(recorded_lineage == lineage, '餐厅场景的上游原生版本、回执或实际输入哈希不一致')
    check(background.is_relative_to(root)
          and Path(identity['scene']).resolve() == background and identity['scene_sha256'] == digest(background),
          '背景参考图的店铺归属或原图哈希不符')
    check(Path(identity['product']).resolve() == expected_product and identity['product_sha256'] == digest(expected_product)
          and identity['photographer'] == meta['source'], '原生双参考商品与本菜指定的摄影原片不一致')
    prompt = (slot/'prompt.txt').read_text().strip()
    check(identity['prompt_sha256'] == hashlib.sha256(prompt.encode()).hexdigest() and graph['8']['inputs']['text'] == prompt
          and settings['seed'] == identity['seed'] == graph['19']['inputs']['noise_seed']
          and settings['size'] == identity['size'] == [1280,1024], '原生候选提示词、种子或尺寸不匹配')
    prefix = f'native_{row["shop"]}_{row["dish_id"]}_{slot.name}'
    return executed_photo(slot,result,graph,prefix,'23',[('1',identity['scene_sha256']),('2',identity['product_sha256'])])


def executed_photo(slot, result, graph, prefix, save_node, fingerprints):
    history = read(slot/'history.json')
    receipt = read(slot/'submission.json')
    status = history['status']
    check(result['prompt_id'] and receipt['prompt_id'] == result['prompt_id'] == history['prompt'][1]
          and status['completed'] is True and status['status_str'] == 'success'
          and history['prompt'][2] == graph == receipt['request']['prompt'], '生产回执、成功记录与已提交工作流不符')
    outputs = history['outputs'][save_node]['images']
    check(Path(graph[save_node]['inputs']['filename_prefix']).name == prefix and len(outputs) == 1
          and outputs[0]['type'] == 'output' and outputs[0]['filename'].startswith(prefix+'_'),
          '生产回执中的输出与本店本菜不一致')
    filename = Path(outputs[0]['filename']).name
    photo = (slot/'downloads'/f'{save_node}_0_{filename}').resolve(strict=True)
    check(photo.is_relative_to(slot) and (slot/result['filename']).resolve() == photo
          and result['sha256'] == digest(photo), '生产下载记录与实际源文件不符')
    with Image.open(photo) as im:
        check(im.size == (1280,1024) and im.format == 'PNG', '正式阶段需要原生 1280×1024 PNG')
        embedded = json.loads(im.info['prompt'])
    for key, fingerprint in fingerprints:
        check(embedded[key].pop('is_changed', None) == [fingerprint], '原生 PNG 实际参与推理的参考图哈希不一致')
    check(embedded == graph, '原生 PNG 中的工作流与成功回执不一致')
    return photo


def verify_adjustment(slot, row, master, identity, settings, result):
    """The exact parent stays unchanged off the reviewed exterior, including the entire tabletop."""
    method = 'native_color_adjustment'
    check(settings['method'] == identity['method'] == method and settings['size'] == [1280,1024], '局部校色身份不同')
    from native_adjustment import prepare_inputs, graph_for
    # Recompute the two true color patches and the connected exterior mask from the
    # parent's pixels using the same specification as production.
    expected_identity = prepare_inputs(slot,row,master,settings)[3]
    check(expected_identity == identity, '局部校色的母图、来源、实拍色差或遮罩不同')
    parent = Path(identity['scene'])
    maskfile = slot/'exterior_mask.png'
    calibration = read(slot/'calibration.json')
    color = calibration['screen_rgb_int']
    graph = read(slot/'颜色校正.api.json')
    prefix = f'color_{row["shop"]}_{row["dish_id"]}_{slot.name}'
    expected_graph = graph_for(graph['1']['inputs']['image'],graph['2']['inputs']['image'],calibration,'fission_abc/'+prefix)
    check(expected_graph == graph, '局部校色的色值、节点或实际接线不同')
    photo = executed_photo(slot,result,graph,prefix,'7',[('1',digest(parent)),('2',digest(maskfile))])
    with Image.open(parent) as im: before=np.asarray(im.convert('RGB'))
    with Image.open(photo) as im: after=np.asarray(im.convert('RGB'))
    with Image.open(maskfile) as im: channels=np.asarray(im.convert('RGB'))
    check(channels.shape==before.shape and np.array_equal(channels[:,:,0],channels[:,:,1]) and
          np.array_equal(channels[:,:,0],channels[:,:,2]), '真实碗壳遮罩须与母图同尺寸且为灰阶')
    alpha=channels[:,:,0]
    check(np.any(alpha) and np.any(alpha==0) and np.array_equal(before[alpha==0],after[alpha==0]), '白沿、食品或桌面在遮罩外发生改变')
    # Check the actual pixels, including feathering. PNG encoding may round or truncate by one level.
    tint=np.array([(color>>16)&255,(color>>8)&255,color&255],dtype=np.float64)
    expected_pixels=before+(255.-before)*(tint/255.)*(alpha[:,:,None]/255.)
    check(np.max(np.abs(after-expected_pixels))<=1.001 and np.any(after!=before), '实际碗壳像素与登记参数不同')
    changed = np.any(before!=after,axis=2)
    receipt = dict(photo_sha256=digest(photo),parent_sha256=digest(parent),mask_sha256=digest(maskfile),
                   changed_pixels=int(changed.sum()),mask_pixels=int(np.sum(alpha>0)),outside_mask_changed_pixels=0)
    check(read(slot/'保护像素核查.json') == receipt, '保护区域核查与原图重测不一致')
    return photo


def verify_native(dish, row, master, selection):
    check(selection.get('approved',True) is True and selection.get('status') not in ('rejected','reject','failed'), '原生选图记录已退回')
    candidate = selection.get('candidate_id')
    check(isinstance(candidate,str) and re.fullmatch(r'[0-9]{2,3}',candidate), '原生候选编号无效')
    slot = (dish/'原生双参考'/candidate).resolve(strict=True)
    check(slot.is_relative_to(dish.resolve()), '原生候选越过本菜目录')
    check(selection.get('method') == read(slot/'result.json').get('method','native_dual_reference'), '选图记录与实际生成路线不同')
    photo = verify_source(slot,row,master)
    review_path = slot/'visual_review.json'
    sheet = slot/'实拍碗沿对照.jpg'
    require_approval(photo,sheet,review_path)
    review = read(review_path)
    check(review.get('reviewer') == 'root' and review.get('status') not in ('rejected','reject','failed')
          and selection.get('sha256') == digest(photo)
          and selection.get('review_sha256') == digest(review_path)
          and review.get('source_master_sha256') == digest(master/'master_1280.png'), '选图或签审与原生样片、实拍版本不一致')
    identity = read(slot/'identity.json')
    library = master.parents[2]/'work/diagnostics/multishop_hero_refresh_v1/backgrounds'
    # The initial ABC library encodes store membership in its filenames. A new
    # style is valid when its individual assignment is explicitly signed by root.
    if 'background' not in row and Path(identity['scene']).resolve() != (library/f'{row["shop"]}.png').resolve():
        check(review.get('scene_sha256') == identity['scene_sha256'], '新背景需签审其与本店本菜的归属')
    if selection['method']=='native_color_adjustment':
        check(review.get('mask_sha256') == digest(slot/'exterior_mask.png')
              and review.get('mask_overlay_sha256') == digest(slot/'mask_overlay.jpg')
              and isinstance(review.get('mask_observation'),str) and review['mask_observation'].strip(),
              '局部校色缺少对遮罩实际范围和边界的 root 复核')
    if review.get('comparison_basis') != 'visual_perspective':
        geometry = review['geometry']
        for name in ('overall_width','front_lip','outer_white_rim','left_ear','right_ear'):
            pair = geometry.get(name)
            check(isinstance(pair,list) and len(pair)==2 and all(type(v) in (int,float) and math.isfinite(v) and 0<v<=1280 for v in pair),
                  f'缺少实拍和原生图的量测 {name}')
    for name in ('front_lip','outer_white_rim','ears','foot_shadow_table','food_props','thumbnail'):
        note = review['observations'].get(name)
        check(isinstance(note,str) and note.strip(), f'缺少实际视觉核查记录 {name}')
    report_path = slot/'色差实测.json'
    check(review['color_report_sha256'] == digest(report_path), '审核后色差报告发生变化')
    report = read(report_path)
    patches = [dict(region=r['region'],reference_xyxy=r['reference_master_xyxy'],sample_xyxy=r['sample']['box_xyxy'])
               for r in report['rows']]
    check(audit(photo,master,patches) == report, '色差原图或两个实拍区域的测量结果不一致')
    disposition = review['color_disposition']
    expected = 'accept_after_root_review' if report['flag'] else 'within_threshold'
    check(disposition.get('decision') == expected and isinstance(disposition.get('reason'),str) and disposition['reason'].strip(),
          '色差预警、暗部采样或实拍差异缺少 root 对本图的明确处置')
    return photo,sheet


def comparison_sheet(slot, reference_box, sample_box):
    """Compare at the same overall body-and-ears span. Crops retain their own perspective."""
    ident = read(slot/'identity.json')
    result = read(slot/'result.json')
    ref = Path(ident['product'])
    photo = slot/result['filename']
    check(digest(ref) == ident['product_sha256'] and digest(photo) == result['sha256'], '实际对照的图片哈希不符')
    canvas = Image.new('RGB',(1200,775),'#f5f2e9')
    draw = ImageDraw.Draw(canvas)
    font_path = str(Path(__file__).resolve().parents[2]/'fission/fonts/SourceHanSansSC-Regular.otf')
    title = ImageFont.truetype(font_path,26)
    font = ImageFont.truetype(font_path,19)
    draw.text((20,8),'双耳、碗沿与落桌感  /  实拍和新场景对照',font=title,fill='#273e36')
    for i,(path,box,label) in enumerate(((ref,reference_box,'摄影师原片  '+Path(ident['photographer']).stem),
                                         (photo,sample_box,'原生双参考  '+slot.name))):
        with Image.open(path) as im:
            im = im.convert('RGB')
            x0,y0,x1,y1 = box
            check(0<=x0<x1<=im.width and 0<=y0<y1<=im.height,'器型比较范围越界')
            w,h=x1-x0,y1-y0
            scale=520/w
            cx,cy=(x0+x1)/2,(y0+y1)/2
            # Identical display width from outer ear tip to outer ear tip in each column.
            photo_box=(round(cx-285/scale),round(cy-190/scale),round(cx+285/scale),round(cy+190/scale))
            crop=im.crop(photo_box).resize((570,380),Image.Resampling.LANCZOS)
            left=20+i*600
            draw.text((left,47),label,font=font,fill='#224038')
            canvas.paste(crop,(left,80))
            # Compare both ear tips without making assumptions about vertical rim depth.
            for j,(center_x,description) in enumerate(((x0+.14*w,'左耳及碗口'),(x1-.14*w,'右耳及碗口'))):
                region=(round(center_x-.20*w),round(y0-.04*h),round(center_x+.20*w),round(y0+.81*h))
                detail=im.crop(region)
                detail.thumbnail((276,236),Image.Resampling.LANCZOS)
                x=left+290*j
                canvas.paste(detail,(x+(276-detail.width)//2,478))
                draw.text((x,718),description,font=font,fill='#35463f')
    canvas.save(slot/'实拍碗沿对照.jpg',quality=95,subsampling=0)


if __name__ == '__main__':
    import argparse
    parser=argparse.ArgumentParser(description='从真实原片及本版无字原图各给出外耳到外耳、顶至足的像素范围 xyxy。')
    parser.add_argument('slot',type=Path)
    parser.add_argument('--reference-box',type=int,nargs=4,required=True)
    parser.add_argument('--sample-box',type=int,nargs=4,required=True)
    args=parser.parse_args()
    comparison_sheet(args.slot,args.reference_box,args.sample_box)
