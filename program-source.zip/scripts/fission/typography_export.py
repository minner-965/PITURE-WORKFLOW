"""Render menu-based proofs, then package only the exact images reviewed by root."""
import argparse
from collections import Counter
from functools import lru_cache
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import tempfile
from zipfile import ZipFile, ZIP_STORED

from PIL import Image, ImageColor, ImageDraw, ImageFont
from rim_review import NATIVE_METHODS, master_id, rows_for, facts_path, require_approval

BASE = Path(__file__).resolve().parents[2] / "fission"
DEFAULT_RUN = BASE / "runs/abc_20261104"
DEFAULT_OUT = BASE / "exports/w1125/ABC_20261104"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


@lru_cache
def font(filename, size):
    entry = read(BASE / "fonts/manifest.json")["files"].get(filename)
    path = BASE / "fonts" / filename
    if not entry or path.suffix != ".otf" or digest(path) != entry["sha256"]:
        raise ValueError(f"未登记或内容变化的字体 {filename}")
    return ImageFont.truetype(str(path), size)


def luminance(hex_color):
    values = [v / 255 for v in ImageColor.getrgb(hex_color)]
    linear = [v / 12.92 if v < 0.04045 else ((v + 0.055) / 1.055) ** 2.4 for v in values]
    return sum(v * weight for v, weight in zip(linear, (0.2126, 0.7152, 0.0722)))


def contrast(foreground, background):
    dark, light = sorted((luminance(foreground), luminance(background)))
    return (light + 0.05) / (dark + 0.05)


def centered(draw, text, box, face, color):
    # Center the visible glyphs, accounting for different CJK and Latin metrics.
    x0, y0, x1, y1 = box
    left, top, right, bottom = draw.textbbox((0, 0), text, font=face)
    width, height = right - left, bottom - top
    if width > x1 - x0 or height > y1 - y0:
        raise ValueError(f"文字超过留白区域 {text}")
    x, y = (x0 + x1 - width) // 2 - left, (y0 + y1 - height) // 2 - top
    draw.text((x, y), text, font=face, fill=color)


def decoration(draw, t, title_width):
    shop, accent = t["shop"], t["accent"]
    if shop == "A":
        # Menu callout with short gilded rules flanking the dish name.
        for a, b in ((37, 385 - title_width // 2), (415 + title_width // 2, 763)):
            draw.line((a, 690, b, 690), fill=accent, width=2)
        draw.rectangle((0, 640, 799, 644), fill=accent)
    elif shop == "B":
        draw.rectangle((0, 640, 12, 741), fill=accent)
        x, y = 728, 690
        draw.arc((x - 28, y - 17, x + 28, y + 19), 0, 180, fill=accent, width=3)
        draw.rounded_rectangle((x - 30, y - 4, x + 30, y), 2, fill=accent)
        draw.line((x - 12, y + 23, x + 12, y + 23), fill=accent, width=3)
    else:
        draw.line((24, 648, 776, 648), fill=accent, width=2)
        for x in (42, 758):
            draw.polygon([(x, 683), (x + 7, 691), (x, 699), (x - 7, 691)], fill=accent)


def render(source, title, t, claims):
    if not 1 <= len(title) <= t["max_title_chars"] or not re.fullmatch(r"[\w·]+", title):
        raise ValueError(f"标题需在 1–7 字之内，实际为 {title}")
    if set(t["claims"] + [t["tag"]]) - claims or len(t["claims"]) != 3:
        raise ValueError(f"{t['shop']} 店模板卖点未登记")
    for fg, bg in [(t["title_color"], t["title_fill"]), (t["claim_color"], t["claim_fill"])]:
        if contrast(fg, bg) < 4.5:
            raise ValueError("缩略图色块对比度不足")
    with Image.open(source) as photo:
        if photo.size != (1280, 1024) or photo.format != "PNG":
            raise ValueError(f"无字母版尺寸或格式不符 {source}")
        image = Image.new("RGB", tuple(t["canvas"]))
        image.paste(photo.convert("RGB").resize((800, 640), Image.Resampling.LANCZOS))
    draw = ImageDraw.Draw(image)
    draw.rectangle(t["title_area"], fill=t["title_fill"])
    draw.rectangle(t["claim_area"], fill=t["claim_fill"])
    title_box = (54, 650, 746, 729)
    if t["shop"] == "B":
        title_box = (38, 650, 640, 729)
    for size in range(t["title_size"], t["title_min_size"] - 1, -1):
        title_face = font(t["fonts"]["title"], size)
        l, u, r, b = draw.textbbox((0, 0), title, font=title_face)
        if r - l <= title_box[2] - title_box[0] and b - u <= title_box[3] - title_box[1]:
            break
    if t["shop"] == "B":  # Align the menu title to the left margin.
        title_box = (38, 650, min(640, 38 + (r - l)), 729)
    decoration(draw, t, r - l)
    centered(draw, title, title_box, title_face, t["title_color"])
    for i, text in enumerate(t["claims"]):
        left = 24 + i * 251
        display = "单只 550 mL" if text == "单只550ml" else text
        centered(draw, display, (left, 747, left + 248, 793), font(t["fonts"]["claim"], t["claim_size"]), t["claim_color"])
        if i < 2:
            x = left + 249
            if t["shop"] == "A":
                draw.ellipse((x - 3, 769, x + 3, 775), fill=t["claim_color"])
            else:
                draw.line((x, 760, x, 782), fill=t["claim_color"], width=1)
    face = font(t["fonts"]["tag"], t["tag_size"])
    tag_w = int(draw.textlength(t["tag"], font=face)) + 40
    tag = (22, 22, 22 + tag_w, 65)
    draw.rounded_rectangle(tag, radius={"A": 21, "B": 5, "C": 12}[t["shop"]], fill=t["title_fill"])
    centered(draw, t["tag"], tag, face, t["title_color"])
    return image


def load_menu(run):
    menu = rows_for(run,base=BASE)
    keys = set()
    for row in menu:
        key = (row["shop"], row["dish_id"])
        if (key[0] not in "ABC" or len(key[0]) != 1 or not re.fullmatch(r"[\w-]+", key[1])
                or key in keys or not re.fullmatch(r"[\w·]+", row["name"])):
            raise ValueError(f"菜品身份或名称有误 {key}")
        keys.add(key)
    return menu


def contact_sheet(proofs, rows):
    indexes = Counter()
    photos = []
    for row in rows:
        shop = row["shop"]
        indexes[shop] += 1
        photos.append((shop, indexes[shop] - 1, proofs / row["jpg"]))
    tile, gap, left = 204, 8, 57
    sheet = Image.new("RGB", (left + max(indexes.values()) * (tile + gap), 3 * (tile + gap) + gap), "#F0EDE6")
    draw = ImageDraw.Draw(sheet)
    for nr, shop in enumerate("ABC"):
        centered(draw, shop + "店", (3, nr * (tile + gap), left - 6, (nr + 1) * (tile + gap)), font("SourceHanSansSC-Bold.otf", 23), "#39433A")
    for shop, i, image_path in photos:
        with Image.open(image_path) as im:
            sheet.paste(im.resize((tile, tile), Image.Resampling.LANCZOS), (left + i * (tile + gap), gap + "ABC".index(shop) * (tile + gap)))
    sheet.save(proofs / "三店菜品对照.jpg", quality=93, subsampling=0)


def check_photo_source(row, photo):
    decision = photo.parent/'selection.json'
    if 'master_id' in row or decision.is_file():
        from run_layers import selected_photo
        chosen, sheet = selected_photo(photo.parent, row)
        if digest(chosen) != digest(photo) or digest(sheet) != digest(photo.parent/'实拍碗沿对照.jpg'):
            raise ValueError(f'{row["name"]} 正式源图或实拍对照与选稿不同')
        if read(decision).get('method') in NATIVE_METHODS:
            return digest(decision)
    return None


from fission.ledger import tracked_cpu

@tracked_cpu('layout')
def proof(run, partial):
    settings = {t["shop"]: t for t in (read(f) for f in (BASE / "templates").glob("*/template.json")) if t.get("shop") in ("A", "B", "C")}
    target = run / "排版校样"
    target.mkdir(exist_ok=True)
    counts = Counter()
    records = []
    menu = load_menu(run)
    for row in menu:
        shop, dish, title = row["shop"], row["dish_id"], row["title"]
        counts[shop] += 1
        photo = run / shop / dish / "photo_1280.png"
        if partial and not photo.is_file():
            continue
        selected_hash = check_photo_source(row, photo)
        jpg = Path(f"{shop}店") / f"{shop}{counts[shop]:02}_{row['name']}.jpg"
        (target / jpg.parent).mkdir(exist_ok=True)
        claims = set(read(facts_path(row["product_id"],BASE))["allowed_claims"])
        render(photo, title, settings[shop], claims).save(target / jpg, quality=95, subsampling=0, optimize=True)
        records.append(dict(shop=shop, dish_id=dish, title=title, master_id=master_id(row),
                            bowl_color=row.get("bowl_color"), jpg=str(jpg), jpg_sha256=digest(target / jpg),
                            photo=str(photo.relative_to(run)), photo_sha256=digest(photo)))
        if selected_hash:
            records[-1]['selection_sha256'] = selected_hash
    if not records:
        raise ValueError("尚无本批次照片可排版")
    contact_sheet(target, records)
    manifest = target / "校样清单.json"
    manifest.write_text(json.dumps(dict(complete=(len(records) == len(menu)), menu_sha256=digest(run / "menu.json"), images=records),
                                   ensure_ascii=False, indent=2) + "\n")
    print(f"{len(records)} 张校样 → {target}   清单 SHA-256 {digest(manifest)}")


def archive(path, files, folder):
    with ZipFile(path, "w", compression=ZIP_STORED) as z:
        for f in files:
            z.write(f, f.relative_to(folder))
    with ZipFile(path) as z:
        assert z.testzip() is None and len(z.namelist()) == len(files)


@tracked_cpu('layout')
def publish(run, output, reviewed):
    proofs = run / "排版校样"
    manifest = proofs / "校样清单.json"
    if digest(manifest) != reviewed:
        raise ValueError("与 root 看过的校样清单哈希不符")
    data = read(manifest)
    if not data["complete"] or digest(run / "menu.json") != data["menu_sha256"]:
        raise ValueError("菜品清单已变更或校样不完整")
    if Counter(row["shop"] for row in data["images"]) != {"A": 5, "B": 5, "C": 5}:
        raise ValueError("本批要求三店各五图")
    menu = {(r['shop'], r['dish_id']): r for r in load_menu(run)}
    if set(menu) != {(r['shop'], r['dish_id']) for r in data['images']}:
        raise ValueError('五色菜单与已审核校样的菜品不一致')
    for record in data['images']:
        row = menu[record['shop'], record['dish_id']]
        if 'master_id' in row and (record.get('master_id'), record.get('bowl_color')) != (master_id(row),row['bowl_color']):
            raise ValueError('成品清单和菜品的母版或碗色不一致')
        photo = run / record['photo']
        if photo != run / row['shop'] / row['dish_id'] / 'photo_1280.png':
            raise ValueError('正式图所在目录与菜品不一致')
        if check_photo_source(row,photo) != record.get('selection_sha256'):
            raise ValueError('原生选图或签审在排版校样后变化')
        if digest(proofs/record['jpg']) != record['jpg_sha256'] or digest(photo) != record['photo_sha256']:
            raise ValueError(f'文件在校样后变化 {row["dish_id"]}')
        final_review = photo.parent/'正式碗沿复核.json'
        require_approval(photo,photo.parent/'实拍碗沿对照.jpg',final_review)
        if record.get('selection_sha256'):
            signed = read(final_review)
            selection = read(photo.parent/'selection.json')
            if (signed.get('reviewer') != 'root' or signed.get('method') != selection.get('method')
                    or signed.get('status') in ('reject','rejected','failed')
                    or signed.get('review_sha256') != selection['review_sha256']):
                raise ValueError('原生正式复核未绑定本次 root 选稿')
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        if (output / "交付记录.json").is_file() and digest(output / "交付记录.json") == reviewed:
            print(f"此校样已交付 {output}")
            return
        raise FileExistsError(f"已有其他批次，请另选交付目录 {output}")
    with tempfile.TemporaryDirectory(dir=output.parent) as tmp:
        stage = Path(tmp) / "交付"
        stage.mkdir()
        for row in data["images"]:
            jpg, photo = proofs / row["jpg"], run / row["photo"]
            if digest(jpg) != row["jpg_sha256"] or digest(photo) != row["photo_sha256"]:
                raise ValueError(f"文件在校样后变化 {row['dish_id']}")
            dest = stage / row["jpg"]
            dest.parent.mkdir(exist_ok=True)
            shutil.copyfile(jpg, dest)
            clean = stage / "无字原图" / Path(row["jpg"]).with_suffix(".png")
            clean.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(photo, clean)
        shutil.copyfile(proofs / "三店菜品对照.jpg", stage / "三店菜品对照.jpg")
        shutil.copyfile(manifest, stage / "交付记录.json")
        packs = stage / "压缩包"
        packs.mkdir()
        for s in "ABC":
            folder = stage / f"{s}店"
            archive(packs / f"{s}店_五张菜品主图.zip", sorted(folder.glob("*.jpg")), folder)
        archive(packs / "三店_全部15张菜品主图.zip", sorted(stage.glob("?店/*.jpg")), stage)
        os.rename(stage, output)
    print(output)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["proof", "publish"])
    parser.add_argument("--run", type=Path, default=DEFAULT_RUN)
    parser.add_argument("--partial", action="store_true", help="只为已经出图的菜品排版预览")
    parser.add_argument("--reviewed", help="root 看过的完整校样清单 SHA-256")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    if args.action == "proof":
        proof(args.run, args.partial)
    else:
        publish(args.run, args.output, args.reviewed)
