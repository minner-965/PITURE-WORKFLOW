"""Execute approved native local removal and verify source protection."""
import argparse,fcntl,json,shutil,subprocess
from pathlib import Path
import numpy as np
from PIL import Image
from build_workflows import check_graph,ui
from comfy_client import ComfyClient
from native_multishop import ROOT,read,write,sha

def main():
 p=argparse.ArgumentParser();p.add_argument('--prep',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--check',action='store_true');a=p.parse_args();src=a.prep.resolve(strict=True);out=a.output.resolve();chain=read(src/'source_chain.json');g=read(src/'sample_check.api.json');review=read(src/'review.json');
 if sha(chain['source'])!=chain['source_sha256'] or sha(src/'edit_mask.png')!=chain['mask_sha256'] or review.get('mask_sha256')!=chain['mask_sha256'] or review.get('status')!='passed':raise ValueError('Source or review changed')
 g['1']['inputs']['image']=chain['source'];g['90']['inputs']['image']=str(src/'edit_mask.png');c=ComfyClient();schema=c.get('/object_info');check_graph(g,schema);v=ui(g,schema,'移除多余餐盘','局部生成石桌，遮罩外恢复源图。')
 if a.check:print('check passed');return
 out.mkdir(parents=True,exist_ok=True)
 with (ROOT/'fission/runs/native_gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('queue busy')
  if (out/'submission.json').exists():raise RuntimeError('existing receipt')
  for n in ['1','2','90']:g[n]['inputs']['image']=c.upload(g[n]['inputs']['image'])
  check_graph(g,schema);v=ui(g,schema,'移除多余餐盘','局部生成石桌，遮罩外恢复源图。');write(out/'workflow.api.json',g);write(out/'workflow.ui.json',v);write(out/'source_chain.json',chain);write(out/'identity.json',{'source_sha256':chain['source_sha256'],'mask_sha256':chain['mask_sha256'],'review_sha256':sha(src/'review.json'),'cfg':1.3,'steps':4,'seed':g['19']['inputs']['noise_seed'],'positive':g['8']['inputs']['text'],'negative':g['9']['inputs']['text']});shutil.copyfile(src/'edit_mask.png',out/'actual_mask.png');pid=c.submit(g,v,out/'submission.json');backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());hist,metrics=c.wait(pid,out,backend);files=c.download(hist,out/'download')
  for n,name in {'23':'result.png','26':'result_800.png'}.items():shutil.copyfile(files[n][0],out/name)
  before=np.asarray(Image.open(chain['source']).convert('RGB'));after=np.asarray(Image.open(out/'result.png').convert('RGB'));mask=np.asarray(Image.open(out/'actual_mask.png').convert('L'));changed=np.any(before!=after,axis=2);report={'prompt_id':pid,'seconds':metrics.get('backend_wall_seconds'),'outside_mask_changed':int((changed&(mask==0)).sum()),'changed_pixels':int(changed.sum()),'outputs':{n:sha(out/n) for n in ['result.png','result_800.png','actual_mask.png']},'status':'pending_visual_review'};write(out/'pixel_check.json',report);print(json.dumps(report))
if __name__=='__main__':main()
