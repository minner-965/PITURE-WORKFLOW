"""Verify reviewed ComfyUI outputs, then publish byte-identical PNGs by shop.

Default is verification only. Use --publish to write new delivery folders and
--replace to archive and replace existing deliveries. Selection JSON maps every
plan row id to {"version": "v01"} or {"directory": "/absolute/product/v02"}.
"""

import argparse
import datetime
import fcntl
import hashlib
import json
import os
import re
import shutil
import tempfile
import uuid
from pathlib import Path
from zipfile import ZipFile, ZIP_STORED
from zoneinfo import ZoneInfo

from PIL import Image, ImageDraw, ImageFont
from fission.bridge import equivalent_graph

from native_multishop import ROOT, approved_background, completed, fingerprint, load_plan, read, require, sha, write


def safe_label(value, label):
    require(isinstance(value, str) and value.strip(), f"Missing {label}")
    value = value.strip()
    require(len(value) <= 100 and value not in (".", "..")
            and not re.search(r'[/\\:*?"<>|\x00-\x1f]', value), f"Invalid {label}: {value!r}")
    return value


def check_fingerprint(item):
    require(isinstance(item, dict) and set(("path", "sha256")) <= item.keys(), "Missing source fingerprint")
    path = Path(item["path"])
    require(path.is_absolute() and path.is_file(), f"Missing absolute source: {path}")
    require(sha(path) == item["sha256"], f"Source checksum differs: {path}")


def verify_png_graph(path, graph, identity):
    """Check saved ComfyUI metadata, including its verified runtime input hashes."""
    with Image.open(path) as picture:
        embedded = json.loads(picture.info.get("prompt", "null"))
    require(isinstance(embedded, dict), "Output PNG has no ComfyUI prompt metadata")
    for loader, reference in zip(identity.get("reference_loaders", []), identity.get("files", [])):
        recorded = embedded.get(loader, {})
        if "is_changed" in recorded:
            require(recorded.get("class_type") == "LoadImage" and recorded["is_changed"] == [reference["sha256"]],
                    "ComfyUI runtime input checksum differs")
            del recorded["is_changed"]
    require(equivalent_graph(embedded, graph), "Output PNG lacks its actual ComfyUI graph")


def verify_product_sources(identity, graph):
    for source in identity.get("product_sources", []):
        reference = {"path": source["file"], "sha256": source["sha256"]}
        check_fingerprint(reference)
        if "photographer_original" in source or "original_sha256" in source:
            require("photographer_original" in source and "original_sha256" in source,
                    "Derived reference needs both original path and checksum")
            check_fingerprint({"path": source["photographer_original"], "sha256": source["original_sha256"]})
            continue
        with Image.open(source["file"]) as picture:
            size = list(picture.size)
            if picture.getexif().get(274, 1) in (5, 6, 7, 8):
                size.reverse()
        require(source.get("oriented_size", size) == size, "Direct photograph dimensions differ")
        crop = source.get("crop_xywh", [0, 0, *size])
        matches = [index for index, item in enumerate(identity["files"][1:], 1) if item == reference
                   and identity["product_crops_xywh"][index - 1] == crop]
        require(matches, "Direct photograph and crop are absent from the actual product inputs")
        loaders = [identity["reference_loaders"][index] for index in matches]
        require(any(node["class_type"] == "ImageCrop" and node["inputs"]["image"] in [[loader, 0] for loader in loaders]
                    and [node["inputs"][key] for key in ("x", "y", "width", "height")] == crop
                    for node in graph.values()), "Direct photograph crop is absent from the executed graph")


def verify_workflow(out, identity):
    graph = read(out / "workflow.api.json")
    result = completed(out, identity, graph)
    receipt = read(out / "submission.json")
    visual = read(out / "workflow.ui.json")
    require(receipt["request"]["extra_data"]["extra_pnginfo"]["workflow"] == visual,
            f"UI receipt differs: {out}")
    require(set(graph) <= {str(node["id"]) for node in visual["nodes"]}, f"UI is missing execution nodes: {out}")
    require(graph["26"]["class_type"] == "SaveImage" and graph["26"]["inputs"]["images"] == ["25", 0],
            "800 output must be saved by ComfyUI node 26")
    require(graph["25"]["class_type"] == "ImageScale"
            and graph["25"]["inputs"]["width"] == 800 and graph["25"]["inputs"]["height"] == 800
            and graph["25"]["inputs"]["image"] == ["24", 0],
            "800 output must be scaled inside ComfyUI")
    require(graph["24"]["class_type"] == "ImageCrop" and graph["24"]["inputs"]["image"] == ["22", 0]
            and [graph["24"]["inputs"][key] for key in ("x", "y", "width", "height")]
            == identity["output_crop_xywh"], "ComfyUI crop differs from its identity record")
    require(graph["8"]["inputs"]["text"] == identity["positive"]
            and graph["19"]["inputs"]["noise_seed"] == identity["seed"], "Executed prompt or seed differs")
    require(graph["9"]["class_type"] == "CLIPTextEncode" and graph["9"]["inputs"]["text"] == identity["negative"]
            and graph["16"]["inputs"]["cfg"] == identity["cfg"] > 1, "Negative conditioning is inactive")
    conditioning = graph["16"]["inputs"]["negative"]
    visited = set()
    while conditioning != ["9", 0]:
        node_id = conditioning[0]
        require(node_id not in visited and graph[node_id]["class_type"] == "ReferenceLatent",
                "Negative conditioning does not reach the encoded negative text")
        visited.add(node_id)
        conditioning = graph[node_id]["inputs"]["conditioning"]
    for item in result["outputs"].values():
        verify_png_graph(item["path"], graph, identity)
    for item in identity.get("files", []):
        check_fingerprint(item)
    verify_product_sources(identity, graph)
    return result


def check_row(row, selection, run_root):
    require(isinstance(selection, dict), f"{row['id']}: selection must be an object")
    if "directory" in selection:
        out = Path(selection["directory"])
        require(out.is_absolute(), "Selected directory must be absolute")
    else:
        version = safe_label(selection.get("version", "v01"), "version")
        out = run_root / row["id"] / "product" / version
    out = out.resolve(strict=True)
    require(out.parent == (run_root / row["id"] / "product").resolve(), "Selected run lies outside its product version folder")
    identity = read(out / "identity.json")
    require(identity["stage"] == "product" and all(identity[key] == row[key] for key in ("id", "shop", "sku")),
            "Selected image belongs to another row")
    require(identity.get("color") == row.get("color"), "Selected color differs from the plan")
    result = verify_workflow(out, identity)
    approval = identity["background_approval"]
    for item in approval.values():
        check_fingerprint(item)
    background = Path(approval["image"]["path"]).parent
    require(background.parent == (run_root / row["id"] / "background").resolve(), "Background belongs to another row")
    require(approved_background(background) == approval, "Background approval has changed since generation")
    background_identity = read(background / "identity.json")
    verify_workflow(background, background_identity)
    require(identity["files"][0] == approval["image"], "Product scene differs from the reviewed background")
    require("product_reference.png" in result["outputs"], "ComfyUI product-reference output is missing")
    for item in result["outputs"].values():
        check_fingerprint(item)
    review_path = out / "visual_review.json"
    outputs = dict(result["outputs"])
    crop_record = None
    crop_rectangle = identity["output_crop_xywh"]
    if "crop_version" in selection:
        from recrop_native_multishop import verify_recrop
        crop_version = safe_label(selection["crop_version"], "crop version")
        crop_out = out / "crops" / crop_version
        crop_result = verify_recrop(crop_out)
        crop_identity = read(crop_out / "identity.json")
        require(crop_identity["source_directory"] == str(out), "Selected crop belongs to another source version")
        outputs["result_800.png"] = crop_result["outputs"]["result_800.png"]
        review_path = crop_out / "visual_review.json"
        crop_rectangle = crop_identity["crop_xywh"]
        crop_evidence = (("identity", "identity.json"), ("result", "result.json"))
        if crop_identity.get("method") != "pillow_crop_lanczos":
            crop_evidence += (("workflow_api", "workflow.api.json"), ("workflow_ui", "workflow.ui.json"),
                              ("submission", "submission.json"), ("history", "history.json"))
        crop_record = {"version": crop_version, "prompt_id": crop_result["prompt_id"], "crop_xywh": crop_rectangle,
                       "method": crop_identity.get("method", "comfy_image_operations"),
                       **{key: fingerprint(crop_out / filename) for key, filename in crop_evidence}}
    review = read(review_path)
    require(review.get("status") == "passed", f"{row['id']}: visual review has not passed")
    require(review.get("reviewer") == "root", f"{row['id']}: root visual review required")
    require(review.get("native_sha256") == result["outputs"]["result.png"]["sha256"]
            and review.get("output_800_sha256") == outputs["result_800.png"]["sha256"]
            and review.get("identity_sha256") == sha(out / "identity.json"), "Visual review belongs to another image")
    if crop_record:
        require(review.get("crop_identity_sha256") == crop_record["identity"]["sha256"],
                "Visual review belongs to another crop")
    require(isinstance(review.get("notes"), str) and len(review["notes"].strip()) >= 16,
            "Visual review needs actual image observations")
    shop = safe_label(row["shop"], "shop")
    shop_folder = safe_label(row.get("shop_folder", shop if shop.endswith("店") else shop + "店"), "shop folder")
    color = safe_label(row["color"], "color")
    dish = safe_label(row["dish"], "dish")
    product = safe_label(row.get("product_name", "快餐盘"), "product name")
    filename = f"{row['id']}_{color}{product}_{dish}_无字.png"
    require(len(filename.encode("utf-8")) <= 240, "Image filename exceeds the filesystem limit")
    return {"id": row["id"], "shop": shop, "shop_folder": shop_folder, "sku": row["sku"], "color": color, "dish": dish,
            "relative_file": str(Path(shop_folder) / filename), "source_directory": str(out),
            "outputs": outputs, "source_outputs": result["outputs"], "crop_generation": crop_record,
            "prompt_id": result["prompt_id"],
            "identity": fingerprint(out / "identity.json"), "visual_review": fingerprint(review_path),
            "workflow_api": fingerprint(out / "workflow.api.json"), "workflow_ui": fingerprint(out / "workflow.ui.json"),
            "submission": fingerprint(out / "submission.json"), "history": fingerprint(out / "history.json"),
            "background_approval": approval, "background_submission": fingerprint(background / "submission.json"),
            "input_references": identity["files"], "product_sources": identity.get("product_sources", []),
            "crop_xywh": crop_rectangle, "notes": review["notes"]}


def font(size, bold=False):
    name = "SourceHanSansSC-Bold.otf" if bold else "SourceHanSansSC-Regular.otf"
    return ImageFont.truetype(str(ROOT / "fission/fonts" / name), size)


def preview(stage, rows, filename, title):
    columns = min(5, len(rows))
    tile, gap, margin, label_height = 280, 16, 28, 84
    count = (len(rows) + columns - 1) // columns
    sheet = Image.new("RGB", (margin * 2 + columns * (tile + gap) - gap,
                              90 + count * (tile + label_height + gap)), "#f1eee9")
    draw = ImageDraw.Draw(sheet)
    draw.text((margin, 20), title, font=font(30, True), fill="#27352e")
    for index, row in enumerate(rows):
        x = margin + index % columns * (tile + gap)
        y = 80 + index // columns * (tile + label_height + gap)
        draw.rectangle((x, y, x + tile, y + tile + label_height), fill="white")
        with Image.open(stage / row["relative_file"]) as picture:
            sheet.paste(picture.convert("RGB").resize((tile, tile), Image.Resampling.LANCZOS), (x, y))
        draw.text((x + 8, y + tile + 5), f"{row['id']} · {row['color']}", font=font(20, True), fill="#27352e")
        lines = [""]
        for character in row["dish"]:
            if draw.textlength(lines[-1] + character, font=font(17)) > tile - 16:
                lines.append("")
            lines[-1] += character
        require(len(lines) <= 2, "Preview caption exceeds two lines")
        for line_number, line in enumerate(lines):
            draw.text((x + 8, y + tile + 35 + line_number * 22), line, font=font(17), fill="#3b3e3a")
    sheet.save(stage / "预览" / filename, quality=94, subsampling=0, optimize=True)


def tree(path):
    require(path.is_dir() and not path.is_symlink(), f"Expected a normal delivery directory: {path}")
    files = {}
    for item in sorted(path.rglob("*")):
        require(not item.is_symlink(), f"Delivery contains a symbolic link: {item}")
        if item.is_file():
            files[item.relative_to(path).as_posix()] = sha(item)
    return files


def build(stage, rows, manifest, archive_name, title):
    stage.mkdir()
    (stage / "预览").mkdir()
    for row in rows:
        target = stage / row["relative_file"]
        target.parent.mkdir(exist_ok=True)
        source = row["outputs"]["result_800.png"]
        shutil.copyfile(source["path"], target)
        require(sha(target) == source["sha256"], "Published PNG changed bytes")
    shops = list(dict.fromkeys(row["shop"] for row in rows))
    for shop in shops:
        group = [row for row in rows if row["shop"] == shop]
        label = group[0]["shop_folder"]
        preview(stage, group, f"{label}预览.jpg", f"{title} / {label}")
    preview(stage, rows, "多店铺总览.jpg", f"{title} / 多店铺主图")
    with ZipFile(stage / archive_name, "x", compression=ZIP_STORED) as archive:
        for row in rows:
            archive.write(stage / row["relative_file"], row["relative_file"])
    with ZipFile(stage / archive_name) as archive:
        require(set(archive.namelist()) == {row["relative_file"] for row in rows}, "Archive membership differs")
        for row in rows:
            require(hashlib.sha256(archive.read(row["relative_file"])).hexdigest()
                    == row["outputs"]["result_800.png"]["sha256"], "Archive member changed bytes")
    write(stage / "交付清单.json", manifest)
    return tree(stage)


from fission.ledger import tracked_cpu

@tracked_cpu('export')
def publish(staged, expected, old_trees, transaction, receipt_path):
    changes = []
    try:
        for stage, destination in staged:
            expected_old = old_trees[str(destination)]
            require((tree(destination) if destination.exists() else None) == expected_old,
                    f"Destination changed during staging: {destination}")
            previous = destination.with_name(f".{destination.name}.previous-{transaction['id']}")
            require(not previous.exists(), "Rollback folder already exists")
            change = {"stage": stage, "destination": destination, "previous": previous,
                      "old_moved": False, "new_moved": False}
            changes.append(change)
            if destination.exists():
                destination.rename(previous)
                change["old_moved"] = True
            stage.rename(destination)
            change["new_moved"] = True
            require(tree(destination) == expected, f"Published files differ: {destination}")
        transaction["status"] = "published_and_verified"
        write(receipt_path, transaction)
    except BaseException:
        for change in reversed(changes):
            if change["new_moved"]:
                change["destination"].rename(change["stage"])
            if change["old_moved"]:
                change["previous"].rename(change["destination"])
        transaction["status"] = "rolled_back"
        write(receipt_path, transaction)
        raise
    for change in changes:
        if change["old_moved"]:
            shutil.rmtree(change["previous"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--selected", type=Path, required=True)
    parser.add_argument("--output", type=Path, action="append", required=True,
                        help="Absolute delivery folder; repeat for project and Desktop mirrors")
    parser.add_argument("--title", default="快餐盘")
    parser.add_argument("--archive-name", default="快餐盘_多店铺无字主图.zip")
    parser.add_argument("--publish", action="store_true")
    parser.add_argument("--replace", action="store_true", help="Archive existing delivery folders before replacing them")
    args = parser.parse_args()
    plan, run_root, rows = load_plan(args.plan, None)
    selected = read(args.selected)
    require(isinstance(selected, dict) and set(selected) == {row["id"] for row in rows},
            "Selection must cover every plan row exactly")
    targets = []
    for path in args.output:
        require(path.is_absolute() and len(path.parts) >= 5 and not path.is_symlink(), "Use a dedicated absolute delivery folder")
        targets.append(path.resolve())
    require(len(set(targets)) == len(targets), "Delivery targets repeat")
    for target in targets:
        require(all(target == other or not target.is_relative_to(other) for other in targets), "Delivery folders overlap")
        require(not run_root.is_relative_to(target) and not target.is_relative_to(run_root), "Delivery overlaps source runs")
    archive_name = safe_label(args.archive_name, "archive filename")
    require(archive_name.endswith(".zip"), "Archive filename must end in .zip")
    title = safe_label(args.title, "preview title")
    snapshots = [fingerprint(args.plan), fingerprint(args.selected)]
    checked = [check_row(row, selected[row["id"]], run_root) for row in rows]
    require(len({row["relative_file"].casefold() for row in checked}) == len(checked), "Output filenames collide")
    shop_directories = {row["shop"]: row["shop_folder"] for row in checked}
    require(len(set(value.casefold() for value in shop_directories.values())) == len(shop_directories), "Shop folders collide")
    require(all(row["shop_folder"] == shop_directories[row["shop"]] for row in checked), "One shop has inconsistent folder names")
    require(all(row["shop_folder"] not in ("预览", archive_name, "交付清单.json") for row in checked), "Shop name conflicts with package files")
    print(f"Verified {len(checked)} reviewed ComfyUI photos across {len(set(row['shop'] for row in checked))} shops", flush=True)
    if not args.publish:
        return
    lock_path = run_root / "publish_native_multishop.lock"
    with lock_path.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        old_trees = {str(target): tree(target) if target.exists() else None for target in targets}
        require(args.replace or not any(value is not None for value in old_trees.values()),
                "Existing delivery requires --replace to archive it before replacement")
        stamp = datetime.datetime.now(ZoneInfo("America/New_York")).strftime("%Y%m%d_%H%M%S")
        token = stamp + "_" + uuid.uuid4().hex[:8]
        archive_root = ROOT / "work/archives/native_multishop" / token
        archive_root.mkdir(parents=True)
        backups = {}
        for index, target in enumerate(targets):
            if old_trees[str(target)] is not None:
                backup = archive_root / f"previous_{index + 1}"
                shutil.copytree(target, backup)
                require(tree(backup) == old_trees[str(target)], "Old delivery archive checksum differs")
                backups[str(target)] = str(backup)
        manifest = {"schema_version": 1, "created_at": datetime.datetime.now(ZoneInfo("America/New_York")).isoformat(),
                    "plan": snapshots[0], "selection": snapshots[1], "targets": list(map(str, targets)),
                    "image_processing": "ComfyUI outputs copied byte-for-byte; Pillow used only for previews",
                    "count": len(checked), "shops": list(dict.fromkeys(row["shop"] for row in checked)), "rows": checked}
        transaction = {"id": token, "status": "staging", "targets": list(map(str, targets)),
                       "backups": backups, "old_delivery_hashes": old_trees, "source_manifest": manifest}
        receipt_path = archive_root / "publication.json"
        write(receipt_path, transaction)
        for target in targets:
            target.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix=".native-delivery-", dir=targets[0].parent) as first:
            stage = Path(first) / "delivery"
            expected = build(stage, checked, manifest, archive_name, title)
            staged = [(stage, targets[0])]
            temporary_dirs = []
            try:
                for target in targets[1:]:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    temporary = tempfile.TemporaryDirectory(prefix=".native-delivery-", dir=target.parent)
                    temporary_dirs.append(temporary)
                    mirror = Path(temporary.name) / "delivery"
                    shutil.copytree(stage, mirror)
                    require(tree(mirror) == expected, "Delivery mirror differs")
                    staged.append((mirror, target))
                for item in snapshots:
                    check_fingerprint(item)
                for row in checked:
                    for item in (row["identity"], row["visual_review"], row["workflow_api"], row["workflow_ui"],
                                 row["submission"], row["history"], row["background_submission"],
                                 *row["outputs"].values(), *row["source_outputs"].values(),
                                 *row["input_references"], *row["background_approval"].values()):
                        check_fingerprint(item)
                    if row["crop_generation"]:
                        for key in ("identity", "workflow_api", "workflow_ui", "submission", "history"):
                            check_fingerprint(row["crop_generation"][key])
                transaction["new_delivery_hashes"] = expected
                write(receipt_path, transaction)
                publish(staged, expected, old_trees, transaction, receipt_path)
            finally:
                for temporary in temporary_dirs:
                    temporary.cleanup()
        write(run_root / "交付核验.json", {"status": "published_and_verified", "transaction": fingerprint(receipt_path),
                                        "targets": list(map(str, targets)), "count": len(checked), "files": expected})
        print(json.dumps({"targets": list(map(str, targets)), "count": len(checked), "archive": archive_name,
                          "transaction": str(receipt_path)}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
