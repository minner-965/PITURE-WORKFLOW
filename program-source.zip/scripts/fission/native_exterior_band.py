"""A05 deterministic exterior-color diagnostic; preview must be visually reviewed."""
import argparse,fcntl,importlib.util,json,shutil
from pathlib import Path
import numpy as np
from PIL import Image
from build_workflows import node,check_graph,ui
from comfy_client import ComfyClient
from native_multishop import ROOT,sha,read,write
from fission.deterministic import run
BASE=ROOT/'fission/runs/fastplate_20261104/全套重做';PARENT=BASE/'A05/product/approved_batch_v07';OUT=BASE/'A05/product/exterior_band_v01';NODE=Path('/Users/luohuiwu/ComfyUI-Installs/E-commerce image workflow/ComfyUI/custom_nodes/fission_photo_lock/__init__.py')
SETTINGS={'roi_xywh':[95,370,455,205],'seed_xy':[125,455],'reference_sample_xywh':[320,502,280,14]}
def main():
 p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');p.add_argument('--settings',type=Path);p.add_argument('--output',type=Path);a=p.parse_args();settings=read(a.settings) if a.settings else SETTINGS;src=PARENT/'result.png';ref=PARENT/'product_reference.png';result=read(PARENT/'result.json');ident=read(PARENT/'identity.json');receipt=read(PARENT/'submission.json');history=read(PARENT/'history.json')
 if result['sha256']!=sha(src) or result['outputs']['product_reference.png']['sha256']!=sha(ref) or result['identity_sha256']!=sha(PARENT/'identity.json') or result['prompt_id']!=receipt['prompt_id'] or result['prompt_id']!=history['prompt'][1] or history['status']['status_str']!='success':raise ValueError('Source provenance changed')
 im=np.asarray(Image.open(src).convert('RGB'));reference=np.asarray(Image.open(ref).convert('RGB'));sample=reference[502:516,320:600].astype(np.int16);selected=(sample[:,:,0]>150)&(sample[:,:,0]>sample[:,:,1]*1.3)&(sample[:,:,1]>sample[:,:,2]*1.1);pixel=im[455,125].astype(int)
 if not (pixel.min()>150 and pixel.max()-pixel.min()<24 and selected.sum()>=50):raise ValueError('Seed or reference sample invalid')
 spec=importlib.util.spec_from_file_location('photo_lock',NODE);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);assert set(module.FissionExteriorBandColor.INPUT_TYPES()['required'])=={'image','reference','settings_json'}
 chain={'source_sha256':sha(src),'reference_sha256':sha(ref),'identity_sha256':sha(PARENT/'identity.json'),'result_sha256':sha(PARENT/'result.json'),'receipt_sha256':sha(PARENT/'submission.json'),'history_sha256':sha(PARENT/'history.json'),'node_sha256':sha(NODE),'source_prompt_id':result['prompt_id'],'settings':settings,'seed_rgb':pixel.tolist(),'reference_orange_count':int(selected.sum()),'reference_orange_median_rgb':np.median(sample[selected],axis=0).tolist(),'status':'pending_mask_review'}
 if a.check:print(json.dumps({'check':'offline_schema_and_provenance_passed','chain':chain},ensure_ascii=False));return
 c=ComfyClient();info=c.get('/object_info');out=a.output.resolve() if a.output else OUT;out.mkdir(parents=True,exist_ok=True)
 with (ROOT/'fission/runs/native_gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('Comfy queue is busy')
  g={'1':node('LoadImage','源图',image=c.upload(src)),'2':node('LoadImage','同色实拍',image=c.upload(ref)),'3':node('FissionExteriorBandColor','外壁局部修色',image=['1',0],reference=['2',0],settings_json=json.dumps(settings)),'4':node('SaveImage','1024预览',images=['3',0],filename_prefix='exterior_band/result'),'5':node('MaskToImage','选区图',mask=['3',1]),'6':node('SaveImage','保存mask',images=['5',0],filename_prefix='exterior_band/mask'),'7':node('ImageCrop','近景',image=['3',0],x=80,y=160,width=864,height=864),'8':node('ImageScale','800',image=['7',0],upscale_method='lanczos',width=800,height=800,crop='disabled'),'9':node('SaveImage','800',images=['8',0],filename_prefix='exterior_band/800')}
  check_graph(g,info);visual=ui(g,info,'实拍色局部外壁','先审核mask及实物色。')
  for i,n in enumerate(visual['nodes']):n['pos']=[(i%5)*360,(i//5)*360]
  write(out/'workflow.api.json',g);write(out/'workflow.ui.json',visual);write(out/'source_chain.json',chain);entry,hit=run(c,g,visual,out,NODE,src)
  for k,name in [('4','result.png'),('6','mask.png'),('9','result_800.png')]:
   source=Path(entry['files'][k][0]);dest=out/name;digest=entry['output_hashes'][str(source)]
   if dest.exists() and sha(dest)!=digest:raise ValueError('Existing output mismatch')
   if not dest.exists():shutil.copyfile(source,dest)
   if sha(dest)!=digest:raise ValueError('Output copy mismatch')
  h=entry.get('history');h=read(h) if isinstance(h,str) else h
  if h and not (out/'history.json').exists():write(out/'history.json',h)
  if hit and not (out/'submission.json').exists():shutil.copyfile(Path(entry['source'])/'submission.json',out/'submission.json')
  after=np.asarray(Image.open(out/'result.png').convert('RGB'));mask=np.asarray(Image.open(out/'mask.png').convert('L'));changed=np.any(im!=after,axis=2);outside=int(np.sum(changed&(mask==0)));stats={'outside_mask_changed_pixels':outside,'changed_pixels':int(changed.sum()),'mask_pixels':int((mask>0).sum()),'output_sha256':{name:sha(out/name) for name in ['result.png','mask.png','result_800.png']},'prompt_id':entry['prompt_id'],'status':'pending_visual_review'};write(out/'pixel_check.json',stats)
  if outside:raise ValueError('Pixels changed outside mask')
  print(json.dumps(stats,ensure_ascii=False))
if __name__=='__main__':main()
