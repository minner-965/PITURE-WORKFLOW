"""Full-frame Klein soft layout guidance, prepared separately from source templates."""
import argparse,fcntl,json,shutil,subprocess
from pathlib import Path
from build_workflows import check_graph,ui
from comfy_client import ComfyClient
from native_multishop import ROOT,read,write,sha

def main():
 p=argparse.ArgumentParser();p.add_argument('--guide-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--check',action='store_true');a=p.parse_args();src=a.guide_dir.resolve(strict=True);out=a.output.resolve();check=read(src/'sample_check.json');diag=read(src/'diagnostics.json')
 for name in ['layout.png','reference_3019.png']:
  if sha(src/name)!=diag['outputs'][name]:raise ValueError('Guide provenance changed: '+name)
 if sha(src/'layout.png')!=check['guide_sha256'] or not check['soft_constraint_only']:raise ValueError('Guide check mismatch')
 g=read(src/'sample_check.api.json');g['8']['inputs']['text']='Natural premium restaurant photograph of exactly six matching blue-and-white hotpot bowls and six matching bottom plates, all the same real-world product and physical size. Use reference 1 as a soft composition guide, preserving the six positions and close proportions, and reference 2 for the actual shallow outward-flared silhouette, white interiors, proportional wall height and low foot, cobalt blue peonies and leaves. Fill each existing bowl naturally: back left tofu, back right mushrooms, middle left marbled beef rolls, middle right lotus root slices with holes, front left peeled shrimp, front right pale meatballs. All six bowls contain food, modest portions beneath or just above the rim. Preserve natural relative size, bowl and plate as separate matching objects. Harmonize the photographed white ceramic and blue print brightness with the warm restaurant table lighting. Rebuild realistic contact shadows directly beneath each foot and plate, coherent reflections and moist food textures. Full scene generated together; preserve positions, intact edges, realistic depth and photographic lighting, no overlay.'
 g['9']['inputs']['text']='empty bowls, extra bowls, additional central bowl, additional dishes or objects, hands, people, apron, merged bowl and plate, absent matching plate, flat shallow plate in place of bowl, deep tall cup, distorted or stretched bowls, different product sizes, mismatched shape, changed blue flower pattern, warped rim, cropped product, floating dishes, detached shadows, pasted appearance, fake food, text, logo, watermark, blur.'
 g['1']['inputs']['image']=str(src/'layout.png');g['2']['inputs']['image']=str(src/'reference_3019.png');c=ComfyClient();info=c.get('/object_info');check_graph(g,info);v=ui(g,info,'青花六碗全图软引导','引导图作为参考与初始latent，模型全图生成。')
 assert g['21']['inputs']['latent_image']==['10',0] and g['21']['inputs']['sigmas']==['80',1] and g['80']['inputs']['step']==36 and g['18']['inputs']['steps']==40 and g['16']['inputs']['cfg']==1.3
 if a.check:print(json.dumps({'check':'passed','sigmas':check['sigmas'],'steps':4,'guide_sha256':sha(src/'layout.png')}));return
 approval=read(src/'guide_review.json')
 if approval.get('status')!='passed' or approval.get('guide_sha256')!=sha(src/'layout.png'):raise ValueError('Guide approval missing or changed')
 out.mkdir(parents=True,exist_ok=True)
 with (ROOT/'fission/runs/native_gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('Comfy queue busy')
  if (out/'submission.json').exists():raise RuntimeError('Existing receipt; reconcile first')
  g['1']['inputs']['image']=c.upload(src/'layout.png');g['2']['inputs']['image']=c.upload(src/'reference_3019.png');check_graph(g,info);v=ui(g,info,'青花六碗全图软引导','引导图作为参考与初始latent，模型全图生成。');write(out/'workflow.api.json',g);write(out/'workflow.ui.json',v);write(out/'identity.json',{'guide':str(src/'layout.png'),'guide_sha256':sha(src/'layout.png'),'guide_source_chain_sha256':sha(src/'source_chain.json'),'guide_approval_sha256':sha(src/'guide_review.json'),'photo_reference':str(src/'reference_3019.png'),'photo_reference_sha256':sha(src/'reference_3019.png'),'sigmas':check['sigmas'],'steps':4,'cfg':1.3,'seed':g['19']['inputs']['noise_seed'],'positive':g['8']['inputs']['text'],'negative':g['9']['inputs']['text'],'method':'whole image generation; guide is soft conditioning and initial latent; no product pixels composited back'})
  pid=c.submit(g,v,out/'submission.json');backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());hist,metrics=c.wait(pid,out,backend);files=c.download(hist,out/'download');outputs={'23':'result.png','26':'result_800.png','28':'reference_3019.png'}
  for n,name in outputs.items():shutil.copyfile(files[n][0],out/name)
  write(out/'result.json',{'prompt_id':pid,'seconds':metrics.get('backend_wall_seconds'),'outputs':{name:sha(out/name) for name in outputs.values()},'identity_sha256':sha(out/'identity.json'),'status':'pending_visual_review'});print(json.dumps(read(out/'result.json'),ensure_ascii=False))
if __name__=='__main__':main()
