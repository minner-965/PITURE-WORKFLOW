"""Package 15 explicitly reviewed sources. No existing destination is replaced.

Manifest: {"sources":[{"id":"A01", "path":"/absolute/result.png",
"sha256":"<64 hex>", "qa":{"status":"passed", "reviewer":"root",
"source_sha256":"<same hash>", "notes":"review observations"}}]}
Usage: python scripts/fission/package_approved_sources.py MANIFEST [--output NEW_DIRECTORY]
Without --output, validates only. Output must not exist.
"""
import argparse
import hashlib
import json
import re
import shutil
from pathlib import Path
from zipfile import ZipFile, ZIP_STORED
from PIL import Image, ImageDraw, ImageFont


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate(manifest):
    rows = json.loads(manifest.read_text(encoding='utf-8'))['sources']
    expected = {f'{shop}{i:02}' for shop in 'ABC' for i in range(1, 6)}
    assert isinstance(rows, list) and len(rows) == 15
    assert {r['id'] for r in rows} == expected
    assert len({r['sha256'] for r in rows}) == 15, 'Duplicate source hashes'
    for r in rows:
        p = Path(r['path'])
        assert p.is_absolute() and p.is_file() and not p.is_symlink()
        digest = r['sha256']
        assert re.fullmatch(r'[0-9a-f]{64}', digest) and sha(p) == digest
        q = r['qa']
        assert q['status'] == 'passed' and q['reviewer'] == 'root'
        assert q['source_sha256'] == digest and len(q['notes'].strip()) >= 16
        with Image.open(p) as im:
            assert im.format == 'PNG' and im.size == (800, 800)
            im.verify()
    return sorted(rows, key=lambda r: r['id'])


def package(rows, dest):
    dest.mkdir(parents=True, exist_ok=False)
    (dest / '预览').mkdir()
    for r in rows:
        shop = r['id'][0] + '店'
        (dest / shop).mkdir(exist_ok=True)
        target = dest / shop / (r['id'] + '_无字.png')
        shutil.copyfile(r['path'], target)
        assert sha(target) == r['sha256']
    font_path = Path(__file__).resolve().parents[2] / 'fission/fonts/SourceHanSansSC-Regular.otf'
    font = ImageFont.truetype(str(font_path), 16)
    for name, group in [('A店', rows[:5]), ('B店', rows[5:10]), ('C店', rows[10:]), ('多店铺总览', rows)]:
        captions = []
        for r in group:
            lines = [f"{r['id']} · {r['color']}", '']
            for char in r['dish']:
                if font.getlength(lines[-1] + char) > 210:
                    lines.append('')
                lines[-1] += char
            captions.append(lines)
        line_height = 22
        tile_height = 220 + max(len(lines) for lines in captions) * line_height + 8
        sheet = Image.new('RGB', (5 * 220, ((len(group)+4)//5)*tile_height), 'white')
        draw = ImageDraw.Draw(sheet)
        for i, (r, lines) in enumerate(zip(group, captions)):
            x, y = i % 5 * 220, i // 5 * tile_height
            with Image.open(dest / (r['id'][0]+'店') / (r['id']+'_无字.png')) as im:
                sheet.paste(im.convert('RGB').resize((210,210), Image.Resampling.LANCZOS), (x,y))
            for j, line in enumerate(lines):
                draw.text((x, y + 214 + j * line_height), line, font=font, fill='black')
        sheet.save(dest / '预览' / (name+'.jpg'), quality=92)
    (dest / '交付清单.json').write_text(json.dumps({'sources': rows}, ensure_ascii=False, indent=2), encoding='utf-8')
    archive = dest / '快餐盘_三店15张无字主图.zip'
    files = sorted(p for p in dest.rglob('*') if p.is_file() and p != archive)
    with ZipFile(archive, 'w', ZIP_STORED) as z:
        for p in files: z.write(p, p.relative_to(dest).as_posix())
    with ZipFile(archive) as z:
        assert set(z.namelist()) == {p.relative_to(dest).as_posix() for p in files}
        for p in files:
            assert hashlib.sha256(z.read(p.relative_to(dest).as_posix())).hexdigest() == sha(p)
    for r in rows:
        assert sha(dest / (r['id'][0]+'店') / (r['id']+'_无字.png')) == r['sha256']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    rows = validate(args.manifest)
    if args.output: package(rows, args.output)
    print(f'Validated {len(rows)} sources' + (f'; packaged in {args.output}' if args.output else ''))

if __name__ == '__main__': main()
