"""Read-only, loopback-only progress viewer for the w1125 ABC batch."""
import argparse
from collections import Counter
from datetime import datetime
from html import escape
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import hashlib
from functools import lru_cache
from PIL import Image
import mimetypes
from pathlib import Path
import re
import shutil
from urllib.parse import urlsplit
from zipfile import ZipFile, BadZipFile
from urllib.request import build_opener, ProxyHandler

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'fission'
RUN = BASE / 'runs/abc_20261104'
EXPORT = BASE / 'exports/w1125/ABC_20261104'
CLOSEUP = ROOT / 'output/w1125_三店主图_商品放大版_20261104'
BACKEND = build_opener(ProxyHandler({}))
SHOPS = ('A','B','C')
MASTER_COLORS = {'A':'黄','B':'红','C':'蓝','green':'绿','orange':'橙'}


def read_json(path):
    try:
        return json.loads(path.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def queue():
    try:
        with BACKEND.open('http://127.0.0.1:8188/queue', timeout=2) as r:
            data=json.load(r)
        return True, {a[1]: status for k,status in [('queue_running','生成中'),('queue_pending','已提交，排队中')] for a in data[k]}
    except (OSError, ValueError, KeyError, IndexError):
        return False, {}


@lru_cache(maxsize=128)
def media_signature(path, mtime, size):
    """Cache by file identity; invalid or partial writes are not displayable."""
    try:
        with Image.open(path) as im:
            fmt, dimensions=im.format, im.size
            im.verify()
        return fmt, dimensions, hashlib.sha256(path.read_bytes()).hexdigest()
    except (ValueError, OSError, SyntaxError):
        return None,None,None


def native_photo(slot,receipt,pid):
    name=receipt.get('filename','')
    if (not pid or receipt.get('prompt_id')!=pid or
        not isinstance(name,str) or not re.fullmatch(r'downloads/[A-Za-z0-9_.-]+\.png',name)):
        return None
    photo=slot/name
    preview=slot/'带字预览.jpg'
    if (not photo.is_file() or not preview.is_file() or
        photo.resolve().parent!=(slot/'downloads').resolve() or
        not photo.resolve().is_relative_to(slot.resolve()) or preview.resolve().parent!=slot.resolve()):
        return None
    im=photo.stat(); j=preview.stat()
    fmt,_,sha=media_signature(photo,im.st_mtime_ns,im.st_size)
    jf,dims,jsha=media_signature(preview,j.st_mtime_ns,j.st_size)
    if (fmt=='PNG' and sha==receipt.get('sha256') and jf=='JPEG' and dims==(800,800) and
        receipt.get('preview_sha256',jsha)==jsha):
        return photo,preview
    return None


def inspect(q=None):
    """Resolve only menu-owned image paths and completed archives."""
    rows=[]; files={}; current=[]; indexes=Counter()
    menu_path=RUN/'menu.json'
    menu_sha=hashlib.sha256(menu_path.read_bytes()).hexdigest()
    delivered = read_json(EXPORT/'交付记录.json').get('menu_sha256')==menu_sha
    proof_current = read_json(RUN/'排版校样'/'校样清单.json').get('menu_sha256')==menu_sha
    hold_policy=read_json(RUN/'quality_hold.json')
    hold=hold_policy.get('hold') is True
    legacy_only=hold and hold_policy.get('hold_scope')=='legacy_projection'
    withdrawal=read_json(RUN/'用户退回记录.json') if hold else {}
    withdrawn={r['card'] for r in withdrawal.get('withdrawn',[])}
    for r in read_json(RUN/'menu.json'):
        shop, dish, name = r['shop'], r['dish_id'], r['name']
        if shop not in SHOPS or not re.fullmatch(r'[a-z0-9_]+', dish) or not re.fullmatch(r'[\w·]+',name):
            continue
        master_id=r.get('master_id')
        color=r.get('bowl_color')
        if master_id not in MASTER_COLORS or color!=MASTER_COLORS[master_id]:
            continue
        master=BASE/'masters'/master_id
        metadata=read_json(master/'master.json')
        master_image=master/'master_1280.png'
        master_url='/asset/master-'+master_id
        master_sha=metadata.get('artifacts',{}).get('master_1280.png') if metadata.get('color')==color else None
        if master_sha and master_image.is_file():
            files[master_url]=master_image
        indexes[shop]+=1
        key=f'{shop}{indexes[shop]:02}'
        dest=f'{key}_{name}.jpg'
        folder=RUN/shop/dish
        media=[]; active=[]; previews=0; status='待生成'; reviews={}; rejections=[]
        def add(token,path,label):
            if path.is_file():
                url='/asset/'+key+'-'+token
                files[url]=path; media.append((url,label))
        if delivered:
            add('final',EXPORT/f'{shop}店'/dest,'已审核主图')
        if proof_current: add('proof',RUN/'排版校样'/f'{shop}店'/dest,'排版校样')
        repair=folder/'repair_rim2'
        review=read_json(repair/'review.json')
        sample=repair/'reviewed_preview.jpg'
        repaired=(key=='A01' and master_id=='A' and review.get('status')=='root_reviewed_for_user' and
                  sample.is_file() and review.get('sha256')==hashlib.sha256(sample.read_bytes()).hexdigest())
        if repaired:
            add('repair',sample,'碗沿修复 · 已保留样片')
        slots=sorted(f for f in folder.glob('*_*') if f.is_dir() and re.fullmatch(r'(full|preview)_\d+', f.name))
        valid_results=set()
        for slot in slots:
            stage,i=slot.name.split('_')
            desc=('正式图' if stage=='full' else '候选')+str(int(i)+1)
            result=read_json(slot/'result.json')
            source=(result.get('composition',{}).get('master_sha256')
                    or result.get('master',{}).get('files',{}).get('master_1280.png')
                    or read_json(slot/'props'/'identity.json').get('src'))
            if source is None and not result and q and (slot/'food'/'submission.json').is_file():
                # The texture step may reuse an earlier verified background of the same variant parity.
                source=next((master_sha for orig in slots if int(orig.name.split('_')[1])%2==int(i)%2
                             and read_json(orig/'props'/'identity.json').get('src')==master_sha),None)
            if not master_sha or source!=master_sha or result.get('master_id',master_id)!=master_id:
                continue
            if result.get('sha256'): valid_results.add(result['sha256'])
            review=read_json(slot/'visual_review.json')
            if result and review.get('sha256')==result.get('sha256') and isinstance(review.get('approved'),bool):
                if review['approved']:
                    reviews[slot.name]=1
                    desc+=' · 预览通过' if stage=='preview' else ' · 照片通过'
                else:
                    reviews[slot.name]=-1
                    desc+=' · 已退回'
                    rejections.append((desc,review.get('reason','待重做')))
            if result:
                add(slot.name+'-type',slot/'带字预览.jpg',desc+' · 带字预览')
                add(slot.name,slot/'food/photo.png',desc+' · 无字图')
                if stage=='preview':
                    previews+=1
            for layer,part in [('props','桌面配菜'),('food','碗内食物')]:
                path=slot/layer
                pid=read_json(path/'submission.json').get('prompt_id') if q and not (path/'verified.json').exists() else None
                if pid and pid in q:
                    title=f'{desc} · {part}{q[pid]}'
                    active.append(title); current.append(f'{key} {color}碗 · {name}　{title}')
                if layer=='props' and (path/'verified.json').is_file():
                    add(slot.name+'-props',path/'photo.png',desc+' · 配菜底图（空碗）')
        if previews: status='预览待选'
        if previews and sum(k.startswith('preview_') and v==-1 for k,v in reviews.items())==previews:status='候选已退回'
        if any(v==1 for v in reviews.values()):status='照片已通过初审'
        if repaired:valid_results.add(read_json(repair/'review.json').get('photo_sha256'))
        selection=read_json(folder/'selection.json')
        selected=selection.get('sha256')
        if selected and selected in valid_results:
            status='已选预览'
            add('photo',folder/'photo_1280.png','高清无字图')
            if (folder/'photo_1280.png').is_file():status='待排版或终审'
        if any(label=='排版校样' for _,label in media): status='排版待终审'
        final=any(label=='已审核主图' for _,label in media)
        if hold and not final:
            status='等待原生样' if legacy_only else '批量暂停'
            if key in withdrawn:status='用户已退回 · 待重做'
            elif key in withdrawal.get('pending',[]):status='旧候选待审 · 未选定'
        native_rank={}
        native_status=[]
        for slot in sorted((folder/'原生双参考').glob('*')):
            if not re.fullmatch(r'[0-9]{2,}',slot.name) or not slot.is_dir() or slot.is_symlink():continue
            identity=read_json(slot/'identity.json')
            if not master_sha or identity.get('product_sha256')!=master_sha:continue
            method=identity.get('method','native_dual_reference')
            if method not in ('native_dual_reference','native_color_adjustment'):continue
            prefix=f'原生双参考 {slot.name}'
            if method=='native_color_adjustment':prefix+=' · 碗身校色'
            pid=read_json(slot/'submission.json').get('prompt_id')
            if q and pid in q:
                active.append(prefix+' · '+q[pid])
                current.append(f'{key} {color}碗 · {name}　{active[-1]}')
            entry=read_json(slot/'result.json')
            if entry.get('method','native_dual_reference')!=method:continue
            result_files=native_photo(slot,entry,pid)
            if not result_files:continue
            validity=read_json(slot/'visual_review.json')
            verdict=validity.get('approved') if validity.get('sha256')==entry['sha256'] else None
            level,state=1,'待复核'
            if verdict is False:
                level,state=0,'已退回'
                rejections.append((prefix+' · '+state,validity.get('reason','待重做')))
            elif verdict is True:
                matches=selection.get('method')==method and selection.get('candidate_id')==slot.name and selected==entry['sha256']
                level,state=(3,'已选') if matches else (2,'初审通过')
            token='native'+slot.name
            native_rank[token]=(-level,-int(slot.name))
            label=prefix+' · '+state
            native_status.append((level,int(slot.name),label))
            add(token+'-type',result_files[1],label+' · 带字预览')
            add(token,result_files[0],label+' · 无字图')
            previews+=1
        if native_status:status=max(native_status)[2]
        if repaired:status='已保留修复样片'
        if final: status='已审核'
        if active: status=active[0]
        # Prefer complete photos over partial background layers.
        def priority(asset):
            url,label=asset
            token=url.removeprefix('/asset/'+key+'-')
            if token.split('-')[0] in native_rank:
                level,n=native_rank[token.split('-')[0]]
                return level+(-3 if level<0 else 6),n,'无字图' in label
            if token in ('repair','final','proof','photo'): rank={'repair':-1,'final':0,'proof':1,'photo':2}[token]
            else: rank={1:3,0:4,-1:5}[reviews.get(token.split('-')[0],0)]
            if token.endswith('-props'):rank=6
            return rank,'无字图' in label,-files[url].stat().st_mtime_ns
        media.sort(key=priority)
        display=[(u,label) for u,label in media if '已退回' not in label]
        legacy=key in withdrawn or key in withdrawal.get('pending',[])
        if legacy:display=[(url,label) for url,label in display if '原生双参考' in label]
        rows.append(dict(legacy=legacy,display=display, repaired=repaired, key=key, shop=shop, color=color, master_url=master_url, name=name, title=r['title'], status=status, active=bool(active),
                         previews=previews, final=final, media=media, rejections=rejections))
    if delivered:
        for code, filename in [(s,f'{s}店_五张菜品主图.zip') for s in SHOPS]+[('all','三店_全部15张菜品主图.zip')]:
            path=EXPORT/'压缩包'/filename
            if path.is_file(): files['/asset/zip-'+code]=path
    return rows,files,current


CSS="""
*{box-sizing:border-box}body{margin:0;color:#22372e;background:#f6f5ee;font:16px/1.5 -apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif}main{max-width:1380px;padding:32px clamp(14px,4vw,60px) 70px;margin:auto}small,.muted{color:#56685c}h1{font-size:clamp(30px,4.5vw,58px);letter-spacing:-.04em;margin:7px 0 8px}h2{margin:30px 0 12px;font-size:23px}p{margin:4px 0 12px}header{padding-bottom:22px;border-bottom:2px solid #294839}.live{color:#25674b;font-weight:700}.numbers{display:flex;gap:9px;flex-wrap:wrap;margin:14px 0}.stat{padding:7px 13px;background:white;border:1px solid #d7ded5;border-radius:8px}.stat b{font-size:22px;margin-right:4px}.now{background:#214a37;color:#fff;padding:13px 17px;border-radius:9px}.shophead{display:flex;align-items:baseline;gap:12px;flex-wrap:wrap}.shophead h2{margin-bottom:9px}.grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px}.card{min-width:0;background:white;border:1px solid #d9dfd4;border-radius:11px;overflow:hidden}.card.active{border:2px solid #368859}.photo,.wait{display:block;width:100%;aspect-ratio:5/4;background:#e1e5d9;object-fit:contain}.wait{display:grid;place-items:center;color:#677668;font-size:14px}.content{padding:12px}.content h3{margin:2px 0 5px;font-size:18px}.status{display:block;font-size:13px;font-weight:600;color:#3e654c}.media{font-size:13px;margin-top:5px}.media a{display:block}.cap{font-size:12px;color:#f6faed;background:#355944;padding:3px 8px}.master{font-size:14px}a{color:#1b6749}.num{font-size:12px;color:#6e7869}#net{padding:0 6px;background:#ffd5ac}footer{margin-top:30px}.pack{border-radius:8px;display:inline-block;margin:10px 8px 0 0;padding:8px 14px;background:#204d39;color:white}
.reject{background:#f8e4db;color:#843d28;border-radius:6px;padding:7px;font-size:13px}.focus{display:flex;align-items:center;gap:22px;padding:14px;margin:16px 0;background:#e7ece1;border-radius:12px}.focus img{width:min(38vw,320px);max-height:225px;object-fit:contain;border-radius:7px;display:block}.focus h2{margin:5px 0}.focus p{margin:0 0 9px}@media(max-width:620px){.focus{gap:12px}.focus h2{font-size:18px}}
@media(max-width:940px){.grid{grid-template-columns:repeat(3,minmax(0,1fr))}}@media(max-width:620px){.grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}.content{padding:8px}.content h3{font-size:16px}}
"""



@lru_cache(maxsize=12)
def pack_matches(path, mtime, size, expected):
    try:
        with ZipFile(path) as z:
            return (sorted(z.namelist()) == sorted(name for name,_ in expected)
                    and all(hashlib.sha256(z.read(name)).hexdigest() == sha for name,sha in expected))
    except (OSError, BadZipFile, KeyError):
        return False


def delivered_gallery():
    """Expose only the published 15 cards and four shop/contact proofs after matching the shipped manifest."""
    manifest = read_json(CLOSEUP/'交付清单.json')
    if not isinstance(manifest,dict) or manifest.get('sku') != 'w1125':
        return None
    try:
        rows = manifest['images']
        expected_ids = [f'{shop}{i:02}' for shop in SHOPS for i in range(1,6)]
        if sorted(r['id'] for r in rows) != expected_ids:
            return None
        files = {}
        def register(url,path,sha,dimensions=None):
            if path.resolve(strict=True) != path or not path.is_relative_to(CLOSEUP):
                raise ValueError('交付文件路径不符')
            stat=path.stat()
            fmt,shape,actual=media_signature(path,stat.st_mtime_ns,stat.st_size)
            if fmt!='JPEG' or not actual or actual!=sha or (dimensions and shape!=dimensions):
                raise ValueError('交付图片不符')
            files[url]=path
        for r in rows:
            key,shop,name = r['id'],r['shop'],r['name']
            if shop!=key[0] or not re.fullmatch(r'[\w·]+',name) or r['file']!=f'{shop}店/{key}_{name}.jpg':
                return None
            register('/asset/final-'+key,CLOSEUP/r['file'],r['sha256'],(800,800))
        for key,label in [(s,s+'店预览.jpg') for s in SHOPS]+[('all','三店总览.jpg')]:
            register('/asset/overview-'+key,CLOSEUP/'预览'/label,manifest['previews'][label])
        for key in (*SHOPS,'all'):
            filename='全部商品主图.zip' if key=='all' else key+'店_主图.zip'
            path=CLOSEUP/'压缩包'/filename
            if not path.is_file() or path.resolve()!=path:continue
            expected=tuple((r['file'] if key=='all' else Path(r['file']).name,r['sha256'])
                           for r in rows if key=='all' or r['shop']==key)
            st=path.stat()
            if pack_matches(path,st.st_mtime_ns,st.st_size,expected):
                files['/asset/zip-'+key]=path
        return sorted(rows,key=lambda r:r['id']),files
    except (OSError,KeyError,TypeError,ValueError):
        return None


def final_board(gallery):
    rows,files=gallery
    parts=['<div id="delivery-final"><nav class="numbers"><a class="pack" href="/asset/overview-all" target="_blank">查看三店总览 ↗</a>']
    if '/asset/zip-all' in files:
        parts.append('<a class="pack" href="/asset/zip-all">下载全部 15 张</a>')
    parts.append('</nav>')
    for shop in SHOPS:
        parts.append(f'<section><div class="shophead"><h2>{shop} 店</h2><a href="/asset/overview-{shop}" target="_blank">查看本店五张大图 ↗</a>')
        if '/asset/zip-'+shop in files:
            parts.append(f'<a href="/asset/zip-{shop}">下载本店五张</a>')
        parts.append('</div><div class="grid">')
        for r in rows:
            if r['shop']!=shop:continue
            key=r['id'];title=escape(r['name']); url='/asset/final-'+key
            parts.append(f'<article class="card"><a href="{url}" target="_blank" aria-label="打开 {key} {title} 原图"><img src="{url}" class="photo" style="aspect-ratio:1" alt="{key} {title}"></a><div class="content"><small>{key}</small><h3>{title}</h3></div></article>')
        parts.append('</div></section>')
    return ''.join(parts)+'</div>'


def board():
    gallery=delivered_gallery()
    if gallery is not None:
        return final_board(gallery)
    online,q=queue()
    rows,files,now=inspect(q)
    count=sum(bool(r['previews']) for r in rows); final=sum(r['final'] for r in rows)
    stamp=datetime.now().strftime('%H:%M:%S')
    msg='　'.join(now) or ('本批暂无正在采样的图片' if online else '暂未连接到生成后端，可查看已保存的图片')
    hold_record=read_json(RUN/'quality_hold.json')
    hold=hold_record.get('hold') is True
    if hold:
        msg=('原生双参考　' if hold_record.get('hold_scope')=='legacy_projection' else '批量暂停　')+str(hold_record.get('reason',''))
        if now:msg+='　当前单张　'+'　'.join(now)
    banner='background:#903f27' if hold and hold_record.get('hold_scope')!='legacy_projection' else ''
    parts=[f'<small>本机时间 {stamp}　·　每 8 秒更新　<span id="net"></span></small>',
           f'<div class="numbers"><span class="stat">完整预览 <b>{count}</b>/ {len(rows)} 道</span><span class="stat">已审核主图 <b>{final}</b>/ {len(rows)} 张</span></div>',
           f'<div class="now" style="{banner}">{escape(msg)}</div>']
    available=[r for r in rows if r['display']]
    if hold and hold_record.get('locked_sample'):
        locked=read_json(RUN/'用户退回记录.json').get('accepted',[])
        if locked:available=[r for r in available if r['key'] in locked or '原生双参考' in r['display'][0][1]]

    if available:
        featured=next((r for r in available if r['active']), max(available,key=lambda r:max(files[u].stat().st_mtime_ns for u,_ in r['display'])))
        url,label=featured['display'][0]
        detail='配菜背景 · 空碗' if '配菜底图' in label else label
        detail+= '，碗内菜品生成中' if '配菜底图' in label and '食物生成中' in featured['status'] else ''
        reason=next((text for title,text in featured['rejections'] if label.startswith(title)),'')
        note=f'<p class="reject">{escape(reason)}</p>' if reason else ''
        parts.append(f'<aside class="focus"><a href="{url}" target="_blank"><img src="{url}" alt="{escape(detail)}"></a><div><small>最新可看画面</small><h2>{featured["key"]}　{featured["color"]}碗 · {escape(featured["name"])}</h2><p>{escape(detail)}</p>{note}<a href="{url}" target="_blank">查看原图 ↗</a></div></aside>')
    for shop in SHOPS:
        palette=" / ".join(r["color"] for r in rows if r["shop"]==shop)
        parts.append(f'<section><div class="shophead"><h2>{shop} 店</h2><span class="muted">菜品配色　{palette}</span></div><div class="grid">')
        for row in (r for r in rows if r['shop']==shop):
            media=row['media']
            parts.append('<article class="card'+(' active' if row['active'] else '')+'">')
            if row['display']:
                url,label=row['display'][0]
                parts.append(f'<a href="{url}" target="_blank"><img class="photo" src="{url}" alt="{escape(label)}"></a><div class="cap">{escape(label)}</div>')
            else:
                pending='旧方案已暂停 · 等待新样' if row['legacy'] else '等待首张画面'
                parts.append(f'<div class="wait">{pending}</div>')
            parts.append(f'<div class="content"><span class="num">{row["key"]}</span><h3>{row["color"]}碗 · {escape(row["name"])}</h3><span class="status">{escape(row["status"])}</span><div class="media">')
            if row['master_url'] in files:
                parts.append(f'<a class="master" href="{row["master_url"]}" target="_blank">查看{row["color"]}碗实拍母版 ↗</a>')
            else:
                parts.append(f'<small>{row["color"]}碗实拍母版准备中</small>')
            for title,reason in row['rejections']:
                parts.append(f'<p class="reject"><strong>{escape(title)}</strong><br>{escape(reason)}</p>')
            for url,label in media:
                old=row['legacy'] and '原生双参考' not in label
                style=' style="color:#7a807c"' if old else ''
                name=('旧样 · ' if old else '')+label
                parts.append(f'<a href="{url}"{style} target="_blank">{escape(name)} ↗</a>')
            parts.append('</div></div></article>')
        parts.append('</div></section>')
    for url in files:
        if url.startswith('/asset/zip-'):
            label='三店全部' if url.endswith('all') else url[-1]+' 店五张'
            parts.append(f'<a class="pack" href="{url}">下载{label}</a>')
    return ''.join(parts)


def page():
    gallery=delivered_gallery()
    if gallery is not None:
        return f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>三店商品主图 · 商品放大版</title><style>{CSS}</style><main><header><small class="live">w1125 ／ 商品放大版</small><h1>三店商品主图</h1><p>三店各五张 · 800 × 800 · 点击单张图片查看原图</p></header>{final_board(gallery)}</main></html>'''
    return f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>三店主图 · 实时进度</title><style>{CSS}</style><main><header><small class="live">商品摄影 ／ 制作进度</small><h1>三店主图工作台</h1><p>双耳粥碗 · 每店五张 · 点击照片查看原图</p></header><div id="board">{board()}</div><footer><small>完整预览按菜品计数。配菜底图先显示空碗，后续加入食物；通过排版终审的图片进入「已审核主图」。</small></footer></main><script>
const refresh=async()=>{{try{{const r=await fetch('/live',{{cache:'no-store'}});if(!r.ok)throw new Error();document.querySelector('#board').innerHTML=await r.text();if(document.querySelector('#delivery-final'))location.reload();}}catch{{const n=document.querySelector('#net');if(n)n.textContent='刷新中断，保留上次画面';}}finally{{setTimeout(refresh,8000);}}}};setTimeout(refresh,8000);
</script></html>'''


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.headers.get('Host') not in (f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}'):
            self.send_error(HTTPStatus.FORBIDDEN)
            return
        path=urlsplit(self.path).path
        if path in ['/','/live']:
            data=(page() if path=='/' else board()).encode()
            self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
        if path.startswith('/asset/'):
            gallery=delivered_gallery()
            if gallery is None:
                _,files,_=inspect()
                allowed=BASE
            else:
                _,files=gallery
                allowed=CLOSEUP
            target=files.get(path)
            if target and target.is_file() and target.resolve().is_relative_to(allowed.resolve()):
                stat=target.stat()
                etag=f'"{stat.st_size}-{stat.st_mtime_ns}"'
                if self.headers.get('If-None-Match')==etag:
                    self.send_response(304);self.end_headers();return
                self.send_response(200);self.send_header('Content-Type',mimetypes.guess_type(target.name)[0] or 'application/octet-stream')
                self.send_header('Content-Length',str(stat.st_size));self.send_header('ETag',etag)
                if target.suffix=='.zip':
                    from urllib.parse import quote
                    self.send_header('Content-Disposition',"attachment; filename*=UTF-8''"+quote(target.name))
                self.end_headers()
                try:
                    with target.open('rb') as f: shutil.copyfileobj(f,self.wfile)
                except (BrokenPipeError, ConnectionResetError):pass
                return
        self.send_error(HTTPStatus.NOT_FOUND)
    def log_message(self,*args):
        pass

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8190)
    server=ThreadingHTTPServer(('127.0.0.1',p.parse_args().port),Handler)
    server.serve_forever()
