"""Run reviewed, serial ComfyUI background and product stages for any shop list."""

import argparse
import ast
import copy
import fcntl
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
from build_workflows import check_graph, node, ui as make_ui
from comfy_client import ComfyClient, sync_ui
from fission.bridge import equivalent_graph

WORKFLOWS = ROOT / "fission/workflows/商品主图近景/多店铺无字主图"
STEMS = {"background": "01_独立差异化空景", "product": "02_商品双参考与800输出"}
OUTPUTS = {"23": ("result.png", (1024, 1024)), "26": ("result_800.png", (800, 800))}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".partial")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def sha(path):
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def fingerprint(path):
    path = Path(path).resolve(strict=True)
    return {"path": str(path), "sha256": sha(path)}


def slug(value, label):
    require(isinstance(value, str) and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", value),
            f"{label} must be a simple identifier")
    return value


def absolute(value, label):
    require(isinstance(value, str) and Path(value).is_absolute(), f"{label} must be an absolute path")
    return Path(value).resolve()


def prompt_text(config, name):
    require((name in config) != (name + "_file" in config), f"Provide exactly one of {name} or {name}_file")
    value = config.get(name)
    if name + "_file" in config:
        value = absolute(config[name + "_file"], name + "_file").read_text(encoding="utf-8")
    require(isinstance(value, str) and len(value.strip()) >= 20, f"{name} must contain a detailed prompt")
    return value.strip()


def image_size(path, formats=("PNG",)):
    with Image.open(path) as image:
        require(image.format in formats and image.mode in ("RGB", "RGBA") and getattr(image, "n_frames", 1) == 1,
                f"Use an existing normalized RGB/RGBA image in {formats}: {path}")
        require(image.getexif().get(274, 1) == 1, f"Reference orientation must already be normalized: {path}")
        size = image.size
        image.load()
    return size


def crop_rectangle(value, size, label, square=False):
    rectangle = value if value is not None else [0, 0, *size]
    require(isinstance(rectangle, list) and len(rectangle) == 4 and all(type(n) is int for n in rectangle),
            f"{label} uses integer [x, y, width, height]")
    x, y, width, height = rectangle
    require(x >= 0 and y >= 0 and width > 0 and height > 0 and x + width <= size[0] and y + height <= size[1],
            f"{label} lies outside the source image")
    require(not square or width == height, f"{label} must stay square for the 800 output")
    return rectangle


def product_board(row, graph):
    sources = row.get("products")
    if sources is None:
        sources = [{"path": row.get("product"), "crop_xywh": row.get("product_crop_xywh")}]
    require(isinstance(sources, list) and 1 <= len(sources) <= 4, "Provide one to four real product photographs")
    files, loaders, crops, tiles = [], [], [], []
    for index, source in enumerate(sources):
        source = {"path": source} if isinstance(source, str) else source
        require(isinstance(source, dict), "Product references use paths or {path, crop_xywh}")
        path = absolute(source.get("path"), "product")
        crop = crop_rectangle(source.get("crop_xywh"), image_size(path, ("PNG", "JPEG")), "product reference crop")
        loader, crop_node, scale_node = ("2", "27", "29") if index == 0 else tuple(str(30 + (index - 1) * 3 + n) for n in range(3))
        graph[loader] = node("LoadImage", f"商品实拍 {index + 1} · 器型与颜色", image=path.name)
        graph[crop_node] = node("ImageCrop", f"实拍 {index + 1} · 身份区域取景", image=[loader, 0],
                                x=crop[0], y=crop[1], width=crop[2], height=crop[3])
        if len(sources) == 1:
            tiles.append((crop_node, crop[2], crop[3]))
        else:
            width = max(16, round(512 * crop[2] / crop[3] / 16) * 16)
            require(width <= 4096, "Product identity crop is too wide; select a tighter real-photo crop")
            graph[scale_node] = node("ImageScale", f"实拍 {index + 1} · 等比缩放", image=[crop_node, 0],
                                     upscale_method="lanczos", width=width, height=512, crop="disabled")
            tiles.append((scale_node, width, 512))
        files.append(fingerprint(path))
        loaders.append(loader)
        crops.append(crop)
    board = tiles[0]
    stitch_id = 45
    def stitch(first, second, direction):
        nonlocal stitch_id
        identifier = str(stitch_id)
        stitch_id += 1
        graph[identifier] = node("ImageStitch", "商品身份参考板 · 仅拼实拍", image1=[first[0], 0], image2=[second[0], 0],
                                 direction=direction, match_image_size=True, spacing_width=16, spacing_color="white")
        if direction == "right":
            return identifier, first[1] + int(first[2] * second[1] / second[2]) + 16, first[2]
        return identifier, first[1], first[2] + int(first[1] * second[2] / second[1]) + 16
    if len(tiles) == 4:
        board = stitch(stitch(tiles[0], tiles[1], "right"), stitch(tiles[2], tiles[3], "right"), "down")
    else:
        for tile in tiles[1:]:
            board = stitch(board, tile, "right")
    factor = 1024 / max(board[1:])
    size = [max(16, round(value * factor / 16) * 16) for value in board[1:]]
    graph["7"]["inputs"].update(image=[board[0], 0], width=size[0], height=size[1])
    return files, loaders, crops, size


def reference_long_edge(value, label):
    require(type(value) is int and 256 <= value <= 1536 and value % 16 == 0,
            f"{label} must be a multiple of 16 between 256 and 1536")
    return value


def reference_size(size, long_edge):
    factor = long_edge / max(size)
    return [max(16, round(value * factor / 16) * 16) for value in size]


def independent_products(row, graph):
    sources = row.get("products")
    if sources is None:
        sources = [{"path": row.get("product"), "crop_xywh": row.get("product_crop_xywh")}]
    require(isinstance(sources, list) and 1 <= len(sources) <= 6, "Provide one to six real product photographs")
    files, loaders, crops, references = [], [], [], []
    for index, source in enumerate(sources):
        source = {"path": source} if isinstance(source, str) else source
        require(isinstance(source, dict), "Product references use paths or {path, crop_xywh}")
        path = absolute(source.get("path"), "product")
        crop = crop_rectangle(source.get("crop_xywh"), image_size(path, ("PNG", "JPEG")), "product reference crop")
        edge = reference_long_edge(source.get("reference_long_edge", 1024), "reference_long_edge")
        size = reference_size(crop[2:], edge)
        if index == 0:
            loader, crop_node, scale_node, latent_node, save_node = "2", "27", "7", "11", "28"
            filename = "product_reference.png"
        elif index < 4:
            loader, crop_node, scale_node = (str(30 + (index - 1) * 3 + n) for n in range(3))
            latent_node, save_node = str(69 + index), str(72 + index)
            filename = f"product_reference_{index + 1:02d}.png"
        else:
            loader, crop_node, scale_node, latent_node, save_node = (str(200 + (index - 4) * 5 + n) for n in range(5))
            filename = f"product_reference_{index + 1:02d}.png"
        graph[loader] = node("LoadImage", f"商品独立实拍 {index + 1}", image=path.name)
        graph[crop_node] = node("ImageCrop", f"商品 {index + 1} · 实拍取景", image=[loader, 0],
                                x=crop[0], y=crop[1], width=crop[2], height=crop[3])
        graph[scale_node] = node("ImageScale", f"商品 {index + 1} · 独立归一化", image=[crop_node, 0],
                                 upscale_method="lanczos", width=size[0], height=size[1], crop="disabled")
        graph[latent_node] = node("VAEEncode", f"商品 {index + 1} · 独立编码", pixels=[scale_node, 0], vae=["5", 0])
        graph[save_node] = node("SaveImage", f"保存 · 实际商品参考 {index + 1}", images=[scale_node, 0],
                                filename_prefix="product_closeup/multishop/" + Path(filename).stem)
        files.append(fingerprint(path))
        loaders.append(loader)
        crops.append(crop)
        references.append(dict(product_index=index, loader_node=loader, crop_node=crop_node,
                               scale_node=scale_node, latent_node=latent_node, save_node=save_node,
                               filename=filename, size=size, reference_long_edge=edge))
    return files, loaders, crops, references


def wire_independent_references(graph, references, order, composition=None):
    scene = dict(role="scene", latent_node="10")
    products = [dict(role="product", product_index=ref["product_index"], latent_node=ref["latent_node"])
                for ref in references]
    sequence = products + [scene] if order == "product_first" else [scene] + products
    if composition is not None:
        sequence.append(dict(role="composition", latent_node=composition["latent_node"]))
    positive, negative = ["8", 0], ["9", 0]
    for index, reference in enumerate(sequence):
        pos, neg = (("12", "13"), ("14", "15"))[index] if index < 2 else (str(72 + index * 2), str(73 + index * 2))
        label = "已审场景" if reference["role"] == "scene" else ("构图参考" if reference["role"] == "composition" else f"商品实拍 {reference['product_index'] + 1}")
        for identifier, conditioning, polarity in ((pos, positive, "正向"), (neg, negative, "负向")):
            graph[identifier] = node("ReferenceLatent", f"{polarity}参考 {index + 1} · {label}",
                                     conditioning=conditioning, latent=[reference["latent_node"], 0])
        reference.update(reference_index=index + 1, positive_node=pos, negative_node=neg)
        graph[reference["latent_node"]]["_meta"]["title"] = f"参考 {index + 1} · {label}编码"
        loader = "1" if reference["role"] == "scene" else (composition["loader_node"] if reference["role"] == "composition" else references[reference["product_index"]]["loader_node"])
        graph[loader]["_meta"]["title"] = f"参考 {index + 1} · {label}"
        positive, negative = [pos, 0], [neg, 0]
    graph["16"]["inputs"].update(positive=positive, negative=negative)
    return sequence


def saved_outputs(identity):
    saved = dict(OUTPUTS)
    if identity["stage"] == "product":
        if identity.get("product_reference_mode") == "independent":
            for ref in identity["product_references"]:
                require(ref["save_node"] not in saved, "Duplicate reference output node")
                saved[ref["save_node"]] = (ref["filename"], tuple(ref["size"]))
        else:
            saved["28"] = ("product_reference.png", tuple(identity["product_reference_size"]))
    if "scene_reference_size" in identity:
        require("61" not in saved, "Duplicate scene output node")
        saved["61"] = ("scene_reference.png", tuple(identity["scene_reference_size"]))
    if "composition_reference" in identity:
        ref = identity["composition_reference"]
        saved[ref["save_node"]] = (ref["filename"], tuple(ref["size"]))
    if "refinement" in identity:
        saved["115"] = ("result_initial.png", tuple(identity["size"]))
    require(len({item[0] for item in saved.values()}) == len(saved), "Duplicate reference output filename")
    return saved


def refinement_sigmas():
    """Evaluate the installed Flux2 schedule on CPU without importing its backend."""
    import torch
    from fission.__main__ import PYTHON
    source = PYTHON.parent.parent.parent / "comfy_extras/nodes_flux.py"
    tree = ast.parse(source.read_text(encoding="utf-8"))
    names = {"generalized_time_snr_shift", "compute_empirical_mu", "get_schedule"}
    definitions = [item for item in tree.body if isinstance(item, ast.FunctionDef) and item.name in names]
    require({item.name for item in definitions} == names, "Installed Flux2 scheduler needs review")
    namespace = {"torch": torch, "math": math}
    module = ast.Module(body=definitions, type_ignores=[])
    with torch.device("cpu"):
        exec(compile(module, str(source), "exec"), namespace)
        sigmas = namespace["get_schedule"](96, 4096)[94:].tolist()
    require(len(sigmas) == 3 and all(math.isfinite(value) for value in sigmas)
            and 0 < sigmas[1] < sigmas[0] <= 0.15 and sigmas[2] == 0,
            "Installed Flux2 tail exceeds the low-strength refinement preset")
    return sigmas, fingerprint(source)


def add_refinement(config, identity, graph):
    require(isinstance(config, dict) and set(config) == {"preset", "seed"},
            "refinement requires exactly preset and seed")
    require(config["preset"] == "flux2_tail2_96", "Only refinement preset flux2_tail2_96 is supported")
    seed = config["seed"]
    require(type(seed) is int and 0 <= seed < 2**64 and seed != identity["seed"],
            "Refinement seed must be a uint64 distinct from the initial seed")
    require(identity["stage"] == "product" and identity["size"] == [1024, 1024],
            "Refinement supports the 1024 product stage only")
    require(not set(str(value) for value in range(110, 116)).intersection(graph), "Refinement node ids are in use")
    sigmas, scheduler_source = refinement_sigmas()
    graph["110"] = node("Flux2Scheduler", "细化调度 · 96区间仅取末2步", steps=96, width=1024, height=1024)
    graph["111"] = node("SplitSigmas", "低强度尾段 · 起点约0.1096", sigmas=["110", 0], step=94)
    graph["112"] = node("RandomNoise", "细化独立种子", noise_seed=seed)
    graph["113"] = node("SamplerCustomAdvanced", "原生latent细化 · 仅2步", noise=["112", 0],
                         guider=["16", 0], sampler=["20", 0], sigmas=["111", 1], latent_image=["21", 0])
    graph["114"] = node("VAEDecode", "首轮原图解码 · 保留对照", samples=["21", 0], vae=["5", 0])
    graph["115"] = node("SaveImage", "保存 · 未细化首轮原图", images=["114", 0],
                         filename_prefix="product_closeup/multishop/initial")
    graph["22"]["inputs"]["samples"] = ["113", 0]
    graph["22"]["_meta"]["title"] = "细化结果解码"
    graph["23"]["_meta"]["title"] = "保存 · 1024细化结果"
    identity["refinement"] = dict(preset=config["preset"], seed=seed, scheduler_steps=96,
                                  split_step=94, actual_sampling_steps=2, sigmas=sigmas,
                                  scheduler_source=scheduler_source, input_kind="initial_native_latent",
                                  initial_latent_source=["21", 0], refined_latent_source=["113", 0],
                                  initial_image=dict(filename="result_initial.png", save_node="115", decode_node="114"),
                                  final_image=dict(filename="result.png", save_node="23", decode_node="22"),
                                  shared_guider=["16", 0], shared_sampler=["20", 0])
    verify_refinement(identity, graph)


def verify_refinement(identity, graph):
    if "refinement" not in identity:
        return
    record = identity["refinement"]
    require(record["preset"] == "flux2_tail2_96" and record["scheduler_steps"] == 96
            and record["split_step"] == 94 and record["actual_sampling_steps"] == 2,
            "Refinement preset metadata differs")
    sigmas = record["sigmas"]
    require(len(sigmas) == 3 and all(type(value) in (int, float) and math.isfinite(value) for value in sigmas)
            and 0 < sigmas[1] < sigmas[0] <= 0.15 and sigmas[2] == 0,
            "Refinement sigma record differs from the low-strength tail")
    expected = {
        "110": ("Flux2Scheduler", dict(steps=96, width=1024, height=1024)),
        "111": ("SplitSigmas", dict(sigmas=["110", 0], step=94)),
        "112": ("RandomNoise", dict(noise_seed=record["seed"])),
        "113": ("SamplerCustomAdvanced", dict(noise=["112", 0], guider=["16", 0], sampler=["20", 0],
                                               sigmas=["111", 1], latent_image=["21", 0])),
        "114": ("VAEDecode", dict(samples=["21", 0], vae=["5", 0])),
    }
    for identifier, (kind, inputs) in expected.items():
        require(graph[identifier]["class_type"] == kind and graph[identifier]["inputs"] == inputs,
                f"Refinement node {identifier} differs from its recorded source")
    require(graph["21"]["class_type"] == "SamplerCustomAdvanced"
            and graph["21"]["inputs"]["guider"] == record["shared_guider"] == ["16", 0]
            and graph["21"]["inputs"]["sampler"] == record["shared_sampler"] == ["20", 0]
            and record["initial_latent_source"] == ["21", 0] and record["refined_latent_source"] == ["113", 0]
            and graph["22"]["inputs"]["samples"] == ["113", 0], "Refinement latent provenance differs")
    require(record["initial_image"] == dict(filename="result_initial.png", save_node="115", decode_node="114")
            and record["final_image"] == dict(filename="result.png", save_node="23", decode_node="22")
            and graph["115"]["class_type"] == "SaveImage" and graph["115"]["inputs"]["images"] == ["114", 0]
            and graph["23"]["inputs"]["images"] == ["22", 0], "Refinement image provenance differs")


def verify_independent_references(identity, graph):
    if identity.get("product_reference_mode") != "independent":
        return
    refs = identity["product_references"]
    require(isinstance(refs, list) and 1 <= len(refs) <= 6, "Independent product reference manifest is missing")
    require(len(refs) + 1 + (1 if "composition_reference" in identity else 0) == len(identity["files"]) == len(identity["reference_loaders"]),
            "Independent reference sources differ from the manifest")
    expected = []
    for index, ref in enumerate(refs):
        require(ref["product_index"] == index and ref["loader_node"] == identity["reference_loaders"][index + 1],
                "Independent product reference order differs")
        crop = graph[ref["crop_node"]]
        require(crop["class_type"] == "ImageCrop" and crop["inputs"]["image"] == [ref["loader_node"], 0]
                and [crop["inputs"][key] for key in ("x", "y", "width", "height")] == identity["product_crops_xywh"][index],
                "Independent product crop differs")
        scale = graph[ref["scale_node"]]
        require(scale["class_type"] == "ImageScale" and scale["inputs"]["image"] == [ref["crop_node"], 0]
                and [scale["inputs"][key] for key in ("width", "height")] == ref["size"],
                "Independent product reference size differs")
        latent = graph[ref["latent_node"]]
        require(latent["class_type"] == "VAEEncode" and latent["inputs"]["pixels"] == [ref["scale_node"], 0]
                and latent["inputs"]["vae"] == ["5", 0], "Independent product encoding differs")
        save = graph[ref["save_node"]]
        require(save["class_type"] == "SaveImage" and save["inputs"]["images"] == [ref["scale_node"], 0],
                "Saved independent reference differs from the encoded image")
        expected.append(("product", index, ref["latent_node"]))
    scene = ("scene", None, "10")
    expected = expected + [scene] if identity.get("reference_order") == "product_first" else [scene] + expected
    if "composition_reference" in identity:
        comp = identity["composition_reference"]
        require(identity["reference_loaders"][-1] == comp["loader_node"], "Composition loader mismatch")
        require(graph[comp["crop_node"]]["inputs"]["image"] == [comp["loader_node"], 0] and [graph[comp["crop_node"]]["inputs"][k] for k in ("x", "y", "width", "height")] == comp["crop_xywh"], "Composition crop mismatch")
        require(graph[comp["scale_node"]]["inputs"]["image"] == [comp["crop_node"], 0] and [graph[comp["scale_node"]]["inputs"][k] for k in ("width", "height")] == comp["size"], "Composition scale mismatch")
        require(graph[comp["latent_node"]]["inputs"]["pixels"] == [comp["scale_node"], 0] and graph[comp["save_node"]]["inputs"]["images"] == [comp["scale_node"], 0], "Composition encoding mismatch")
        expected.append(("composition", None, comp["latent_node"]))
    sequence = identity["reference_sequence"]
    require([(ref["role"], ref.get("product_index"), ref["latent_node"]) for ref in sequence] == expected,
            "Reference sequence differs from the source manifest")
    previous = {"positive": ["8", 0], "negative": ["9", 0]}
    for index, ref in enumerate(sequence):
        require(ref["reference_index"] == index + 1, "Reference sequence index differs")
        for polarity in previous:
            identifier = ref[polarity + "_node"]
            item = graph[identifier]
            require(item["class_type"] == "ReferenceLatent" and item["inputs"]["latent"] == [ref["latent_node"], 0]
                    and item["inputs"]["conditioning"] == previous[polarity], "Independent conditioning chain differs")
            previous[polarity] = [identifier, 0]
    require(all(graph["16"]["inputs"][key] == value for key, value in previous.items()),
            "Independent references do not reach the sampler")


def load_plan(path, selected):
    plan = read(path)
    require(plan.get("version") == 1 and isinstance(plan.get("rows"), list), "Expected plan version 1 and rows")
    root = absolute(plan.get("run_root"), "run_root")
    require(root != ROOT and root != Path("/"), "Use a dedicated run_root")
    seen = set()
    for row in plan["rows"]:
        identifier = slug(row.get("id"), "row id")
        require(identifier not in seen, f"Duplicate image id: {identifier}")
        seen.add(identifier)
        require(all(isinstance(row.get(key), str) and row[key].strip() for key in ("shop", "sku")),
                f"{identifier}: shop and sku are required")
    if selected:
        require(set(selected) <= seen, "Requested ids are absent from the plan")
    rows = [row for row in plan["rows"] if not selected or row["id"] in selected]
    require(rows, "The selected row list is empty")
    return plan, root, rows


def completed(out, identity, graph):
    result = read(out / "result.json")
    receipt = read(out / "submission.json")
    history = read(out / "history.json")
    require(read(out / "identity.json") == identity, "Completed run identity differs")
    require(result["prompt_id"] == receipt["prompt_id"] == history["prompt"][1], "Completed run receipt differs")
    require(receipt["request"]["prompt"] == graph and equivalent_graph(graph, history["prompt"][2]), "Completed run graph differs")
    require(history["status"]["status_str"] == "success", "ComfyUI history is incomplete")
    require(result["identity_sha256"] == sha(out / "identity.json"), "Completed identity checksum differs")
    verify_independent_references(identity, graph)
    verify_refinement(identity, graph)
    for name, size in saved_outputs(identity).values():
        path = out / name
        require(result["outputs"][name]["path"] == str(path) and result["outputs"][name]["sha256"] == sha(path),
                f"Completed output checksum differs: {name}")
        require(image_size(path) == size, f"Unexpected output size: {name}")
    return result


def approved_background(out):
    identity = read(out / "identity.json")
    require(identity["stage"] == "background", "Scene reference must come from the background stage")
    result = completed(out, identity, read(out / "workflow.api.json"))
    review_path = out / "background_review.json"
    review = read(review_path)
    require(review.get("status") == "passed", "Background awaits visual approval")
    require(review.get("image_sha256") == sha(out / "result.png") == result["outputs"]["result.png"]["sha256"],
            "Background approval belongs to a different image")
    require(review.get("identity_sha256") == sha(out / "identity.json"), "Background approval belongs to another generation")
    require(review.get("reference_sources") == identity["reference_sources"], "Background reference comparison record differs")
    require(isinstance(review.get("reviewer"), str) and review["reviewer"].strip(), "Background reviewer is missing")
    require(isinstance(review.get("notes"), str) and len(review["notes"].strip()) >= 16, "Background visual notes are missing")
    for source in identity["reference_sources"]:
        require(sha(source["path"]) == source["sha256"], "A background comparison source has changed")
    return {"review": fingerprint(review_path), "image": fingerprint(out / "result.png"),
            "identity": fingerprint(out / "identity.json")}


def validate_measurements(value):
    require(isinstance(value, dict), "product_measurements must be an object")
    require(value.get("status") == "verified", "product_measurements status must be verified")
    require(value.get("unit") in ("cm", "mm"), "product_measurements unit must be cm or mm")
    require(isinstance(value.get("source"), str) and bool(value["source"].strip()),
            "product_measurements source must identify the original measurement source")
    for key in ("length", "width", "height"):
        number = value.get(key)
        require(type(number) in (int, float) and math.isfinite(number) and number > 0,
                f"product_measurements {key} must be a finite positive physical measurement")
    if "depth" in value:
        number = value["depth"]
        require(type(number) in (int, float) and math.isfinite(number) and number > 0,
                "product_measurements depth must be a finite positive physical measurement")
    return copy.deepcopy(value)


def prepare(plan, row, stage, version, background_version, root, schema):
    config = row["background" if stage == "background" else "product_generation"]
    settings = {**plan.get("defaults", {}), **config}
    cfg = settings.get("cfg", 1.3)
    steps = settings.get("steps", 4)
    seed = config.get("seed")
    require(type(cfg) in (float, int) and math.isfinite(cfg) and 1.01 <= cfg <= 5.0,
            "CFG must be 1.01 to 5 so the connected negative conditioning contributes")
    require(type(steps) is int and 1 <= steps <= 50, "steps must be an integer from 1 to 50")
    require(type(seed) is int and 0 <= seed < 2**64, "seed must be a uint64 integer")
    stem = WORKFLOWS / STEMS[stage]
    api_path = stem.with_suffix(".api.json")
    ui_path = stem.with_suffix(".ui.json")
    graph = read(api_path)
    visual = read(ui_path)
    positive, negative = prompt_text(config, "positive"), prompt_text(config, "negative")
    graph["8"]["inputs"]["text"] = positive
    graph["9"]["inputs"]["text"] = negative
    graph["16"]["inputs"]["cfg"] = float(cfg)
    graph["18"]["inputs"]["steps"] = steps
    graph["19"]["inputs"]["noise_seed"] = seed
    crop = crop_rectangle(config.get("crop_xywh"), (1024, 1024), "output crop", square=True)
    graph["24"]["inputs"].update(zip(("x", "y", "width", "height"), crop))
    out = root / row["id"] / stage / version
    identity = {"schema_version": 1, "stage": stage, "id": row["id"], "shop": row["shop"],
                "sku": row["sku"], "color": row.get("color"), "theme": row.get("theme"),
                "layout_kind": row.get("layout_kind"), "version": version,
                "template": fingerprint(api_path), "ui_template": fingerprint(ui_path),
                "positive": positive, "negative": negative, "cfg": float(cfg), "steps": steps,
                "seed": seed, "size": [1024, 1024], "output_crop_xywh": crop,
                "negative_conditioning": "CLIPTextEncode connected to CFGGuider; CFG exceeds 1",
                "sampler_note": "CFG1.3 is an experimental distilled-model setting; visual QA required",
                "files": []}
    if stage == "product":
        measurements = row.get("product_measurements", plan.get("product_measurements"))
        if "product_measurements" in row or "product_measurements" in plan:
            measurements = validate_measurements(measurements)
            # Preserve historical identities when reconnecting or verifying their receipts.
            identity_path = out / "identity.json"
            legacy = ((out / "submission.json").exists() and identity_path.exists()
                      and "product_measurements" not in read(identity_path))
            if not legacy:
                identity["product_measurements"] = measurements
    if stage == "background":
        sources = config.get("reference_sources", [])
        require(isinstance(sources, list) and sources, "List reference_sources for the background difference review")
        identity["reference_sources"] = [fingerprint(absolute(path, "reference_source")) for path in sources]
        require(isinstance(config.get("design_notes"), str) and config["design_notes"].strip(), "Background design_notes required")
        identity["design_notes"] = config["design_notes"]
    else:
        reference_order = config.get("reference_order", "scene_first")
        require(reference_order in ("scene_first", "product_first"),
                "reference_order must be scene_first or product_first")
        reference_mode = config.get("product_reference_mode", "board")
        require(reference_mode in ("board", "independent"), "product_reference_mode must be board or independent")
        scene_edge = reference_long_edge(config.get("scene_reference_long_edge", 1024), "scene_reference_long_edge")
        background = root / row["id"] / "background" / background_version
        approval = approved_background(background)
        scene = Path(approval["image"]["path"])
        if reference_mode == "independent":
            products, loaders, crops, references = independent_products(row, graph)
            board_size = references[0]["size"]
            identity.update(product_reference_mode=reference_mode, product_references=references,
                            scene_reference_long_edge=scene_edge)
        else:
            products, loaders, crops, board_size = product_board(row, graph)
        graph["1"]["inputs"]["image"] = scene.name
        identity.update(files=[fingerprint(scene), *products], reference_loaders=["1", *loaders],
                        background_approval=approval, product_crops_xywh=crops, product_reference_size=board_size,
                        product_sources=copy.deepcopy(row.get("product_sources", [])))
        if "scene_crop_xywh" in config:
            scene_crop = crop_rectangle(config["scene_crop_xywh"], image_size(scene), "scene reference crop")
            scene_size = reference_size(scene_crop[2:], scene_edge)
            graph["60"] = node("ImageCrop", "已审空景取景 · 压缩环境占比", image=["1", 0],
                               x=scene_crop[0], y=scene_crop[1], width=scene_crop[2], height=scene_crop[3])
            graph["6"]["inputs"].update(image=["60", 0], width=scene_size[0], height=scene_size[1])
            graph["61"] = node("SaveImage", "保存 · 实际采用的空景参考", images=["6", 0],
                               filename_prefix="product_closeup/multishop/scene_reference")
            identity.update(scene_crop_xywh=scene_crop, scene_reference_size=scene_size)
        elif reference_mode == "independent" or scene_edge != 1024:
            scene_size = reference_size(image_size(scene), scene_edge)
            graph["6"]["inputs"].update(width=scene_size[0], height=scene_size[1])
            graph["61"] = node("SaveImage", "保存 · 实际采用的空景参考", images=["6", 0],
                               filename_prefix="product_closeup/multishop/scene_reference")
            identity["scene_reference_size"] = scene_size
        if reference_mode == "independent":
            if reference_order == "product_first":
                identity["reference_order"] = reference_order
            composition = None
            if "composition_reference" in row:
                spec = row["composition_reference"]
                require(isinstance(spec, dict), "composition_reference must be an object")
                path = absolute(spec.get("path"), "composition_reference")
                crop = crop_rectangle(spec.get("crop_xywh"), image_size(path, ("PNG", "JPEG")), "composition reference crop")
                edge = reference_long_edge(spec.get("reference_long_edge", 1024), "composition reference long edge")
                size = reference_size(crop[2:], edge)
                composition = dict(loader_node="150", crop_node="151", scale_node="152", latent_node="153", save_node="154", filename="composition_reference.png", crop_xywh=crop, size=size, reference_long_edge=edge)
                graph["150"] = node("LoadImage", "构图参考", image=path.name)
                graph["151"] = node("ImageCrop", "构图参考取景", image=["150", 0], x=crop[0], y=crop[1], width=crop[2], height=crop[3])
                graph["152"] = node("ImageScale", "构图参考等比缩放", image=["151", 0], upscale_method="lanczos", width=size[0], height=size[1], crop="disabled")
                graph["153"] = node("VAEEncode", "构图参考编码", pixels=["152", 0], vae=["5", 0])
                graph["154"] = node("SaveImage", "保存构图参考", images=["152", 0], filename_prefix="product_closeup/multishop/composition_reference")
                identity["composition_reference"] = composition
                identity["files"].append(fingerprint(path))
                identity["reference_loaders"].append("150")
            identity["reference_sequence"] = wire_independent_references(graph, references, reference_order, composition)
            verify_independent_references(identity, graph)
        elif reference_order == "product_first":
            # Preserve historical default identities while recording the opt-in order.
            identity["reference_order"] = reference_order
            for identifiers, latent, title in (
                (("12", "13"), "11", "参考一 · 商品实拍"),
                (("14", "15"), "10", "参考二 · 已审场景"),
            ):
                for identifier, polarity in zip(identifiers, ("正向", "负向")):
                    graph[identifier]["inputs"]["latent"] = [latent, 0]
                    graph[identifier]["_meta"]["title"] = f"{polarity}{title}"
            graph["1"]["_meta"]["title"] = "参考二 · 审核通过的新空景"
            graph["6"]["_meta"]["title"] = "参考二 · 场景等比缩放"
            graph["10"]["_meta"]["title"] = "参考二 · 场景编码"
            graph["7"]["_meta"]["title"] = "参考一 · 商品身份等比归一化"
            graph["11"]["_meta"]["title"] = "参考一 · 商品身份编码"
            for index, loader in enumerate(loaders, 1):
                graph[loader]["_meta"]["title"] = f"参考一 · 商品实拍 {index}"
    if "refinement" in config:
        require(stage == "product", "Refinement is a product-only option")
        add_refinement(config["refinement"], identity, graph)
    token = hashlib.sha256(json.dumps(identity, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]
    prefix = f"product_closeup/multishop/{row['id']}/{stage}_{version}_{token}"
    graph["23"]["inputs"]["filename_prefix"] = prefix + "_1024"
    graph["26"]["inputs"]["filename_prefix"] = prefix + "_800"
    if stage == "product":
        graph["28"]["inputs"]["filename_prefix"] = prefix + "_product_reference"
        if "61" in graph:
            graph["61"]["inputs"]["filename_prefix"] = prefix + "_scene_reference"
        if "composition_reference" in identity:
            graph["154"]["inputs"]["filename_prefix"] = prefix + "_composition_reference"
        if "refinement" in identity:
            graph["115"]["inputs"]["filename_prefix"] = prefix + "_initial_1024"
        if reference_mode == "independent":
            for ref in identity["product_references"]:
                graph[ref["save_node"]]["inputs"]["filename_prefix"] = prefix + "_" + Path(ref["filename"]).stem
            reference_note = "每张实拍独立编码，参考顺序见节点标题及 reference_sequence。实际输入逐张保存。"
        else:
            reference_note = ("参考一为商品实拍，参考二为审核通过的新空景。"
                              if reference_order == "product_first" else
                              "先审核差异化空景，再输入实拍身份参考。")
        visual = make_ui(graph, schema, "多店铺原生独立多参考" if reference_mode == "independent" else "多店铺原生双参考",
                         reference_note + "主盘占宽约八成。CFG > 1 激活负条件，画质逐张验收。"
                         + ("保留未细化原图，低强度尾段仅采样2步；细化前后分别审核。" if "refinement" in identity else ""))
        if "refinement" in identity:
            visual["last_node_id"] = max(item["id"] for item in visual["nodes"])
    timeout = settings.get("timeout_seconds", 3600)
    require(type(timeout) is int and timeout >= 60, "timeout_seconds must be at least 60")
    return out, identity, graph, visual, timeout


def run_stage(client, schema, prepared, check_only):
    out, identity, graph, visual, timeout = prepared
    if identity["stage"] == "product":
        approval = approved_background(Path(identity["files"][0]["path"]).parent)
        require(approval == identity["background_approval"], "Background review changed after preflight")
    check_graph(graph, schema)
    visual = sync_ui(graph, visual, schema)
    if check_only:
        return {"id": identity["id"], "stage": identity["stage"], "status": "checked_without_upload_or_submission",
                "cfg": identity["cfg"], "output": str(out)}
    out.mkdir(parents=True, exist_ok=True)
    identity_path = out / "identity.json"
    receipt = out / "submission.json"
    if identity_path.exists():
        require(read(identity_path) == identity, "Run parameters changed; select a new --version")
    else:
        require(not receipt.exists() and not (out / "result.json").exists(), "Run identity is missing")
    if receipt.exists():
        stored_graph = read(out / "workflow.api.json")
        expected_graph = copy.deepcopy(graph)
        if identity["stage"] == "product":
            for node_id in identity["reference_loaders"]:
                expected_graph[node_id]["inputs"]["image"] = stored_graph[node_id]["inputs"]["image"]
        require(stored_graph == expected_graph == read(receipt)["request"]["prompt"], "Stored graph differs from this task")
        graph = stored_graph
        if (out / "result.json").exists():
            completed(out, identity, graph)
            return {"id": identity["id"], "stage": identity["stage"], "status": "verified_existing", "output": str(out)}
        task = client.reconcile(receipt)
    else:
        queue = client.get("/queue")
        require(not queue["queue_running"] and not queue["queue_pending"], "ComfyUI has another task; retry this same command later")
        write(identity_path, identity)
        if identity["stage"] == "product":
            for node_id, source in zip(identity["reference_loaders"], identity["files"]):
                require(sha(source["path"]) == source["sha256"], "Reference changed before upload")
                graph[node_id]["inputs"]["image"] = client.upload(source["path"])
        visual = sync_ui(graph, visual, schema)
        write(out / "workflow.api.json", graph)
        write(out / "workflow.ui.json", visual)
        (out / "positive.txt").write_text(identity["positive"] + "\n", encoding="utf-8")
        (out / "negative.txt").write_text(identity["negative"] + "\n", encoding="utf-8")
        task = client.submit(graph, visual, receipt)
    print(json.dumps({"id": identity["id"], "stage": identity["stage"], "prompt_id": task}, ensure_ascii=False), flush=True)
    backend_pid = int(subprocess.check_output(["lsof", "-t", "-nP", "-iTCP:8188", "-sTCP:LISTEN"], text=True).strip())
    history, metrics = client.wait(task, out, backend_pid, timeout=timeout)
    require(equivalent_graph(history["prompt"][2], graph), "ComfyUI history belongs to a different workflow")
    downloads = client.download(history, out / "download")
    outputs = {}
    for node_id, (name, size) in saved_outputs(identity).items():
        require(len(downloads.get(node_id, [])) == 1, f"Expected one saved image from node {node_id}")
        source = Path(downloads[node_id][0])
        require(image_size(source) == size, f"Unexpected ComfyUI output dimensions: {name}")
        temporary = out / (name + ".partial")
        shutil.copyfile(source, temporary)
        os.replace(temporary, out / name)
        outputs[name] = fingerprint(out / name)
    result = {"prompt_id": task, "path": str(out / "result.png"), "sha256": outputs["result.png"]["sha256"],
              "outputs": outputs, "identity_sha256": sha(identity_path),
              "seconds": metrics.get("backend_wall_seconds"), "visual_review": "pending",
              "image_operations": "ComfyUI generation, reference crop/resize, output crop/resize and PNG save"}
    write(out / "result.json", result)
    completed(out, identity, graph)
    return {"id": identity["id"], "stage": identity["stage"], "status": "generated_pending_visual_review", "output": str(out)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--stage", choices=STEMS, required=True)
    parser.add_argument("--id", nargs="+", dest="ids")
    parser.add_argument("--version", default="v01")
    parser.add_argument("--background-version", default="v01")
    parser.add_argument("--check", action="store_true", help="Validate plan and live node schema without uploading or submitting")
    args = parser.parse_args()
    slug(args.version, "version")
    slug(args.background_version, "background version")
    plan, root, rows = load_plan(args.plan, args.ids)
    client = ComfyClient()
    schema = client.get("/object_info")
    # Preflight every selected row before a batch can submit its first image.
    prepared = [prepare(plan, row, args.stage, args.version, args.background_version, root, schema) for row in rows]
    for item in prepared:
        check_graph(item[2], schema)
        sync_ui(item[2], item[3], schema)
    if args.check:
        for item in prepared:
            print(json.dumps(run_stage(client, schema, item, True), ensure_ascii=False), flush=True)
        return
    lock_path = ROOT / "fission/runs/native_gpu.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for item in prepared:
            # A unique client_id per row also disambiguates a POST whose response is lost.
            print(json.dumps(run_stage(ComfyClient(), schema, item, False), ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
