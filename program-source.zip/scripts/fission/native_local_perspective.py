"""Explicit per-image deterministic diagnostics; never infers control points."""
import argparse,fcntl,json,shutil,importlib.util
import torch
from pathlib import Path
import numpy as np
from PIL import Image
from build_workflows import node,check_graph,ui
from comfy_client import ComfyClient
from native_multishop import ROOT,sha,write
from fission.deterministic import run
NODE=Path('/Users/luohuiwu/ComfyUI-Installs/E-commerce image workflow/ComfyUI/custom_nodes/fission_local_perspective/__init__.py')

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--config',type=Path,required=True);p.add_argument('--check',action='store_true');a=p.parse_args()
 src=a.source.resolve(strict=True);out=a.output.resolve();config=json.loads(a.config.read_text());parent=src.parent
 files=['identity.json','result.json','submission.json','history.json']
 evidence={n:json.loads((parent/n).read_text()) for n in files}
 result=evidence['result.json'];history=evidence['history.json'];receipt=evidence['submission.json']
 if result.get('sha256')!=sha(src) or result.get('identity_sha256')!=sha(parent/'identity.json'):raise ValueError('Source or identity hash mismatch')
 if result.get('prompt_id')!=receipt.get('prompt_id') or result['prompt_id']!=history['prompt'][1] or history.get('status',{}).get('status_str')!='success':raise ValueError('Source submission/history mismatch')
 review=result.get('visual_review',{});status=str(review.get('status','') if isinstance(review,dict) else review).lower()
 if 'reject' in status or 'invalid' in status:raise ValueError('Source explicitly rejected; select a valid source')
 crop=config['crop_xywh'];points=config['points'];top=config.get('protected_top',500);maxdisp=config.get('max_displacement',50)
 with Image.open(src) as im:w,h=im.size
 if not (isinstance(crop,list) and len(crop)==4 and all(type(i) is int for i in crop)):raise ValueError('Invalid crop')
 x,y,cw,ch=crop
 if x<0 or y<0 or cw!=ch or cw<=0 or x+cw>w or y+ch>h:raise ValueError('Crop must be square and inside source')
 if not isinstance(points,list):raise ValueError('points must be a list')
 geometry=None
 if points:
  spec=importlib.util.spec_from_file_location('local_perspective_node',NODE);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
  _,_,raw=mod.FissionLocalPerspective().warp(torch.zeros((1,h,w,3)),json.dumps(points),maxdisp,top);geometry=json.loads(raw)
 chain={n:sha(parent/n) for n in files};chain.update(source_sha256=sha(src),source=str(src),source_prompt_id=result['prompt_id'],visual_status=status or 'unreviewed',config_sha256=sha(a.config),node_sha256=sha(NODE))
 c=ComfyClient();info=c.get('/object_info');image=src.name
 def graph(name):
  g={'1':node('LoadImage','已验源图',image=name)};base='1'
  if points:
   g['2']=node('FissionLocalPerspective','逐图明确控制点',image=['1',0],points_json=json.dumps(points,separators=(',',':')),max_displacement=maxdisp,protected_top=top);base='2'
   g['7']=node('SaveImage','位移图',images=['2',1],filename_prefix='fission/local_perspective/displacement')
  g['3']=node('SaveImage','完整图',images=[base,0],filename_prefix='fission/local_perspective/full')
  g['4']=node('ImageCrop','取景',image=[base,0],x=x,y=y,width=cw,height=ch)
  g['5']=node('ImageScale','800',image=['4',0],upscale_method='lanczos',width=800,height=800,crop='disabled')
  g['6']=node('SaveImage','800输出',images=['5',0],filename_prefix='fission/local_perspective/800');return g
 check_graph(graph(image),info)
 if a.check:print(json.dumps({'check':'passed','source_chain':chain},ensure_ascii=False));return
 out.mkdir(parents=True,exist_ok=True)
 with (ROOT/'fission/runs/native_gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('Comfy queue is busy')
  api=graph(c.upload(src));check_graph(api,info);visual=ui(api,info,'逐图局部透视或取景','控制点由审阅人指定。')
  for i,n in enumerate(visual['nodes']):n['pos']=[i*340,0]
  write(out/'workflow.api.json',api);write(out/'workflow.ui.json',visual);write(out/'source_chain.json',chain)
  entry,hit=run(c,api,visual,out,NODE,src)
  for key,name in [('3','result.png'),('6','result_800.png')]+([('7','displacement.png')] if points else []):
   target=out/name;source=Path(entry['files'][key][0]);expected=entry['output_hashes'][str(source)]
   if target.exists() and sha(target)!=expected:raise ValueError('Existing local output differs from cache')
   if not target.exists():shutil.copyfile(source,target)
   if sha(target)!=expected:raise ValueError('Copied output hash mismatch')
  history=entry.get('history');history=json.loads(Path(history).read_text()) if isinstance(history,str) else history
  if history and not (out/'history.json').exists():write(out/'history.json',history)
  origin=Path(entry.get('source') or '')
  if hit and (origin/'submission.json').is_file() and not (out/'submission.json').exists():shutil.copyfile(origin/'submission.json',out/'submission.json')
  before=np.asarray(Image.open(src).convert('RGB'));after=np.asarray(Image.open(out/'result.png').convert('RGB'));diff=np.any(before!=after,axis=2)
  if not points and diff.any():raise ValueError('Pure crop altered source image')
  write(out/'diagnostics.json',{'cache_hit':hit,'prompt_id':entry['prompt_id'],'source_sha256':sha(src),'output_sha256':{name:sha(out/name) for name in ['result.png','result_800.png']},'changed_pixels':int(diff.sum()),'above_protected_top_changed':int(diff[:top+1].sum()),'config':config,'geometry':geometry,'visual_status':'pending','method':'2D diagnostic only; product shape must be visually reviewed'})
  print(json.dumps({'cache_hit':hit,'prompt_id':entry['prompt_id'],'output':str(out)},ensure_ascii=False))
if __name__=='__main__':main()
