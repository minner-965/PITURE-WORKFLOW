"""Make a high-resolution edible surface and project it inside a reviewed physical lip."""

import numpy as np
from PIL import Image
from scipy.ndimage import distance_transform_edt, map_coordinates

from fission.graphs import graph as klein_graph

MASK_NAME = 'food_surface_rim_v2.png'
CROP = (42, 52, 990, 972)


def texture_graph(row, seed, prefix):
    prompt = (
        f"Top-down natural food photography of an authentic serving of {row['name']}. "
        "Tight, edge-to-edge square view of the edible surface, the food extending "
        "past all four edges. The main ingredients are clearly visible in the central "
        "two thirds with realistic scale, natural irregular shapes, side light and moisture. "
        + row['food_prompt']
    )
    config = dict(width=1024, height=1024, reference_size=512, seed=seed, prompt=prompt, job_id='food_surface')
    original = klein_graph(config, 'rim_v2')
    # This is a text-to-image pass: only the cooked food is generated.
    graph = {k: v for k, v in original.items() if k not in {'1','2','6','7','10','11','12','13','14','15'}}
    graph['16']['inputs'].update(positive=['8',0], negative=['9',0])
    graph['23']['inputs']['filename_prefix'] = prefix
    return graph


from fission.ledger import tracked_cpu

@tracked_cpu('layout')
def project(background, mask_path, texture, crop=CROP):
    base = Image.open(background).convert('RGB')
    matte = Image.open(mask_path)
    tex = Image.open(texture).convert('RGB')
    if matte.mode != 'L' or matte.size != base.size or not matte.getbbox():
        raise ValueError('液面蒙版与摄影母版不匹配')
    if tex.size != (1024,1024) or not (0 <= crop[0] < crop[2] <= tex.width and 0 <= crop[1] < crop[3] <= tex.height):
        raise ValueError('纹理图或纹理取样区域无效')
    box = matte.getbbox()
    x0,y0,x1,y1 = box
    yy,xx = np.mgrid[y0:y1,x0:x1]
    u = (xx-x0+.5)/(x1-x0)-.5
    v = (yy-y0+.5)/(y1-y0)
    source_y = 1.11*v/(1+.11*v)
    source_x = .5+u*1.055/(1+.11*v)
    tex = np.asarray(tex.crop(crop))
    coords = [np.clip(source_y,0,1)*(tex.shape[0]-1), np.clip(source_x,0,1)*(tex.shape[1]-1)]
    rgb = np.stack([map_coordinates(channel,coords,order=1,mode='nearest') for channel in tex.transpose(2,0,1)],axis=-1)
    area = np.asarray(matte)>0
    contact = 1.-.105*np.exp(-distance_transform_edt(area)[y0:y1,x0:x1]/5.8)
    layer = Image.fromarray(np.clip(rgb*contact[...,None],0,255).astype('uint8'))
    result = base.copy()
    result.paste(layer,box[:2],matte.crop(box))
    if not np.array_equal(np.asarray(result)[~area],np.asarray(base)[~area]):
        raise ValueError('液面外的实拍像素变化')
    return result
