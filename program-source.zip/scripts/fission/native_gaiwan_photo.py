"""ComfyUI photo-locked six-bowl layout; no sampling in layout stage."""
import argparse,fcntl,json,shutil,subprocess
from pathlib import Path
import numpy as np
from PIL import Image
from build_workflows import node,check_graph,ui
from comfy_client import ComfyClient
from native_multishop import ROOT,sha,read,write,approved_background
from fission.ledger import append
NODE=Path('/Users/luohuiwu/ComfyUI-Installs/E-commerce image workflow/ComfyUI/custom_nodes/fission_photo_lock/__init__.py')
def sample(a):
 if not a.layout_dir: raise ValueError('--layout-dir required')
 source=a.layout_dir.resolve(strict=True);out=a.output.resolve();diag=read(source/'diagnostics.json');chain=read(source/'source_chain.json');history=read(source/'history.json');receipt=read(source/'submission.json')
 if history['status']['status_str']!='success' or history['prompt'][1]!=receipt['prompt_id'] or receipt['prompt_id']!=diag['prompt_id'] or diag['product_overlap_pixels']!=0: raise ValueError('Layout provenance or overlap failed')
 names=['layout.png','scene_reference.png','food_mask.png','shadow_mask.png','product_mask.png','protection_mask.png']
 for n in names:
  if sha(source/n)!=diag['outputs'][n]: raise ValueError('Layout artifact changed: '+n)
 for entry in chain['photos'].values():
  if sha(entry['path'])!=entry['sha256']: raise ValueError('Photo changed')
 if sha(chain['background']['path'])!=chain['background']['sha256']:raise ValueError('Background changed')
 approved_background(Path(chain['background']['path']).parent)
 c=ComfyClient();schema=c.get('/object_info')
 def make(paths):
  g=read(ROOT/'fission/workflows/商品主图近景/多店铺无字主图/02_商品双参考与800输出.api.json')
  for n in ['17','27','28']:g.pop(n,None)
  g['1']['inputs']['image']=paths['layout.png'];g['2']['inputs']['image']=paths['scene_reference.png'];g['7']['inputs'].update(image=['2',0],width=1024,height=1024)
  g['8']['inputs']['text']='Realistic restaurant photograph of six existing open Chinese ingredient bowls. Preserve their exact layout and photographed bodies and plates. Fill the back left red bowl with pale beef meatballs and back right blue bowl with ivory tofu cubes. Fill middle left green bowl with sliced shiitake mushrooms and middle right red bowl with thin lotus root slices with visible holes. Fill front left blue bowl with peeled raw pink shrimp and front right green bowl with thin marbled beef rolls. Each food stays inside its own bowl below the rim, with a narrow visible white interior border. Modest portions, realistic moist surfaces, coherent soft food-contact shadows and gentle grounded shadows below each plate, matching the warm restaurant light.'
  g['9']['inputs']['text']='food outside bowls, altered rims or floral patterns, misplaced ingredients, missing plates, extra dishes, floating food, plastic surfaces, flat stickers, tall heaps, soup, incompatible shadows, excessive shadows, text, blur.'
  g['16']['inputs']['cfg']=1.3;g['18']['inputs']['steps']=4;g['19']['inputs']['noise_seed']=202611052203
  g['40']=node('LoadImageMask','食品许可区',image=paths['food_mask.png'],channel='red');g['41']=node('LoadImageMask','接触阴影许可区',image=paths['shadow_mask.png'],channel='red');g['42']=node('MaskComposite','食品和阴影许可并集',destination=['40',0],source=['41',0],x=0,y=0,operation='add');g['43']=node('MaskToImage','许可区',mask=['42',0]);g['44']=node('ImageBlur','3像素柔边',image=['43',0],blur_radius=3,sigma=1.5);g['45']=node('ImageToMask','柔边遮罩',image=['44',0],channel='red');g['46']=node('MaskComposite','严格限制许可区',destination=['45',0],source=['42',0],x=0,y=0,operation='multiply');g['47']=node('SetLatentNoiseMask','仅许可区采样',samples=['10',0],mask=['46',0]);g['21']['inputs']['latent_image']=['47',0]
  g['48']=node('ImageCompositeMasked','保护像素恢复',destination=['1',0],source=['22',0],mask=['46',0],x=0,y=0,resize_source=False);g['23']['inputs']['images']=['48',0];g['24']['inputs'].update(image=['48',0],x=0,y=0,width=1024,height=1024)
  g['49']=node('SaveImage','原始生成图',images=['22',0],filename_prefix='gaiwan_photo/raw');g['50']=node('MaskToImage','实际有效遮罩',mask=['46',0]);g['51']=node('SaveImage','有效遮罩保存',images=['50',0],filename_prefix='gaiwan_photo/effective_mask');g['52']=node('InvertMask','保护区',mask=['46',0]);g['53']=node('MaskToImage','保护区图片',mask=['52',0]);g['54']=node('SaveImage','保护区保存',images=['53',0],filename_prefix='gaiwan_photo/protection')
  for n in ['23','26']:g[n]['inputs']['filename_prefix']='gaiwan_photo/'+n
  return g
 paths={n:str(source/n) for n in names};g=make(paths);check_graph(g,schema);v=ui(g,schema,'实拍碗局部填食','原图作为初始latent，限制食品与阴影区。')
 if a.check:print(json.dumps({'check':'passed','layout_sha256':sha(source/'layout.png'),'seed':202611052203,'steps':4,'cfg':1.3}));return
 review=read(source/'layout_review.json')
 if review.get('status')!='passed' or review.get('layout_sha256')!=sha(source/'layout.png') or not review.get('reviewer'):raise ValueError('Layout requires root approval bound to its hash')
 out.mkdir(parents=True,exist_ok=True)
 with (ROOT/'fission/runs/native_gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('Comfy queue busy')
  if (out/'submission.json').exists():raise RuntimeError('Existing receipt needs reconciliation')
  paths={n:c.upload(source/n) for n in names};g=make(paths);check_graph(g,schema);v=ui(g,schema,'实拍碗局部填食','原图作为初始latent，限制食品与阴影区。');write(out/'workflow.api.json',g);write(out/'workflow.ui.json',v);write(out/'source_chain.json',{'layout':str(source),'diagnostics_sha256':sha(source/'diagnostics.json'),'review_sha256':sha(source/'layout_review.json'),'input_hashes':{n:sha(source/n) for n in names},'seed':202611052203,'cfg':1.3,'steps':4})
  pid=c.submit(g,v,out/'submission.json');backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());history,metrics=c.wait(pid,out,backend);files=c.download(history,out/'download');outputs={'23':'result.png','26':'result_800.png','49':'raw_generated.png','51':'effective_mask.png','54':'protected_mask.png'}
  for key,n in outputs.items():shutil.copyfile(files[key][0],out/n)
  before=np.asarray(Image.open(source/'layout.png').convert('RGB'));after=np.asarray(Image.open(out/'result.png').convert('RGB'));m=np.asarray(Image.open(out/'effective_mask.png').convert('L'));changed=np.any(before!=after,axis=2);zero=int(np.sum(changed&(m==0)));protected=np.asarray(Image.open(source/'protection_mask.png').convert('L')); protected_changed=int(np.sum(changed&(protected>0)&(m==0)));report={'protected_zero_mask_changed_pixels':protected_changed,'prompt_id':pid,'seconds':metrics.get('backend_wall_seconds'),'changed_pixels':int(changed.sum()),'zero_mask_changed_pixels':zero,'outputs':{n:sha(out/n) for n in outputs.values()},'status':'pending_visual_review'};write(out/'pixel_check.json',report)
  if zero:raise ValueError('Pixels outside effective mask changed: '+str(zero))
  print(json.dumps(report,ensure_ascii=False))

def main():
 p=argparse.ArgumentParser();p.add_argument('--config',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--stage',choices=['layout','sample'],default='layout');p.add_argument('--layout-dir',type=Path);p.add_argument('--check',action='store_true');a=p.parse_args();
 if a.stage=='sample': return sample(a)
 cfg=read(a.config);out=a.output.resolve();bg=Path(cfg['background']).resolve(strict=True);approval=approved_background(bg.parent)
 photos={k:Path(v['path']).resolve(strict=True) for k,v in cfg['photos'].items()}; chain={'background':{'path':str(bg),'sha256':sha(bg),'approval':approval},'photos':{k:{'path':str(v),'sha256':sha(v),'crop_xywh':cfg['photos'][k]['crop_xywh']} for k,v in photos.items()},'background_crop_xywh':[256,256,768,768],'background_scaled_size':[1024,1024],'config_sha256':sha(a.config),'node_sha256':sha(NODE)}
 c=ComfyClient();schema=c.get('/object_info')
 def graph(paths):
  g={'1':node('LoadImage','已审背景',image=paths['background']),'2':node('ImageCrop','背景裁切',image=['1',0],x=256,y=256,width=768,height=768),'3':node('ImageScale','背景等比放大',image=['2',0],upscale_method='lanczos',width=1024,height=1024,crop='disabled')};ids={}
  for j,(k,v) in enumerate(cfg['photos'].items()):
   load=str(10+j*3);crop=str(11+j*3);save=str(12+j*3);x,y,w,h=v['crop_xywh'];g[load]=node('LoadImage',k+'原片',image=paths[k]);g[crop]=node('ImageCrop',k+'实拍裁切',image=[load,0],x=x,y=y,width=w,height=h);g[save]=node('SaveImage',k+'参考留档',images=[crop,0],filename_prefix='gaiwan_photo/'+k);ids[k]=crop
  previous='3'; masks=[]
  for j,item in enumerate(cfg['placements']):
   n=str(100+j); k=item['photo'];v=cfg['photos'][k];conf={'outer_polygon':v['outer_polygon'],'food_polygon':v['food_polygon'],'placements':[{'role':'hero','x':item['x'],'y':item['y'],'width':item['width']}],'shadow_radius':28};g[n]=node('FissionPhotoLock',f'第{j+1}只真实实拍',photo=[ids[k],0],background=[previous,0],layout_json=json.dumps(conf,ensure_ascii=False));previous=n;masks.append(n)
   g[str(200+j)]=node('MaskToImage','单只商品遮罩',mask=[n,1]);g[str(210+j)]=node('SaveImage','单只商品遮罩保存',images=[str(200+j),0],filename_prefix=f'gaiwan_photo/p{j}')
  g['300']=node('SaveImage','六只实拍布局',images=[previous,0],filename_prefix='gaiwan_photo/layout');g['301']=node('SaveImage','实际背景',images=['3',0],filename_prefix='gaiwan_photo/background')
  for idx,name in [(1,'product'),(2,'food'),(3,'protection'),(4,'shadow')]:
   prev=masks[0]; prevslot=idx
   for j,n in enumerate(masks[1:]):
    key=str(400+idx*10+j);g[key]=node('MaskComposite',name+'合并',destination=[prev,prevslot],source=[n,idx],x=0,y=0,operation='add');prev=key;prevslot=0
   if idx==4:
    key='499';g[key]=node('MaskComposite','阴影区剔除商品',destination=[prev,prevslot],source=['414',0],x=0,y=0,operation='subtract');prev=key;prevslot=0
   mid=str(500+idx);sid=str(510+idx);g[mid]=node('MaskToImage',name+'遮罩',mask=[prev,prevslot]);g[sid]=node('SaveImage',name+'保存',images=[mid,0],filename_prefix='gaiwan_photo/'+name)
  return g
 paths={'background':str(bg),**{k:str(v) for k,v in photos.items()}};g=graph(paths);check_graph(g,schema);visual=ui(g,schema,'六件实拍锁定布局','仅实拍裁切缩放和合成，无生成。')
 if a.check:print(json.dumps({'check':'passed','chain':chain},ensure_ascii=False));return
 out.mkdir(parents=True,exist_ok=True)
 with (ROOT/'fission/runs/native_gpu.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);q=c.get('/queue')
  if q['queue_running'] or q['queue_pending']:raise RuntimeError('Comfy queue busy')
  if (out/'submission.json').exists():raise RuntimeError('已有提交回执，须核对后再执行')
  g=graph({k:c.upload(v) for k,v in paths.items()});check_graph(g,schema);visual=ui(g,schema,'六件实拍锁定布局','仅实拍裁切缩放和合成，无生成。');write(out/'workflow.api.json',g);write(out/'workflow.ui.json',visual);write(out/'source_chain.json',chain)
  pid=c._submit_uncached(g,visual,out/'submission.json');backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());history,metrics=c._wait_uncached(pid,out,backend);files=c._download_uncached(history,out/'download')
  names={'300':'layout.png','301':'scene_reference.png','511':'product_mask.png','512':'food_mask.png','513':'protection_mask.png','514':'shadow_mask.png',**{str(210+j):f'product_{j+1}_mask.png' for j in range(6)},**{str(12+j*3):f'reference_{k}.png' for j,k in enumerate(cfg['photos'])}}
  for key,name in names.items():shutil.copyfile(files[key][0],out/name)
  masks=[np.asarray(Image.open(out/f'product_{j+1}_mask.png').convert('L'))>0 for j in range(6)]; overlap=int((np.sum(masks,axis=0)>1).sum());report={'prompt_id':pid,'seconds':metrics.get('backend_wall_seconds'),'product_overlap_pixels':overlap,'outputs':{n:sha(out/n) for n in names.values()},'status':'pending_visual_review'};write(out/'diagnostics.json',report)
  append(dict(type='cpu',task='gaiwan',stage='master/gaiwan-photo',model=None,gpu_seconds=0,cpu_seconds=metrics.get('backend_wall_seconds',0),prompt_id=pid,input_hashes=chain,result_paths=[str(out/n) for n in names.values()],status='success'))
  if overlap:raise ValueError(f'实拍商品重叠 {overlap} 像素：联合遮罩须按可见层处理，暂停审核')
  print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
