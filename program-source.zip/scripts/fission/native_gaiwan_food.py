"""Parameterized bounded food repair; mask preview uses ComfyUI without sampling."""
import argparse, json, math, shutil, subprocess, fcntl
from pathlib import Path
import numpy as np
from PIL import Image
from build_workflows import node,check_graph,ui
from comfy_client import ComfyClient
from native_multishop import ROOT,sha,read,write,completed
POS='Fill ONLY the currently empty blue-and-white bowl at the center of the image with a modest portion of moist peeled shrimp arranged naturally inside its white opening. Pale translucent pink raw shrimp curls, realistic segmented bodies, subtle food-contact shadows. Keep food below the rim and preserve a visible narrow white interior border. Preserve every bowl and matching plate, all printed flowers and characters, all existing foods in the other five bowls, background and lighting.'
NEG='food outside mask, modified bowl rim or printed pattern, floating shrimp, dry plastic shrimp, opaque flat sticker, large tall food heap, soup, altered other food, altered dishes, changed background, extra dishes, text overlay.'
def mask_graph(cx,cy,rx,ry):
 g={'200':node('SolidMask','空白画布',value=0.0,width=1024,height=1024)}; prev='200'; n=201
 # One-pixel horizontal bands form a bounded ellipse, constructed entirely inside ComfyUI.
 for y in range(cy-ry,cy+ry+1):
  dx=int(rx*math.sqrt(max(0,1-((y-cy)/ry)**2)))
  if not dx: continue
  a,b=str(n),str(n+1); n+=2
  g[a]=node('SolidMask','椭圆横带',value=1.0,width=2*dx+1,height=1)
  g[b]=node('MaskComposite','合并横带',destination=[prev,0],source=[a,0],x=cx-dx,y=y,operation='add');prev=b
 g['800']=node('MaskToImage','硬边限定',mask=[prev,0]);g['801']=node('ImageBlur','柔边',image=['800',0],blur_radius=3,sigma=1.5);g['802']=node('ImageToMask','柔边遮罩',image=['801',0],channel='red');g['803']=node('MaskComposite','严格限制在椭圆内',destination=['802',0],source=[prev,0],x=0,y=0,operation='multiply');g['804']=node('MaskToImage','有效遮罩',mask=['803',0]);g['805']=node('SaveImage','保存有效遮罩',images=['804',0],filename_prefix='gaiwan_food/mask');return g

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--cx',type=int,default=515);p.add_argument('--cy',type=int,default=490);p.add_argument('--rx',type=int,default=118);p.add_argument('--ry',type=int,default=48);p.add_argument('--seed',type=int,default=202611052202);p.add_argument('--check',action='store_true');p.add_argument('--mask-preview',action='store_true');a=p.parse_args()
 src=a.source.resolve();ref=a.reference.resolve();out=a.output.resolve();parent=src.parent; ident=read(parent/'identity.json'); completed(parent,ident,read(parent/'workflow.api.json'))
 if src.name!='result.png' or sha(ref)!=read(parent/'result.json')['outputs']['product_reference.png']['sha256']: raise ValueError('Source or reference provenance mismatch')
 c=ComfyClient(); schema=c.get('/object_info'); mask=mask_graph(a.cx,a.cy,a.rx,a.ry)
 g=read(ROOT/'fission/workflows/商品主图近景/多店铺无字主图/02_商品双参考与800输出.api.json');g.update(mask)
 for n in ['17','27','28']:g.pop(n,None)
 g['1']['inputs']['image']=str(src);g['2']['inputs']['image']=str(ref)
 w,h=Image.open(ref).size;g['7']['inputs'].update(image=['2',0],width=round(w*768/max(w,h)/16)*16,height=round(h*768/max(w,h)/16)*16)
 g['8']['inputs']['text']=POS;g['9']['inputs']['text']=NEG;g['16']['inputs']['cfg']=1.3;g['18']['inputs']['steps']=4;g['19']['inputs']['noise_seed']=a.seed
 g['806']=node('SetLatentNoiseMask','仅碗内采样',samples=['10',0],mask=['803',0]);g['21']['inputs']['latent_image']=['806',0]
 g['807']=node('ImageCompositeMasked','仅遮罩合成',destination=['1',0],source=['22',0],mask=['803',0],x=0,y=0,resize_source=False);g['23']['inputs']['images']=['807',0];g['24']['inputs'].update(image=['807',0],x=0,y=0,width=1024,height=1024)
 for n in ['23','26']:g[n]['inputs']['filename_prefix']='gaiwan_food/'+n
 check_graph(g,schema); visual=ui(g,schema,'盖碗食品局部修复','限定碗口内部')
 if a.check: print(json.dumps({'check':'passed','mask':[a.cx,a.cy,a.rx,a.ry],'source_sha256':sha(src),'reference_sha256':sha(ref),'negative_cfg':1.3,'reference_size':[g['7']['inputs']['width'],g['7']['inputs']['height']]}));return
 out.mkdir(parents=True,exist_ok=True)
 if a.mask_preview:
  check_graph(mask,schema);v=ui(mask,schema,'碗口遮罩预览','无采样');write(out/'mask_workflow.api.json',mask);write(out/'mask_workflow.ui.json',v)
  pid=c._submit_uncached(mask,v,out/'mask_submission.json');backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());history,metrics=c._wait_uncached(pid,out,backend); files=c._download_uncached(history,out/'mask_download');shutil.copyfile(files['805'][0],out/'edit_mask.png')
  im=Image.open(src).convert('RGB');m=Image.open(out/'edit_mask.png').convert('L'); overlay=Image.new('RGB',im.size,(255,35,20));im=Image.composite(overlay,im,m.point(lambda x:round(x*0.5)));im.save(out/'mask_overlay.png');print(json.dumps({'mask':str(out/'edit_mask.png'),'overlay':str(out/'mask_overlay.png'),'mask_sha256':sha(out/'edit_mask.png')}));return
 raise RuntimeError('执行采样前需完成审核与实现结果保护核验')
if __name__=='__main__':main()
