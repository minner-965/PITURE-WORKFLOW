"""A measured, deterministic shell-color adjustment executed inside ComfyUI."""
import fcntl
import re
import subprocess
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps
from scipy import ndimage

from build_workflows import node, check_graph, ui
from run_layers import ROOT, FISSION, ComfyClient, digest, make_preview_card, read, save
from native_color import audit
from native_review import verify_source

METHOD = 'native_color_adjustment'


def make_mask(source, spec):
    """Select the colored shell connected to a known midtone; bound the foot by its silhouette."""
    pixels = np.asarray(source).astype(np.int16)
    hue = np.asarray(source.convert('HSV'))[:,:,0]
    y,x = np.indices(hue.shape)
    left,top,right,bottom = spec['bounds']
    lo,hi = spec['hue_range']
    good = ((x>=left)&(x<right)&(y>=top)&(y<bottom)&(hue>=lo)&(hue<=hi)
            &(pixels[:,:,1]-pixels[:,:,2]>spec['min_green_blue']))
    labels,_ = ndimage.label(good)
    sx,sy = spec['seed_xy']
    label = labels[sy,sx]
    if not label: raise ValueError('外壁种子落在选色范围之外')
    region = ndimage.binary_fill_holes(labels==label)
    px,py = np.asarray(spec['max_y_curve']).T
    bottom_edge = np.interp(x[0],px,py)
    region &= (x<px[0])|(x>px[-1])|(y<=bottom_edge)
    # Feather inward only. Keep the near-black foot contact and its narrow reflection.
    distance = ndimage.distance_transform_edt(region)
    edge_weight = np.clip((distance-.75)/3,0,1)
    luminance = pixels@np.array([.2126,.7152,.0722])
    shade = np.clip((luminance-18)/51,0,1)
    return Image.fromarray(np.rint(255*edge_weight*shade).astype('uint8'))


def measure(parent, master, patches):
    meta=read(master/'master.json')
    original=ROOT/meta['source']
    result=audit(parent,master,patches)
    with Image.open(original) as image: real=ImageOps.exif_transpose(image).convert('RGB')
    photo=Image.open(parent).convert('RGB')
    refs=[]; samples=[]; rows=[]
    for p,r in zip(patches,result['rows']):
        coords=r['reference']['box_xyxy']
        ref=np.median(np.asarray(real.crop(coords)).reshape(-1,3),axis=0)
        obs=np.median(np.asarray(photo.crop(p['sample_xyxy'])).reshape(-1,3),axis=0)
        refs.append(ref);samples.append(obs)
        rows.append(dict(**p,photographer_xyxy=coords,reference_rgb=ref.tolist(),source_rgb=obs.tolist()))
    # Screen preserves luminance differences within each channel, including surface reflections.
    # Each matched swatch contributes equally, independent of its pixel count in the source photograph.
    weights=(np.asarray(refs)-samples)/np.maximum(255-np.asarray(samples),1)
    rgb=np.clip(np.rint(weights.mean(axis=0)*255),0,255).astype(int).tolist()
    return dict(parent_sha256=digest(parent),photographer_sha256=digest(original),
                patches=rows,screen_rgb=rgb,screen_rgb_int=(rgb[0]<<16)|(rgb[1]<<8)|rgb[2])


def prepare_inputs(slot,row,master,settings):
    version=settings['scene_parent_version']
    if (not isinstance(version,str) or not re.fullmatch(r'[0-9]{2,3}',version)
            or int(version)>=int(slot.name) or settings['size']!=[1280,1024]):
        raise ValueError('颜色子流程需要同款更早的原生母版和原始尺寸')
    parent_slot=slot.parent/version
    if parent_slot.resolve(strict=True)!=parent_slot:raise ValueError('母版目录不可跨主题链接')
    parent=verify_source(parent_slot,row,master)
    prior=read(parent_slot/'result.json')
    if prior.get('method','native_dual_reference')!='native_dual_reference':
        raise ValueError('颜色子图直接接续原生双参考照片')
    refs=read(master/'master.json')
    cal_path=slot/'calibration.json'
    cal=measure(parent,master,settings['patches'])
    if read(cal_path)!=cal:raise ValueError('实拍或标定参数已发生变化')
    mask=slot/'exterior_mask.png'
    with Image.open(parent) as image:expected=make_mask(image.convert('RGB'),settings['mask_spec'])
    with Image.open(mask) as image:
        if not np.array_equal(np.asarray(image.convert('RGB')),np.asarray(expected.convert('RGB'))):
            raise ValueError('颜色选区不符合实拍壳体蒙版说明')
    identity=dict(method=METHOD,scene=str(parent),scene_sha256=digest(parent),
        product=str(master/'master_1280.png'),product_sha256=digest(master/'master_1280.png'),
        photographer=refs['source'],parent_prompt_id=prior['prompt_id'],mask=str(mask),mask_sha256=digest(mask),
        calibration_sha256=digest(cal_path),settings_sha256=digest(slot/'settings.json'))
    if (slot/'identity.json').exists() and read(slot/'identity.json')!=identity:raise ValueError('已登记的颜色输入发生变化')
    if (slot/'submission.json').exists() and not (slot/'identity.json').exists():raise ValueError('颜色提交缺少输入证明')
    return row,slot,'',identity


def graph_for(source,mask,calibration,prefix):
    return {
        '1':node('LoadImage','原生双参考母片',image=source),
        '2':node('LoadImage','受保护壳体蒙版',image=mask),
        '3':node('ImageToMask','读取单通道蒙版',image=['2',0],channel='red'),
        '4':node('EmptyImage','实拍两区标定色',width=1280,height=1024,batch_size=1,color=calibration['screen_rgb_int']),
        '5':node('ImageBlend','实拍标定滤色',image1=['1',0],image2=['4',0],blend_factor=1.0,blend_mode='screen'),
        '6':node('ImageCompositeMasked','只写入已核定外壁',destination=['1',0],source=['5',0],mask=['3',0],x=0,y=0,resize_source=False),
        '7':node('SaveImage','颜色子图原生输出',images=['6',0],filename_prefix=prefix)
    }


def run_adjustment(run,row,slot,ident,submit):
    from native_dual_reference import check_result, ensure_allowed
    if (slot/'result.json').exists():return check_result(slot,row,ident)
    receipt=slot/'submission.json'
    def guard():ensure_allowed(run,row['shop'],row['dish_id'],slot.name,not receipt.exists())
    guard()
    if not submit:return None
    with (run/'queue.lock').open('a') as local,(FISSION/'runs'/'native_gpu.lock').open('a') as serial:
        fcntl.flock(local,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(serial,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if (slot/'result.json').exists():return check_result(slot,row,ident)
        client=ComfyClient();graph_path=slot/'颜色校正.api.json'
        source=Path(ident['scene']);mask=Path(ident['mask']);master=Path(ident['product']).parent
        if receipt.exists():
            if read(receipt)['request']['prompt']!=read(graph_path):raise ValueError('颜色工作流与回执不符')
            prompt_id=client.reconcile(receipt)
        else:
            q=client.get('/queue')
            if q['queue_running'] or q['queue_pending']:raise RuntimeError('等待正在处理的任务')
            live=client.get('/object_info')
            prefix=f'fission_abc/color_{row["shop"]}_{row["dish_id"]}_{slot.name}'
            api=graph_for(client.upload(source),client.upload(mask),read(slot/'calibration.json'),prefix)
            check_graph(api,live)
            visual=ui(api,live,'局部颜色校正','摄影师外壁两处中段标定，仅限定区域执行原生节点滤色。')
            positions=[(0,0),(0,350),(402,375),(0,700),(442,82),(825,124),(1230,124)]
            for n,pos in zip(visual['nodes'],positions):n['pos']=list(pos)
            if prepare_inputs(slot,row,master,read(slot/'settings.json'))[3]!=ident:raise ValueError('颜色输入发生变化')
            guard();save(slot/'identity.json',ident);save(graph_path,api);save(slot/'颜色校正.ui.json',visual)
            prompt_id=client.submit(api,visual,receipt)
        backend=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip())
        hist,metrics=client.wait(prompt_id,slot,backend)
        outs=client.download(hist,slot/'downloads')['7']
        if len(outs)!=1:raise ValueError('颜色工作流期望单一原生输出')
        photo=Path(outs[0])
        with Image.open(photo) as out,Image.open(source) as parent,Image.open(mask) as m:
            before=np.asarray(parent.convert('RGB'));after=np.asarray(out.convert('RGB'));allowed=np.asarray(m.convert('L'))>0
            changed=np.any(before!=after,axis=2)
        check=dict(photo_sha256=digest(photo),parent_sha256=digest(source),mask_sha256=digest(mask),
                   changed_pixels=int(changed.sum()),mask_pixels=int(allowed.sum()),
                   outside_mask_changed_pixels=int(np.sum(changed&~allowed)))
        save(slot/'保护像素核查.json',check)
        if check['outside_mask_changed_pixels'] or not check['changed_pixels']:raise ValueError('保护像素核查失败')
        qa=audit(photo,master,read(slot/'settings.json')['patches']);save(slot/'色差实测.json',qa)
        if qa['flag']:raise ValueError('标定区域色差超出阈值')
        preview=slot/'带字预览.jpg';make_preview_card(photo,row,preview)
        save(slot/'result.json',dict(method=METHOD,filename=str(photo.relative_to(slot)),sha256=digest(photo),
            parent_version=read(slot/'settings.json')['scene_parent_version'],preview_sha256=digest(preview),
            visual_status='wait_root',prompt_id=prompt_id,seconds=metrics['backend_wall_seconds']))
        return photo
