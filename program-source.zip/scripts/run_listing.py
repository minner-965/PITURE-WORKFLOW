#!/usr/bin/env python3
"""Render eligible layouts independently; report the actual pending dependencies."""
from listing_q6 import ROOT,compose
if __name__=='__main__':
    layouts=sorted((ROOT/'layouts').glob('main_0[1-4].json'))+sorted((ROOT/'layouts').glob('detail_0[128].json'))
    for layout in layouts:
        try: print(layout.stem,compose(layout.stem))
        except (ValueError,FileNotFoundError) as e: print(layout.stem,'pending:',e)
