#!/usr/bin/env python3
"""Audit HD replica technical evidence and render review sheets; never approve visuals."""
import hashlib
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output/TAOBAO_REPLICA_HD_20261103'
WORK = OUT / '04_工作流'
REPORT = OUT / '05_交付清单/技术核对.json'
REVIEW = OUT / '03_对照审核'
MASTERS = OUT / '05_交付清单/尺寸与参数记录.json'
MAIN = [f'M{i:02}' for i in range(1, 6)]
DETAIL = [f'D{i:02}' for i in range(1, 16)]
MASTER_SIZES = {'D20': (750, 1350), 'D21': (750, 1000)}


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def image_info(path):
    with Image.open(path) as image:
        image.verify()
    with Image.open(path) as image:
        image.load()
        return {'size': list(image.size), 'format': image.format, 'mode': image.mode}


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def audit_export(asset):
    log = WORK / asset / 'export'
    item = {'id': asset, 'role': 'main' if asset in MAIN else 'detail',
            'result_path': str(log / 'result.json'), 'status': 'pending', 'issues': []}
    result_path = log / 'result.json'
    if not result_path.is_file():
        item['issues'].append('missing_result')
        return item
    try:
        r = read_json(result_path)
        if r.get('asset_id') != asset or r.get('identity', {}).get('asset_id') != asset:
            item['issues'].append('asset_id_mismatch')
        for filename in ('actual.api.json', 'actual.ui.json', 'submission.json', 'history.json'):
            if not (log / filename).is_file():
                item['issues'].append('missing_' + filename)
        output = Path(r['output_path'])
        item['path'] = str(output)
        item['expected_sha256'] = r['output_sha256']
        if not output.is_file():
            item['issues'].append('missing_output')
            return item
        item.update(image_info(output)); item['actual_sha256'] = sha(output)
        if item['format'] != 'PNG': item['issues'].append('not_png')
        if item['actual_sha256'] != item['expected_sha256']: item['issues'].append('output_hash_mismatch')
        if asset in MAIN and item['size'] != [800, 800]: item['issues'].append('main_size_mismatch')
        if asset in DETAIL and item['size'][0] != 750: item['issues'].append('detail_width_mismatch')
        if r.get('download_sha256') != item['actual_sha256']: item['issues'].append('download_hash_mismatch')
        downloads = [p for p in (log / 'downloads').glob('*') if p.is_file()]
        matching = [str(p) for p in downloads if sha(p) == item['actual_sha256']]
        item['matching_downloads'] = matching
        if not matching: item['issues'].append('matching_comfy_download_missing')
        if (log / 'submission.json').is_file():
            sub = read_json(log / 'submission.json')
            if not sub.get('prompt_id') or sub.get('prompt_id') != r.get('prompt_id'):
                item['issues'].append('submission_prompt_id_mismatch')
            else:
                request = sub.get('request', {})
                if (log / 'actual.api.json').is_file() and request.get('prompt') != read_json(log / 'actual.api.json'):
                    item['issues'].append('submission_api_mismatch')
                if (log / 'actual.ui.json').is_file() and request.get('extra_data', {}).get('extra_pnginfo', {}).get('workflow') != read_json(log / 'actual.ui.json'):
                    item['issues'].append('submission_ui_mismatch')
        if (log / 'history.json').is_file():
            history = read_json(log / 'history.json')
            if history.get('status', {}).get('status_str') != 'success': item['issues'].append('history_not_success')
            outputs = history.get('outputs', {})
            entries = outputs.get('9', {}).get('images', [])
            if len(entries) != 1:
                item['issues'].append('history_export_image_count_mismatch')
            elif not any(Path(p).name == '9_0_' + Path(entries[0].get('filename', '')).name for p in matching):
                item['issues'].append('download_not_identified_in_history')
        item['method'] = r.get('method')
    except Exception as exc:
        item['issues'].append('audit_error: ' + str(exc))
    if not item['issues']: item['status'] = 'passed'
    return item


def audit_master(asset, records):
    item = {'id': asset, 'role': 'supplementary_master', 'status': 'pending', 'issues': []}
    matches = [x for x in records if x.get('id') == asset]
    if len(matches) != 1:
        item['issues'].append('master_record_missing_or_duplicate')
        return item
    r = matches[0]
    try:
        p = Path(r['output_path']); item['path'] = str(p)
        if not p.is_file():
            item['issues'].append('missing_output')
            return item
        item.update(image_info(p)); item['actual_sha256'] = sha(p)
        if item['format'] != 'PNG': item['issues'].append('not_png')
        if tuple(item['size']) != MASTER_SIZES[asset]: item['issues'].append('master_size_mismatch')
        if item['actual_sha256'] != r['output_sha256'] or item['actual_sha256'] != r['source_sha256']:
            item['issues'].append('master_hash_mismatch')
        for name in ('actual.api.json', 'actual.ui.json', 'submission.json', 'root_review.json'):
            entry = r.get('evidence', {}).get(name)
            if not entry or not Path(entry['path']).is_file(): item['issues'].append('missing_' + name)
            elif sha(entry['path']) != entry['sha256']: item['issues'].append('hash_mismatch_' + name)
    except Exception as exc:
        item['issues'].append('audit_error: ' + str(exc))
    if not item['issues']: item['status'] = 'passed'
    return item


def overview(filename, ids, items, cols, width=390, height=620):
    REVIEW.mkdir(parents=True, exist_ok=True)
    rows = (len(ids) + cols - 1) // cols
    board = Image.new('RGB', (cols * width, rows * height), '#e9e9e9')
    draw = ImageDraw.Draw(board)
    font = ImageFont.truetype('/System/Library/Fonts/STHeiti Medium.ttc', 22)
    for i, asset in enumerate(ids):
        x, y = (i % cols) * width, (i // cols) * height
        item = items[asset]
        label = Path(item['path']).stem.replace('_复刻', '').replace('_', ' ') if item.get('path') else asset + ' 待完成'
        draw.text((x + 8, y + 8), label, font=font, fill='#171717')
        if item.get('path') and Path(item['path']).is_file():
            try:
                with Image.open(item['path']) as source:
                    im = ImageOps.contain(source.convert('RGB'), (width - 16, height - 50), Image.Resampling.LANCZOS)
                board.paste(im, (x + (width-im.width)//2, y + 40 + (height-45-im.height)//2))
            except Exception:
                draw.text((x + 10, y + 60), '图像读取失败', font=font, fill='#a82020')
        else:
            draw.text((x + 10, y + 60), '待完成', font=font, fill='#8b2727')
    board.save(REVIEW / filename, quality=92, subsampling=0)
    return str(REVIEW / filename)


def main():
    records = read_json(MASTERS).get('items', []) if MASTERS.is_file() else []
    all_items = [audit_export(i) for i in MAIN + DETAIL] + [audit_master(i, records) for i in MASTER_SIZES]
    ids = [x['id'] for x in all_items]
    if len(ids) != len(set(ids)): raise ValueError('Duplicate asset IDs in audit')
    paths = {}
    for item in all_items:
        if item.get('path'):
            canonical = str(Path(item['path']).resolve())
            paths.setdefault(canonical, []).append(item)
    for same in paths.values():
        if len(same) > 1:
            for item in same: item['issues'].append('duplicate_output_path'); item['status'] = 'pending'
    by_id = {x['id']: x for x in all_items}
    overview_paths = [overview('主图总览.jpg', MAIN, by_id, 3, height=435),
                      overview('详情总览_01.jpg', DETAIL[:8], by_id, 3),
                      overview('详情总览_02.jpg', DETAIL[8:], by_id, 3),
                      overview('尺寸参数总览.jpg', list(MASTER_SIZES), by_id, 2)]
    pending = [x['id'] for x in all_items if x['status'] != 'passed']
    report = {'status': 'pending' if pending else 'passed', 'scope': 'technical_only',
              'visual_review': 'separate_root_decision_required', 'expected_count': 22,
              'passed_count': 22-len(pending), 'pending_ids': pending,
              'overviews': overview_paths, 'items': all_items}
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'passed': report['passed_count'], 'pending': pending}, ensure_ascii=False))


if __name__ == '__main__': main()
