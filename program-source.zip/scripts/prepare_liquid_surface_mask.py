"""Lower the rear food boundary while preserving side/front occlusion geometry."""
import argparse, hashlib, json
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw


def prepare(mother, original, old_mask, out, drop=.15, feather=3):
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    photo=np.array(Image.open(mother).convert('RGB'))
    source=np.array(Image.open(original).convert('RGB'))
    old=np.array(Image.open(old_mask).convert('L'))
    if photo.shape != source.shape or old.shape != photo.shape[:2]:
        raise ValueError('All inputs must share the same photograph coordinates')
    if not 0 < drop < .4 or not 0 <= feather <= 6:
        raise ValueError('Unsupported level drop or feather')
    new=old.copy(); boundaries=[]
    # A lower plane exposes the rear inner wall. The front lip still occludes it.
    # Eroding the entire ellipse instead would expose an artificial white annulus.
    for x in range(old.shape[1]):
        ys=np.flatnonzero(old[:,x]>0)
        if len(ys)<2: continue
        top,bottom=int(ys[0]),int(ys[-1]); target=top+round((bottom-top)*drop)
        if target<=top: continue
        new[:target,x]=0
        if feather:
            end=min(bottom+1,target+feather)
            weights=(np.arange(target,end)-target+1)/(feather+1)
            new[target:end,x]=np.rint(old[target:end,x]*weights).astype('uint8')
        boundaries.append([x,top,target,bottom])
    restore=new<old
    base=photo.copy(); base[restore]=source[restore]
    if np.any(new>old): raise ValueError('Food mask expanded beyond the reviewed aperture')
    Image.fromarray(base).save(out/'base.png')
    Image.fromarray(new).save(out/'paint_mask.png')
    Image.fromarray(255-new).save(out/'inverse_mask.png')
    Image.fromarray((restore*255).astype('uint8')).save(out/'restore_mask.png')
    overlay=Image.fromarray(base).convert('RGBA')
    tint=Image.new('RGBA',overlay.size,(240,30,30,0));tint.putalpha(Image.fromarray(np.rint(new*.4).astype('uint8')))
    overlay=Image.alpha_composite(overlay,tint)
    tint=Image.new('RGBA',overlay.size,(0,150,255,0));tint.putalpha(Image.fromarray((restore*130).astype('uint8')))
    Image.alpha_composite(overlay,tint).convert('RGB').save(out/'overlay.png')
    sha=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    data={'method':'rear_boundary_only_front_side_unchanged','level_drop_fraction':drop,'feather_px':feather,
          'mother':str(Path(mother).resolve()),'mother_sha256':sha(mother),
          'original':str(Path(original).resolve()),'original_sha256':sha(original),
          'old_mask':str(Path(old_mask).resolve()),'old_mask_sha256':sha(old_mask),
          'new_mask_sha256':sha(out/'paint_mask.png'),'restored_pixels':int(restore.sum()),
          'outside_restore_different_pixels':int(np.any(base[~restore]!=photo[~restore],axis=1).sum()),
          'mask_expanded_pixels':int(np.count_nonzero(new>old)),
          'column_boundaries_x_oldtop_newtop_front':boundaries,
          'review':'pending_root','limitation':'Rear-boundary warp is a photograph-space approximation; visible depth and rim geometry require review.'}
    (out/'evidence.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    return data


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--mother',required=True);p.add_argument('--original',required=True)
    p.add_argument('--old-mask',required=True);p.add_argument('--out',required=True)
    p.add_argument('--level-drop',type=float,default=.15);p.add_argument('--feather',type=int,default=3)
    a=p.parse_args();data=prepare(a.mother,a.original,a.old_mask,a.out,a.level_drop,a.feather)
    print(json.dumps({k:v for k,v in data.items() if not k.startswith('column_')},ensure_ascii=False,indent=2))
