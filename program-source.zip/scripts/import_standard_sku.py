#!/usr/bin/env python3
"""Read the standard SKU workbook without changing it; validate before exporting JSON."""
import argparse, collections, copy, datetime, hashlib, json, math, os, posixpath, re, sys, tempfile, zipfile
import qa_state
from pathlib import Path
from xml.etree import ElementTree as ET

NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships','p':'http://schemas.openxmlformats.org/package/2006/relationships'}
SCHEMA='standard-sku-1.0'
FIELDS={
 'SKU主表':dict(zip('内部SKU编码,型号,商品名称,颜色,重量（克）,容量（毫升）,长（厘米）,宽（厘米）,高（厘米）,英寸,用途,销售方式,每销售单位数量,起订量,实拍路径,参考图目录,资料状态,备注'.split(','),'sku_id,model,product_name,color,weight_g,capacity_ml,length_cm,width_cm,height_cm,inches,uses,sales_method,units_per_sale,moq,photo_path,reference_dir,data_status,notes'.split(','))),
 '图片任务':dict(zip('任务编号,型号,适用SKU,图片类型,食品,场景,宽（像素）,高（像素）,文件格式,成品路径,审核状态,退回原因,源任务编号'.split(','),'task_id,model,sku_ids,image_type,food,scene,width_px,height_px,formats,output_path,review_status,rejection_reason,source_task_id'.split(','))),
 '上架记录':dict(zip('记录编号,型号,平台,店铺,平台商品编号,商品链接,状态,上架日期,图片版本,备注'.split(','),'record_id,model,platform,store,platform_product_id,product_url,status,listed_date,image_version,notes'.split(',')))}
def col(ref):
 n=0
 for c in re.match(r'[A-Z]+',ref).group(): n=n*26+ord(c)-64
 return n

def read_xlsx(path):
 with zipfile.ZipFile(path) as z:
  wb=ET.fromstring(z.read('xl/workbook.xml')); rel=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
  targets={x.attrib['Id']:x.attrib['Target'] for x in rel}
  strings=[]
  if 'xl/sharedStrings.xml' in z.namelist():
   strings=[''.join(t.text or '' for t in s.findall('.//m:t',NS)) for s in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',NS)]
  props=wb.find('m:workbookPr',NS)
  date1904=props is not None and props.get('date1904','0').lower() in ('1','true')
  data={}
  for sheet in wb.findall('m:sheets/m:sheet',NS):
   name=sheet.attrib['name']
   if name not in FIELDS: continue
   target=targets[sheet.attrib['{%s}id'%NS['r']]]
   member=target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join('xl',target))
   root=ET.fromstring(z.read(member)); rows=[]
   for row in root.findall('.//m:sheetData/m:row',NS):
    cells={}
    for c in row.findall('m:c',NS):
     ref=c.attrib['r'];typ=c.attrib.get('t');v=c.find('m:v',NS);f=c.find('m:f',NS)
     if typ=='inlineStr': value=''.join(t.text or '' for t in c.findall('.//m:t',NS))
     elif v is None or v.text is None: value=None
     elif typ=='s': value=strings[int(v.text)]
     elif typ in ('str','e','d'): value=v.text
     elif typ=='b': value=v.text=='1'
     else:
      try: value=float(v.text);value=int(value) if value.is_integer() else value
      except ValueError: value=v.text
     if isinstance(value,str) and not value.strip(): value=None
     cells[col(ref)]=(value,f is not None,ref)
    rows.append(cells)
   matches=[]
   for i,row in enumerate(rows):
    mapping={v[0]:k for k,v in row.items() if isinstance(v[0],str) and v[0] in FIELDS[name]}
    if set(mapping)==set(FIELDS[name]): matches.append((i,mapping))
   if len(matches)!=1: raise ValueError(f'{name}: 表头缺失、重复或不完整')
   index,mapping=matches[0]; records=[]
   if name=='图片任务':
    optional=[c for c,v in rows[index].items() if v[0]=='派生自']
    if len(optional)>1: raise ValueError('图片任务: 派生自表头重复')
    if optional: mapping['派生自']=optional[0]
   for row in rows[index+1:]:
    if not any(row.get(c,(None,))[0] is not None or row.get(c,(None,False))[1] for c in (mapping[h] for h in FIELDS[name])): continue
    record={}
    for header,key in FIELDS[name].items():
     v,formula,ref=row.get(mapping[header],(None,False,''))
     if formula: raise ValueError(f'{name}!{ref}: 输入字段含公式')
     record[key]=v
    if name=='图片任务' and '派生自' in mapping:
     v,formula,ref=row.get(mapping['派生自'],(None,False,''))
     record['derived_from']=v
    records.append(record)
   data[name]=records
  if set(data)!=set(FIELDS): raise ValueError('缺少必需工作表')
  return data, date1904

STATUS={"待生成":"pending_generation","生成中":"generating","待审核":"pending_review","待审":"pending_review","通过":"passed_in_sheet","已通过":"passed_in_sheet","返工":"rework","历史通过待本轮复核":"pending_recheck"}

def validate(source_data, date1904=False):
 data=copy.deepcopy(source_data)
 errors=[]; warnings=[]; skus=data['SKU主表'];tasks=data['图片任务']; listings=data['上架记录']; ids={}
 for label,records,key in [('SKU',skus,'sku_id'),('任务',tasks,'task_id'),('上架',listings,'record_id')]:
  for r in records:
   v=r[key]
   if isinstance(v,str): v=v.strip(); r[key]=v
   if not isinstance(v,str) or not v.strip(): errors.append(f'{label}: 缺少ID');continue
   if v in ids: errors.append(f'全局重复ID: {v}')
   ids[v]=label
 for records in (skus,tasks,listings):
  for r in records:
   if isinstance(r['model'],str): r['model']=r['model'].strip()
 sku_map={r['sku_id']:r for r in skus if r['sku_id']}
 for r in skus:
  tag=r['sku_id'];r['needs_review']=any(r[k] is None for k in ('weight_g','capacity_ml','length_cm','width_cm','height_cm'))
  if not r['model']:errors.append(f'{tag}: 缺少型号')
  for k in ('weight_g','capacity_ml','length_cm','width_cm','height_cm'):
   v=r[k]
   if v is None: warnings.append(f'{tag}: {k}未提供，资料待补充')
   elif isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<=0: errors.append(f'{tag}: {k}须为空或有限正数')
  v=r['inches']
  if v is not None and (isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<=0): errors.append(f'{tag}: inches须为空或有限正数')
  for k in ('units_per_sale','moq'):
   v=r[k]
   if v is not None and (isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<=0 or v!=int(v)): errors.append(f'{tag}: {k}须为空或正整数')
  for k,method in [('photo_path','is_file'),('reference_dir','is_dir')]:
   if not isinstance(r[k],str) or not Path(r[k]).is_absolute() or not getattr(Path(r[k]),method)():errors.append(f'{tag}: {k}路径不存在')
 for r in tasks:
  tag=r['task_id']
  if r['output_path'] is not None and (not isinstance(r['output_path'],str) or not Path(r['output_path']).is_absolute()): errors.append(f'{tag}: 成品路径须为绝对路径')
  v=r['sku_ids']
  if isinstance(v,str): r['sku_ids']=[x.strip() for x in re.split(r'[、,，;；]',v) if x.strip() and x.strip()!='待核实']
  elif isinstance(v,list): r['sku_ids']=[x.strip() for x in v if isinstance(x,str) and x.strip() and x.strip()!='待核实']
  else: r['sku_ids']=[]
  r['needs_review']=not bool(r['sku_ids'])
  if r['needs_review']: warnings.append(f'{tag}: SKU关联待核实')
  for sid in r['sku_ids']:
   if sid not in sku_map:errors.append(f'{tag}: 未知SKU {sid}')
   elif sku_map[sid]['model']!=r['model']:errors.append(f'{tag}: 型号与SKU {sid}不一致')
  if not r['model'] or r['model'] not in {s['model'] for s in skus}:errors.append(f'{tag}: 未知型号')
  for k in ('width_px','height_px'):
   v=r[k]
   if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<=0 or v!=int(v):errors.append(f'{tag}: {k}须为正整数')
  r['review_status_code']=STATUS.get(r['review_status'],'unmapped')
  if r['review_status_code']=='unmapped': errors.append(f'{tag}: 未知审核状态 {r["review_status"]}')
 for r in listings:
  if r['status'] not in ('待准备','待上传','已上架','已下架'): errors.append(f'{r["record_id"]}: 未知上架状态 {r["status"]}')
  if r['model'] not in {s['model'] for s in skus}:errors.append(f'{r["record_id"]}: 未知型号')
  if r['status']=='已上架' and not all(r[k] for k in ('platform','store','platform_product_id')): errors.append(f'{r["record_id"]}: 已上架缺平台、店铺或商品ID')
  v=r['listed_date']
  if isinstance(v,(int,float)) and not isinstance(v,bool):r['listed_date']=(datetime.datetime(1904,1,1) + datetime.timedelta(days=v)).date().isoformat() if date1904 else (datetime.datetime(1899,12,31) + datetime.timedelta(days=v-(1 if v>=60 else 0))).date().isoformat()
  elif v is not None:
   try: r['listed_date']=datetime.date.fromisoformat(str(v)).isoformat()
   except ValueError:errors.append(f'{r["record_id"]}: 日期须为ISO日期')
 return data, errors, warnings

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--input',required=True,type=Path);ap.add_argument('--output-dir',required=True,type=Path);args=ap.parse_args()
 if not args.input.is_absolute():ap.error('--input 须为绝对路径')
 source=args.input.resolve(strict=True);raw_data,date1904=read_xlsx(source);data,errors,warnings=validate(raw_data,date1904)
 qa=qa_state.load();manifest=qa_state.rows()
 expected={'pending_recheck':'pending_recheck','visual_rejected':'rework','passed':'passed_in_sheet','pending_review':'pending_review'}
 for task in data['图片任务']:
  ident=task['task_id'].removeprefix('w1125-')
  if task['model']=='w1125':
   if ident not in qa: errors.append(f'{ident}: QA记录缺失')
   elif task['review_status_code']!=expected.get(qa[ident].get('status')): errors.append(f'{ident}: 统一表审核状态与 QA 不一致')
   if 'derived_from' in task and (task['derived_from'] or '') != manifest.get(ident,{}).get('derived_from',''): errors.append(f'{ident}: 统一表派生自与交付清单不一致')
 if errors: raise ValueError('\n'.join(errors[:30]))
 counts=collections.Counter(r['review_status_code'] for r in data['图片任务'])
 report={'schema_version':SCHEMA,'source_path':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'counts':{'sku':len(data['SKU主表']),'image_tasks':len(data['图片任务']),'listing':len(data['上架记录']),'rework':counts['rework'],'pending_recheck':counts['pending_recheck']},'validation':'passed','date_system':'1904' if date1904 else '1900','status_counts':{code:counts[code] for code in STATUS.values()},'warnings':warnings,'needs_review':bool(warnings),'ready_for_automatic_submission':False}
 outputs={'sku_records.json':data['SKU主表'],'image_tasks.json':data['图片任务'],'listing_records.json':data['上架记录'],'import_report.json':report}
 args.output_dir.mkdir(parents=True,exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='.sku_import_',dir=args.output_dir) as temp:
  for name,obj in outputs.items(): (Path(temp)/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
  for name in outputs: os.replace(Path(temp)/name,args.output_dir/name)
 print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':
 try: main()
 except (ValueError,OSError,KeyError,zipfile.BadZipFile,ET.ParseError) as e: print('导入校验失败:',e,file=sys.stderr);sys.exit(1)
