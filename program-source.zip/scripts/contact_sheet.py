import html,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    records=[]
    for f in (ROOT/'work/logs').glob('*/result.json'):
        d=json.loads(f.read_text())
        if d.get('status')=='success':records.append(dict(task=d['task'],sku=d['sku'],master=str(Path(d['master']).relative_to(ROOT)),visual_pass=False))
    page=['<!doctype html><meta charset="utf-8"><title>商品图候选选择</title><style>body{font:16px system-ui;padding:24px;background:#eee}section{display:inline-block;width:300px;padding:12px}img{width:280px}button{padding:12px}label{display:block}</style><h1>候选图选择</h1><p>检查碗沿、食物透视、接缝与原碗纹理后勾选。下载 picks.json，再交给 finalize.py；没有勾选不会导出成品。</p><button id="save">下载 picks.json</button><main>']
    for i,r in enumerate(records):page.append(f'<section><img src="../{html.escape(r["master"],quote=True)}"><label><input type="checkbox" data-index="{i}">视觉验收通过并选中 {html.escape(r["sku"])} / {html.escape(r["task"])}</label></section>')
    page+=['</main><script>const records='+json.dumps(records,ensure_ascii=False).replace('<','\\u003c')+';document.querySelector("#save").onclick=()=>{const picks=[...document.querySelectorAll("input:checked")].map(x=>({...records[Number(x.dataset.index)],visual_pass:true}));const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(picks,null,2)],{type:"application/json"}));a.download="picks.json";a.click();URL.revokeObjectURL(a.href)}</script>']
    (ROOT/'output/contact_sheet.html').write_text(''.join(page));print(ROOT/'output/contact_sheet.html')
if __name__=='__main__':main()
