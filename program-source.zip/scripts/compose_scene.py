#!/usr/bin/env python3
"""Deterministic scene composition. Missing inputs fail before any export."""
import argparse, csv, json
import numpy as np
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter, ImageOps, ImageFont
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/LISTING_V3/w1125'

def read_csv(path):
    with open(path,encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))

def asset_path(s):
    p=Path(s); return p if p.is_absolute() else ROOT/p

def render(layout, records):
    w,h=layout['canvas']; bg=asset_path(layout['background'])
    if not bg.is_file(): raise FileNotFoundError(f'background missing: {bg}')
    selected=[]
    for item in layout['items']:
        matches=[r for r in records if all(not item.get(k) or r.get(k)==item[k] for k in ('asset_id','color_id','dish_id')) and r.get('status','').lower() in ('passed',) and r.get('rgba_filled') and asset_path(r['rgba_filled']).is_file()]
        if len(matches)!=1: raise ValueError(f"{item.get('placement_id')}: expected exactly one qualified asset; found {len(matches)} for {item}")
        selected.append((item,matches[0]))
    scene=layout.get('scene_id','').upper(); colors={r.get('color_id') for _,r in selected}; dishes={r.get('dish_id') for _,r in selected}
    if scene=='MAIN_02' and colors!={'red','orange','green','yellow','blue'}: raise ValueError('MAIN_02 must cover all five real colors')
    if scene=='MAIN_01' and not (6<=len(selected)<=9): raise ValueError('MAIN_01 requires 6–9 bowls')
    if scene in ('MAIN_03','MAIN_04') and len(dishes)<3: raise ValueError(f'{scene} requires three different verified dishes')
    use_map={'century_pork_congee':('congee','粥','皮蛋瘦肉粥'),'corn_rib_soup':('soup','咸汤','玉米排骨汤'),'redbean':('dessert','糖水','红豆沙')}
    if scene=='DETAIL_02':
        if len(selected)!=3: raise ValueError('DETAIL_02 requires one bowl for each use')
        for i,(item,row) in enumerate(selected):
            fact=use_map.get(row.get('dish_id'))
            if not fact or item.get('use_category')!=fact[0] or fact[0]!=('congee','soup','dessert')[i]: raise ValueError(f'DETAIL_02 dish/use mapping invalid: {item}')
    product_rows=read_csv(ROOT/'config/product_assets.csv'); products={r['color_id']:r for r in product_rows if r.get('base_image') and r.get('core_mask')}
    canvas=ImageOps.fit(Image.open(bg).convert('RGB'),(w,h),method=Image.Resampling.LANCZOS,centering=(.5,.7)).convert('RGBA')
    # Optional typography is part of the background layer, never a product edit.
    for field in ('headline','subtitle'):
        spec=layout.get(field)
        if not spec: continue
        size=int(spec['font_size']); xy=(int(spec['x']),int(spec['y'])); d=ImageDraw.Draw(canvas)
        while True:
            ft=ImageFont.truetype('/System/Library/Fonts/STHeiti Medium.ttc',size); bounds=d.textbbox(xy,spec['text'],font=ft)
            if bounds[2]<=w-xy[0] or size<=12: break
            size-=1
        text_limit=180 if h>w else 350
        if bounds[0]<0 or bounds[1]<0 or bounds[2]>w-xy[0] or bounds[3]>=text_limit: raise ValueError(f'{field} must fit canvas and upper {text_limit}px: {bounds}')
        shadow=Image.new('RGBA',(w,h)); sd=ImageDraw.Draw(shadow); rgb=tuple(bytes.fromhex(spec.get('shadow_color','#312820').lstrip('#'))); dx,dy=spec.get('shadow_offset',[2,2]); sd.text((xy[0]+dx,xy[1]+dy),spec['text'],font=ft,fill=rgb+(int(spec.get('shadow_opacity',100)),)); shadow=shadow.filter(ImageFilter.GaussianBlur(float(spec.get('shadow_blur',2))))
        canvas=Image.alpha_composite(canvas,shadow);ImageDraw.Draw(canvas).text(xy,spec['text'],font=ft,fill=spec.get('color','#f7f5ee'))
    if scene=='DETAIL_02':
        d=ImageDraw.Draw(canvas); heading=ImageFont.truetype('/System/Library/Fonts/STHeiti Medium.ttc',29); detail=ImageFont.truetype('/System/Library/Fonts/STHeiti Medium.ttc',22)
        for (item,row),y in zip(selected,(160,520,880)):
            _,category,dish=use_map[row['dish_id']]
            d.rounded_rectangle((25,y,208,y+83),radius=8,fill='#faf9f5'); d.text((35,y+9),category,font=heading,fill='#27332d'); d.text((35,y+48),dish,font=detail,fill='#4f5c54')
    audits=[]
    for item,row in sorted(selected,key=lambda x:x[0]['z_order']):
        src=Image.open(asset_path(row['rgba_filled'])).convert('RGBA'); box=src.getchannel('A').getbbox()
        if not box: raise ValueError('empty alpha: '+row['rgba_filled'])
        product=products.get(row['color_id'])
        if not product: raise ValueError('missing real base/core for '+row['color_id'])
        base=Image.open(asset_path(product['base_image'])).convert('RGB'); core=Image.open(asset_path(product['core_mask'])).convert('L')
        if base.size!=src.size or core.size!=src.size: raise ValueError('base, core and asset geometry differs: '+row['asset_id'])
        raw_mask=(np.asarray(core)==255)&(np.asarray(src.getchannel('A'))==255)
        delta=np.abs(np.asarray(src.convert('RGB'),dtype=np.int16)-np.asarray(base,dtype=np.int16)).max(axis=2)
        n=int(raw_mask.sum()); asset_check={'core_count':n,'maxdiff':int(delta[raw_mask].max()) if n else None,'diffcount':int((delta[raw_mask]!=0).sum())}
        if not n: raise ValueError('empty asset core: '+row['asset_id'])
        src=src.crop(box); width=round(w*item['width']); height=round(src.height*width/src.width)
        src=src.resize((width,height),Image.Resampling.LANCZOS); x=round(w*item['x']-width/2); y=round(h*item['bottom']-height)
        if x<0 or y<0 or x+width>w or y+height>h: raise ValueError(f"{item['placement_id']} extends outside canvas: {(x,y,width,height)}")
        # The base and the core follow exactly the source alpha's crop, resize and placement.
        reference=base.crop(box).resize((width,height),Image.Resampling.LANCZOS)
        source_strict=Image.fromarray(np.where(raw_mask,255,0).astype('uint8')).filter(ImageFilter.MinFilter(7))
        strict=source_strict.crop(box).resize((width,height),Image.Resampling.LANCZOS).filter(ImageFilter.MinFilter(5))
        strict=Image.fromarray(np.where((np.asarray(strict)==255)&(np.asarray(src.getchannel('A'))==255),255,0).astype('uint8'))
        cx=x+width*.51; cy=y+height-1
        broad=Image.new('RGBA',(w,h)); d=ImageDraw.Draw(broad)
        d.ellipse((cx-width*.28,cy-height*.025,cx+width*.28,cy+height*.065),fill=(33,24,18,45)); broad=broad.filter(ImageFilter.GaussianBlur(max(2,width*.025)))
        contact=Image.new('RGBA',(w,h)); d=ImageDraw.Draw(contact)
        d.ellipse((cx-width*.18,cy-height*.0125,cx+width*.18,cy+height*.0125),fill=(25,20,17,110)); contact=contact.filter(ImageFilter.GaussianBlur(max(1,width*.006)))
        # Both later shadow layers obscure previous visible cores.
        shadow_a=(np.asarray(broad.getchannel('A'))>0)|(np.asarray(contact.getchannel('A'))>0)
        for a in audits:
            a['visible'][shadow_a]=False; a['wall_visible'][shadow_a]=False
        canvas=Image.alpha_composite(canvas,broad); canvas=Image.alpha_composite(canvas,contact)
        layer=Image.new('RGBA',(w,h)); layer.alpha_composite(src,(x,y)); alpha=np.asarray(layer.getchannel('A'))>0
        for a in audits:
            a['visible'][alpha]=False; a['wall_visible'][alpha]=False
        canvas=Image.alpha_composite(canvas,layer)
        ref_layer=Image.new('RGB',(w,h)); ref_layer.paste(reference,(x,y)); mask=Image.new('L',(w,h)); mask.paste(strict,(x,y))
        # Approximate exterior wall as the central lower 45% of the source bowl bbox, intersected with the protected core.
        # This is a reproducible visibility proxy; final visual inspection still judges the real outer wall.
        wall_local=np.asarray(strict).copy(); wall_local[:round(height*.55),:]=0; wall_local[:,:round(width*.15)]=0; wall_local[:,round(width*.85):]=0
        wall_count=int((wall_local==255).sum()); wall=Image.new('L',(w,h)); wall.paste(Image.fromarray(wall_local),(x,y))
        audits.append({'item':item,'row':row,'asset_check':asset_check,'reference':np.asarray(ref_layer),'visible':np.asarray(mask).copy()==255,'wall_visible':np.asarray(wall).copy()==255,'wall_count':wall_count})
    result=canvas.convert('RGB'); pixels=np.asarray(result,dtype=np.int16); used=[]
    for a in audits:
        visible=a['visible']; count=int(visible.sum()); delta=np.abs(pixels-a['reference'].astype(np.int16)).max(axis=2)
        layout_check={'core_count':count,'maxdiff':int(delta[visible].max()) if count else None,'diffcount':int((delta[visible]!=0).sum())}
        i,r=a['item'],a['row']; used.append(dict(placement_id=i['placement_id'],asset_id=r['asset_id'],color_id=r['color_id'],dish_id=r['dish_id'],use_category=i.get('use_category'),asset_core=a['asset_check'],visible_layout_core=layout_check,outer_wall_visibility={'visible_pixels':int(a['wall_visible'].sum()),'total_pixels':a['wall_count'],'fraction':round(int(a['wall_visible'].sum())/a['wall_count'],4) if a['wall_count'] else None,'method':'protected core in central 70% and lower 45% of cropped bowl; visual proxy'}))
    return result,used

def export(im, path, size=None):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    im.save(path.with_suffix('.png')); (im.resize(size,Image.Resampling.LANCZOS) if size else im).save(path.with_suffix('.jpg'),quality=95,subsampling=0)

def main():
    p=argparse.ArgumentParser(); p.add_argument('layout'); p.add_argument('--assets',default=str(ROOT/'config/food_assets.csv')); p.add_argument('--output',required=True); a=p.parse_args()
    layout=json.loads(Path(a.layout).read_text()); image,used=render(layout,read_csv(a.assets)); export(image,a.output,(800,800) if image.width==image.height else None)
    Path(a.output).with_suffix('.json').write_text(json.dumps({'layout':a.layout,'assets':used,'visual_qa':'pending'},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
