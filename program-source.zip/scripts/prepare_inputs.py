import argparse, hashlib, io, json
from pathlib import Path
from PIL import Image, ImageOps, ImageCms

def sha(p):return hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()
def prepare(photo,out,size=1024):
    photo=Path(photo);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    im=Image.open(photo);original=im.size;icc=im.info.get('icc_profile');im=ImageOps.exif_transpose(im)
    oriented=im.size
    if icc:
        im=ImageCms.profileToProfile(im,ImageCms.ImageCmsProfile(io.BytesIO(icc)),ImageCms.createProfile('sRGB'),outputMode='RGB');color='ICC profile converted to sRGB'
    else:im=im.convert('RGB');color='No ICC; assumed sRGB'
    scale=min(size/im.width,size/im.height);dims=tuple(round(x*scale) for x in im.size);pad=((size-dims[0])//2,(size-dims[1])//2)
    canvas=Image.new('RGB',(size,size),'white');canvas.paste(im.resize(dims,Image.Resampling.LANCZOS),pad);target=out/'Base_Image.png'
    canvas.save(target,icc_profile=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes())
    record=dict(source=str(photo.resolve()),source_sha256=sha(photo),original_size=original,oriented_size=oriented,base_size=[size,size],scale=scale,scaled_size=dims,padding_left_top=pad,color=color,base_sha256=sha(target))
    (out/'transform.json').write_text(json.dumps(record,ensure_ascii=False,indent=2));return target
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('photo');p.add_argument('out');p.add_argument('--size',type=int,default=1024);a=p.parse_args();print(prepare(a.photo,a.out,a.size))
