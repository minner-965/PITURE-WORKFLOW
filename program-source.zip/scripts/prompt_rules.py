"""Versioned mask-local FLUX prompts and lint checks."""
from pathlib import Path
import re
import yaml

ROOT = Path(__file__).resolve().parents[1]
FOOD_WORDS = re.compile(r"\b(?:bowls?|rims?|edges?|walls?|plates?|cups?|tables?|served|serving|portions?|photographs?|containers?)\b", re.I)
BACKGROUND_WORDS = re.compile(r"\b(?:bowl|food|dish)\b", re.I)
NEGATIVE = re.compile(r"\b(?:no|without|not|dont|don't|don’t)\b", re.I)
WORD = re.compile(r"\b[\w]+(?:[-’'][\w]+)*\b", re.UNICODE)
ALIASES = {'plain_congee': 'rice_congee'}

def lint_prompt(region_type, text):
    if region_type not in ('food', 'background'):
        raise ValueError('region_type must be food or background')
    if not isinstance(text, str) or not text.strip():
        raise ValueError('prompt must be nonempty text')
    errors=[]; warnings=[]
    for match in NEGATIVE.finditer(text): errors.append('negative: '+match.group())
    for match in (FOOD_WORDS if region_type=='food' else BACKGROUND_WORDS).finditer(text):
        errors.append('outside mask: '+match.group())
    count=len(WORD.findall(text))
    if region_type=='food':
        if count<25: warnings.append('food prompt under 25 words')
        if count>60: warnings.append('food prompt over 60 words')
        elif count>50: warnings.append('food prompt over recommended 50 words')
    elif count>90: warnings.append('background prompt over 90 words')
    return {'region_type':region_type,'word_count':count,'errors':errors,'warnings':warnings}

def resolve_food_prompt(dish_id, variant=None):
    data=yaml.safe_load((ROOT/'prompts/foods.yaml').read_text(encoding='utf-8'))
    key=ALIASES.get(dish_id,dish_id)
    entry=data.get(key)
    if not isinstance(entry,dict) or 'description' not in entry:
        raise KeyError(f'Unknown food dish_id: {dish_id}')
    if variant is None:
        text=entry['description']
    else:
        variants=entry.get('variants', {})
        if variant not in variants: raise KeyError(f'Unknown variant {variant!r} for food dish_id: {dish_id}')
        text=variants[variant]
    result=lint_prompt('food',text)
    if result['errors']: raise ValueError(f'Invalid food prompt {dish_id}: {result["errors"]}')
    return text

def resolve_background_prompt(prompt_id):
    data=yaml.safe_load((ROOT/'prompts/backgrounds.yaml').read_text(encoding='utf-8'))
    text=data[prompt_id]; result=lint_prompt('background',text)
    if result['errors']: raise ValueError(f'Invalid background prompt {prompt_id}: {result["errors"]}')
    return text
