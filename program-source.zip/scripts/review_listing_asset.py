#!/usr/bin/env python3
"""Record a root's explicit visual decision for exactly one existing asset."""
import argparse,csv,fcntl,hashlib,io,json,os,re,shutil,subprocess,tempfile
from contextlib import contextmanager
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parents[1];LOG=R/'work/logs/listing_v3';CSV=R/'config/food_assets.csv';LOCK=LOG/'.review_listing_asset.lock'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def atomic(p,data):
 fd,tmp=tempfile.mkstemp(dir=p.parent,prefix='.'+p.name+'.',suffix='.tmp')
 try:
  with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
  os.replace(tmp,p)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)
def one(items,what):
 if len(items)!=1:raise ValueError(f'{what}: expected exactly one, found {len(items)}')
 return items[0]
def runner_active():
 lines=subprocess.check_output(['ps','-axo','pid=,command='],text=True).splitlines()
 return [line.strip() for line in lines if ('run_food_assets' in line or '-m fission food' in line) and int(line.strip().split(None,1)[0])!=os.getpid() and 'python' in line.lower()]
def perform(a):
 if '/' in a.id or a.id in ('.','..'):raise ValueError('asset_id/job_id must be a single identifier')
 timestamp=datetime.now(timezone.utc).isoformat();review={'decision':a.decision,'reviewer':'root','note':a.note,'reviewed_at_utc':timestamp}
 updates={};row=None
 if a.kind=='food':
  raw=CSV.read_bytes();reader=csv.DictReader(io.StringIO(raw.decode('utf-8-sig'),newline=''));rows=list(reader);fields=reader.fieldnames
  row=one([x for x in rows if x['asset_id']==a.id],'matching CSV rows');output=Path(row['rgba_filled']).resolve()
  if not output.is_file():raise FileNotFoundError(output)
  candidates=[]
  for p in (LOG/a.id).glob('**/result.json'):
   d=json.loads(p.read_text())
   if d.get('output') and Path(d['output']).resolve()==output:candidates.append((p,d))
  result_path,result=one(candidates,'matching result files')
  if a.decision=='passed' and (result.get('core_diff_count')!=0 or result.get('core_diff_max')!=0 or not result.get('core_count')):raise ValueError('passed requires present, nonempty core and zero core diff')
  sidecar=output.with_suffix('.json');side_data=json.loads(sidecar.read_text()) if sidecar.exists() else None
  row['status']=a.decision
  buf=io.StringIO(newline='');w=csv.DictWriter(buf,fieldnames=fields);w.writeheader();w.writerows(rows);updates[CSV]=buf.getvalue().encode('utf-8-sig')
 else:
  result_path=LOG/a.id/(a.attempt or '')/'result.json'
  if not result_path.is_file():raise FileNotFoundError(result_path)
  result=json.loads(result_path.read_text());files=result.get('files',{}).get('15',[])
  if a.decision=='passed':
   for key in ('protected_diff_max','protected_diff_count'):
    if key in result and result[key]!=0:raise ValueError(f'passed requires {key}=0')
   if ('protected_diff_max' in result or 'protected_diff_count' in result) and not result.get('protected_count'):raise ValueError('passed requires a nonempty protected region')
  raw_output=Path(one(files,'node 15 output files')).resolve()
  if not raw_output.is_file():raise FileNotFoundError(raw_output)
  selected=result.get('selected_output')
  if selected and not Path(selected).is_absolute():raise ValueError('selected_output must be an absolute path')
  output=Path(selected).resolve() if selected else raw_output
  if not output.is_file():raise FileNotFoundError(output)
  if selected:
   result.setdefault('raw_output_sha256',sha(raw_output))
   if result.get('status')=='visual_rejected':
    result.setdefault('raw_visual_status','visual_rejected')
    result.setdefault('raw_visual_reason',result.get('visual_rejection_reason',''))
  sidecar=output.with_suffix('.json');side_data=json.loads(sidecar.read_text()) if sidecar.exists() else None
 digest=sha(output)
 expected=result.get('selected_output_sha256') if a.kind=='background' and result.get('selected_output') else result.get('output_sha256')
 if expected and expected!=digest:raise ValueError('Existing result SHA-256 differs from file; review target is ambiguous')
 review['output']=str(output);review['output_sha256']=digest
 if a.kind=='background' and result.get('selected_output'):
  provenance=result.get('selected_output_provenance') or result.get('provenance_path')
  if provenance:
   if not Path(provenance).is_absolute() or not Path(provenance).is_file():raise ValueError('Selected output provenance must be an existing absolute file path')
   review['provenance_path']=provenance
 def apply(d):
  d.update(status=a.decision,output_sha256=digest,visual_pass=a.decision=='passed',visual_reviewer='root',visual_review_note=a.note,visual_reviewed_at_utc=timestamp,visual_review=review)
  if a.decision=='visual_rejected':d['visual_rejection_reason']=a.note
  else:d.pop('visual_rejection_reason',None)
 apply(result)
 if a.kind=='background':
  result['sha256']=digest
  if result.get('selected_output'):result['selected_output_sha256']=digest
 updates[result_path]=json.dumps(result,ensure_ascii=False,indent=2).encode()+b'\n'
 if side_data is not None:apply(side_data);updates[sidecar]=json.dumps(side_data,ensure_ascii=False,indent=2).encode()+b'\n'
 report={'kind':a.kind,'id':a.id,'review':review,'files_to_update':[str(p) for p in updates],'dry_run':a.dry_run}
 if a.dry_run:print(json.dumps(report,ensure_ascii=False,indent=2));return
 snapshots={p:p.read_bytes() for p in updates}
 # Refuse changes since the CSV was read and before the first write.
 if a.kind=='food' and CSV.read_bytes()!=raw:raise RuntimeError('Concurrent CSV modification detected; retry')
 suffix=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
 for p,content in snapshots.items():
  backup=p.with_name(p.name+'.before_review_'+suffix+'.bak');atomic(backup,content)
 for p,data in updates.items():atomic(p,data)
 print(json.dumps(report,ensure_ascii=False,indent=2))
def main():
 p=argparse.ArgumentParser();p.add_argument('kind',choices=['food','background']);p.add_argument('id');p.add_argument('--decision',required=True,choices=['passed','visual_rejected']);p.add_argument('--note',required=True);p.add_argument('--dry-run',action='store_true');p.add_argument('--attempt',help='explicit attempt_<hex hash> for a background result');a=p.parse_args()
 if a.attempt and (a.kind!='background' or not re.fullmatch(r'attempt_[0-9a-f]{8,64}',a.attempt)):raise SystemExit('Invalid attempt: use background --attempt attempt_<hex hash>')
 if not a.note.strip():raise SystemExit('A nonempty note is required')
 if a.dry_run:perform(a);return
 LOCK.parent.mkdir(parents=True,exist_ok=True)
 with LOCK.open('a+') as f:
  fcntl.flock(f,fcntl.LOCK_EX)
  if a.kind=='food':
   with (R/'config/.food_assets.lock').open('a+') as food_lock:
    fcntl.flock(food_lock,fcntl.LOCK_EX);perform(a)
  else:perform(a)
if __name__=='__main__':main()
