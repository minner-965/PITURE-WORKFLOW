import argparse,csv,hashlib,json,subprocess,time
from pathlib import Path
import yaml
from PIL import Image
from comfy_client import ComfyClient,bind,sync_ui
from build_workflows import check_graph
from prepare_inputs import sha
from restore_and_check import restore
from make_white_and_sku import make
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser();p.add_argument('--csv',default=str(ROOT/'input/products.csv'));p.add_argument('--candidates',type=int);p.add_argument('--seed',type=int,default=20261102);p.add_argument('--execute',action='store_true');a=p.parse_args()
    cfg=yaml.safe_load((ROOT/'config/pipeline.yaml').read_text());client=ComfyClient(cfg['url']);manifest=json.loads((ROOT/'workflows/manifest.json').read_text())['A'];info=client.get('/object_info');inventory=json.loads((ROOT/'work/diagnostics/model_inventory.json').read_text());rows=list(csv.DictReader(open(a.csv)))
    if not rows:raise SystemExit('等待真实商品照片：products.csv 尚无任务；未提交推理。')
    for row in rows:
        sku=row['sku']
        if not sku or any(x in sku for x in ['..','/','\\']):raise ValueError('Invalid SKU path')
        base=ROOT/'work/base'/sku/'Base_Image.png';masks=ROOT/'work/masks'/sku
        required=[base,masks/'paint_mask.png',masks/'paste_mask.png',masks/'core_mask.png',masks/'empty_bowl_cutout.png']
        if not all(x.is_file() for x in required):raise FileNotFoundError('Prepare real Base and approved masks first: '+sku)
        if any(Image.open(x).size!=(1024,1024) for x in required):raise ValueError('Formal scene inputs must be 1024×1024')
        if sha(row['photo'])!=json.loads(base.with_name('transform.json').read_text())['source_sha256']:raise ValueError('Photo changed; rebuild Base and masks')
        prompt=f"Commercial food photograph of the single bowl in the input image, containing {row['dish']} inside its visible inner cavity, a level liquid surface below the rim, natural texture and viscosity, no overflowing or spilling, perspective matching the camera angle, {row['scene']}, realistic contact shadow, preserve the bowl shape and rim."
        for candidate in range(a.candidates or cfg['candidates']):
            graph=json.loads((ROOT/'workflows/A_flux_fill_scene.api.json').read_text());ui=json.loads((ROOT/'workflows/A_flux_fill_scene.comfy_saved.ui.json').read_text());seed=a.seed+candidate
            bind(graph,manifest,'IN_PROMPT',{'text':prompt});bind(graph,manifest,'IN_SEED',{'seed':seed,'steps':cfg['steps'],'cfg':cfg['cfg'],'sampler_name':cfg['sampler'],'scheduler':cfg['scheduler']})
            bind(graph,manifest,'FLUX_GUIDANCE',{'guidance':cfg['guidance']})
            identity=dict(sku=sku,row=row,inputs={str(x):sha(x) for x in required},workflow=graph,models={m['path']:m['sha256'] for m in inventory['models']},seed=seed)
            task=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()[:20];log=ROOT/'work/logs'/task;log.mkdir(exist_ok=True);done=log/'result.json';submission=log/'submission.json'
            if done.exists() and json.loads(done.read_text()).get('status')=='success':print(task,'already completed');continue
            (log/'identity.json').write_text(json.dumps(identity,ensure_ascii=False,indent=2))
            if not a.execute:print(task,'preflight ready; --execute required');continue
            if submission.exists():prompt_id=client.reconcile(submission)
            else:
                q=client.get('/queue')
                if q['queue_running'] or q['queue_pending']:raise RuntimeError('Existing queue nonempty; do not overlap other work')
                for title,file in [('IN_IMAGE',base),('IN_PAINT_MASK',masks/'paint_mask.png'),('IN_PASTE_MASK',masks/'paste_mask.png')]:bind(graph,manifest,title,{'image':client.upload(file)})
                for title in ['OUT_RAW','OUT_SAVE']:bind(graph,manifest,title,{'filename_prefix':f'ComfyProductPipeline/{sku}/{task}_{title}'})
                check_graph(graph,client.get('/object_info'));ui=sync_ui(graph,ui,info);prompt_id=client.submit(graph,ui,submission)
            pid=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip())
            try:
                history,measure=client.wait(prompt_id,log,pid,cfg['timeout_seconds']);files=client.download(history,ROOT/'work/candidates'/task)
                master=ROOT/'work/masters'/sku/(task+'.png');check=restore(base,files[manifest['nodes']['OUT_RAW']['id']][0],masks/'paste_mask.png',masks/'core_mask.png',master)
                make(masks/'empty_bowl_cutout.png',ROOT/'output'/sku,row.get('sku_label',''),cfg['font'])
                report=dict(status='success',task=task,sku=sku,seed=seed,width=1024,height=1024,steps=cfg['steps'],guidance=cfg['guidance'],cold_or_warm='未自动判定：以后台模型加载日志为准',prompt_id=prompt_id,files=files,master=str(master),check=check,measurements=measure,visual_pass=None,swap_delta_bytes=measure['swap_delta_bytes'])
                done.write_text(json.dumps(report,ensure_ascii=False,indent=2));print(task,'completed, visual review pending')
            except Exception as e:
                (log/'failure.json').write_text(json.dumps(dict(task=task,prompt_id=prompt_id,error=str(e),time=time.time()),ensure_ascii=False,indent=2));raise
if __name__=='__main__':main()
