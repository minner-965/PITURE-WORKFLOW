#!/usr/bin/env python3
"""Authoritative visual QA state; source changes invalidate downstream approvals."""
import argparse, builtins, csv, hashlib, json, os, re, tempfile, zlib
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

R=Path(__file__).resolve().parents[1]
CURRENT_ROUND='v7'
QA=R/'config/qa_approvals.json'
MANIFEST=R/'delivery_manifest.csv'

def load(): return json.loads(QA.read_text(encoding='utf-8'))
def get(ident): return load()[ident]
def rows():
 with MANIFEST.open(encoding='utf-8-sig',newline='') as f: return {r['deliverable_id']:r for r in csv.DictReader(f)}
def digest(p):
 return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def receipt_valid(batch, ready, manifest_file, receipt):
 try:
  manifest=json.loads(manifest_file.read_text(encoding='utf-8'))
  report=json.loads(receipt.read_text(encoding='utf-8'))
  assets=manifest['assets']
  if not isinstance(assets,list) or any(type(a.get('byte_size')) is not int or a['byte_size']<0 for a in assets): return False
  expected={'batch_id':manifest['batch_id'],'file_count':len(assets),'total_bytes':sum(a['byte_size'] for a in assets),'manifest_sha256':digest(manifest_file)}
  if expected['batch_id']!=batch.name or report.get('status')!='VALID': return False
  return all(type(ready.get(k)) is type(v) and ready.get(k)==v and type(report.get(k)) is type(v) and report.get(k)==v for k,v in expected.items())
 except (OSError,ValueError,TypeError,KeyError,AttributeError): return False
def deps(row): return [x for x in row.get('derived_from','').split(';') if x]
def source_files(row):
 return [Path(x) for x in row.get('source_files','').split(';') if x]
def independent_sources_valid(row, entry):
 records=entry.get('independent_sources'); expected=[str(p) for p in source_files(row)]
 if not isinstance(records,list) or not expected or len(records)!=len(expected):return False
 if builtins.set(x.get('path') for x in records if isinstance(x,dict))!=builtins.set(expected):return False
 for review in records:
  if not isinstance(review,dict) or review.get('reviewer')!='root' or review.get('review_round')!=CURRENT_ROUND or not isinstance(review.get('note'),str) or not review['note'].strip():return False
  file=Path(review['path'])
  if not file.is_file() or review.get('sha256')!=digest(file):return False
 canonical=json.dumps(records,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
 return entry.get('source_reviews_sha256')==hashlib.sha256(canonical).hexdigest()
def _preview_path(path):
 return any(part.lower() in ('preview','preview_tiers') for part in Path(path).parts)
def _declares_preview(value):
 if isinstance(value,dict):
  if str(value.get('tier','')).strip().lower() in ('preview','crop') or value.get('test_only') is True: return True
  return any(_declares_preview(v) for v in value.values())
 if isinstance(value,list): return any(_declares_preview(v) for v in value)
 return False
def _png_texts(path):
 texts=[]
 try:
  with Path(path).open('rb') as f:
   if f.read(8)!=b'\x89PNG\r\n\x1a\n':return texts
   while True:
    head=f.read(8)
    if len(head)!=8:return texts
    length=int.from_bytes(head[:4],'big');kind=head[4:]
    if length>16*1024*1024:return texts
    payload=f.read(length);f.read(4)
    if kind in (b'tEXt',b'zTXt',b'iTXt'):
     texts.append(payload)
     if kind==b'zTXt':
      try:texts.append(zlib.decompress(payload.split(b'\0',1)[1][1:]))
      except (ValueError,zlib.error,IndexError):pass
     if kind==b'iTXt':
      try:
       bits=payload.split(b'\0',1);flag=bits[1][0];rest=bits[1][2:].split(b'\0',2)[2];texts.append(zlib.decompress(rest) if flag else rest)
      except (ValueError,zlib.error,IndexError):pass
    if kind==b'IEND':return texts
 except OSError:return texts
def _png_preview(path):
 for text in _png_texts(path):
  if re.search(rb'(?:["\s]|^)tier(?:["\s:=\x00]+)(?:preview|crop)(?:["\s\x00,}]|$)',text,re.I):return True
  if re.search(rb'(?:["\s]|^)test_only(?:["\s:=\x00]+)true(?:["\s\x00,}]|$)',text,re.I):return True
 return False
def _known_preview_hashes():
 found=builtins.set(); directory_flags={}
 def explicit_preview(p):
  directory=p.parent
  if directory not in directory_flags:
   directory_flags[directory]=False
   for meta in (directory/'identity.json',directory/'result.json',directory/'job_config.json'):
    try:
     if _declares_preview(json.loads(meta.read_text(encoding='utf-8'))): directory_flags[directory]=True;break
    except (OSError,ValueError,UnicodeError):pass
  if directory_flags[directory]:return True
  sidecar=p.with_suffix('.json')
  try:return _declares_preview(json.loads(sidecar.read_text(encoding='utf-8')))
  except (OSError,ValueError,UnicodeError):return False
 for base in (R/'work',R/'output'):
  if not base.exists():continue
  for p in base.rglob('*'):
   if p.is_file() and p.suffix.lower() in ('.jpg','.jpeg','.png','.webp') and (_preview_path(p) or explicit_preview(p)):
    found.add(digest(p))
 return found
def preview_reasons(path, known=None):
 path=Path(path);out=[]; known=_known_preview_hashes() if known is None else known
 # Walk recorded image/JSON provenance, with a conservative fail-closed limit.
 queue=[(path,0)];seen=builtins.set();max_depth=16;max_nodes=512
 def refs(v):
  if isinstance(v,dict):
   for x in v.values():yield from refs(x)
  elif isinstance(v,list):
   for x in v:yield from refs(x)
  elif isinstance(v,str) and v.lower().endswith(('.json','.png','.jpg','.jpeg','.webp')):
   p=Path(v);yield p if p.is_absolute() else R/p
 while queue:
  current,depth=queue.pop()
  current=current.resolve()
  if current in seen:continue
  if depth>max_depth or len(seen)>=max_nodes:
   out.append('provenance traversal limit exceeded');break
  seen.add(current)
  if not current.is_file() or not current.is_relative_to(R.resolve()):continue
  if _preview_path(current):out.append('preview provenance path: '+str(current))
  if current.suffix.lower() in ('.png','.jpg','.jpeg','.webp'):
   if _png_preview(current):out.append('PNG trial metadata: '+str(current))
   if digest(current) in known:out.append('matches known trial SHA-256: '+str(current))
   for meta in (current.with_suffix('.json'),current.parent/'result.json',current.parent/'identity.json'):
    if meta.is_file():queue.append((meta,depth+1))
   docs=[]
   for raw in _png_texts(current):
    try:
     text=raw.decode('utf-8');start=min((i for i in (text.find('{'),text.find('[')) if i>=0),default=-1)
     if start>=0:docs.append(json.loads(text[start:]))
    except (ValueError,UnicodeError):pass
  elif current.suffix.lower()=='.json':
   try:docs=[json.loads(current.read_text(encoding='utf-8'))]
   except (ValueError,OSError,UnicodeError):continue
  else:continue
  for doc in docs:
   if _declares_preview(doc):out.append('trial provenance: '+str(current))
   for ref in refs(doc):
    if ref.is_file():queue.append((ref,depth+1))
 return list(dict.fromkeys(out))
def issues(ident, data=None, manifest=None, visited=None):
 data=load() if data is None else data; manifest=rows() if manifest is None else manifest
 visited=builtins.set() if visited is None else visited
 if ident in visited: return ['dependency cycle']
 if ident not in data or ident not in manifest: return ['unknown deliverable']
 visited=visited|{ident}; v=data[ident]; row=manifest[ident]; out=[]
 if v.get('status')!='passed': out.append('not approved: '+str(v.get('status')))
 if v.get('review_round')!=CURRENT_ROUND: out.append('wrong review round')
 if v.get('reviewer')!='root': out.append('reviewer must be root')
 if row.get('dependency_status')=='待核实' and not (ident=='D02' and independent_sources_valid(row,v)): out.append('dependencies unresolved')
 if ident=='D02' and v.get('status')=='passed' and not independent_sources_valid(row,v): out.append('independent source reviews missing or invalid')
 p=Path(row['planned_path'])
 for ext in ('.jpg','.png'):
  f=p.with_suffix(ext)
  if not f.is_file() or v.get(ext[1:]+'_sha256')!=digest(f): out.append(ext+' missing or SHA-256 mismatch')
 if v.get('status')=='passed':
  known=_known_preview_hashes()
  for f in (p.with_suffix('.jpg'),p.with_suffix('.png')):
   out.extend(preview_reasons(f,known))
  expected=v.get('source_files_sha256')
  actual=source_files(row)
  if not isinstance(expected,dict) or builtins.set(expected)!=builtins.set(map(str,actual)):out.append('source file snapshot missing or changed')
  else:
   for f in actual:
    if not f.is_file() or expected[str(f)]!=digest(f):out.append('source file changed: '+str(f))
    else:out.extend(preview_reasons(f,known))
 for parent in deps(row):
  if issues(parent,data,manifest,visited): out.append('upstream not approved: '+parent)
  elif v.get('upstream_sha256',{}).get(parent)!={ext[1:]:digest(Path(manifest[parent]['planned_path']).with_suffix(ext)) for ext in ('.jpg','.png')}: out.append('upstream changed: '+parent)
 return out

def set(ident,status,reviewer,note,sha256=None,source_reviews=None):
 data=load(); manifest=rows()
 if ident not in data or ident not in manifest: raise KeyError(ident)
 if status not in ('passed','pending_recheck','visual_rejected','pending_review'): raise ValueError('invalid status')
 old=data[ident]; entry={'status':status,'review_round':CURRENT_ROUND,'reviewer':reviewer,'note':note,'reviewed_at_utc':datetime.now(timezone.utc).isoformat(),'previous_review':old}
 if status=='passed':
  if reviewer!='root': raise ValueError('reviewer must be root')
  if source_reviews is not None:
   if ident!='D02' or not isinstance(source_reviews,list): raise ValueError('source reviews are reserved for D02')
   entry['independent_sources']=source_reviews
   canonical=json.dumps(source_reviews,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
   entry['source_reviews_sha256']=hashlib.sha256(canonical).hexdigest()
  if manifest[ident].get('dependency_status')=='待核实' and not (ident=='D02' and independent_sources_valid(manifest[ident],entry)): raise ValueError('dependencies unresolved')
  if ident=='D02' and not independent_sources_valid(manifest[ident],entry): raise ValueError('independent source reviews missing or invalid')
  p=Path(manifest[ident]['planned_path'])
  if not isinstance(sha256,dict) or builtins.set(sha256)!={'jpg','png'}: raise ValueError('sha256 requires jpg and png')
  for ext in ('jpg','png'):
   f=p.with_suffix('.'+ext)
   if not f.is_file() or digest(f)!=sha256[ext]: raise ValueError(ext+' SHA-256 mismatch')
   entry[ext+'_sha256']=sha256[ext]
  known=_known_preview_hashes()
  for f in (p.with_suffix('.jpg'),p.with_suffix('.png'))+tuple(source_files(manifest[ident])):
   if not f.is_file():raise ValueError('source missing: '+str(f))
   reasons=preview_reasons(f,known)
   if reasons:raise ValueError('; '.join(reasons))
  entry['source_files_sha256']={str(f):digest(f) for f in source_files(manifest[ident])}
  entry['upstream_sha256']={}
  for parent in deps(manifest[ident]):
   if issues(parent,data,manifest): raise ValueError('upstream not approved: '+parent)
   entry['upstream_sha256'][parent]={ext:digest(Path(manifest[parent]['planned_path']).with_suffix('.'+ext)) for ext in ('jpg','png')}
 data[ident]=entry
 # Every source transition invalidates downstream approval, recursively.
 queue=[ident]; seen={ident}
 while queue:
  parent=queue.pop(0)
  for child,row in manifest.items():
   if parent in deps(row) and child not in seen:
    seen.add(child);queue.append(child);prior=data[child]
    data[child]={'status':'visual_rejected' if status=='visual_rejected' else 'pending_recheck','review_round':CURRENT_ROUND,'reviewer':reviewer,'note':'cascade from '+ident,'previous_review':prior}
 QA.parent.mkdir(parents=True,exist_ok=True)
 fd,tmp=tempfile.mkstemp(dir=QA.parent,prefix='.qa_')
 try:
  with os.fdopen(fd,'w',encoding='utf-8') as f: json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n')
  os.replace(tmp,QA)
 finally:
  if os.path.exists(tmp): os.unlink(tmp)

def render_status():
 data=load(); manifest=rows(); counts=Counter(v.get('status') for v in data.values())
 def cell(x): return str(x or '').replace('|','\\|').replace('\n',' ')
 lines=['# 当前状态（脚本生成）','','审核轮次：'+CURRENT_ROUND+'。技术检查与 root 视觉审核分别记录；文件存在不代表视觉通过。','', '## 审核统计','']
 lines.extend('- '+k+': '+str(v) for k,v in sorted(counts.items()))
 lines.extend(['','## 交付项明细','','| 交付项 | 视觉状态 | 文件检查 | 审核门禁 | 备注 |','|---|---|---|---|---|'])
 for ident,row in manifest.items():
  v=data.get(ident,{});path=Path(row['planned_path']); missing=[ext for ext in ('jpg','png') if not path.with_suffix('.'+ext).is_file()]
  mechanical='缺少 '+','.join(missing) if missing else 'JPG/PNG 均存在（未替代完整机械校验）'
  blocked=issues(ident,data,manifest)
  lines.append('| '+cell(ident)+' | '+cell(v.get('status','缺记录'))+' | '+cell(mechanical)+' | '+cell('待核：'+'; '.join(blocked) if blocked else '通过')+' | '+cell(v.get('note'))+' |')
 validation=R/'output/LISTING_V3/w1125/validation.json'
 if validation.is_file():
  check=json.loads(validation.read_text(encoding='utf-8'));stamp=datetime.fromtimestamp(validation.stat().st_mtime,timezone.utc).isoformat()
  lines.extend(['','## 最近机械校验','','记录时间（UTC）：'+stamp+'；mechanical_ok：'+str(check.get('mechanical_ok','未记录'))+'；错误数：'+str(len(check.get('errors',[])))+'。此历史记录可能早于当前文件或审核状态，不能代替复验。'])
 measurements=sorted((R/'work').rglob('measurements.json'),key=lambda p:p.stat().st_mtime,reverse=True); latest={}
 for path in measurements:
  try:
   m=json.loads(path.read_text(encoding='utf-8')); jobpath=path.parent/'job_config.json'; job=json.loads(jobpath.read_text(encoding='utf-8')) if jobpath.is_file() else {}
   tier=m.get('tier') or job.get('tier')
   if tier not in ('preview','final','crop'):
    parts={x.lower() for x in path.parts}; tier=next((x for x in ('preview','final','crop') if x in parts),'未标明档位')
   if tier not in latest:latest[tier]=(path,m)
  except (OSError,ValueError,TypeError): continue
 lines.extend(['','## 最近运行测量',''])
 if not latest: lines.append('暂无测量记录。')
 for tier,(path,m) in latest.items():
  duration=next((m[k] for k in ('wall_seconds','elapsed_seconds','backend_wall_seconds') if m.get(k) is not None),'未记录')
  lines.append('- '+tier+'：`'+str(path.relative_to(R))+'`；状态 '+str(m.get('status','未记录'))+'；耗时 '+str(duration)+' 秒。')
 lines.extend(['','## 视频素材交接',''])
 batches=sorted((R/'exchange').glob('*/batch_*')) if (R/'exchange').exists() else []
 if not batches: lines.append('尚无本地交接批次。')
 for batch in batches:
  if not batch.is_dir():continue
  ready_file=batch/'READY.json'; manifest_file=batch/'manifest.json'; receipt=batch/'receive_report_from_B.json'
  try:
   ready=json.loads(ready_file.read_text(encoding='utf-8')); actual=digest(manifest_file)
   if ready.get('batch_id')!=batch.name or ready.get('manifest_sha256')!=actual: raise ValueError('READY 与清单不一致')
   state='本地 READY，清单哈希一致；文件数 '+str(ready.get('file_count','未记录'))+'；总字节 '+str(ready.get('total_bytes','未记录'))
  except (OSError,ValueError,TypeError,AttributeError):state='本地批次未就绪或 READY / 清单无效'
  if receipt.is_file():
   try: valid=receipt_valid(batch,json.loads(ready_file.read_text(encoding='utf-8')),manifest_file,receipt)
   except (OSError,ValueError,TypeError): valid=False
   received='B 机回执已存档，回执内容校验通过' if valid else 'B 机回执已存档，回执内容校验未通过，接收尚未确认'
  else: received='未发现 B 机回执，接收尚未确认'
  lines.append('- `'+str(batch.relative_to(R))+'`：'+state+'；'+received+'。')
 lines.extend(['','运行数据历史见 [背景与融合测试](archive/20261103/背景与融合测试_20261103.md)。',''])
 (R/'docs/STATUS.md').write_text('\n'.join(lines),encoding='utf-8')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--render-status',action='store_true');p.add_argument('--set',dest='ident');p.add_argument('--status',choices=('passed','pending_recheck','visual_rejected','pending_review'));p.add_argument('--reviewer');p.add_argument('--note');p.add_argument('--jpg-sha256');p.add_argument('--png-sha256');p.add_argument('--source-reviews',type=Path,help='JSON list of root source review records');a=p.parse_args()
 if a.ident:
  if not a.status or not a.reviewer or not a.note or not a.note.strip(): p.error('--set requires --status, --reviewer and nonempty --note')
  hashes={'jpg':a.jpg_sha256,'png':a.png_sha256} if a.status=='passed' else None
  source_reviews=json.loads(a.source_reviews.read_text(encoding='utf-8')) if a.source_reviews else None
  set(a.ident,a.status,a.reviewer,a.note,hashes,source_reviews)
 elif any((a.status,a.reviewer,a.note,a.jpg_sha256,a.png_sha256,a.source_reviews)): p.error('review options require --set')
 if a.render_status: render_status()
 if not a.ident and not a.render_status: p.error('specify --set or --render-status')
