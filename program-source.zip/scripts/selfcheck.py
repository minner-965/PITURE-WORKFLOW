"""Deterministic fixtures only; never counts as real product or FLUX inference acceptance."""
import json,sys,subprocess,time
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from prepare_inputs import prepare
from build_masks import masks
from restore_and_check import restore
from make_white_and_sku import make
from comfy_client import ComfyClient,sync_ui
ROOT=Path(__file__).resolve().parents[1]
def main():
    out=ROOT/'work/diagnostics/selfcheck';out.mkdir(exist_ok=True)
    im=Image.new('RGB',(600,400),'#d0d0d0');ImageDraw.Draw(im).rectangle((130,120,470,320),fill='#4b6580');im.save(out/'fixture.png');base=prepare(out/'fixture.png',out/'base')
    b=Image.new('L',(1024,1024));ImageDraw.Draw(b).rectangle((220,350,800,850),fill=255);b.save(out/'bowl.png');i=Image.new('L',(1024,1024));ImageDraw.Draw(i).ellipse((280,380,740,570),fill=255);i.save(out/'inner.png')
    maskreport=masks(base,out/'bowl.png',out/'inner.png',out/'masks');Image.new('RGB',(1024,1024),'#ff4400').save(out/'generated_fixture.png');check=restore(base,out/'generated_fixture.png',out/'masks/paste_mask.png',out/'masks/core_mask.png',out/'fixture_master.png');white=make(out/'masks/empty_bowl_cutout.png',out/'layout','测试素材 · 非商品验收')
    bad=Image.new('L',(1024,1024),255);bad.save(out/'invalid_inner.png')
    try:masks(base,out/'bowl.png',out/'invalid_inner.png',out/'invalid');raise AssertionError('Outside-inner not rejected')
    except ValueError:pass
    edited=Image.open(base).convert('RGBA');edited.putalpha(Image.open(out/'masks/paint_mask.png'));edited.save(out/'edited_mask_fixture.png')
    client=ComfyClient();api=json.loads((ROOT/'workflows/B_manual_masks.api.json').read_text());api['1']['inputs']['image']=client.upload(out/'edited_mask_fixture.png');api['16']['inputs']['filename_prefix']='ComfyProductPipeline/selfcheck_not_product/mask';ui=sync_ui(api,json.loads((ROOT/'workflows/B_manual_masks.ui.json').read_text()),client.get('/object_info'))
    q=client.get('/queue')
    if q['queue_running'] or q['queue_pending']:raise RuntimeError('Other queue work present')
    pid=int(subprocess.check_output(['lsof','-t','-nP','-iTCP:8188','-sTCP:LISTEN'],text=True).strip());prompt_id=client.submit(api,ui,out/'submission.json');history,measure=client.wait(prompt_id,out/'api',pid,120);files=client.download(history,out/'api');image=Image.open(files['16'][0]);metadata_workflow=json.loads(image.info['workflow'])
    assert metadata_workflow['nodes'] and image.size==(1024,1024)
    (out/'report.json').write_text(json.dumps(dict(status='pass',scope='Synthetic deterministic and B mask export API selfcheck only. NO FLUX model inference; NOT product acceptance.',masks=maskreport,pixel_check=check,white=white,api=measure,png_workflow_metadata=True,invalid_mask_rejected=True),ensure_ascii=False,indent=2))
    print('PASS: preprocess, masks, core diff=0, white/SKU font, invalid mask rejection, B API execution, PNG UI metadata roundtrip. FLUX/product unverified.')
if __name__=='__main__':main()
