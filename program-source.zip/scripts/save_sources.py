import json
from pathlib import Path
import requests
ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'docs/model_sources';out.mkdir(exist_ok=True)
records=[]
for cache in (ROOT/'work/diagnostics/upstream').glob('*.json'):
    data=json.loads(cache.read_text());repo=data['id'];revision=data['sha']
    names=[s['rfilename'] for s in data['siblings'] if s['rfilename'].lower() in ['license','license.md','license.txt','readme.md']]
    for name in names:
        url=f'https://huggingface.co/{repo}/resolve/{revision}/{name}'
        try:
            r=requests.get(url,timeout=30);r.raise_for_status();p=out/(repo.replace('/','__')+'__'+name);p.write_bytes(r.content);records.append(dict(repo=repo,revision=revision,url=url,local=str(p),status='saved'))
        except requests.RequestException as e:records.append(dict(repo=repo,revision=revision,url=url,status='unavailable',error=str(e)))
(out/'sources.json').write_text(json.dumps(records,ensure_ascii=False,indent=2));print('Saved source/license records:',len(records))
