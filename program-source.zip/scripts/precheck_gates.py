#!/usr/bin/env python3
"""Mechanical screening; incomplete checks are never accepted as passing."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
import numpy as np
from PIL import Image,ImageFilter
from prompt_rules import lint_prompt
CHECKS=('dimensions_mode','protected_diff','white_edge','edge_diagnostics','background_text','liquid_level','prompt_lint')
p=argparse.ArgumentParser();p.add_argument('--required-checks',nargs='+',choices=CHECKS,default=None,help='Checks whose incomplete result blocks; any flag always blocks');p.add_argument('--image',required=True);p.add_argument('--baseline');p.add_argument('--protect-mask');p.add_argument('--edge-baseline');p.add_argument('--edge-mask');p.add_argument('--background-mask');p.add_argument('--rim-mask');p.add_argument('--food-mask');p.add_argument('--out',required=True);p.add_argument('--expected-size',nargs=2,type=int,default=[1024,1024],metavar=('W','H'));p.add_argument('--liquid-annotations');p.add_argument('--prompt');p.add_argument('--region-type',choices=('food','background'));p.add_argument('--roi',nargs=4,type=int,metavar=('X0','Y0','X1','Y1'));a=p.parse_args()
out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
im=Image.open(a.image);rgb=np.asarray(im.convert('RGB'));h,w=rgb.shape[:2]
report={'image':a.image,'visual_review':'required','checks':{}}
c=report['checks'];
if a.prompt is not None and a.region_type:
 verdict=lint_prompt(a.region_type,a.prompt);c['prompt_lint']={'status':'flag' if verdict['errors'] else 'pass',**verdict}
else:c['prompt_lint']={'status':'incomplete','reason':'prompt and region type required together'}
c['dimensions_mode']={'status':'pass' if im.size==tuple(a.expected_size) and im.mode in ('RGB','RGBA') else 'flag','size':list(im.size),'mode':im.mode,'expected_size':a.expected_size,'expected_modes':['RGB','RGBA']}
def mask(path):
 m=Image.open(path).convert('L')
 if m.size!=im.size:raise ValueError('mask size mismatch')
 return np.asarray(m)>127
def bright(x):
 x=x.astype(float)/255;mx=x.max(axis=2);mn=x.min(axis=2);return (mx>.9)&((mx-mn)/np.maximum(mx,1e-9)<.08)
if a.baseline and a.protect_mask:
 base=Image.open(a.baseline).convert('RGB')
 if base.size!=im.size:raise ValueError('baseline size mismatch')
 protected_base=np.asarray(base);protected=mask(a.protect_mask);d=np.abs(rgb.astype(int)-protected_base.astype(int));n=int(np.any(d[protected]!=0,axis=1).sum());c['protected_diff']={'status':'pass' if protected.any() and n==0 else 'flag','pixels':int(protected.sum()),'different_pixels':n,'threshold':0,'baseline':a.baseline,'mask':a.protect_mask}
else:c['protected_diff']={'status':'incomplete','reason':'baseline and protect mask required'}
edge_baseline=a.edge_baseline if a.edge_baseline is not None else a.baseline
edge_mask=a.edge_mask if a.edge_mask is not None else a.protect_mask
if edge_baseline and edge_mask:
 base=Image.open(edge_baseline).convert('RGB')
 if base.size!=im.size:raise ValueError('edge baseline size mismatch')
 b=np.asarray(base);m=mask(edge_mask);pil=Image.fromarray((m*255).astype('uint8'));outer=np.asarray(pil.filter(ImageFilter.MaxFilter(7)))>0;ring=outer & ~m
 nring=int(ring.sum());pr=float(bright(rgb)[ring].mean()) if nring else None;br=float(bright(b)[ring].mean()) if nring else None
 c['white_edge']={'status':('incomplete' if not nring or br>.30 else 'flag' if pr>br else 'pass'),'candidate_ratio':pr,'baseline_ratio':br,'threshold_excess':0,'ring_pixels':nring,'ring_width_px':[1,3],'brightness_min':.9,'saturation_max':.08,'baseline_reliability_max':.30,'baseline':edge_baseline,'mask':edge_mask}
 if nring and br>.30:c['white_edge'].update(calibration_required=True,reason='Baseline bright fraction exceeds 0.30; this comparison cannot reliably assess white edges.')
 elif not nring:c['white_edge']['reason']='No boundary ring pixels'
 if nring:
  ys,xs=np.nonzero(ring);box=(max(0,int(xs.min())-5),max(0,int(ys.min())-5),min(w,int(xs.max())+6),min(h,int(ys.max())+6));im.crop(box).resize(((box[2]-box[0])*4,(box[3]-box[1])*4)).save(out/'edge_4x.png');c['white_edge']['crop_xyxy']=box
 region=np.ones((h,w),dtype=bool)
 if a.roi:
  x0,y0,x1,y1=a.roi
  if not (0<=x0<x1<=w and 0<=y0<y1<=h):raise ValueError('ROI outside image')
  region[:]=False;region[y0:y1,x0:x1]=True
 def erode(n):return np.asarray(pil.filter(ImageFilter.MinFilter(2*n+1)))>0
 inner13=(m & ~erode(3)) & region
 inner58=(erode(4) & ~erode(8)) & region
 def stats(area):
  if not area.any():return {'pixels':0}
  return {'pixels':int(area.sum()),'candidate_white_fraction':float(bright(rgb)[area].mean()),'baseline_white_fraction':float(bright(b)[area].mean()),'mean_abs_rgb_diff':float(np.abs(rgb.astype(float)-b.astype(float))[area].mean())}
 c['edge_diagnostics']={'status':'incomplete','reason':'Exploratory measurements have no calibrated decision threshold; inner white can be real bowl material.','roi':a.roi,'inner_1_3_px':stats(inner13),'inner_5_8_px':stats(inner58)}
else:
 c['white_edge']={'status':'incomplete','reason':'edge baseline and edge mask required'}
 c['edge_diagnostics']={'status':'incomplete','reason':'edge baseline and edge mask required'}
if a.background_mask:
 try:
  bg=mask(a.background_mask);r=subprocess.run(['swift',str(Path(__file__).with_name('vision_ocr.swift')),a.image],capture_output=True,text=True,check=True);rows=json.loads(r.stdout);hits=[]
  for v in rows:
   x,y,bw,bh=v['bbox_normalized_bottom_left'];x0=max(0,int(x*w));x1=min(w,int((x+bw)*w)+1);y0=max(0,int((1-y-bh)*h));y1=min(h,int((1-y)*h)+1);portion=bg[y0:y1,x0:x1];v['background_fraction']=float(portion.mean()) if portion.size else 0
   if v['background_fraction']>.5:hits.append(v)
  c['background_text']={'status':'flag' if hits else 'pass','hits':hits,'all_observations':rows,'threshold_background_fraction':.5}
 except Exception as e:c['background_text']={'status':'incomplete','reason':str(e)}
else:c['background_text']={'status':'incomplete','reason':'background mask required'}
c['liquid_level']={'status':'incomplete','reason':'Actual food surface is not segmented; a paint mask is an edit region and cannot measure the food surface. Rim and actual food segmentation plus calibration are required.','threshold_fraction_of_rim_height':.08,'detection_scope':'not measured'}
if a.liquid_annotations:
 try:
  ann=json.loads(Path(a.liquid_annotations).read_text());items=[]
  if ann.get('image_sha256')!=hashlib.sha256(Path(a.image).read_bytes()).hexdigest():raise ValueError('Annotation image hash mismatch')
  for item in ann['bowls']:
   rim=item['rim_inner_line'];food=item['food_surface_line'];height=float(item['rim_height_px'])
   if item.get('reviewer')!='root' or height<=0 or len(rim)<2 or len(food)<2:raise ValueError('Each bowl needs root-reviewed rim and food lines and positive rim height')
   for points in (rim,food):
    if any(len(pt)!=2 or not (0<=pt[0]<w and 0<=pt[1]<h) for pt in points):raise ValueError('Line points must be full-image coordinates')
    if any(points[i][0]>=points[i+1][0] for i in range(len(points)-1)):raise ValueError('Line x coordinates must increase')
   start=max(rim[0][0],food[0][0]);end=min(rim[-1][0],food[-1][0]);xs=np.arange(start,end+1)
   if not len(xs):raise ValueError('Lines must overlap in x')
   delta=np.interp(xs,*zip(*food))-np.interp(xs,*zip(*rim));minimum=float(delta.min());threshold=.08*height
   items.append({'id':item['id'],'minimum_vertical_gap_px':minimum,'rim_height_px':height,'threshold_px':threshold,'status':'flag' if minimum<threshold else 'pass','overlap_x':[int(start),int(end)]})
  if not items:raise ValueError('At least one bowl required')
  c['liquid_level']={'status':'flag' if any(v['status']=='flag' for v in items) else 'pass','bowls':items,'detection_scope':'root-annotated visible line overlap only; vertical pixel gap; not a full surface or automatic food segmentation','threshold_fraction_of_rim_height':.08}
 except Exception as e:c['liquid_level']={'status':'incomplete','reason':str(e)}
required=list(dict.fromkeys(a.required_checks if a.required_checks is not None else CHECKS))
flags=[name for name,v in c.items() if v['status']=='flag']
incomplete=[name for name in required if c[name]['status']=='incomplete']
report.update(required_checks=required,flagged_checks=flags,required_incomplete=incomplete,nonrequired_incomplete=[name for name,v in c.items() if name not in required and v['status']=='incomplete'])
report['status']='flag' if flags else 'incomplete' if incomplete else 'pass'
report['exit_code']=2 if flags else 3 if incomplete else 0
(out/'precheck.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2));sys.exit(report['exit_code'])
