#!/usr/bin/env python3
"""Prepare one reviewable food-mask comparison; never performs inference."""
import argparse,hashlib,json
from pathlib import Path
import numpy as np
from PIL import Image,ImageFilter,ImageOps
p=argparse.ArgumentParser();p.add_argument('--mother',required=True);p.add_argument('--original',required=True);p.add_argument('--old-mask',required=True);p.add_argument('--out',required=True);p.add_argument('--level-drop',type=float,required=True,choices=(.10,.15));p.add_argument('--rim-guard',type=int,default=4);p.add_argument('--feather',type=int,default=3);a=p.parse_args()
if not 0<=a.rim_guard<=10 or not 0<=a.feather<=6:raise ValueError('guard or feather out of supported range')
out=Path(a.out);out.mkdir(parents=True,exist_ok=True);mother=Image.open(a.mother).convert('RGB');original=Image.open(a.original).convert('RGB');old=Image.open(a.old_mask).convert('L')
if mother.size!=(1024,1024) or original.size!=mother.size or old.size!=mother.size:raise ValueError('inputs must share 1024 coordinates')
oldarr=np.asarray(old);binary=oldarr>0;ys,xs=np.nonzero(binary)
if not len(xs):raise ValueError('empty old mask')
short_height=int(ys.max()-ys.min()+1); drop=round(short_height*a.level_drop);mask=Image.fromarray((binary*255).astype('uint8'));guard=np.asarray(mask.filter(ImageFilter.MinFilter(2*a.rim_guard+1)))>0 if a.rim_guard else binary.copy();guard[:int(ys.min())+drop,:]=False
# Blur inward only: no paint leaks outside the guarded area.
inner=Image.fromarray((guard*255).astype('uint8'));feather=np.asarray(inner.filter(ImageFilter.GaussianBlur(a.feather)),dtype=np.uint8).copy();feather[~guard]=0
if not feather.any():raise ValueError('empty new mask')
restore=binary & (feather==0);M=np.asarray(mother).copy();Orig=np.asarray(original);M[restore]=Orig[restore];Image.fromarray(M).save(out/'common_base.png');Image.fromarray((restore*255).astype('uint8')).save(out/'restore_mask.png')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name,m in [('old',oldarr),('new',feather)]:
 im=Image.fromarray(m);im.save(out/f'{name}_mask.png');ImageOps.invert(im).save(out/f'{name}_inverse.png');core=m==0;Image.fromarray((core*255).astype('uint8')).save(out/f'{name}_core.png');layer=Image.new('RGBA',mother.size,(255,0,0,0));layer.putalpha(im.point(lambda v:round(v*.44)));overlay=Image.alpha_composite(Image.fromarray(M).convert('RGBA'),layer);blue=Image.new('RGBA',mother.size,(0,150,255,0));blue.putalpha(Image.fromarray((restore*120).astype('uint8')));Image.alpha_composite(overlay,blue).convert('RGB').save(out/f'{name}_overlay.png')
core=~restore;record={'mother':str(Path(a.mother).resolve()),'mother_sha256':sha(a.mother),'original':str(Path(a.original).resolve()),'original_sha256':sha(a.original),'old_mask':str(Path(a.old_mask).resolve()),'old_mask_sha256':sha(a.old_mask),'base_sha256':sha(out/'common_base.png'),'old_mask_bbox':[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)],'bbox_short_axis_height_px':short_height,'level_drop_fraction':a.level_drop,'level_drop_px':drop,'rim_guard_px':a.rim_guard,'feather_radius_px':a.feather,'restored_pixels':int(restore.sum()),'protected_outside_restore_differing_pixels':int(np.any(M[core]!=np.asarray(mother)[core],axis=1).sum()),'original_restore_max_difference':int(np.abs(M[restore].astype(int)-Orig[restore].astype(int)).max()) if restore.any() else None,'limitations':'Drop uses food-mask bbox height as proxy for inner-rim short axis; root must assess actual geometry. Feather is inward clipped. Common base intentionally used for both comparison branches.','review':'pending_root'};(out/'evidence.json').write_text(json.dumps(record,indent=2,ensure_ascii=False));print(out)
