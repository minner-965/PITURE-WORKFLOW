#!/usr/bin/env python3
"""Refresh the listing-v3 run record from existing submission/result logs only."""
import csv,json
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
R=Path(__file__).resolve().parents[1];LOG=R/'work/logs/listing_v3';DOC=R/'docs';csvpath=DOC/'LISTING_V3_实际运行记录.csv';mdpath=DOC/'LISTING_V3_实际运行记录.md'
def read(p):
 try:return json.loads(p.read_text())
 except (FileNotFoundError,json.JSONDecodeError):return {}
def val(x):return '未记录' if x is None or x=='' else str(x)
rows=[]
for sub in sorted([*LOG.rglob('submission.json'),*(R/'work/logs/whole_photo_v5').rglob('submission.json'),*(R/'work/diagnostics/whole_photo_v5').rglob('submission.json')]):
 d=read(sub);pid=d.get('prompt_id')
 if not pid:continue
 folder=sub.parent;m=read(folder/'measurements.json');r=read(folder/'result.json');h=read(folder/'history.json');g=d.get('request',{}).get('prompt',{})
 identity=r.get('identity') or read(folder/'identity.json');settings=identity.get('settings',{});regions=identity.get('regions',[]);stage_kind=r.get('stage_kind') or identity.get('stage_kind') or ('q6_inference' if any(n.get('class_type')=='KSampler' for n in g.values()) else 'unclassified_non_q6')
 context='未记录';canvas='未记录'
 if folder.is_relative_to(R/'work/logs/whole_photo_v5'):
  if settings.get('width') and settings.get('height'):canvas=f"{settings['width']}×{settings['height']}"
  if identity.get('crop_context'):
   c=identity['crop_context'];context=f"crop_rescaled_1024: x={c['x']}, y={c['y']}, {c['width']}×{c['height']} → 采样 {c['sampling_width']}×{c['sampling_height']}"
  elif regions:context='regional_cropped: '+', '.join(f"{x.get('index','?')}={x['area']['width']}×{x['area']['height']}" for x in regions if isinstance(x.get('area'),dict) and 'width' in x['area'] and 'height' in x['area'])
  elif any(x.get('class_type')=='ConditioningSetArea' for x in g.values()):context='regional_cropped: '+', '.join(f"{x['inputs']['width']}×{x['inputs']['height']}" for x in g.values() if x.get('class_type')=='ConditioningSetArea')
  elif any(x.get('class_type')=='KSampler' for x in g.values()) and settings.get('width')==1024 and settings.get('height')==1024:context='full_frame_1024'
 sampler=next((x.get('inputs',{}) for x in g.values() if x.get('class_type')=='KSampler'),{});guidance=next((x.get('inputs',{}).get('guidance') for x in g.values() if x.get('class_type')=='FluxGuidance'),None);model=next((x.get('inputs',{}).get('unet_name') for x in g.values() if x.get('class_type')=='UnetLoaderGGUF'),None)
 ini=m.get('initial') or d.get('timing',{}).get('initial',{});end=m.get('final',{});outs=r.get('outputs',{});best=outs.get('exact') or outs.get('restored') or {};output=r.get('selected_output') or r.get('output') or (best.get('path') if isinstance(best,dict) else None);raw_status=r.get('raw_visual_status');visual=r.get('status') if r.get('status') in ('passed','visual_rejected','visual_rework','partial_visual_rework') else '待审'
 if stage_kind=='deterministic_original_restore':canvas='1024×1024';context='原片恢复，无模型；无采样上下文'
 samples=[];samplefile=folder/'memory_samples.jsonl'
 if samplefile.is_file():
  for line in samplefile.read_text().splitlines():
   try:samples.append(json.loads(line))
   except json.JSONDecodeError:continue
 rss=[x.get('rss_kib')*1024 for x in samples if isinstance(x.get('rss_kib'),(int,float))];swap=[x.get('swap_used_bytes') for x in samples if isinstance(x.get('swap_used_bytes'),(int,float))];pressure=[x.get('vm_pressure_level_raw') for x in samples if isinstance(x.get('vm_pressure_level_raw'),(int,float))]
 if raw_status:visual='原始'+raw_status+'；派生'+visual
 job=folder.parent.name if folder.parent.parent.name=='whole_photo_v5' or folder.name.startswith('attempt_') else folder.name
 failure=read(folder/'failure.json');technical=('success_after_exact_recovery' if failure.get('resolved_by') and r.get('status') in ('awaiting_root_visual_review','passed') else ('postprocess_check_failed' if failure and m.get('status')=='success' else (m.get('status') or h.get('status',{}).get('status_str') or ('failed' if failure else d.get('status','进行中/未记录')))))
 row=dict(stage_kind=stage_kind,job=job,attempt=folder.name,prompt_id=pid,output_canvas=canvas,sampling_context=context,model=model,seed=sampler.get('seed'),steps=sampler.get('steps'),cfg=sampler.get('cfg'),guidance=guidance,sampler=sampler.get('sampler_name'),scheduler=sampler.get('scheduler'),technical_status=technical,visual_status=visual,backend_seconds=m.get('backend_wall_seconds') if m.get('backend_wall_seconds') is not None else m.get('wall_seconds'),rss_start_bytes=ini.get('rss_kib')*1024 if ini.get('rss_kib') is not None else None,rss_end_bytes=end.get('rss_kib')*1024 if end.get('rss_kib') is not None else None,rss_peak_sampled_bytes=m.get('rss_peak_sampled_bytes') if m.get('rss_peak_sampled_bytes') is not None else max(rss,default=None),swap_peak_sampled_bytes=max(swap,default=None),pressure_peak_raw=max(pressure,default=None),pressure_critical_samples=sum(v==4 for v in pressure) if pressure else None,sample_count=len(samples),swap_start_bytes=ini.get('swap_used_bytes'),swap_end_bytes=end.get('swap_used_bytes'),swap_delta_bytes=m.get('swap_delta_bytes'),pressure_start_raw=ini.get('vm_pressure_level_raw'),pressure_end_raw=end.get('vm_pressure_level_raw'),pressure_start_report=ini.get('memory_pressure'),pressure_end_report=end.get('memory_pressure'),output=output,provenance=r.get('selected_output_provenance'),result_path=str(folder/'result.json') if (folder/'result.json').is_file() else '',measurement_path=str(folder/'measurements.json') if (folder/'measurements.json').is_file() else '',history_path=str(folder/'history.json') if (folder/'history.json').is_file() else '')
 rows.append({k:val(v) for k,v in row.items()})
if not rows:raise SystemExit('No recorded prompt IDs')
for x in rows:
 if x['stage_kind']=='deterministic_original_restore':
  for k in ('model','seed','steps','cfg','guidance','sampler','scheduler'):x[k]='不适用'
with csvpath.open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
lines=['# LISTING V3 实际运行记录','',f"刷新时间：{datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()}。范围为 `work/logs/listing_v3`、`work/logs/whole_photo_v5` 和 `work/diagnostics/whole_photo_v5` 中具有真实 prompt_id 的提交；在跑任务的最终结果以完成后刷新为准。",'',f"已记录真实提交 {len(rows)} 次：Q6 推理 {sum(x['stage_kind']=='q6_inference' for x in rows)} 次；原片恢复/无模型 {sum(x['stage_kind']=='deterministic_original_restore' for x in rows)} 次（不计 Q6 推理）。仅 prepare 的草稿不计提交；技术状态与视觉决定分别列出。既有橙白米粥复用自前轮，不计入本轮新增提交。",'','| 阶段类型 | 任务 / attempt | prompt_id | Q6 参数：seed / steps / cfg / guidance / sampler | 输出画布 / 采样上下文 | 技术状态 | 原图/选中图视觉状态 | 后端秒 | RSS起 / 止 / 采样峰（字节） | 系统swap起 / 止 / 差 / 采样峰（字节） | 系统压力原始值起 / 止 / 采样峰；critical次数 |','|---|---|---|---|---|---|---|---:|---:|---|---|']
for x in rows:
 lines.append(f"| {'原片恢复/无模型' if x['stage_kind']=='deterministic_original_restore' else ('Q6推理' if x['stage_kind']=='q6_inference' else x['stage_kind'])} | {x['job']} / {x['attempt']} | {x['prompt_id']} | {x['seed']} / {x['steps']} / {x['cfg']} / {x['guidance']} / {x['sampler']}-{x['scheduler']} | {x['output_canvas']} / {x['sampling_context']} | {x['technical_status']} | {x['visual_status']} | {x['backend_seconds']} | {x['rss_start_bytes']} / {x['rss_end_bytes']} / {x['rss_peak_sampled_bytes']} | {x['swap_start_bytes']} / {x['swap_end_bytes']} / {x['swap_delta_bytes']} / {x['swap_peak_sampled_bytes']} | {x['pressure_start_raw']} / {x['pressure_end_raw']} / {x['pressure_peak_raw']}；{x['pressure_critical_samples']} |")
lines+=['','各提交的实际模型名称、压力原始文字、源 result/measurements/history 路径和输出路径见同名 CSV；记录缺失标注“未记录”。输出画布尺寸与采样上下文分开记录：regional_cropped 为各区域裁切上下文，crop_rescaled_1024 为裁切后等比放大采样，full_frame_1024 为整幅上下文；前者耗时不可当作完整1024模型上下文的同等基准。背景 EmptyImage 的尺寸可从对应 submission 图核对。','', 'RSS 为后端进程采样峰值，不是 MPS 总统一内存；MPS allocator/driver峰值未记录。swap 为系统全局数据，并非该进程独占。压力采样也为系统级；原始数字和文字见 CSV 与每次 measurements.json。','', '原始 BG01 与 BG01_r2 均退回；BG01_r2 的确定性清理派生版本及 BG02_dessert_masked 曾经通过，后因最终场景真实感不合格撤回，当前均为 visual_rejected。旧蓝色皮蛋粥退回，新的蓝色任务以其各自 result 为准。whole_photo 首次全食品图因内容相似退回，首次新背景因额外假碗退回；七区域结果为 partial_visual_rework，后续两绿碗修复以对应任务记录为准。历史证据保留，审核状态不能由技术成功推断。','', '## 模型哈希与来源','', '原始模型路径及 SHA-256 依据 `work/diagnostics/model_inventory.json`，每次实际记录有模型哈希时也保留于对应 result.json；不重新推断或改写其来源。','']
models=read(R/'work/diagnostics/model_inventory.json').get('models',[])
for model in models:
 if model.get('sha256'):lines.append(f"- `{model.get('path')}`：`{model['sha256']}`")
lines+=['','## 当前交付状态与历史候选','']
lines+=['历史退回素材（未用于当前交付，不构成当前待办）：旧布局引用的 green_corn_rib_soup、yellow_tremella 及旧 BG01/BG02 等候选，保留其提交与退回记录供追溯。','']
import qa_state
from validate_delivery import validate_whole,validate_cards
manifest=R/'delivery_manifest.csv';approvals=read(R/'config/qa_approvals.json')
with manifest.open(encoding='utf-8-sig',newline='') as f:deliverables=list(csv.DictReader(f))
missing=[];review=[];rejected=[];invalid_provenance=[];passed_count=0
for item in deliverables:
 path=Path(item['planned_path']);ident=item['deliverable_id'];entry=approvals.get(ident,{}) if isinstance(approvals,dict) else {}
 approved=not qa_state.issues(ident)
 if not path.is_file():missing.append(ident)
 elif isinstance(entry,dict) and entry.get('status')=='visual_rejected':rejected.append(ident)
 elif not approved:review.append(ident)
 else:
  try:
   meta=path.with_suffix('.json')
   if ident in ('MAIN_01','MAIN_02','MAIN_03','MAIN_04','D01','D08'):
    if not meta.is_file():raise ValueError('缺少场景来源记录')
    data=read(meta)
    if 'export_transform' not in data or 'native_generation_size' not in data:raise ValueError('非当前实拍场景来源格式')
    validate_whole(data,path.with_suffix('.png'),path.with_suffix('.jpg'),ident)
   elif ident=='D02':validate_cards(read(meta))
   if isinstance(entry,dict):
    import hashlib
    for ext,key in (('.jpg','jpg_sha256'),('.png','png_sha256')):
     if entry.get(key) and hashlib.sha256(path.with_suffix(ext).read_bytes()).hexdigest()!=entry[key]:raise ValueError(key+' 审核哈希不一致')
   passed_count+=1
  except (OSError,ValueError,KeyError,TypeError,IndexError) as e:invalid_provenance.append(f'{ident} ({e})')
def section(label,missing,review,rejected=()):
 if missing:lines.append(f"- {label}文件未生成或缺失：{', '.join(missing)}。")
 if review:lines.append(f"- {label}已生成、待 root 审核：{', '.join(review)}。")
 if rejected:lines.append(f"- {label}已生成、视觉退回：{', '.join(rejected)}。")
lines.append(f'- 最终成品已通过：{passed_count}/{len(deliverables)}；依据 manifest 路径、root QA 和当前实拍来源链校验。')
section('最终成品',missing,review,rejected)
if invalid_provenance:lines.append('- 最终成品来源链或审核哈希待核：'+'；'.join(invalid_provenance)+'。')
if not any([missing,review,rejected,invalid_provenance]):lines.append('当前清单所列最终成品均有文件、审核和有效来源记录。')
lines+=['', '刷新：使用项目既有 Python 执行 `scripts/summarize_listing_v3.py`。历史任务及失败材料不覆盖。']
mdpath.write_text('\n'.join(lines)+'\n');print(f'{len(rows)} submissions recorded; {csvpath}; {mdpath}')
