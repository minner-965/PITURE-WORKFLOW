import torch
import torch.nn.functional as F

class FissionPerspective:
 @classmethod
 def INPUT_TYPES(cls):
  return {'required':{'image':('IMAGE',),'corner_delta':('FLOAT',{'default':40,'min':0,'max':50}),'center_delta':('FLOAT',{'default':14,'min':0,'max':50})}}
 RETURN_TYPES=('IMAGE','IMAGE','STRING')
 RETURN_NAMES=('image','displacement','diagnostics')
 FUNCTION='warp'
 CATEGORY='fission/geometry'
 def warp(self,image,corner_delta,center_delta):
  import json
  b,h,w,c=image.shape
  if (w,h)!=(1024,1024):raise ValueError('Expected 1024 square image')
  dev=image.device; yy,xx=torch.meshgrid(torch.arange(h,device=dev,dtype=torch.float32),torch.arange(w,device=dev,dtype=torch.float32),indexing='ij')
  def bump(x,center,radius):
   t=torch.clamp(torch.abs(x-center)/radius,0,1);return torch.where(t<1,(1+torch.cos(torch.pi*t))/2,torch.zeros_like(t))
  def displacement(y):
   left=corner_delta*bump(xx,140,300)*bump(y,795,190)
   right=corner_delta*bump(xx,858,300)*bump(y,805,190)
   middle=center_delta*bump(xx,505,300)*bump(y,900,190)
   edge_x=torch.clamp(xx/70,0,1)*torch.clamp((1023-xx)/63,0,1)
   edge_y=torch.clamp((1023-y)/100,0,1)
   return (left+right+middle)*edge_x*edge_y
  field=displacement(yy);jac=1+(field[2:]-field[:-2])/2
  if field.max().item()>50.0001 or jac.min().item()<=0:raise ValueError('Displacement exceeds 50 px or has nonpositive Jacobian')
  sy=yy.clone()
  for _ in range(30):sy=yy-displacement(sy)
  error=torch.max(torch.abs(sy+displacement(sy)-yy)).item()
  if error>0.01:raise ValueError('Inverse solver failed')
  grid=torch.stack((xx/(w-1)*2-1,sy/(h-1)*2-1),-1).unsqueeze(0).expand(b,-1,-1,-1)
  warped=F.grid_sample(image.permute(0,3,1,2),grid,mode='bilinear',padding_mode='border',align_corners=True).permute(0,2,3,1)
  changed=displacement(sy)>0
  warped=torch.where(changed[None,:,:,None],warped,image)
  vis=(displacement(sy)/50).clamp(0,1)[None,:,:,None].expand(b,-1,-1,3)
  report={'min_forward_jacobian':float(jac.min()),'max_forward_displacement':float(field.max()),'inverse_max_residual_px':error,'control_points':[[140,795,corner_delta],[858,805,corner_delta],[505,900,center_delta]],'actual_forward_displacements':[float(field[795,140]),float(field[805,858]),float(field[900,505])],'interpolation':'bilinear','support_y_min':int(torch.where(field>0)[0].min()),'support_y_max':int(torch.where(field>0)[0].max())}
  return warped,vis,json.dumps(report)
NODE_CLASS_MAPPINGS={'FissionPerspective':FissionPerspective}
NODE_DISPLAY_NAME_MAPPINGS={'FissionPerspective':'Fission Deterministic Perspective'}
