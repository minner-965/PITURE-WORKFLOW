"""Explicit photographic plate layout. Coordinates belong to the provided photo crop."""
import json,math
import numpy as np
import torch
from PIL import Image,ImageDraw,ImageFilter,ImageChops

class FissionPhotoLock:
 @classmethod
 def INPUT_TYPES(cls):
  return {'required':{'photo':('IMAGE',),'background':('IMAGE',),'layout_json':('STRING',{'default':'{}','multiline':True})}}
 RETURN_TYPES=('IMAGE','MASK','MASK','MASK','MASK')
 RETURN_NAMES=('layout','product_mask','food_mask','rim_protection','shadow_zone')
 FUNCTION='layout';CATEGORY='fission/photo'
 def layout(self,photo,background,layout_json):
  cfg=json.loads(layout_json);outer=cfg['outer_polygon'];inner=cfg['food_polygon'];placements=cfg['placements']
  if photo.shape[0]!=1 or background.shape[0]!=1:raise ValueError('single images only')
  h,w=photo.shape[1:3];bh,bw=background.shape[1:3]
  def polygon(points):
   if not isinstance(points,list) or len(points)<3 or len(points)>500:raise ValueError('polygon requires 3 to 500 points')
   if any(not isinstance(p,list) or len(p)!=2 or not all(isinstance(v,(int,float)) and math.isfinite(v) and 0<=v<=1 for v in p) for p in points):raise ValueError('polygon points require normalized [0,1] coordinates')
   scale=4;mask=Image.new('L',(w*scale,h*scale));ImageDraw.Draw(mask).polygon([(round(x*(w-1)*scale),round(y*(h-1)*scale)) for x,y in points],fill=255);return mask.resize((w,h),Image.Resampling.BOX)
  om=polygon(outer);im=polygon(inner)
  if ImageChops.subtract(im,om).getbbox():raise ValueError('Food polygon must lie inside product polygon')
  if not placements or sum(p.get('role')=='hero' for p in placements)!=1 or placements[-1].get('role')!='hero':raise ValueError('Exactly one hero placement is required and it must be last')
  pix=np.clip(photo[0].detach().cpu().numpy()*255,0,255).astype('uint8');bg=np.clip(background[0].detach().cpu().numpy()*255,0,255).astype('uint8')
  src=Image.fromarray(pix[:,:,:3]);canvas=Image.fromarray(bg[:,:,:3]);product=Image.new('L',(bw,bh));food=Image.new('L',(bw,bh));visible_rim=Image.new('L',(bw,bh))
  for p in placements:
   if p.get('role') not in ('hero','support'):raise ValueError('Unknown placement role')
   width=p['width'];x=p['x'];y=p['y']
   if not all(type(v) is int for v in [width,x,y]) or width<=0:raise ValueError('Placement needs integer width,x,y')
   height=round(h*width/w)
   if x<0 or y<0 or x+width>bw or y+height>bh:raise ValueError('Whole transformed photo must fit canvas')
   size=(width,height);tile=src.resize(size,Image.Resampling.LANCZOS);m=om.resize(size,Image.Resampling.BOX);i=im.resize(size,Image.Resampling.BOX)
   canvas.paste(tile,(x,y),m);layer=Image.new('L',(bw,bh));layer.paste(m,(x,y));product=ImageChops.lighter(product,layer)
   visible_rim=ImageChops.subtract(visible_rim,layer)
   if p['role']=='hero':
    layer_inner=Image.new('L',(bw,bh));layer_inner.paste(i,(x,y));food=layer_inner;visible_rim=ImageChops.lighter(visible_rim,ImageChops.subtract(layer,layer_inner))
   else:visible_rim=ImageChops.lighter(visible_rim,layer)
  shadow_radius=cfg.get('shadow_radius',16)
  if type(shadow_radius) is not int or not 1<=shadow_radius<=64:raise ValueError('shadow_radius must be 1..64')
  # This output defines an allowed zone, not a fabricated shadow.
  product_binary=product.point(lambda value: 255 if value else 0)
  zone=ImageChops.subtract(product_binary.filter(ImageFilter.MaxFilter(shadow_radius*2+1)),product_binary)
  def tensor_image(x):return torch.from_numpy(np.asarray(x).copy().astype('float32')/255).unsqueeze(0)
  return tensor_image(canvas),tensor_image(product),tensor_image(food),tensor_image(visible_rim),tensor_image(zone)
NODE_CLASS_MAPPINGS={'FissionPhotoLock':FissionPhotoLock}
NODE_DISPLAY_NAME_MAPPINGS={'FissionPhotoLock':'Fission Real Photo Plate Layout'}

class FissionExteriorBandColor:
 """Extract a bounded neutral exterior strip and tint it to the photographed orange."""
 @classmethod
 def INPUT_TYPES(cls):
  return {'required':{'image':('IMAGE',),'reference':('IMAGE',),'settings_json':('STRING',{'default':'{}','multiline':True})}}
 RETURN_TYPES=('IMAGE','MASK','STRING');RETURN_NAMES=('image','mask','diagnostics');FUNCTION='color';CATEGORY='fission/photo'
 def color(self,image,reference,settings_json):
  import colorsys
  from scipy import ndimage
  cfg=json.loads(settings_json);x,y,w,h=cfg['roi_xywh'];sx,sy=cfg['seed_xy'];rx,ry,rw,rh=cfg['reference_sample_xywh']
  if image.shape[0]!=1 or reference.shape[0]!=1:raise ValueError('single images required')
  src=np.clip(image[0].detach().cpu().numpy()*255,0,255).astype(np.uint8);ref=np.clip(reference[0].detach().cpu().numpy()*255,0,255).astype(np.uint8);H,W=src.shape[:2]
  if min(x,y,rx,ry)<0 or x+w>W or y+h>H or rx+rw>ref.shape[1] or ry+rh>ref.shape[0] or not (x<=sx<x+w and y<=sy<y+h):raise ValueError('ROI or seed out of bounds')
  patch=src[y:y+h,x:x+w].astype(np.int16);neutral=(patch.min(2)>150)&((patch.max(2)-patch.min(2))<24)
  labels,_=ndimage.label(neutral);label=labels[sy-y,sx-x]
  if not label:raise ValueError('Seed is not in neutral plate region')
  shape=ndimage.binary_fill_holes(labels==label)
  if shape.sum()<1000:raise ValueError('Plate segmentation too small')
  sample=ref[ry:ry+rh,rx:rx+rw].astype(np.int16);chosen=(sample[:,:,0]>150)&(sample[:,:,0]>sample[:,:,1]*1.3)&(sample[:,:,1]>sample[:,:,2]*1.1)
  if chosen.sum()<50:raise ValueError('Insufficient reference orange pixels')
  target=np.median(sample[chosen],axis=0)/255.;hue,sat,_=colorsys.rgb_to_hsv(*target);mask=np.zeros((H,W),dtype=np.uint8)
  for column in range(w):
   ys=np.flatnonzero(shape[:,column]);
   if not len(ys):continue
   bottom=y+int(ys[-1]);global_x=x+column
   # Approximate wall just below the white boundary, reject bright inner surface and dark contact shadow.
   for yy in range(max(y,bottom-1),min(y+h,bottom+7,H)):
    pix=src[yy,global_x].astype(int);mx=pix.max();mn=pix.min()
    taper=min(1.,max(0.,(global_x-(x+10))/35),max(0.,((x+w-10)-global_x)/35))
    if 90<=mx<=205 and mx-mn<40:mask[yy,global_x]=round(255*taper)
  manual=cfg.get('band_polygon_xy')
  if manual is not None:
   if not isinstance(manual,list) or len(manual)<3 or any(not isinstance(p,list) or len(p)!=2 or not all(isinstance(v,(int,float)) and math.isfinite(v) for v in p) or not (x<=p[0]<x+w and y<=p[1]<y+h) for p in manual):raise ValueError('Manual band polygon must be inside ROI')
   high=Image.new('L',(W*4,H*4));ImageDraw.Draw(high).polygon([(round(px*4),round(py*4)) for px,py in manual],fill=255)
   mask=np.asarray(high.resize((W,H),Image.Resampling.BOX)).copy()
  if np.count_nonzero(mask)<100:raise ValueError('Band extraction is unstable or too small')
  hsv=np.array(Image.fromarray(src).convert('HSV'));sel=mask>0;hsv[:,:,0][sel]=round(hue*255);hsv[:,:,1][sel]=round(sat*255)
  recol=np.asarray(Image.fromarray(hsv,'HSV').convert('RGB')).astype(np.float32);original=src.astype(np.float32);alpha=mask.astype(np.float32)[:,:,None]/255;out=np.round(original*(1-alpha)+recol*alpha).astype(np.uint8)
  meta={'mask_mode':'manual_polygon' if manual is not None else 'automatic','reference_rgb':target.tolist(),'reference_count':int(chosen.sum()),'segmentation_area':int(shape.sum()),'mask_pixels':int(sel.sum()),'mask_bounds_xyxy':None if not sel.any() else [int(np.where(sel)[1].min()),int(np.where(sel)[0].min()),int(np.where(sel)[1].max()),int(np.where(sel)[0].max())],'note':'Provisional band extraction: verify mask and colored edge visually.'}
  return torch.from_numpy(out.astype(np.float32)/255).unsqueeze(0),torch.from_numpy(mask.astype(np.float32)/255).unsqueeze(0),json.dumps(meta)
NODE_CLASS_MAPPINGS['FissionExteriorBandColor']=FissionExteriorBandColor
NODE_DISPLAY_NAME_MAPPINGS['FissionExteriorBandColor']='Fission Exterior Band Color'
