import json, math
import torch
import torch.nn.functional as F

class FissionLocalPerspective:
 @classmethod
 def INPUT_TYPES(cls):
  return {'required':{'image':('IMAGE',),'points_json':('STRING',{'default':'[]','multiline':True}),'max_displacement':('FLOAT',{'default':50,'min':0,'max':50}),'protected_top':('INT',{'default':500,'min':0,'max':8192})}}
 RETURN_TYPES=('IMAGE','IMAGE','STRING');RETURN_NAMES=('image','displacement','diagnostics');FUNCTION='warp';CATEGORY='fission/geometry'
 def warp(self,image,points_json,max_displacement,protected_top):
  points=json.loads(points_json);b,h,w,c=image.shape
  if not isinstance(points,list) or len(points)>12:raise ValueError('points must be a list of up to 12 control points')
  for p in points:
   if not isinstance(p,list) or len(p)!=5 or not all(isinstance(a,(int,float)) and math.isfinite(a) for a in p):raise ValueError('Each point must be [x,y,dy,rx,ry]')
   x,y,dy,rx,ry=p
   if not (0<x<w-1 and protected_top<y<h-1 and 0<=dy<=max_displacement and rx>0 and ry>0):raise ValueError('Control point outside allowed bounds')
  yy,xx=torch.meshgrid(torch.arange(h,device=image.device,dtype=torch.float32),torch.arange(w,device=image.device,dtype=torch.float32),indexing='ij')
  def bump(z,center,radius):
   t=torch.clamp(torch.abs(z-center)/radius,0,1);return torch.where(t<1,(1+torch.cos(torch.pi*t))/2,torch.zeros_like(t))
  def field(y):
   d=torch.zeros_like(y)
   for x,cy,dy,rx,ry in points:d=d+dy*bump(xx,x,rx)*bump(y,cy,ry)
   # smooth finite protection at top and image borders; exact zero at boundary
   def ramp(v):
    t=torch.clamp(v,0,1);return t*t*(3-2*t)
   d=d*ramp(xx/80)*ramp((w-1-xx)/80)*ramp((y-protected_top)/80)*ramp((h-1-y)/80)
   return d
  f=field(yy);jac=1+(f[2:]-f[:-2])/2
  if f.max().item()>max_displacement+1e-4 or jac.min().item()<=0:raise ValueError('Displacement bound or Jacobian violated')
  sy=yy.clone()
  for _ in range(40):sy=yy-field(sy)
  err=torch.max(torch.abs(sy+field(sy)-yy)).item()
  if err>0.01:raise ValueError('Inverse map did not converge')
  grid=torch.stack((xx/(w-1)*2-1,sy/(h-1)*2-1),-1).unsqueeze(0).expand(b,-1,-1,-1)
  warped=F.grid_sample(image.permute(0,3,1,2),grid,mode='bilinear',padding_mode='border',align_corners=True).permute(0,2,3,1)
  d=field(sy);out=torch.where((d>0)[None,:,:,None],warped,image)
  vis=(d/max(max_displacement,1)).clamp(0,1)[None,:,:,None].expand(b,-1,-1,3)
  report={'min_jacobian':float(jac.min()),'max_displacement':float(f.max()),'inverse_error':err,'points':points,'protected_top':protected_top}
  return out,vis,json.dumps(report)
NODE_CLASS_MAPPINGS={'FissionLocalPerspective':FissionLocalPerspective}
NODE_DISPLAY_NAME_MAPPINGS={'FissionLocalPerspective':'Fission Local Perspective (explicit points)'}
