# 当前状态（脚本生成）

审核轮次：v7。技术检查与 root 视觉审核分别记录；文件存在不代表视觉通过。

## 审核统计

- passed: 18
- visual_rejected: 6

## 交付项明细

| 交付项 | 视觉状态 | 文件检查 | 审核门禁 | 备注 |
|---|---|---|---|---|
| MAIN_01 | visual_rejected | JPG/PNG 均存在（未替代完整机械校验） | 待核：not approved: visual_rejected | root复审退回：右后蓝碗食品表面过度均匀的干细颗粒/砂面，缺乏可信粥液质感。 |
| MAIN_02 | visual_rejected | JPG/PNG 均存在（未替代完整机械校验） | 待核：not approved: visual_rejected | root复审退回：右后黄碗红豆呈干颗粒堆，中心红碗内口出现不自然额外白色环/槽，后方设备缺乏清晰可信结构。 |
| MAIN_03 | visual_rejected | JPG/PNG 均存在（未替代完整机械校验） | 待核：not approved: visual_rejected | root复审退回：蓝碗新增假白内沿；红豆呈干颗粒堆，观感不符合糖水；上方店内设备变形。D08复用同一源图。 |
| MAIN_04 | visual_rejected | JPG/PNG 均存在（未替代完整机械校验） | 待核：not approved: visual_rejected | root复审退回：左前红碗和手持黄碗粥面过高，几乎与上沿齐平，削弱碗内深度，未达到留出液面距离标准。 |
| MAIN_05 | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看800原图，复用已重新审核红色白底；外形、耳朵、配色与商品一致。 |
| D01 | visual_rejected | JPG/PNG 均存在（未替代完整机械校验） | 待核：not approved: visual_rejected; upstream not approved: MAIN_02 | 复用MAIN_02，同步退回：黄碗红豆干颗粒堆、红碗不自然额外白色环/槽、后方设备结构不可信。 |
| D02 | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root亲看750x1300 D02及三份1024单碗原图，三菜品各用独立整图卡片，食品与内壁接合可接受；橙碗来源与FIRST_BOWL_V2可见区域零差证据已核对。 |
| D03 | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看750全图与2x图：五色对应与色名正确，真实双耳空碗排版清楚。 |
| D04 | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看750x1400及2x尺寸区：跨耳长16.5cm、宽12.8cm、高8cm、550ml、207g为单只参数，箭头及文字清楚。 |
| D05 | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看750x1250及2x图：真实碗沿、双耳与内外配色细节，无结构改造。 |
| D06 | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看750x1024及2x图：倒扣足部与侧面实拍，展示裁切清楚。 |
| D07 | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看750x1152及2x图：五色对应正确，6.5英寸、批量采购与单只参数明确。 |
| D08 | visual_rejected | JPG/PNG 均存在（未替代完整机械校验） | 待核：not approved: visual_rejected; upstream not approved: MAIN_03 | root复审退回：蓝碗新增假白内沿；红豆呈干颗粒堆，观感不符合糖水；上方店内设备变形。D08复用同一源图。 |
| w1125_row2 | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看11项白底/SKU总览，核对五色实拍来源、外形、耳朵及配色；SKU长宽高容量列分开，旧包JPG哈希匹配。PNG仅记录本轮哈希，不宣称旧记录匹配。 |
| w1125_row3 | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看11项白底/SKU总览，核对五色实拍来源、外形、耳朵及配色；SKU长宽高容量列分开，旧包JPG哈希匹配。PNG仅记录本轮哈希，不宣称旧记录匹配。 |
| w1125_row4 | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看11项白底/SKU总览，核对五色实拍来源、外形、耳朵及配色；SKU长宽高容量列分开，旧包JPG哈希匹配。PNG仅记录本轮哈希，不宣称旧记录匹配。 |
| w1125_row5 | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看11项白底/SKU总览，核对五色实拍来源、外形、耳朵及配色；SKU长宽高容量列分开，旧包JPG哈希匹配。PNG仅记录本轮哈希，不宣称旧记录匹配。 |
| w1125_row6 | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看11项白底/SKU总览，核对五色实拍来源、外形、耳朵及配色；SKU长宽高容量列分开，旧包JPG哈希匹配。PNG仅记录本轮哈希，不宣称旧记录匹配。 |
| WHITE_RED | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看11项白底/SKU总览，核对五色实拍来源、外形、耳朵及配色；SKU长宽高容量列分开，旧包JPG哈希匹配。PNG仅记录本轮哈希，不宣称旧记录匹配。 |
| WHITE_ORANGE | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看11项白底/SKU总览，核对五色实拍来源、外形、耳朵及配色；SKU长宽高容量列分开，旧包JPG哈希匹配。PNG仅记录本轮哈希，不宣称旧记录匹配。 |
| WHITE_GREEN | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看11项白底/SKU总览，核对五色实拍来源、外形、耳朵及配色；SKU长宽高容量列分开，旧包JPG哈希匹配。PNG仅记录本轮哈希，不宣称旧记录匹配。 |
| WHITE_YELLOW | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看11项白底/SKU总览，核对五色实拍来源、外形、耳朵及配色；SKU长宽高容量列分开，旧包JPG哈希匹配。PNG仅记录本轮哈希，不宣称旧记录匹配。 |
| WHITE_BLUE | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看11项白底/SKU总览，核对五色实拍来源、外形、耳朵及配色；SKU长宽高容量列分开，旧包JPG哈希匹配。PNG仅记录本轮哈希，不宣称旧记录匹配。 |
| EXTRA_01 | passed | JPG/PNG 均存在（未替代完整机械校验） | 通过 | root本轮亲看11项总览：五色五只空碗在纯白底，比例一致，未添加食品文字环境。 |

## 最近机械校验

记录时间（UTC）：2026-11-03T04:12:28.279280+00:00；mechanical_ok：True；错误数：0。此历史记录可能早于当前文件或审核状态，不能代替复验。

## 最近运行测量

- crop：`work/diagnostics/preview_tiers/crop/MAIN04_left_red_denoise_075/cd95ef6243f60d3a0f8526c3/measurements.json`；状态 success；耗时 190.74341487884521 秒。
- final：`work/logs/whole_photo_v5/MAIN04_left_red_final_v9/4a9e27de629a0f11f3c5ed6e/measurements.json`；状态 success；耗时 702.7186908721924 秒。
- preview：`work/diagnostics/preview_tiers/preview/MAIN02_background_region_v7/367a1ce749a93bb1c9a3e03a/measurements.json`；状态 success；耗时 296.5660629272461 秒。
- 未标明档位：`work/logs/whole_photo_v5/SCENE_V7_fusion_A/9028d6a6299a52dbf0a71c29/measurements.json`；状态 success；耗时 719.2994890213013 秒。

## 视频素材交接

- `exchange/w1125/batch_001`：本地 READY，清单哈希一致；文件数 57；总字节 447595609；B 机回执已存档，回执内容校验通过。

运行数据历史见 [背景与融合测试](archive/20261103/背景与融合测试_20261103.md)。
