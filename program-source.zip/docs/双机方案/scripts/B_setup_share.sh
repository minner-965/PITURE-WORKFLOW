#!/bin/bash
# 在 B 机运行：建立只给 A 机投递素材用的 SMB 共享目录。
# 用法：
#   bash B_setup_share.sh            # 建立 / 修复（可重复运行）
#   bash B_setup_share.sh --check    # 只检查，不做任何修改
#   bash B_setup_share.sh --remove   # 移除共享和投递账户（目录与文件保留）
# 会通过 sudo 要求输入本机管理员密码；投递账户密码只在运行时输入，不写入任何文件。
set -euo pipefail

SHARE_DIR="/Users/Shared/video_inbox"
SHARE_NAME="video_inbox"
DROP_USER="videodrop"
OWNER="${SUDO_USER:-$USER}"

say()  { printf '\n== %s\n' "$*"; }
ok()   { printf '  [OK] %s\n' "$*"; }
warn() { printf '  [!!] %s\n' "$*"; }

check() {
  say "检查"
  [[ -d "$SHARE_DIR" ]] && ok "目录存在：$SHARE_DIR" || warn "目录不存在：$SHARE_DIR"
  id "$DROP_USER" >/dev/null 2>&1 && ok "投递账户存在：$DROP_USER" || warn "投递账户不存在：$DROP_USER"
  if sharing -l 2>/dev/null | grep -q "$SHARE_NAME"; then ok "共享已登记：$SHARE_NAME"; else warn "共享未登记：$SHARE_NAME"; fi
  if nc -z -G 2 127.0.0.1 445 >/dev/null 2>&1; then ok "SMB 445 端口在监听"; else warn "SMB 445 端口没有监听（文件共享未开启）"; fi
  local fw
  fw=$(/usr/libexec/ApplicationFirewall/socketfilterfw --getblockall 2>/dev/null || true)
  if echo "$fw" | grep -qi "enabled"; then warn "防火墙为「阻止所有传入连接」，A 机将无法连接"; else ok "防火墙未阻止全部传入连接"; fi
  say "A 机连接地址"
  local host ip
  host="$(scutil --get LocalHostName 2>/dev/null || hostname -s).local"
  ip="$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo '未取得')"
  echo "  主机名：$host   （推荐，IP 变了也能用）"
  echo "  IP：    $ip"
  echo "  地址：  smb://$DROP_USER@$host/$SHARE_NAME"
}

remove() {
  say "移除共享与投递账户（不删除目录中的文件）"
  sudo sharing -r "$SHARE_NAME" 2>/dev/null && ok "已移除共享" || warn "共享不存在或已移除"
  if id "$DROP_USER" >/dev/null 2>&1; then
    read -r -p "  确认删除投递账户 $DROP_USER ？(yes/no) " a
    [[ "$a" == "yes" ]] && sudo sysadminctl -deleteUser "$DROP_USER" && ok "已删除账户"
  fi
  echo "  如需关闭文件共享：系统设置 → 通用 → 共享 → 关闭「文件共享」"
}

setup() {
  [[ "$(uname -s)" == "Darwin" ]] || { echo "只能在 macOS 运行"; exit 1; }
  echo "将要执行："
  echo "  1. 创建目录 $SHARE_DIR（所有者 $OWNER）"
  echo "  2. 创建仅共享账户 $DROP_USER（不能登录桌面、不能开终端、在登录界面隐藏）"
  echo "  3. 开启 SMB 文件共享，只共享这一个目录，关闭访客访问"
  read -r -p "继续？(yes/no) " a; [[ "$a" == "yes" ]] || exit 0

  say "1 目录"
  sudo mkdir -p "$SHARE_DIR"
  sudo chown "$OWNER":staff "$SHARE_DIR"
  sudo chmod 0750 "$SHARE_DIR"
  ok "$SHARE_DIR"

  say "2 投递账户"
  if id "$DROP_USER" >/dev/null 2>&1; then
    ok "账户已存在，跳过创建（如需重设密码：sudo dscl . -passwd /Users/$DROP_USER）"
  else
    local pw pw2
    read -r -s -p "  为 $DROP_USER 设置密码（A 机连接时使用）：" pw; echo
    read -r -s -p "  再输入一次：" pw2; echo
    [[ -n "$pw" && "$pw" == "$pw2" ]] || { echo "  两次不一致或为空"; exit 1; }
    sudo sysadminctl -addUser "$DROP_USER" -fullName "Video Drop" -password "$pw" -home /var/empty
    sudo dscl . -create "/Users/$DROP_USER" UserShell /usr/bin/false
    sudo dscl . -create "/Users/$DROP_USER" IsHidden 1
    # SMB 需要 NT 哈希：先开启，再重设一次同样的密码让哈希生成
    sudo pwpolicy -u "$DROP_USER" -sethashtypes SMB-NT on >/dev/null 2>&1 || true
    sudo dscl . -passwd "/Users/$DROP_USER" "$pw"
    unset pw pw2
    ok "已创建 $DROP_USER（仅共享用途）"
  fi

  say "3 目录权限（ACL，子目录与文件继承）"
  sudo chmod -N "$SHARE_DIR"
  local perms="list,add_file,search,add_subdirectory,delete_child,readattr,writeattr,readextattr,writeextattr,readsecurity,file_inherit,directory_inherit"
  sudo chmod +a "$DROP_USER allow $perms" "$SHARE_DIR"
  sudo chmod +a "$OWNER allow $perms,delete" "$SHARE_DIR"
  ok "$DROP_USER 可写入；$OWNER 可读取与删除"

  say "4 开启 SMB 文件共享"
  sudo defaults write /Library/Preferences/SystemConfiguration/com.apple.smb.server EnabledServices -array disk
  sudo launchctl enable system/com.apple.smbd 2>/dev/null || true
  sudo launchctl bootstrap system /System/Library/LaunchDaemons/com.apple.smbd.plist 2>/dev/null || true
  sudo launchctl kickstart -k system/com.apple.smbd 2>/dev/null || true

  say "5 登记共享"
  if sharing -l 2>/dev/null | grep -q "$SHARE_NAME"; then
    ok "已登记，跳过"
  else
    # sharing 默认开启访客访问，创建时直接关闭（-g 000），只开 SMB（-s 001）
    sudo sharing -a "$SHARE_DIR" -S "$SHARE_NAME" -s 001 -g 000
    ok "已登记 $SHARE_NAME"
  fi
  sudo sharing -e "$SHARE_NAME" -g 000 >/dev/null 2>&1 && ok "访客访问已关闭" || warn "无法用命令关闭访客，请在 系统设置 → 共享 → 文件共享 → 选项 中确认未勾选访客"

  check
  cat <<EOF

== 如果上面 445 端口仍显示未监听
  打开 系统设置 → 通用 → 共享 → 打开「文件共享」，
  点 ⓘ → 共享文件夹中应只有 video_inbox；选项 → 勾选「使用 SMB 共享文件」，
  并在下方账户列表勾选 $DROP_USER。然后重新运行：bash $0 --check

== 下一步（在 A 机）
  1. Finder → 前往 → 连接服务器，输入上面的 smb:// 地址，
     用 $DROP_USER 和刚设的密码登录，勾选「在钥匙串中记住此密码」。
  2. 之后 A 机用 A_push_batch.sh 推送批次。
  3. B 机的 receive_batch.py 从 $SHARE_DIR 读取。
EOF
}

case "${1:-}" in
  --check)  check ;;
  --remove) remove ;;
  "")       setup ;;
  *) echo "未知参数：$1"; exit 2 ;;
esac
