#!/bin/bash
# 在 A 机运行：把一个已导出的批次目录按交接协议推送到 B 机共享目录。
# 用法：
#   bash A_push_batch.sh <批次目录> <B机主机名或IP>
#   例：bash A_push_batch.sh exchange/w1125/batch_001 B-Mac-mini.local
# 前提：批次目录内有 files/、manifest.json、READY.json；
#       已在 Finder 用 videodrop 账户连接过一次 B 机并把密码存入钥匙串。
# 顺序：先复制到 .incoming_<批次> → 远端逐个校验 sha256 → 改名为正式批次名 → 最后复制 READY.json。
set -euo pipefail

BATCH_DIR="${1:?需要批次目录}"
B_HOST="${2:?需要 B 机主机名或 IP}"
SHARE_NAME="video_inbox"
DROP_USER="videodrop"

BATCH_DIR="$(cd "$BATCH_DIR" && pwd)"
BATCH_ID="$(basename "$BATCH_DIR")"
for f in manifest.json READY.json; do
  [[ -f "$BATCH_DIR/$f" ]] || { echo "缺少 $BATCH_DIR/$f"; exit 1; }
done
[[ -d "$BATCH_DIR/files" ]] || { echo "缺少 $BATCH_DIR/files/"; exit 1; }

find_mount() { mount | awk -v s="/$SHARE_NAME on " 'index($0,s){sub(/^.* on /,""); sub(/ \(.*$/,""); print; exit}'; }

MNT="$(find_mount || true)"
if [[ -z "$MNT" ]]; then
  echo "挂载 smb://$DROP_USER@$B_HOST/${SHARE_NAME}（使用钥匙串中的密码）"
  open "smb://$DROP_USER@$B_HOST/$SHARE_NAME"
  for _ in $(seq 1 30); do sleep 1; MNT="$(find_mount || true)"; [[ -n "$MNT" ]] && break; done
fi
[[ -n "$MNT" && -d "$MNT" ]] || { echo "挂载失败：请先在 Finder 手动连接一次并保存密码"; exit 1; }
echo "已挂载：$MNT"

DEST="$MNT/$BATCH_ID"
TMP="$MNT/.incoming_$BATCH_ID"
if [[ -e "$DEST" ]]; then
  echo "B 机已存在 $BATCH_ID。批次只追加不覆盖；如需更新请导出新的批次号。"; exit 1
fi

echo "1/4 复制 files/ 与 manifest.json 到 $TMP"
rm -rf "$TMP"
mkdir -p "$TMP"
ditto "$BATCH_DIR/files" "$TMP/files"
cp "$BATCH_DIR/manifest.json" "$TMP/manifest.json"

echo "2/4 在远端逐个校验 sha256 与大小"
/usr/bin/python3 - "$BATCH_DIR" "$TMP" <<'PY'
import hashlib, json, sys
from pathlib import Path
src, dst = Path(sys.argv[1]), Path(sys.argv[2])
m = json.loads((src / "manifest.json").read_text(encoding="utf-8"))
bad = []
for a in m["assets"]:
    p = dst / a["relative_path"]
    if not p.is_file():
        bad.append(f"缺失 {a['relative_path']}"); continue
    if p.stat().st_size != a["byte_size"]:
        bad.append(f"大小不符 {a['relative_path']}"); continue
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    if h.hexdigest() != a["sha256"]:
        bad.append(f"哈希不符 {a['relative_path']}")
listed = {a["relative_path"] for a in m["assets"]}
extra = [str(p.relative_to(dst)) for p in (dst / "files").rglob("*") if p.is_file() and p.name != ".DS_Store" and str(p.relative_to(dst)) not in listed]
bad += [f"清单外文件 {e}" for e in extra]
if bad:
    print("\n".join(bad)); sys.exit(1)
print(f"  {len(listed)} 个文件全部一致")
PY

echo "3/4 改名为正式批次 $BATCH_ID"
mv "$TMP" "$DEST"

echo "4/4 最后写入 READY.json"
cp "$BATCH_DIR/READY.json" "$DEST/READY.json"

echo "完成：$DEST"
echo "请在 B 机运行 receive_batch.py 校验，并把 receive_report.json 回传 A 机存档。"
