---
license: other
license_name: flux-1-dev-non-commercial-license
license_link: LICENSE.md
base_model:
- black-forest-labs/FLUX.1-Fill-dev
library_name: gguf
tags:
- flux
- image-generation
---


This GGUF file is a direct conversion of [black-forest-labsFLUX.1-Fill-dev](https://huggingface.co/black-forest-labs/FLUX.1-Fill-dev)

Since this is a quantized model, all original licensing terms and usage restrictions remain in effect.

**Usage**

The model can be used with the ComfyUI custom node [ComfyUI-GGUF](https://github.com/city96/ComfyUI-GGUF) by [city96](https://huggingface.co/city96)

Place model files in `ComfyUI/models/unet` see the GitHub readme for further installation instructions.


**Interface Used**

These models were quantized using [EasyQuantizationGUI](https://github.com/rainlizard/EasyQuantizationGUI) by [rainlizard](https://github.com/rainlizard)