# 统一 SKU 表标准

本表是内部统一数据源，供商品资料、图片任务及上架进度协作使用；不是淘宝或拼多多官方一键导入格式。平台导出应按当时平台后台模板另行映射。表格文件：`outputs/sku_standard_20261103/商品SKU与图片任务统一表.xlsx`。

## 字段与唯一键

- **SKU主表**：内部SKU编码（唯一、稳定，非平台 ID）、型号、商品名称、颜色、重量（克）、容量（毫升）、长／宽／高（厘米）、英寸、用途、销售方式、每销售单位数量、起订量、实拍路径、参考图目录、资料状态、备注。每行一个颜色／规格变体；原表“红包”经用户更正显示为红色，原始表不改。
- **图片任务**：任务编号（全局唯一，如 `w1125-MAIN_01`）、型号、适用SKU（可用顿号分隔多个内部编码）、图片类型、食品、场景、宽／高（像素）、文件格式、成品路径、审核状态、退回原因、源任务编号（保留原系统编号）。每逻辑图一行，PNG/JPG 是同一任务。派生自（derived_from）记录上游 deliverable_id，多个值以分号分隔；路径另记 source_files，待核实关系不猜测。顶部按类型及状态统计。
- **上架记录**：记录编号（全局唯一，如 `w1125-LIST-001`）、型号、平台、店铺、平台商品编号、商品链接、状态、上架日期、图片版本、备注。每个平台商品条目一行；型号、平台、店铺及平台商品编号共同关联具体条目，颜色变体由 SKU 主表关联。顶部仅统计平台、店铺、商品编号均已填写且状态为已上架的记录。

## 填写与新增

蓝字为可编辑内容；状态使用下拉框，重量、尺寸、容量、数量和像素输入正数。未知销售单位数量、起订量、店铺、平台商品编号、链接、日期留空，勿推测；未核实食品、场景或适用 SKU 标待核实。原片路径仅填已核实文件。增加新 SKU、任务或上架记录时在相应表中填入跨型号全局唯一编号；任务编号以型号及源任务编号组合，来源编号另存，重复编号会标色；增加前核对型号、颜色和规格，更新资料状态。表格和统计预留至约第 1000 行，超过后扩展表格、验证及统计范围。

图片退回应记录可复核原因，按实际 root 复审更新；历史通过待本轮复核不视为本轮通过。源图退回时撤回相关派生及交付包。上架状态由人确认，图片未通过前勿上架；上架记录的状态与商品编号应与平台后台事实一致，不用占位 ID 冒充上架。

## JSON 字段映射

可按以下稳定英文键将中文表头映射为 JSON；数字保持数值，空白映射为 `null`，多 SKU 在导出时拆成数组，日期转 ISO `YYYY-MM-DD`。未知值保留空白或待核实标记，不推导。

- SKU：`sku_id`, `model`, `product_name`, `color`, `weight_g`, `capacity_ml`, `length_cm`, `width_cm`, `height_cm`, `inches`, `uses`, `sales_method`, `units_per_sale`, `moq`, `photo_path`, `reference_dir`, `data_status`, `notes`。
- 图片：`task_id`, `model`, `sku_ids`, `image_type`, `food`, `scene`, `width_px`, `height_px`, `formats`, `output_path`, `review_status`, `rejection_reason`, `source_task_id`。
- 上架：`record_id`, `model`, `platform`, `store`, `platform_product_id`, `product_url`, `status`, `listed_date`, `image_version`, `notes`。

## 生命周期与导入

图片状态统一使用：`待生成` → `pending_generation`、`生成中` → `generating`、`待审核` → `pending_review`、`通过` → `passed_in_sheet`、`返工` → `rework`、`历史通过待本轮复核` → `pending_recheck`。未知状态报错。表内“通过”是人工填表状态，独立于正式 QA 审批，也不触发自动上架。直接复用的空碗实拍可进入待审核或通过，不必虚构生成任务。

容量对于浅盘等器型可空，空白表示未提供或不适用，与数值 0 不同；导入器给出资料待补提示，不凭空生成规格。当前 w1125 五行容量 550 毫升有来源。自动提交始终为 false。

使用现有 ComfyUI Python，导入器仅依赖 Python 标准库：

```bash
'/Users/luohuiwu/ComfyUI-Installs/E-commerce image workflow/ComfyUI/.venv/bin/python3' scripts/import_standard_sku.py --input /Users/luohuiwu/codex/ComfyProductPipeline/outputs/sku_standard_20261103/商品SKU与图片任务统一表.xlsx --output-dir /Users/luohuiwu/codex/ComfyProductPipeline/work/sku_standard_import
```

输出 `sku_records.json`、`image_tasks.json`、`listing_records.json` 和 `import_report.json`，schema 版本 `standard-sku-1.0`。导入只读取统一表并生成结构化资料与报告；当前历史 CSV 不被覆盖，未来按本标准转换时另行明确。检查报告的输入哈希，确保对应最新工作簿。

## 映射冻结

JSON 映射与导入器保持现状并冻结，不再扩展；新字段的实现须另行评审。
