# LISTING V3 实际运行记录

刷新时间：2026-11-03T02:52:18.991563+08:00。范围为 `work/logs/listing_v3`、`work/logs/whole_photo_v5` 和 `work/diagnostics/whole_photo_v5` 中具有真实 prompt_id 的提交；在跑任务的最终结果以完成后刷新为准。

已记录真实提交 32 次：Q6 推理 31 次；原片恢复/无模型 1 次（不计 Q6 推理）。仅 prepare 的草稿不计提交；技术状态与视觉决定分别列出。既有橙白米粥复用自前轮，不计入本轮新增提交。

| 阶段类型 | 任务 / attempt | prompt_id | Q6 参数：seed / steps / cfg / guidance / sampler | 输出画布 / 采样上下文 | 技术状态 | 原图/选中图视觉状态 | 后端秒 | RSS起 / 止 / 采样峰（字节） | 系统swap起 / 止 / 差 / 采样峰（字节） | 系统压力原始值起 / 止 / 采样峰；critical次数 |
|---|---|---|---|---|---|---|---:|---:|---|---|
| 原片恢复/无模型 | MAIN04_final_restore / MAIN04_final_restore | 999e6f77-9ed2-49e9-b989-c39d28e907d5 | 不适用 / 不适用 / 不适用 / 不适用 / 不适用-不适用 | 1024×1024 / 原片恢复，无模型；无采样上下文 | success_after_exact_recovery | passed | 0.849 | 540229632 / 595460096 / 595460096 | 12716930499 / 12599489987 / -117440512 / 12624655811 | 2 / 1 / 2；0 |
| Q6推理 | BG01_restaurant / BG01_restaurant | 3f645389-db84-4041-a827-bb9e7ab5f41f | 20261102 / 20 / 1.0 / 30.0 / euler-normal | 未记录 / 未记录 | success | visual_rejected | 789.873 | 511082496 / 495222784 / 4214685696 | 3282042880 / 8148609925 / 4866567045 / 8148609925 | 未记录 / 未记录 / 未记录；未记录 |
| Q6推理 | BG01_restaurant_r2 / BG01_restaurant_r2 | 8047039d-86c3-49f6-a8df-5b404dba2274 | 20261112 / 20 / 1.0 / 30.0 / euler-normal | 未记录 / 未记录 | success | 原始visual_rejected；派生visual_rejected | 781.073 | 520667136 / 517996544 / 3451355136 | 7147618304 / 8159955517 / 1012337213 / 8445168189 | 2 / 2 / 2；0 |
| Q6推理 | BG02_dessert_masked / attempt_552885b46ec2a6134a69 | c69715bd-b0f3-4c6f-a934-ef9d93362242 | 20261113 / 20 / 1.0 / 30.0 / euler-normal | 未记录 / 未记录 | success | visual_rejected | 775.508 | 516194304 / 504135680 / 4144218112 | 8366850048 / 10362615235 / 1995765187 / 10773657027 | 2 / 2 / 2；0 |
| Q6推理 | blue_century_pork_congee / attempt_49f76060d60e362fb681 | edebb66a-2b87-4dd1-9337-a33fb2eb1947 | 20261103 / 20 / 1.0 / 30.0 / euler-normal | 未记录 / 未记录 | success | visual_rejected | 781.91 | 509280256 / 736182272 / 4057006080 | 6587741635 / 7569408000 / 981666365 / 7847542784 | 未记录 / 未记录 / 未记录；未记录 |
| Q6推理 | blue_century_pork_congee / attempt_d7cc621e7fe82773273b | 270beabd-1fbe-414b-8778-34555f1f0fd5 | 20261123 / 20 / 1.0 / 30.0 / euler-normal | 未记录 / 未记录 | success | passed | 741.854 | 527925248 / 504856576 / 4155637760 | 8042515005 / 8030582211 / -11932794 / 8142255555 | 2 / 2 / 4；1 |
| Q6推理 | green_corn_rib_soup / attempt_0d41d550ef2a3ab030d3 | 8584b074-58da-4cdd-adc0-89a103374738 | 20261109 / 20 / 1.0 / 30.0 / euler-normal | 未记录 / 未记录 | success | visual_rejected | 795.92 | 525926400 / 497287168 / 3725590528 | 7656639037 / 9375380931 / 1718741894 / 10700843909 | 2 / 2 / 2；0 |
| Q6推理 | green_mungbean / attempt_b633a5e31d62bd93aefa | d564125a-dff3-4e83-a7f1-95fe4df5ef25 | 20261106 / 20 / 1.0 / 30.0 / euler-normal | 未记录 / 未记录 | success | 原始visual_rejected；派生passed | 786.211 | 746422272 / 513032192 / 4094607360 | 6822821888 / 7979013243 / 1156191355 / 8876720128 | 2 / 2 / 2；0 |
| Q6推理 | orange_redbean / attempt_b70a99c549bdc1de37ed | e9b737d2-f50c-49bf-993e-f7d1a80dc65f | 20261107 / 20 / 1.0 / 30.0 / euler-normal | 未记录 / 未记录 | success | passed | 781.097 | 525254656 / 508592128 / 3695362048 | 8045660733 / 9508885627 / 1463224894 / 9937480581 | 2 / 2 / 4；1 |
| Q6推理 | red_fish_congee / attempt_ccba394cd8918359f840 | 30852ace-1e7f-4389-af4c-eacc714c1a8c | 20261105 / 20 / 1.0 / 30.0 / euler-normal | 未记录 / 未记录 | success | passed | 759.69 | 515457024 / 509788160 / 4154998784 | 10094179779 / 8705928069 / -1388251710 / 10085791171 | 2 / 2 / 2；0 |
| Q6推理 | yellow_salted_bone_congee / attempt_9911822d4a1a4bbeb71e | 40037617-f2bc-4062-bb0f-0f5e5e6b7bf7 | 20261124 / 20 / 1.0 / 30.0 / euler-normal | 未记录 / 未记录 | success | passed | 772.369 | 521207808 / 513261568 / 3217113088 | 6696604795 / 9335597957 / 2638993162 / 9335597957 | 2 / 2 / 2；0 |
| Q6推理 | yellow_salted_bone_congee / attempt_b1958f8b2d0a804108b5 | a7f727d7-6ddd-4708-908c-50d2ad043be2 | 20261104 / 20 / 1.0 / 30.0 / euler-normal | 未记录 / 未记录 | success | visual_rejected | 774.981 | 515506176 / 501596160 / 3237265408 | 7002788987 / 9559993221 / 2557204234 / 9559993221 | 2 / 2 / 2；0 |
| Q6推理 | yellow_tremella / attempt_71ff1b58b7a404807b1c | 93d1cd6d-e3fd-4145-8f45-80557401659e | 20261108 / 20 / 1.0 / 30.0 / euler-normal | 未记录 / 未记录 | success | visual_rejected | 777.545 | 518733824 / 515375104 / 3336830976 | 6882129347 / 8986359235 / 2104229888 / 9169209917 | 2 / 2 / 4；1 |
| Q6推理 | yellow_tremella / attempt_b13d4ef8557c304da4ee | 32c01683-ff8a-4c27-b63e-9bae0fe8a172 | 20261125 / 20 / 1.0 / 30.0 / euler-normal | 未记录 / 未记录 | success | visual_rejected | 782.199 | 508280832 / 501268480 / 3314794496 | 7131826749 / 9513467904 / 2381641155 / 9827128443 | 2 / 2 / 4；1 |
| Q6推理 | MAIN01_food_regional_v1 / b7586ff77ad0b3e0e869a9b4 | 71c85f9a-cbfb-4b55-97dd-9f2c5b951623 | 2026112606 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / regional_cropped: 1=320×304, 2=304×320, 3=352×336, 4=368×352 | success | partial_visual_rework | 1327.793 | 246956032 / 506609664 / 3969269760 | 8173524091 / 10996290683 / 2822766592 / 11679888835 | 2 / 2 / 4；1 |
| Q6推理 | MAIN01_pumpkin_crop_v4 / e8802447f0e3bdadba716424 | 8542011e-1f91-4175-934a-a11e0f7fb658 | 2026112646 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / crop_rescaled_1024: x=704, y=240, 320×320 → 采样 1024×1024 | success | passed | 814.764 | 1044824064 / 565297152 / 1052033024 | 12635141571 / 13995868160 / 1360726589 / 13995868160 | 1 / 1 / 2；0 |
| Q6推理 | MAIN01_redbean_crop_v5 / 721447405d56fa27b32c86ba | 3025ebd2-7dea-47bc-bd9e-c003775a9dc2 | 2026112660 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / crop_rescaled_1024: x=416, y=608, 352×352 → 采样 1024×1024 | success | visual_rejected | 848.995 | 579567616 / 531480576 / 3881156608 | 13561359237 / 13685028291 / 123669054 / 14282129408 | 1 / 2 / 2；0 |
| Q6推理 | MAIN02_food_green_repair_v3 / 2686a6c6815cbbf377c5f7d4 | 0bafd79d-fee3-4fb1-b129-1ad6697d33ca | 2026112613 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / regional_cropped: 1=320×304, 2=352×400 | success | passed | 672.505 | 165494784 / 501612544 / 3900604416 | 7505119805 / 10036843643 / 2531723838 / 10644682179 | 2 / 1 / 4；1 |
| Q6推理 | MAIN02_food_regional_v2 / 08cf17f385ee5c4e410f3f28 | edc6e722-68a1-4a3b-b893-5ebf37c447ad | 2026112603 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / regional_cropped: 1=320×304, 2=384×320, 3=368×352, 4=384×368, 5=352×400, 6=416×384, 7=448×432 | success | partial_visual_rework | 2392.898 | 166756352 / 503513088 / 3936174080 | 6390147973 / 10994319360 / 4604171387 / 10994319360 | 2 / 2 / 4；2 |
| Q6推理 | MAIN02_food_whole_photo / 1bf268f129b313bb978a213c | 07e8d709-f7af-4d9c-b120-7f7b172aeddd | 2026112601 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / full_frame_1024 | success | visual_rejected | 865.388 | 165150720 / 532594688 / 3652419584 | 7526804357 / 8500344259 / 973539902 / 10381950976 | 2 / 1 / 4；1 |
| Q6推理 | MAIN02_restaurant_background / 145f1d1dcfa7f9293fbcb04c | aa6e7ef3-12f1-464b-a04f-5af5855e694b | 2026112602 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / full_frame_1024 | success | visual_rejected | 834.001 | 543916032 / 535216128 / 4229021696 | 4821478277 / 10397155328 / 5575677051 / 10434778235 | 1 / 2 / 2；0 |
| Q6推理 | MAIN02_restaurant_background_r2 / f94325f7aac44185a688a83e | 9c28e631-2d6b-4398-9e78-cb20b167b250 | 2026112603 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / full_frame_1024 | success | passed | 1001.442 | 518701056 / 531202048 / 4400267264 | 5724826501 / 11004742205 / 5279915704 / 12531070403 | 1 / 2 / 4；1 |
| Q6推理 | MAIN03_dessert_background_v1 / e7d21c3b0073937485f43a01 | f9724f86-c977-4a9b-9114-8016e05f63c0 | 2026112614 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / full_frame_1024 | success | passed | 962.963 | 164249600 / 586383360 / 2819129344 | 8367238021 / 12609325629 / 4242087608 / 13649513021 | 2 / 2 / 2；0 |
| Q6推理 | MAIN03_food_regional_v1 / e06be0d226c768aa2f58df15 | 125fa8e8-b4fe-41c1-9b6d-9323b3fef68d | 2026112604 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / regional_cropped: 1=320×288, 2=368×352, 3=400×368 | success | partial_visual_rework | 1041.51 | 167198720 / 511475712 / 3908337664 | 7650012037 / 11219438141 / 3569426104 / 11219438141 | 2 / 2 / 4；1 |
| Q6推理 | MAIN03_mango_crop_v5 / da9ca431cbbd6155e82a24fd | af4a74e6-d40b-4f62-94f2-eb68a290a05b | 2026112654 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / crop_rescaled_1024: x=336, y=352, 320×320 → 采样 1024×1024 | success | visual_rejected | 1331.195 | 165675008 / 533315584 / 3102425088 | 7760636805 / 12354846720 / 4594209915 / 12621908541 | 2 / 2 / 4；2 |
| Q6推理 | MAIN03_mango_crop_v6 / 6dacb7ea8e13b1a7f85dc8f8 | 4a8f549e-1302-450d-8c24-0f9dbcc87ed3 | 2026112654 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / crop_rescaled_1024: x=336, y=352, 320×320 → 采样 1024×1024 | success | passed | 1331.409 | 171311104 / 525926400 / 3062906880 | 8372355072 / 12786136515 / 4413781443 / 13268554875 | 2 / 2 / 4；6 |
| Q6推理 | MAIN03_sesame_repair_v2 / 13f5ce3b9e0afe5bc32870a6 | 6f9dfd2e-b5e7-4cd2-8049-0f4427e8f48e | 2026112624 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / regional_cropped: 1=320×288 | success | visual_rework | 342.543 | 168280064 / 614596608 / 3893149696 | 7574388736 / 11133381509 / 3558992773 / 11133381509 | 2 / 2 / 2；0 |
| Q6推理 | MAIN03_sesame_repair_v3 / 3b1f197e9ca7afb704e3bda8 | 2aa41936-f3ae-47bc-880b-77a1c98e12b4 | 2026112634 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / regional_cropped: 1=320×288 | success | visual_rejected | 341.78 | 517750784 / 507625472 / 3993518080 | 7649886208 / 11807164989 / 4157278781 / 11807164989 | 2 / 2 / 2；0 |
| Q6推理 | MAIN03_tremella_global_v4 / 7d8e21e5b5d84dbd4070f2c6 | f9595c70-3b1f-46f8-88fe-e4af2f162a26 | 2026112644 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / full_frame_1024 | success | visual_rejected | 1550.334 | 517079040 / 491126784 / 4130308096 | 5298852987 / 12213351875 / 6914498888 / 12363696701 | 1 / 2 / 4；2 |
| Q6推理 | MAIN04_food_regional_v1 / 5da6b9d0d1ee6c2e80d738f0 | 34ad9fbb-e4c5-4492-a038-85e6e2b68c24 | 2026112605 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / regional_cropped: 1=288×288, 2=304×320, 3=336×304, 4=352×336 | success | partial_visual_rework | 1285.541 | 168493056 / 500236288 / 3994386432 | 8404923843 / 12381711237 / 3976787394 / 12381711237 | 2 / 1 / 4；1 |
| Q6推理 | MAIN04_pumpkin_crop_v3 / bbd50e877c14c508af43438a | 522f7af2-7b2d-4026-9a3f-d60cb8d64e6e | 2026112648 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / crop_rescaled_1024: x=304, y=480, 320×320 → 采样 1024×1024 | success | visual_rejected | 843.195 | 600932352 / 1036468224 / 3875946496 | 11993150915 / 13784580096 / 1791429181 / 14162067456 | 2 / 1 / 2；0 |
| Q6推理 | MAIN04_pumpkin_crop_v4 / e2339ee2428dd94d8a6e1527 | be93554d-9387-4f41-9a66-a2b7ec83ee70 | 2026112654 / 20 / 1.0 / 30.0 / euler-normal | 1024×1024 / crop_rescaled_1024: x=304, y=480, 320×320 → 采样 1024×1024 | success | visual_rejected | 824.216 | 573800448 / 571785216 / 3796598784 | 13349945344 / 13745908613 / 395963269 / 14181990400 | 1 / 1 / 4；1 |

各提交的实际模型名称、压力原始文字、源 result/measurements/history 路径和输出路径见同名 CSV；记录缺失标注“未记录”。输出画布尺寸与采样上下文分开记录：regional_cropped 为各区域裁切上下文，crop_rescaled_1024 为裁切后等比放大采样，full_frame_1024 为整幅上下文；前者耗时不可当作完整1024模型上下文的同等基准。背景 EmptyImage 的尺寸可从对应 submission 图核对。

RSS 为后端进程采样峰值，不是 MPS 总统一内存；MPS allocator/driver峰值未记录。swap 为系统全局数据，并非该进程独占。压力采样也为系统级；原始数字和文字见 CSV 与每次 measurements.json。

原始 BG01 与 BG01_r2 均退回；BG01_r2 的确定性清理派生版本及 BG02_dessert_masked 曾经通过，后因最终场景真实感不合格撤回，当前均为 visual_rejected。旧蓝色皮蛋粥退回，新的蓝色任务以其各自 result 为准。whole_photo 首次全食品图因内容相似退回，首次新背景因额外假碗退回；七区域结果为 partial_visual_rework，后续两绿碗修复以对应任务记录为准。历史证据保留，审核状态不能由技术成功推断。

## 模型哈希与来源

原始模型路径及 SHA-256 依据 `work/diagnostics/model_inventory.json`，每次实际记录有模型哈希时也保留于对应 result.json；不重新推断或改写其来源。

- `/Users/luohuiwu/ComfyUI-Shared/models/text_encoders/t5-v1_1-xxl-encoder-Q5_K_M.gguf`：`b51cbb10b1a7aac6dd1c3b62f0ed908bfd06e0b42d2f3577d43e061361f51dae`
- `/Users/luohuiwu/ComfyUI-Shared/models/text_encoders/clip_l.safetensors`：`660c6f5b1abae9dc498ac2d21e1347d2abdb0cf6c0c0c8576cd796491d9a6cdd`
- `/Users/luohuiwu/ComfyUI-Shared/models/clip/t5-v1_1-xxl-encoder-Q5_K_M.gguf`：`b51cbb10b1a7aac6dd1c3b62f0ed908bfd06e0b42d2f3577d43e061361f51dae`
- `/Users/luohuiwu/ComfyUI-Shared/models/unet/flux1-fill-dev-Q6_K.gguf`：`d538635d81ed5eca59fa2f5a7b68709f0b5584d936570a8695e4d1ae4d518a72`
- `/Users/luohuiwu/ComfyUI-Shared/models/vae/ae.safetensors`：`afc8e28272cd15db3919bacdb6918ce9c1ed22e96cb12c4d5ed0fba823529e38`

## 当前交付状态与历史候选

历史退回素材（未用于当前交付，不构成当前待办）：旧布局引用的 green_corn_rib_soup、yellow_tremella 及旧 BG01/BG02 等候选，保留其提交与退回记录供追溯。

- 最终成品已通过：24/24；依据 manifest 路径、root QA 和当前实拍来源链校验。
当前清单所列最终成品均有文件、审核和有效来源记录。

刷新：使用项目既有 Python 执行 `scripts/summarize_listing_v3.py`。历史任务及失败材料不覆盖。
